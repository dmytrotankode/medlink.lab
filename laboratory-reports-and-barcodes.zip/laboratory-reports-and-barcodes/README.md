# Medlink-LAB — Лабораторна інформаційна система MedLink (LIS 4.0)

> ТОВ «МедЛінк» (MedLink LLC) © 2026. Модуль «Лабораторія» для веб-МІС MedLink (evomis) та автономний ЛІС-продукт.

Технологічний стек повторює MedLink: **.NET 8 Web API + EF Core**, **Quasar v1.15.3 + Vue 2**, база **PostgreSQL** (схема у стилі evomis, міграції EF Core), крос-платформний **коннектор аналізаторів** (.NET 8 Worker Service: ASTM E1394 / HL7 v2 MLLP / текстові протоколи 65 моделей приладів). Вхід користувачів — сервер ідентифікації evomis (`identity-server`, OIDC, клієнт `MisFront`), токен `Authorization: Bearer` і вибір профілю безпеки (`/api/account/*`).

## Склад репозиторію

| Шлях                     | Що це                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `src/MedLink.LIS.Core`     | Спільна бібліотека: клінічні правила (каскад норм Simplex, прапорці, delta-check, автоверифікація, reflex, Вестгард, EUCAST, TAT), штрихкоди (Simplex EAN-8, Code128, ZPL, QR), протоколи аналізаторів (ASTM, HL7, текстові), побудовники замовлень для приладів, каталог 64 типів аналізаторів, DTO протоколу коннектора |
| `src/MedLink.LIS.Api`      | REST API ЛІС (ASP.NET Core 8, EF Core PostgreSQL, Swagger), віддає зібраний фронтенд із `wwwroot`                                                                                                                                                                                                                                                                                                                                                                                         |
| `src/MedLink.LIS.Web`      | Фронтенд Quasar CLI v1 + Vue 2 у структурі `evomis/src/App.View`                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `src/MedLink.LabConnector` | Коннектор аналізаторів (служба Windows / systemd), CLI `setup`, локальна сторінка статусу `http://localhost:5088`                                                                                                                                                                                                                                                                                                                                            |
| `installers/labconnector`  | Inno Setup, PowerShell, Linux systemd/deb, Docker, скрипти публікації                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `tests/MedLink.LIS.Tests`  | xUnit: клінічні правила, протоколи, API                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| `tests/protocol_samples`   | Зразки повідомлень ASTM/HL7/FHIR                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `db/`                      | DDL PostgreSQL для перенесення, довідники, зразкова БД прототипу                                                                                                                                                                                                                                                                                                                                                                                                         |
| `docs/`                    | **ТЗ v4**, реєстр задач, контракт API; `docs/analysis` — архів етапу аналізу (ТЗ v2 замовника, майстер-спека v3, прототипи, скріншоти)                                                                                                                                                                                                                                                                                     |
| `legacy/`                  | Delphi-коннектор AConnectAstm та дамп MySQL Simplex (норми, типи аналізаторів, процедури)                                                                                                                                                                                                                                                                                                                                                                             |
| `tools/legacy_scripts`     | Python-скрипти етапу аналізу (генерація прототипів/документів)                                                                                                                                                                                                                                                                                                                                                                                                     |

## Швидкий старт

```bash
# 0a. Образ сервера ідентифікації (одноразово, якщо його ще немає локально — окремий репозиторій identity-server):
docker build -t medlink-identity-server:local -f docker/backend/Dockerfile .   # з кореня репозиторію identity-server

# 0b. Сервер ідентифікації, Redis, MailHog, lab-db (docker, лише локально) — див. «Вхід користувачів локально».
#     lab-db сам створює БД lis (роль, схема, дані) при першому старті з порожнім volume.
docker compose up -d

# 1. Бекенд (dotnet-ef database update — без ефекту одразу після compose up, оскільки БД lis уже
#    повністю готова; застосовує лише майбутні нові міграції; сідить довідники при першому запуску)
./run.sh            # Windows: .\run.cmd
#    Swagger: http://localhost:5055/swagger   Health: http://localhost:5055/health

# 2. Фронтенд (dev-режим на http://localhost:8085 із проксі /api → :5055)
cd src/MedLink.LIS.Web && npm ci && npm run dev
#    або зібрати в wwwroot API: ./build.sh (Windows: .\build.ps1) → http://localhost:5055

# 3. Тести
dotnet test MedLink.LIS.sln

# 4. Коннектор аналізаторів (на ПК біля приладу)
#    У веб-інтерфейсі: Інтеграції → Аналізатори та коннектори → «Додати коннектор» → ключ інсталяції
dotnet run --project src/MedLink.LabConnector -- setup --server http://lis-server:5055 --install-key <КЛЮЧ>
dotnet run --project src/MedLink.LabConnector -- run
```

Детальні інструкції: `src/MedLink.LIS.Api/README.md`, `src/MedLink.LIS.Web/README.md`, `installers/labconnector/README_UA.md`.

## Вхід користувачів локально

SPA входить через сервер ідентифікації (`oidc-client` 1.7.1, клієнт `MisFront`, `response_type=code` + PKCE,
скоуп `MisFrontScope IdentityApiScope MisApiScope openid offline_access`), після входу `POST /api/account/try-authenticate/`
(один профіль — обирається одразу, кілька — екран вибору → `POST /api/account/authenticate/`). API ЛІС перевіряє
reference-токен через Redis `IDS:*` або introspection клієнтом `MisApiScope`.

Локальна інфраструктура — `docker-compose.yml` (проєкт `medlink-lab`), запуск: `docker compose up -d` у `laboratory/`:

| Сервіс         | Призначення                                                                                                                          |
| -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `identity-server`  | сервер ідентифікації, https://localhost:5001                                                                                 |
| `identity-db`      | Postgres сервера ідентифікації                                                                                              |
| `identity-redis`   | Redis, localhost:6390: активні токени `IDS:ACTIVE_TOKEN:*` / `IDS:TOKEN_BY_HASH:*` і кеш користувача API ЛІС |
| `identity-mailhog` | пошта сервера ідентифікації (MailHog)                                                                                  |
| `lab-db`           | Postgres ЛІС (БД `lis`)                                                                                                          |

Локальна конфігурація сервера ідентифікації — у `docker-compose.yml` (`configs: identity-server-appsettings`). HTTPS-сертифікат
монтується з `${HOME}/.aspnet/https`; перед першим запуском: `dotnet dev-certs https -ep ${HOME}/.aspnet/https/aspnetapp.pfx -p identity-local-cert`.

ЛІС: `./run.sh` → http://localhost:5055; фронтенд у dev-режимі: `npm run dev` → http://localhost:8085.

## Віддалена робота

- **Claude Code (хмара або локально)**: репозиторій містить `CLAUDE.md` і SessionStart-хук `.claude/hooks/session-start.sh`, який ставить .NET 8 та залежності фронтенду; достатньо відкрити сесію на гілці.
- **Docker**: `docker-compose.yml` у корені — лише локальна інфраструктура: вхід (див. вище) і `lab-db` (Postgres 16, порт 5434, БД ЛІС `lis`). API ЛІС запускається `./run.sh`. Коннектор на ПК лабораторії підключається до сервера через `setup --server http://<host>:5055`.

## Документація

- `docs/ТЗ_ЛІС_MedLink_v4.md` — детальне технічне завдання v4 (вимоги, модель даних, API, коннектор, інсталяція, приймання).
- `docs/РЕЄСТР_ЗАДАЧ.md` — задачі, поставлені власником продукту, та їхній статус.
- `docs/API_CONTRACT.md` — контракт REST API, доменної моделі та протоколу коннектора.

## Змінні GitLab CI/CD

`.gitlab-ci.yml` збирає образ `docker/Dockerfile` (API + SPA) і розгортає його. Змінні задаються в Settings → CI/CD → Variables:

| Змінна                                                       | Призначення                                                                                      |
| ------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------- |
| `LAB_RUNNER_TAG`                                                 | тег GitLab Runner для всіх задач                                                             |
| `LAB_TEST_BRANCH`, `LAB_CANDIDATE_BRANCH`, `LAB_PROD_BRANCH` | гілки, з яких збирається образ з тегом `test`, `candidate` і `latest` |
| `GITLAB_DOCKER_REGISTRY`                                         | адреса реєстру образів                                                                  |
| `LAB_REGISTRY_USER`, `GITLAB_CI_TOKEN`                         | користувач і токен реєстру (токен — masked)                                    |
| `LAB_IMAGE_NAME`                                                 | шлях образу в реєстрі, `<група>/<проєкт>/<образ>`                       |
| `LAB_ORIGIN_TEST`, `LAB_ORIGIN_PROD`                           | публічна адреса ЛІС (redirect OIDC у SPA, URL середовища)                       |
| `LAB_OIDC_AUTHORITY_TEST`, `LAB_OIDC_AUTHORITY_PROD`           | адреса сервера ідентифікації для SPA                                           |
| `SSH_KEY_TEST`, `SSH_USER_TEST`, `VM_IPADDRESS_TEST`         | SSH-ключ, користувач і адреса тестового сервера                        |
| `SSH_USER_PROD`, `VM_IPADDRESS_PROD`                           | користувач і адреса прод-сервера (доступ через тестовий)     |
| `LAB_DEPLOY_DIR`                                                 | каталог з `docker-compose.yml` на тестовому сервері                             |
| `LAB_SERVICE_NAME`                                               | сервіс у `docker-compose.yml`; у k8s — deployment `<LAB_SERVICE_NAME>-deployment`              |
| `SONAR_HOST_URL`, `SONAR_TOKEN`, `LAB_SONAR_PROJECT_KEY`     | SonarQube: адреса, токен, ключ проєкту                                                |
