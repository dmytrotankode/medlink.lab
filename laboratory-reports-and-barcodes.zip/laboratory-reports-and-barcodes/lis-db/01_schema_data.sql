-- Full schema + data dump of the working local 'lis' database (pg_dump, includes
-- ownership/grants/RLS policies), plus EF Core migration-history bookkeeping so
-- 'dotnet-ef database update' treats this as already up to date. Regenerate with:
--   docker exec medlink-lab-lab-db-1 pg_dump -U postgres -d lis --no-tablespaces
-- Runs once, on first init of an empty lab-db-data volume (see docker-compose.yml).

--
-- PostgreSQL database dump
--

\restrict YrTKNCfYvO4Zoku2XaA3S7chduxNVbqHez3OQQ60U50WiHG31JKGNnoZOLxcxy2

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hangfire; Type: SCHEMA; Schema: -; Owner: lis_app
--

CREATE SCHEMA hangfire;


ALTER SCHEMA hangfire OWNER TO lis_app;

--
-- Name: aud_event_append_only(); Type: FUNCTION; Schema: public; Owner: lis
--

CREATE FUNCTION public.aud_event_append_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'aud_event is append-only';
END;
$$;


ALTER FUNCTION public.aud_event_append_only() OWNER TO lis;

--
-- Name: lis_current_tenant(); Type: FUNCTION; Schema: public; Owner: lab_migrator
--

CREATE FUNCTION public.lis_current_tenant() RETURNS uuid
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    PERFORM lis_tenant_guard();
    RETURN NULLIF(current_setting('app.tenant_id', true), '')::uuid;
END
$$;


ALTER FUNCTION public.lis_current_tenant() OWNER TO lab_migrator;

--
-- Name: lis_tenant_guard(); Type: FUNCTION; Schema: public; Owner: lab_migrator
--

CREATE FUNCTION public.lis_tenant_guard() RETURNS boolean
    LANGUAGE plpgsql STABLE COST 0.0001
    AS $$
BEGIN
    IF coalesce(current_setting('app.tenant_id', true), '') <> '' THEN
        RETURN true;
    END IF;
    IF coalesce(current_setting('app.user_id', true), '') <> ''
        OR coalesce(current_setting('app.connector_api_key_hash', true), '') <> ''
        OR coalesce(current_setting('app.connector_install_key', true), '') <> ''
        OR coalesce(current_setting('app.verify_token', true), '') <> ''
        OR coalesce(current_setting('app.tenant_enumeration', true), '') <> '' THEN
        RETURN true;
    END IF;
    RAISE EXCEPTION 'app.tenant_id is not set' USING ERRCODE = '42704';
END
$$;


ALTER FUNCTION public.lis_tenant_guard() OWNER TO lab_migrator;

SET default_table_access_method = heap;

--
-- Name: aggregatedcounter; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.aggregatedcounter (
    id bigint NOT NULL,
    key text NOT NULL,
    value bigint NOT NULL,
    expireat timestamp with time zone
);


ALTER TABLE hangfire.aggregatedcounter OWNER TO lis_app;

--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.aggregatedcounter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.aggregatedcounter_id_seq OWNER TO lis_app;

--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.aggregatedcounter_id_seq OWNED BY hangfire.aggregatedcounter.id;


--
-- Name: counter; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.counter (
    id bigint NOT NULL,
    key text NOT NULL,
    value bigint NOT NULL,
    expireat timestamp with time zone
);


ALTER TABLE hangfire.counter OWNER TO lis_app;

--
-- Name: counter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.counter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.counter_id_seq OWNER TO lis_app;

--
-- Name: counter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.counter_id_seq OWNED BY hangfire.counter.id;


--
-- Name: hash; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.hash (
    id bigint NOT NULL,
    key text NOT NULL,
    field text NOT NULL,
    value text,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.hash OWNER TO lis_app;

--
-- Name: hash_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.hash_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.hash_id_seq OWNER TO lis_app;

--
-- Name: hash_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.hash_id_seq OWNED BY hangfire.hash.id;


--
-- Name: job; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.job (
    id bigint NOT NULL,
    stateid bigint,
    statename text,
    invocationdata jsonb NOT NULL,
    arguments jsonb NOT NULL,
    createdat timestamp with time zone NOT NULL,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.job OWNER TO lis_app;

--
-- Name: job_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.job_id_seq OWNER TO lis_app;

--
-- Name: job_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.job_id_seq OWNED BY hangfire.job.id;


--
-- Name: jobparameter; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.jobparameter (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    name text NOT NULL,
    value text,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.jobparameter OWNER TO lis_app;

--
-- Name: jobparameter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.jobparameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.jobparameter_id_seq OWNER TO lis_app;

--
-- Name: jobparameter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.jobparameter_id_seq OWNED BY hangfire.jobparameter.id;


--
-- Name: jobqueue; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.jobqueue (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    queue text NOT NULL,
    fetchedat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.jobqueue OWNER TO lis_app;

--
-- Name: jobqueue_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.jobqueue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.jobqueue_id_seq OWNER TO lis_app;

--
-- Name: jobqueue_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.jobqueue_id_seq OWNED BY hangfire.jobqueue.id;


--
-- Name: list; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.list (
    id bigint NOT NULL,
    key text NOT NULL,
    value text,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.list OWNER TO lis_app;

--
-- Name: list_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.list_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.list_id_seq OWNER TO lis_app;

--
-- Name: list_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.list_id_seq OWNED BY hangfire.list.id;


--
-- Name: lock; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.lock (
    resource text NOT NULL,
    updatecount integer DEFAULT 0 NOT NULL,
    acquired timestamp with time zone
);


ALTER TABLE hangfire.lock OWNER TO lis_app;

--
-- Name: schema; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.schema (
    version integer NOT NULL
);


ALTER TABLE hangfire.schema OWNER TO lis_app;

--
-- Name: server; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.server (
    id text NOT NULL,
    data jsonb,
    lastheartbeat timestamp with time zone NOT NULL,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.server OWNER TO lis_app;

--
-- Name: set; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.set (
    id bigint NOT NULL,
    key text NOT NULL,
    score double precision NOT NULL,
    value text NOT NULL,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.set OWNER TO lis_app;

--
-- Name: set_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.set_id_seq OWNER TO lis_app;

--
-- Name: set_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.set_id_seq OWNED BY hangfire.set.id;


--
-- Name: state; Type: TABLE; Schema: hangfire; Owner: lis_app
--

CREATE TABLE hangfire.state (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    name text NOT NULL,
    reason text,
    createdat timestamp with time zone NOT NULL,
    data jsonb,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.state OWNER TO lis_app;

--
-- Name: state_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: lis_app
--

CREATE SEQUENCE hangfire.state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.state_id_seq OWNER TO lis_app;

--
-- Name: state_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: lis_app
--

ALTER SEQUENCE hangfire.state_id_seq OWNED BY hangfire.state.id;


--
-- Name: aud_event; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.aud_event (
    id uuid NOT NULL,
    tenant_id uuid,
    actor_user_id uuid,
    event_type text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    before jsonb,
    after jsonb,
    pii jsonb,
    actor_display_name text,
    actor_type text DEFAULT 'system'::text NOT NULL,
    correlation_id text,
    ip text
);

ALTER TABLE ONLY public.aud_event FORCE ROW LEVEL SECURITY;


ALTER TABLE public.aud_event OWNER TO lis;

--
-- Name: cmn_enum_record; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.cmn_enum_record (
    id character varying(64) NOT NULL,
    caption text,
    code text,
    enum_type text,
    parent_id character varying(64),
    value_type integer NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.cmn_enum_record OWNER TO lab_migrator;

--
-- Name: cmn_person; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.cmn_person (
    id character varying(64) NOT NULL,
    last_name character varying(100),
    name character varying(100),
    middle_name character varying(100),
    birthday timestamp without time zone,
    gender_id character varying(64),
    ipn character varying(10),
    no_ipn boolean NOT NULL,
    phone character varying(50),
    email character varying(129),
    location character varying(250),
    caption character varying(300),
    description character varying(1000),
    subscribed_to_notifications boolean NOT NULL,
    user_id text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.cmn_person OWNER TO lab_migrator;

--
-- Name: ehd_dictionary; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehd_dictionary (
    id character varying(64) NOT NULL,
    name text,
    is_active boolean NOT NULL,
    code text,
    value text,
    is_own boolean NOT NULL,
    hidden boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.ehd_dictionary OWNER TO lab_migrator;

--
-- Name: ehe_incoming_medical_referral; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehe_incoming_medical_referral (
    id character varying(64) NOT NULL,
    reg_number text,
    reg_date timestamp without time zone NOT NULL,
    caption text,
    tenant_id uuid NOT NULL,
    patient_card_id character varying(64),
    patient_short_name text,
    service_catalog_service_id character varying(64),
    medical_referral_category_id character varying(64) NOT NULL,
    requester_id character varying(64),
    status_id character varying(64) NOT NULL,
    priority_id character varying(64) NOT NULL,
    expiration_date timestamp without time zone,
    ehealth_id character varying(64),
    patient_instruction character varying(2000),
    medical_service_program_id character varying(64),
    processing_status_in_ehealth_id character varying(64),
    take_in_work_date timestamp without time zone,
    complete_date_in_ehealth timestamp without time zone,
    completed_with_item_entity_id character varying(64),
    completed_with_item_entity_name text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.ehe_incoming_medical_referral FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ehe_incoming_medical_referral OWNER TO lab_migrator;

--
-- Name: ehe_medical_referral_category; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehe_medical_referral_category (
    id character varying(64) NOT NULL,
    code text,
    name text,
    ehealth_code text,
    is_used_in_ehealth boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.ehe_medical_referral_category OWNER TO lab_migrator;

--
-- Name: ehe_medical_service_program; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehe_medical_service_program (
    id character varying(64) NOT NULL,
    is_active boolean NOT NULL,
    hidden boolean NOT NULL,
    ehealth_id character varying(64) NOT NULL,
    type_id character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.ehe_medical_service_program OWNER TO lab_migrator;

--
-- Name: ehe_paper_medical_referral; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehe_paper_medical_referral (
    id character varying(64) NOT NULL,
    reg_number text,
    reg_date timestamp without time zone NOT NULL,
    caption text,
    tenant_id uuid NOT NULL,
    patient_card_id character varying(64) NOT NULL,
    requester_employee_name text,
    requester_legal_entity_name text,
    requester_legal_entity_edrpou character varying(50),
    status integer NOT NULL,
    processed_date timestamp without time zone,
    description character varying(3000),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.ehe_paper_medical_referral FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ehe_paper_medical_referral OWNER TO lab_migrator;

--
-- Name: ehe_service_catalog_service; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ehe_service_catalog_service (
    id character varying(64) NOT NULL,
    caption text,
    code text,
    name text,
    is_active boolean NOT NULL,
    is_composition boolean NOT NULL,
    request_allowed boolean NOT NULL,
    medical_referral_category_id character varying(64) NOT NULL,
    ehealth_id character varying(64),
    inserted_at_in_ehealth timestamp without time zone NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);


ALTER TABLE public.ehe_service_catalog_service OWNER TO lab_migrator;

--
-- Name: id_device_token; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_device_token (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    gateway_id uuid NOT NULL,
    prefix text NOT NULL,
    secret_hash text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone
);

ALTER TABLE ONLY public.id_device_token FORCE ROW LEVEL SECURITY;


ALTER TABLE public.id_device_token OWNER TO lis;

--
-- Name: id_invitation; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_invitation (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    email text NOT NULL,
    role_id uuid NOT NULL,
    division_ids uuid[],
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    accepted_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);

ALTER TABLE ONLY public.id_invitation FORCE ROW LEVEL SECURITY;


ALTER TABLE public.id_invitation OWNER TO lis;

--
-- Name: id_membership; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_membership (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);

ALTER TABLE ONLY public.id_membership FORCE ROW LEVEL SECURITY;


ALTER TABLE public.id_membership OWNER TO lis;

--
-- Name: id_membership_division; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_membership_division (
    membership_id uuid NOT NULL,
    division_id uuid NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.id_membership_division FORCE ROW LEVEL SECURITY;


ALTER TABLE public.id_membership_division OWNER TO lis;

--
-- Name: id_membership_role; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_membership_role (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    membership_id uuid NOT NULL,
    role_id uuid NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.id_membership_role FORCE ROW LEVEL SECURITY;


ALTER TABLE public.id_membership_role OWNER TO lis;

--
-- Name: id_permission; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_permission (
    code character varying(64) NOT NULL,
    caption character varying(512) NOT NULL
);


ALTER TABLE public.id_permission OWNER TO lis;

--
-- Name: id_role; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_role (
    id uuid NOT NULL,
    tenant_id uuid,
    name text NOT NULL,
    is_system_role boolean NOT NULL
);


ALTER TABLE public.id_role OWNER TO lis;

--
-- Name: id_role_permission; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_role_permission (
    role_id uuid NOT NULL,
    permission text NOT NULL
);


ALTER TABLE public.id_role_permission OWNER TO lis;

--
-- Name: id_user; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.id_user (
    id uuid NOT NULL,
    sub text NOT NULL,
    email text NOT NULL,
    name text,
    created_at timestamp with time zone NOT NULL,
    default_tenant_id uuid,
    is_platform_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.id_user OWNER TO lis;

--
-- Name: ins_gateway; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.ins_gateway (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    enrollment_code text,
    enrollment_code_expires_at timestamp with time zone,
    enrollment_code_used_at timestamp with time zone
);

ALTER TABLE ONLY public.ins_gateway FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ins_gateway OWNER TO lis;

--
-- Name: int_api_key; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.int_api_key (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    prefix text NOT NULL,
    secret_hash text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone
);

ALTER TABLE ONLY public.int_api_key FORCE ROW LEVEL SECURITY;


ALTER TABLE public.int_api_key OWNER TO lis;

--
-- Name: int_client; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.int_client (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    scopes text[] NOT NULL,
    created_at timestamp with time zone NOT NULL
);

ALTER TABLE ONLY public.int_client FORCE ROW LEVEL SECURITY;


ALTER TABLE public.int_client OWNER TO lis;

--
-- Name: lab_analyzer; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_analyzer (
    id character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    analyzer_type_id integer NOT NULL,
    connector_id character varying(64),
    department_id uuid,
    connection_mode character varying(8) NOT NULL,
    tcp_host character varying(128),
    tcp_port integer,
    is_tcp_server boolean NOT NULL,
    com_port character varying(32),
    baud_rate integer NOT NULL,
    parity character varying(8) NOT NULL,
    data_bits integer NOT NULL,
    stop_bits character varying(16) NOT NULL,
    flow_control character varying(16) NOT NULL,
    file_path character varying(512),
    file_poll_sec integer NOT NULL,
    auto_query_orders boolean NOT NULL,
    is_active boolean NOT NULL,
    is_online boolean NOT NULL,
    last_message_at timestamp without time zone,
    last_error character varying(1024),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_analyzer FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_analyzer OWNER TO lab_migrator;

--
-- Name: lab_analyzer_lockout; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_analyzer_lockout (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64) NOT NULL,
    test_code character varying(64),
    reason character varying(512) NOT NULL,
    qc_result_id character varying(64),
    started_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by_id character varying(64),
    cause character varying(512),
    action character varying(512),
    comment character varying(1024),
    protocol_text text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_analyzer_lockout FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_analyzer_lockout OWNER TO lab_migrator;

--
-- Name: lab_analyzer_message; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_analyzer_message (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64) NOT NULL,
    direction character varying(4) NOT NULL,
    protocol character varying(16) NOT NULL,
    raw_text text NOT NULL,
    parsed_ok boolean NOT NULL,
    received_at timestamp without time zone NOT NULL,
    results_count integer NOT NULL,
    error character varying(1024),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_analyzer_message FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_analyzer_message OWNER TO lab_migrator;

--
-- Name: lab_analyzer_parameter_map; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_analyzer_parameter_map (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64) NOT NULL,
    analyzer_code character varying(64) NOT NULL,
    test_code character varying(64) NOT NULL,
    factor double precision NOT NULL,
    "offset" double precision NOT NULL,
    unit_override character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_analyzer_parameter_map FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_analyzer_parameter_map OWNER TO lab_migrator;

--
-- Name: lab_analyzer_type; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_analyzer_type (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    manufacturer character varying(128),
    category character varying(32) NOT NULL,
    exch_type character varying(16) NOT NULL,
    bop_base64 character varying(64),
    eop_base64 character varying(64),
    control_sum boolean NOT NULL,
    sleep_ms integer NOT NULL,
    full_text boolean NOT NULL,
    order_template character varying(64) NOT NULL,
    parser_kind character varying(64) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_analyzer_type FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_analyzer_type OWNER TO lab_migrator;

--
-- Name: lab_antibiotic; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_antibiotic (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    group_name character varying(128) NOT NULL,
    atc_code character varying(16),
    eucast_code character varying(32),
    default_disk_content_mcg double precision,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_antibiotic FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_antibiotic OWNER TO lab_migrator;

--
-- Name: lab_archive_cell; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_archive_cell (
    id character varying(64) NOT NULL,
    rack_id character varying(64) NOT NULL,
    row_num integer NOT NULL,
    col_num integer NOT NULL,
    sample_id character varying(64),
    barcode character varying(32),
    stored_at timestamp without time zone,
    stored_by_id character varying(64),
    expiry_at timestamp without time zone,
    is_disposed boolean NOT NULL,
    disposed_at timestamp without time zone,
    disposal_reason character varying(256),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_archive_cell FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_archive_cell OWNER TO lab_migrator;

--
-- Name: lab_archive_rack; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_archive_rack (
    id character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    room_number character varying(64),
    freezer_name character varying(128),
    shelf_number character varying(32),
    temperature_celsius double precision NOT NULL,
    rows_count integer NOT NULL,
    cols_count integer NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_archive_rack FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_archive_rack OWNER TO lab_migrator;

--
-- Name: lab_audit_log; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_audit_log (
    id character varying(64) NOT NULL,
    user_id character varying(64),
    user_name character varying(256),
    action character varying(64) NOT NULL,
    entity character varying(64) NOT NULL,
    entity_id character varying(64),
    before_json text,
    after_json text,
    at timestamp without time zone NOT NULL,
    ip character varying(64),
    comment character varying(512),
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_audit_log FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_audit_log OWNER TO lab_migrator;

--
-- Name: lab_biomaterial_type; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_biomaterial_type (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    default_container character varying(128),
    stability_hours integer NOT NULL,
    temperature_regime character varying(32) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_biomaterial_type FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_biomaterial_type OWNER TO lab_migrator;

--
-- Name: lab_connector_command; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_connector_command (
    id character varying(64) NOT NULL,
    connector_id character varying(64) NOT NULL,
    type character varying(32) NOT NULL,
    payload text,
    is_delivered boolean NOT NULL,
    delivered_at timestamp without time zone,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_connector_command FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_connector_command OWNER TO lab_migrator;

--
-- Name: lab_connector_installation; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_connector_installation (
    id character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    host_name character varying(128),
    os_description character varying(256),
    version character varying(64),
    install_key character varying(64) NOT NULL,
    install_key_used boolean NOT NULL,
    api_key_hash character varying(128),
    status character varying(16) NOT NULL,
    last_heartbeat_at timestamp without time zone,
    registered_at timestamp without time zone,
    buffered_count integer NOT NULL,
    uptime_sec bigint NOT NULL,
    config_version integer NOT NULL,
    poll_interval_sec integer NOT NULL,
    heartbeat_interval_sec integer NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_connector_installation FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_connector_installation OWNER TO lab_migrator;

--
-- Name: lab_connector_log; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_connector_log (
    id character varying(64) NOT NULL,
    connector_id character varying(64) NOT NULL,
    at timestamp without time zone NOT NULL,
    level character varying(16) NOT NULL,
    message text NOT NULL,
    analyzer_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_connector_log FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_connector_log OWNER TO lab_migrator;

--
-- Name: lab_culture_order; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_culture_order (
    id character varying(64) NOT NULL,
    order_test_id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    specimen_locus character varying(128),
    incubation_start timestamp without time zone NOT NULL,
    incubation_hours_recommended integer NOT NULL,
    culture_medium character varying(128) NOT NULL,
    growth_detected boolean,
    growth_intensity character varying(16),
    cfu_per_ml character varying(64),
    preliminary_report text,
    final_microscopy_description text,
    status character varying(16) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_culture_order FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_culture_order OWNER TO lab_migrator;

--
-- Name: lab_ehealth_exchange_log; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_ehealth_exchange_log (
    id character varying(64) NOT NULL,
    mode character varying(8) NOT NULL,
    method character varying(8) NOT NULL,
    url character varying(512) NOT NULL,
    request_json text,
    status_code integer,
    response_json text,
    duration_ms integer NOT NULL,
    at timestamp without time zone NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_ehealth_exchange_log FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_ehealth_exchange_log OWNER TO lab_migrator;

--
-- Name: lab_employee_settings; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_employee_settings (
    employee_id character varying(64) NOT NULL,
    lab_role character varying(32) NOT NULL,
    position_name character varying(256),
    digital_signature_cert_id character varying(128),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_employee_settings FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_employee_settings OWNER TO lab_migrator;

--
-- Name: lab_eucast_breakpoint; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_eucast_breakpoint (
    id character varying(64) NOT NULL,
    organism_id integer NOT NULL,
    antibiotic_id integer NOT NULL,
    eucast_version character varying(32) NOT NULL,
    mic_susceptible_le double precision,
    mic_resistant_gt double precision,
    zone_susceptible_ge double precision,
    zone_resistant_lt double precision,
    intrinsic_resistance boolean NOT NULL,
    guidance_notes text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_eucast_breakpoint FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_eucast_breakpoint OWNER TO lab_migrator;

--
-- Name: lab_invoice; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_invoice (
    id character varying(64) NOT NULL,
    number character varying(32) NOT NULL,
    payer_id character varying(64) NOT NULL,
    order_id character varying(64),
    period_from timestamp without time zone,
    period_to timestamp without time zone,
    amount numeric(18,2) NOT NULL,
    status character varying(16) NOT NULL,
    issued_at timestamp without time zone NOT NULL,
    paid_at timestamp without time zone,
    charge_ids_json text NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_invoice FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_invoice OWNER TO lab_migrator;

--
-- Name: lab_isolate; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_isolate (
    id character varying(64) NOT NULL,
    culture_order_id character varying(64) NOT NULL,
    isolate_number integer NOT NULL,
    organism_id integer NOT NULL,
    quantitative_count character varying(64),
    is_clinically_significant boolean NOT NULL,
    colony_morphology text,
    resistance_phenotypes character varying(128),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_isolate FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_isolate OWNER TO lab_migrator;

--
-- Name: lab_method_type; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_method_type (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_method_type FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_method_type OWNER TO lab_migrator;

--
-- Name: lab_micro_organism; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_micro_organism (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    latin_name character varying(256) NOT NULL,
    common_name character varying(256),
    kingdom character varying(16) NOT NULL,
    gram_stain character varying(16),
    morphology character varying(32),
    is_pathogen boolean NOT NULL,
    is_opportunistic boolean NOT NULL,
    alert_critical_organism boolean NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_micro_organism FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_micro_organism OWNER TO lab_migrator;

--
-- Name: lab_numerator; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_numerator (
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    mask character varying(64) NOT NULL,
    reset_by_period boolean NOT NULL,
    modified_on timestamp without time zone,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_numerator FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_numerator OWNER TO lab_migrator;

--
-- Name: lab_order; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order (
    id character varying(64) NOT NULL,
    order_number character varying(32) NOT NULL,
    patient_id character varying(64) NOT NULL,
    doctor_id character varying(64),
    department_id uuid,
    order_datetime timestamp without time zone NOT NULL,
    status character varying(32) NOT NULL,
    is_urgent_cito boolean NOT NULL,
    ehealth_referral_id character varying(64),
    clinical_notes text,
    is_pregnant boolean NOT NULL,
    pregnancy_week integer,
    menstrual_phase character varying(32),
    icd10_code character varying(16),
    total_price numeric(18,2) NOT NULL,
    created_by_id character varying(64),
    completed_at timestamp without time zone,
    released_at timestamp without time zone,
    released_by_id character varying(64),
    verify_token character varying(128),
    cancel_reason character varying(512),
    repeat_of_order_id character varying(64),
    referral_type character varying(16) NOT NULL,
    paper_referral_id character varying(64),
    referrer_organization_name character varying(256),
    referrer_organization_edrpou character varying(16),
    referrer_doctor_name character varying(256),
    referrer_number character varying(64),
    payer_id character varying(64),
    patient_insurance_id character varying(64),
    insurance_policy_number character varying(64),
    authorization_number character varying(64),
    payer_amount numeric(18,2) NOT NULL,
    patient_amount numeric(18,2) NOT NULL,
    paid_amount numeric(18,2) NOT NULL,
    tenant_id uuid NOT NULL,
    diagnostic_report_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    requester_id uuid
);

ALTER TABLE ONLY public.lab_order FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order OWNER TO lab_migrator;

--
-- Name: lab_order_attachment; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order_attachment (
    id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    send_out_id character varying(64),
    performer_id character varying(64),
    kind character varying(32) NOT NULL,
    file_name character varying(256) NOT NULL,
    content_type character varying(128) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    content bytea NOT NULL,
    visible_to_patient boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_order_attachment FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order_attachment OWNER TO lab_migrator;

--
-- Name: lab_order_charge; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order_charge (
    id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    profile_id character varying(64),
    test_id character varying(64),
    package_id character varying(64),
    code character varying(64) NOT NULL,
    name character varying(512) NOT NULL,
    payer_id character varying(64) NOT NULL,
    payer_kind character varying(16) NOT NULL,
    price_list_id character varying(64),
    amount numeric(18,2) NOT NULL,
    payer_amount numeric(18,2) NOT NULL,
    patient_amount numeric(18,2) NOT NULL,
    is_not_covered boolean NOT NULL,
    is_patient_choice boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_order_charge FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order_charge OWNER TO lab_migrator;

--
-- Name: lab_order_favorite; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order_favorite (
    id character varying(64) NOT NULL,
    employee_id character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    profile_ids_json text NOT NULL,
    test_ids_json text NOT NULL,
    display_order integer NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_order_favorite FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order_favorite OWNER TO lab_migrator;

--
-- Name: lab_order_sample; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order_sample (
    id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    barcode character varying(32) NOT NULL,
    tube_type_id integer NOT NULL,
    biomaterial_type_id integer NOT NULL,
    group_numb integer NOT NULL,
    plan_reasons character varying(128),
    parent_sample_id character varying(64),
    derivation_type character varying(16) NOT NULL,
    derivation_index integer NOT NULL,
    container_type character varying(64),
    lab_section_id character varying(64),
    current_stage character varying(32),
    status character varying(32) NOT NULL,
    collected_at timestamp without time zone,
    collected_by_id character varying(64),
    received_at timestamp without time zone,
    received_by_id character varying(64),
    volume_ml double precision,
    is_hemolyzed boolean NOT NULL,
    is_lipemic boolean NOT NULL,
    is_icteric boolean NOT NULL,
    is_clotted boolean NOT NULL,
    is_insufficient_volume boolean NOT NULL,
    reject_reason character varying(512),
    collect_checklist_json text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_order_sample FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order_sample OWNER TO lab_migrator;

--
-- Name: lab_order_test; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_order_test (
    id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    sample_id character varying(64),
    profile_id character varying(64),
    test_id character varying(64) NOT NULL,
    test_code character varying(64) NOT NULL,
    test_name character varying(256) NOT NULL,
    status character varying(32) NOT NULL,
    assigned_analyzer_id character varying(64),
    is_reflex boolean NOT NULL,
    reflex_from_test_id character varying(64),
    reflex_needs_confirmation boolean NOT NULL,
    reject_reason character varying(512),
    display_order integer NOT NULL,
    released_at timestamp without time zone,
    performer_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_order_test FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_order_test OWNER TO lab_migrator;

--
-- Name: lab_panic_call; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_panic_call (
    id character varying(64) NOT NULL,
    result_id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    patient_name character varying(256) NOT NULL,
    test_code character varying(64) NOT NULL,
    value character varying(64) NOT NULL,
    doctor_notified_name character varying(256) NOT NULL,
    phone character varying(32) NOT NULL,
    department character varying(256),
    readback_confirmed boolean NOT NULL,
    notified_by_id character varying(64) NOT NULL,
    notified_at timestamp without time zone NOT NULL,
    comments character varying(1024),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_panic_call FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_panic_call OWNER TO lab_migrator;

--
-- Name: lab_patient_notification; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_patient_notification (
    id character varying(64) NOT NULL,
    patient_id character varying(64) NOT NULL,
    order_id character varying(64),
    channel character varying(16) NOT NULL,
    payload text NOT NULL,
    status character varying(16) NOT NULL,
    sent_at timestamp without time zone,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_patient_notification FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_patient_notification OWNER TO lab_migrator;

--
-- Name: lab_payer; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_payer (
    id character varying(64) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    kind character varying(16) NOT NULL,
    organization_name character varying(256),
    edrpou character varying(16),
    contract_number character varying(64),
    contract_date timestamp without time zone,
    contract_valid_to timestamp without time zone,
    price_list_id character varying(64),
    coverage_pct numeric(18,2) NOT NULL,
    franchise_amount numeric(18,2) NOT NULL,
    requires_policy boolean NOT NULL,
    requires_authorization boolean NOT NULL,
    medical_program_id character varying(64),
    medlink_contract_id character varying(64),
    contact_person character varying(256),
    phone character varying(64),
    email character varying(128),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_payer FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_payer OWNER TO lab_migrator;

--
-- Name: lab_payment; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_payment (
    id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    amount numeric(18,2) NOT NULL,
    method character varying(16) NOT NULL,
    receipt_number character varying(32) NOT NULL,
    paid_at timestamp without time zone NOT NULL,
    cashier_id character varying(64),
    note character varying(512),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_payment FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_payment OWNER TO lab_migrator;

--
-- Name: lab_performer; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_performer (
    id character varying(64) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    kind character varying(16) NOT NULL,
    exchange_mode character varying(16) NOT NULL,
    medlink_provider character varying(32),
    edrpou character varying(16),
    license_number character varying(128),
    address character varying(512),
    phone character varying(64),
    email character varying(128),
    contract_number character varying(128),
    contract_date timestamp without time zone,
    default_tat_hours integer NOT NULL,
    report_note character varying(512),
    department_id uuid,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_performer FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_performer OWNER TO lab_migrator;

--
-- Name: lab_performer_test; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_performer_test (
    id character varying(64) NOT NULL,
    performer_id character varying(64) NOT NULL,
    test_id character varying(64) NOT NULL,
    external_code character varying(64),
    external_name character varying(256),
    cost numeric(18,2),
    tat_hours integer,
    is_default_route boolean NOT NULL,
    specimen_requirements character varying(512),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_performer_test FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_performer_test OWNER TO lab_migrator;

--
-- Name: lab_price_list; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_price_list (
    id character varying(64) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    is_default boolean NOT NULL,
    currency character varying(3) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_price_list FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_price_list OWNER TO lab_migrator;

--
-- Name: lab_price_list_item; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_price_list_item (
    id character varying(64) NOT NULL,
    price_list_id character varying(64) NOT NULL,
    profile_id character varying(64),
    test_id character varying(64),
    price numeric(18,2) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_price_list_item FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_price_list_item OWNER TO lab_migrator;

--
-- Name: lab_price_package; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_price_package (
    id character varying(64) NOT NULL,
    price_list_id character varying(64) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    price numeric(18,2) NOT NULL,
    member_ids_json text NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_price_package FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_price_package OWNER TO lab_migrator;

--
-- Name: lab_qc_material; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_qc_material (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    level character varying(16) NOT NULL,
    lot_number character varying(64) NOT NULL,
    manufacturer character varying(128),
    expiry_date timestamp without time zone NOT NULL,
    opened_at timestamp without time zone,
    open_stability_days integer NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_qc_material FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_qc_material OWNER TO lab_migrator;

--
-- Name: lab_qc_result; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_qc_result (
    id character varying(64) NOT NULL,
    qc_material_id character varying(64) NOT NULL,
    analyzer_id character varying(64) NOT NULL,
    test_code character varying(64) NOT NULL,
    measured_value double precision NOT NULL,
    target_mean double precision NOT NULL,
    target_sd double precision NOT NULL,
    z_score double precision NOT NULL,
    violated_rules_json text NOT NULL,
    is_warning boolean NOT NULL,
    is_rejection boolean NOT NULL,
    lockout_enforced boolean NOT NULL,
    lockout_id character varying(64),
    resolved_by_id character varying(64),
    resolved_at timestamp without time zone,
    resolution_action character varying(512),
    run_at timestamp without time zone NOT NULL,
    operator_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_qc_result FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_qc_result OWNER TO lab_migrator;

--
-- Name: lab_qc_target; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_qc_target (
    id character varying(64) NOT NULL,
    qc_material_id character varying(64) NOT NULL,
    test_code character varying(64) NOT NULL,
    target_mean double precision NOT NULL,
    target_sd double precision NOT NULL,
    unit character varying(64),
    tea_pct double precision,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_qc_target FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_qc_target OWNER TO lab_migrator;

--
-- Name: lab_reagent_lot; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_reagent_lot (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64),
    test_code character varying(64),
    reagent_name character varying(256) NOT NULL,
    lot_number character varying(64) NOT NULL,
    manufacturer character varying(128),
    tests_initial integer NOT NULL,
    tests_remaining integer NOT NULL,
    minimum_tests integer NOT NULL,
    expiry_date timestamp without time zone NOT NULL,
    opened_at timestamp without time zone,
    onboard_stability_days integer,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_reagent_lot FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_reagent_lot OWNER TO lab_migrator;

--
-- Name: lab_reference_layer; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_reference_layer (
    id character varying(64) NOT NULL,
    test_id character varying(64),
    test_code character varying(64) NOT NULL,
    method_code character varying(64),
    method_name character varying(256),
    layer_type character varying(32) NOT NULL,
    priority_order integer NOT NULL,
    norm_name character varying(256) NOT NULL,
    gender character varying(8) NOT NULL,
    is_gender boolean NOT NULL,
    age_unit character varying(8) NOT NULL,
    age_from double precision NOT NULL,
    age_to double precision NOT NULL,
    is_age boolean NOT NULL,
    is_menstrual_phase boolean NOT NULL,
    menstrual_phase character varying(32),
    is_pregnancy boolean NOT NULL,
    pregnancy_week_from integer,
    pregnancy_week_to integer,
    icd10_code character varying(16),
    norm_low double precision,
    norm_high double precision,
    crit_low double precision,
    crit_high double precision,
    norm_text text,
    unit character varying(64),
    delta_check_max_pct double precision,
    analyzer_code character varying(64),
    dilution double precision,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_reference_layer FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_reference_layer OWNER TO lab_migrator;

--
-- Name: lab_reflex_rule; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_reflex_rule (
    id character varying(64) NOT NULL,
    trigger_test_code character varying(64) NOT NULL,
    condition_operator character varying(16) NOT NULL,
    threshold_value double precision,
    reflex_test_code character varying(64) NOT NULL,
    auto_approve boolean NOT NULL,
    requires_same_sample boolean NOT NULL,
    description character varying(512),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_reflex_rule FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_reflex_rule OWNER TO lab_migrator;

--
-- Name: lab_result_history; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_result_history (
    id character varying(64) NOT NULL,
    order_test_id character varying(64) NOT NULL,
    result_id character varying(64) NOT NULL,
    version integer NOT NULL,
    action character varying(32) NOT NULL,
    numeric_value double precision,
    string_value character varying(512),
    flag character varying(16),
    actor_id character varying(64),
    at timestamp without time zone NOT NULL,
    comment character varying(1024),
    snapshot_json text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_result_history FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_result_history OWNER TO lab_migrator;

--
-- Name: lab_sample_logistics; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_sample_logistics (
    id character varying(64) NOT NULL,
    manifest_number character varying(64) NOT NULL,
    origin_department_id uuid NOT NULL,
    destination_department_id uuid NOT NULL,
    courier_name character varying(128),
    courier_phone character varying(32),
    dispatched_at timestamp without time zone,
    dispatched_by_id character varying(64),
    temperature_dispatch double precision,
    received_at timestamp without time zone,
    received_by_id character varying(64),
    temperature_receipt double precision,
    is_cold_chain_violated boolean NOT NULL,
    status character varying(16) NOT NULL,
    notes text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_sample_logistics FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_sample_logistics OWNER TO lab_migrator;

--
-- Name: lab_sample_logistics_item; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_sample_logistics_item (
    id character varying(64) NOT NULL,
    logistics_id character varying(64) NOT NULL,
    sample_id character varying(64) NOT NULL,
    barcode character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_sample_logistics_item FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_sample_logistics_item OWNER TO lab_migrator;

--
-- Name: lab_sample_stage_event; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_sample_stage_event (
    id character varying(64) NOT NULL,
    sample_id character varying(64) NOT NULL,
    stage_code character varying(32) NOT NULL,
    at timestamp without time zone NOT NULL,
    by_id character varying(64),
    note character varying(1024),
    temperature double precision,
    instrument_id character varying(64),
    data_json text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_sample_stage_event FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_sample_stage_event OWNER TO lab_migrator;

--
-- Name: lab_section; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_section (
    id character varying(64) NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    section_type character varying(32) NOT NULL,
    department_id uuid,
    journal_mask character varying(64) NOT NULL,
    journal_reset_period character varying(8) NOT NULL,
    secondary_mask character varying(64),
    auto_release_verified boolean NOT NULL,
    workflow_template_code character varying(32) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_section FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_section OWNER TO lab_migrator;

--
-- Name: lab_section_journal_entry; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_section_journal_entry (
    id character varying(64) NOT NULL,
    lab_section_id character varying(64) NOT NULL,
    order_id character varying(64) NOT NULL,
    sample_id character varying(64),
    order_test_ids_json text NOT NULL,
    journal_number character varying(64) NOT NULL,
    sequence_value bigint NOT NULL,
    day_number integer NOT NULL,
    secondary_number character varying(64),
    period_key character varying(16) NOT NULL,
    registered_at timestamp without time zone NOT NULL,
    registered_by_id character varying(64),
    status character varying(16) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_section_journal_entry FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_section_journal_entry OWNER TO lab_migrator;

--
-- Name: lab_send_out; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_send_out (
    id character varying(64) NOT NULL,
    number character varying(32) NOT NULL,
    performer_id character varying(64) NOT NULL,
    status character varying(16) NOT NULL,
    external_batch_number character varying(64),
    courier_name character varying(128),
    temperature_dispatch double precision,
    dispatched_at timestamp without time zone,
    dispatched_by_id character varying(64),
    accepted_at timestamp without time zone,
    completed_at timestamp without time zone,
    notes text,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_send_out FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_send_out OWNER TO lab_migrator;

--
-- Name: lab_send_out_item; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_send_out_item (
    id character varying(64) NOT NULL,
    send_out_id character varying(64) NOT NULL,
    order_test_id character varying(64) NOT NULL,
    sample_id character varying(64),
    external_order_number character varying(64),
    external_code character varying(64),
    status character varying(16) NOT NULL,
    due_at timestamp without time zone,
    result_received_at timestamp without time zone,
    reject_reason character varying(512),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_send_out_item FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_send_out_item OWNER TO lab_migrator;

--
-- Name: lab_settings; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_settings (
    id character varying(64) NOT NULL,
    director_name character varying(256),
    working_hours character varying(128),
    order_number_mask character varying(64) NOT NULL,
    barcode_prefix character varying(16),
    report_footer text,
    panic_phone character varying(32),
    cold_chain_min_c double precision NOT NULL,
    cold_chain_max_c double precision NOT NULL,
    label_printer_host character varying(128),
    label_printer_port integer NOT NULL,
    label_printer_name character varying(128),
    report_templates_json text NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_settings FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_settings OWNER TO lab_migrator;

--
-- Name: lab_susceptibility_result; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_susceptibility_result (
    id character varying(64) NOT NULL,
    isolate_id character varying(64) NOT NULL,
    antibiotic_id integer NOT NULL,
    method character varying(32) NOT NULL,
    zone_diameter_mm double precision,
    mic_value_mg_l double precision,
    interpretation character varying(4) NOT NULL,
    is_intrinsic_resistance boolean NOT NULL,
    breakpoint_id character varying(64),
    override_reason character varying(512),
    overridden_by_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_susceptibility_result FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_susceptibility_result OWNER TO lab_migrator;

--
-- Name: lab_test_definition; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_test_definition (
    id character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    short_name character varying(64),
    loinc_code character varying(32),
    unit character varying(64) NOT NULL,
    decimal_places integer NOT NULL,
    result_type character varying(16) NOT NULL,
    dropdown_options_json text,
    formula text,
    category character varying(64) NOT NULL,
    biomaterial_type_id integer NOT NULL,
    tube_type_id integer,
    method_id integer,
    method_code character varying(64),
    lab_section_id character varying(64),
    delta_check_max_pct double precision,
    delta_check_hours integer NOT NULL,
    requires_manual_verification boolean NOT NULL,
    is_qc_tracked boolean NOT NULL,
    requires_separate_tube boolean NOT NULL,
    max_tests_per_tube integer,
    required_volume_ml double precision,
    tube_compatibility_group character varying(32),
    price numeric(18,2) NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_test_definition FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_test_definition OWNER TO lab_migrator;

--
-- Name: lab_test_profile; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_test_profile (
    id character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(512) NOT NULL,
    category character varying(128) NOT NULL,
    turnaround_hours integer NOT NULL,
    fasting_required boolean NOT NULL,
    price numeric(18,2) NOT NULL,
    default_biomaterial_type_id integer,
    default_tube_type_id integer,
    organization_service_id character varying(64),
    ehealth_service_catalog_service_id character varying(64),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_test_profile FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_test_profile OWNER TO lab_migrator;

--
-- Name: lab_test_profile_item; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_test_profile_item (
    id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    test_id character varying(64) NOT NULL,
    display_order integer NOT NULL,
    is_required boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_test_profile_item FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_test_profile_item OWNER TO lab_migrator;

--
-- Name: lab_test_result; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_test_result (
    id character varying(64) NOT NULL,
    order_test_id character varying(64) NOT NULL,
    numeric_value double precision,
    string_value character varying(512),
    unit character varying(64),
    norm_low double precision,
    norm_high double precision,
    crit_low double precision,
    crit_high double precision,
    reference_display character varying(256) NOT NULL,
    flag character varying(16) NOT NULL,
    applied_layer_id character varying(64),
    applied_layer_name character varying(256),
    delta_percent double precision,
    delta_alert boolean NOT NULL,
    previous_value double precision,
    previous_at timestamp without time zone,
    analyzer_id character varying(64),
    analyzer_flags character varying(64),
    raw_message_id character varying(64),
    is_auto_verified boolean NOT NULL,
    auto_verify_block_reason character varying(512),
    verified_by_id character varying(64),
    verified_at timestamp without time zone,
    verification_comment character varying(1024),
    operator_comment character varying(1024),
    report_text text,
    entered_by_id character varying(64),
    entered_at timestamp without time zone NOT NULL,
    measured_at timestamp without time zone,
    version integer NOT NULL,
    performer_id character varying(64),
    external_reference character varying(128),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_test_result FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_test_result OWNER TO lab_migrator;

--
-- Name: lab_tube_type; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_tube_type (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(256) NOT NULL,
    color_code character varying(16) NOT NULL,
    anticoagulant character varying(128),
    volume_ml double precision NOT NULL,
    order_of_draw_index integer NOT NULL,
    inversions_count integer NOT NULL,
    usable_volume_ml double precision,
    max_tests_per_tube integer,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_tube_type FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_tube_type OWNER TO lab_migrator;

--
-- Name: lab_unmatched_result; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_unmatched_result (
    id character varying(64) NOT NULL,
    analyzer_id character varying(64),
    barcode character varying(64) NOT NULL,
    analyzer_code character varying(64) NOT NULL,
    value character varying(128) NOT NULL,
    unit character varying(64),
    flags character varying(64),
    measured_at timestamp without time zone,
    raw_message_id character varying(64),
    reason character varying(512) NOT NULL,
    is_linked boolean NOT NULL,
    linked_order_test_id character varying(64),
    received_at timestamp without time zone NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_unmatched_result FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_unmatched_result OWNER TO lab_migrator;

--
-- Name: lab_workflow_template; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_workflow_template (
    code character varying(32) NOT NULL,
    name character varying(256) NOT NULL,
    stages_json text NOT NULL,
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_workflow_template FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_workflow_template OWNER TO lab_migrator;

--
-- Name: lab_worklist_batch; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.lab_worklist_batch (
    id character varying(64) NOT NULL,
    batch_code character varying(64) NOT NULL,
    analyzer_id character varying(64),
    status character varying(16) NOT NULL,
    created_by_id character varying(64),
    items_json text NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.lab_worklist_batch FORCE ROW LEVEL SECURITY;


ALTER TABLE public.lab_worklist_batch OWNER TO lab_migrator;

--
-- Name: mis_diagnostic_report; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.mis_diagnostic_report (
    id character varying(64) NOT NULL,
    reg_number text,
    reg_date timestamp without time zone NOT NULL,
    caption text,
    status integer NOT NULL,
    patient_card_id character varying(64),
    tenant_id uuid NOT NULL,
    legal_entity_id character varying(64) NOT NULL,
    division_id character varying(64) NOT NULL,
    document_type_id character varying(64) NOT NULL,
    ehealth_service_catalog_service_id character varying(64) NOT NULL,
    ehealth_incoming_medical_referral_id character varying(64),
    diagnostic_report_category_id character varying(64),
    description character varying(3000),
    comment text,
    effective_date_time_start timestamp without time zone,
    effective_date_time_end timestamp without time zone,
    issued_at timestamp without time zone,
    performer_id character varying(64),
    performer_string text,
    is_performer_string boolean NOT NULL,
    recorded_by_id character varying(64),
    ehealth_id character varying(64),
    is_primary_source boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.mis_diagnostic_report FORCE ROW LEVEL SECURITY;


ALTER TABLE public.mis_diagnostic_report OWNER TO lab_migrator;

--
-- Name: mis_patient_insurance; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.mis_patient_insurance (
    id character varying(64) NOT NULL,
    patient_card_id character varying(64) NOT NULL,
    payer_id character varying(64) NOT NULL,
    policy_number character varying(64) NOT NULL,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    note character varying(512),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.mis_patient_insurance FORCE ROW LEVEL SECURITY;


ALTER TABLE public.mis_patient_insurance OWNER TO lab_migrator;

--
-- Name: ord_order_identifier; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.ord_order_identifier (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    order_id character varying(64) NOT NULL,
    system character varying(128) NOT NULL,
    value character varying(256) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.ord_order_identifier FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ord_order_identifier OWNER TO lis;

--
-- Name: ord_patient; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.ord_patient (
    id character varying(64) NOT NULL,
    last_name character varying(100),
    name character varying(100),
    middle_name character varying(100),
    caption character varying(300),
    birthday timestamp without time zone,
    gender_id character varying(64),
    ipn character varying(10),
    phone character varying(50),
    email character varying(129),
    location character varying(250),
    last_name_latin character varying(100),
    first_name_latin character varying(100),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL,
    sex character varying(8) DEFAULT 'unknown'::character varying NOT NULL
);

ALTER TABLE ONLY public.ord_patient FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ord_patient OWNER TO lab_migrator;

--
-- Name: ord_patient_identifier; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.ord_patient_identifier (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    patient_id character varying(64) NOT NULL,
    system character varying(128) NOT NULL,
    value character varying(256) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.ord_patient_identifier FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ord_patient_identifier OWNER TO lis;

--
-- Name: ord_patient_insurance; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.ord_patient_insurance (
    id uuid NOT NULL,
    patient_card_id character varying(64) NOT NULL,
    payer_id character varying(64) NOT NULL,
    policy_number character varying(64) NOT NULL,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    note character varying(512),
    is_active boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    tenant_id uuid NOT NULL
);

ALTER TABLE ONLY public.ord_patient_insurance FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ord_patient_insurance OWNER TO lis;

--
-- Name: ord_requester; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.ord_requester (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(256) NOT NULL,
    organization character varying(256),
    identifiers jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.ord_requester FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ord_requester OWNER TO lis;

--
-- Name: org_employee; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.org_employee (
    id character varying(64) NOT NULL,
    caption text,
    person_id character varying(64) NOT NULL,
    tenant_id uuid NOT NULL,
    department_id uuid,
    department_section_id character varying(64),
    position_type_id character varying(64) NOT NULL,
    working_start_date timestamp without time zone,
    has_schedule_with_partner boolean NOT NULL,
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL,
    membership_id uuid GENERATED ALWAYS AS ((id)::uuid) STORED NOT NULL
);

ALTER TABLE ONLY public.org_employee FORCE ROW LEVEL SECURITY;


ALTER TABLE public.org_employee OWNER TO lab_migrator;

--
-- Name: org_organization_service; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.org_organization_service (
    id character varying(64) NOT NULL,
    caption text,
    tenant_id uuid NOT NULL,
    price numeric(18,2),
    duration smallint NOT NULL,
    profile_id character varying(64) NOT NULL
);

ALTER TABLE ONLY public.org_organization_service FORCE ROW LEVEL SECURITY;


ALTER TABLE public.org_organization_service OWNER TO lab_migrator;

--
-- Name: sys_application_row_level_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_application_row_level_right (
    id character varying(64) NOT NULL,
    entity_name text NOT NULL,
    is_active boolean NOT NULL,
    is_hierarchical boolean NOT NULL,
    hierarchy_field_name text NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_application_row_level_right OWNER TO lab_migrator;

--
-- Name: sys_field_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_field_right (
    id character varying(64) NOT NULL,
    right_id character varying(64) NOT NULL,
    field_name text NOT NULL,
    access_level integer NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_field_right OWNER TO lab_migrator;

--
-- Name: sys_operation_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_operation_right (
    id character varying(64) NOT NULL,
    operation_name text NOT NULL,
    access_level integer NOT NULL,
    is_active boolean NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_operation_right OWNER TO lab_migrator;

--
-- Name: sys_profile; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_profile (
    id character varying(64) NOT NULL,
    is_active boolean NOT NULL,
    type_id character varying(64),
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_profile OWNER TO lab_migrator;

--
-- Name: sys_profile_operation_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_profile_operation_right (
    id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    operation_right_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_profile_operation_right OWNER TO lab_migrator;

--
-- Name: sys_profile_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_profile_right (
    id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    right_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_profile_right OWNER TO lab_migrator;

--
-- Name: sys_profile_role; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_profile_role (
    id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    role_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_profile_role OWNER TO lab_migrator;

--
-- Name: sys_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_right (
    id character varying(64) NOT NULL,
    entity_name text NOT NULL,
    entity_access_level integer NOT NULL,
    is_active boolean NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_right OWNER TO lab_migrator;

--
-- Name: sys_role; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_role (
    id character varying(64) NOT NULL,
    is_active boolean NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_role OWNER TO lab_migrator;

--
-- Name: sys_role_operation_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_role_operation_right (
    id character varying(64) NOT NULL,
    role_id character varying(64) NOT NULL,
    operation_right_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_role_operation_right OWNER TO lab_migrator;

--
-- Name: sys_role_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_role_right (
    id character varying(64) NOT NULL,
    role_id character varying(64) NOT NULL,
    right_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_role_right OWNER TO lab_migrator;

--
-- Name: sys_row_level_right; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_row_level_right (
    id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    main_entity_name text NOT NULL,
    entity_name text NOT NULL,
    access_type integer NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    caption text
);


ALTER TABLE public.sys_row_level_right OWNER TO lab_migrator;

--
-- Name: sys_row_level_security_object; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_row_level_security_object (
    id character varying(64) NOT NULL,
    row_level_right_id character varying(64) NOT NULL,
    entity_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_row_level_security_object OWNER TO lab_migrator;

--
-- Name: sys_user_default_value; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_user_default_value (
    id character varying(64) NOT NULL,
    entity_name text NOT NULL,
    user_id character varying(64) NOT NULL,
    value_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_user_default_value OWNER TO lab_migrator;

--
-- Name: sys_user_profile; Type: TABLE; Schema: public; Owner: lab_migrator
--

CREATE TABLE public.sys_user_profile (
    id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    profile_id character varying(64) NOT NULL,
    record_state integer NOT NULL,
    modified_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    created_by character varying(64) NOT NULL,
    created_on timestamp without time zone NOT NULL
);


ALTER TABLE public.sys_user_profile OWNER TO lab_migrator;

--
-- Name: tn_division; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.tn_division (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    code character varying(10) NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    address text,
    is_active boolean NOT NULL,
    phone character varying(32),
    department_type_id character varying(64),
    created_on timestamp without time zone NOT NULL,
    created_by character varying(64) NOT NULL,
    modified_on timestamp without time zone,
    modified_by character varying(64) NOT NULL,
    record_state integer NOT NULL
);

ALTER TABLE ONLY public.tn_division FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tn_division OWNER TO lis;

--
-- Name: tn_requisites; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.tn_requisites (
    tenant_id uuid NOT NULL,
    legal_name text,
    edrpou text,
    address text,
    phone text,
    email text,
    license_number text,
    logo_url text
);

ALTER TABLE ONLY public.tn_requisites FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tn_requisites OWNER TO lis;

--
-- Name: tn_sequence; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.tn_sequence (
    tenant_id uuid NOT NULL,
    key text NOT NULL,
    scope_key text NOT NULL,
    value bigint NOT NULL
);

ALTER TABLE ONLY public.tn_sequence FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tn_sequence OWNER TO lis;

--
-- Name: tn_settings; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.tn_settings (
    tenant_id uuid NOT NULL,
    date_format text,
    decimal_separator text,
    default_form_language text,
    status_color_markers text,
    criticality_color_markers text
);

ALTER TABLE ONLY public.tn_settings FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tn_settings OWNER TO lis;

--
-- Name: tn_tenant; Type: TABLE; Schema: public; Owner: lis
--

CREATE TABLE public.tn_tenant (
    id uuid NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    time_zone text NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.tn_tenant OWNER TO lis;

--
-- Name: aggregatedcounter id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.aggregatedcounter ALTER COLUMN id SET DEFAULT nextval('hangfire.aggregatedcounter_id_seq'::regclass);


--
-- Name: counter id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.counter ALTER COLUMN id SET DEFAULT nextval('hangfire.counter_id_seq'::regclass);


--
-- Name: hash id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.hash ALTER COLUMN id SET DEFAULT nextval('hangfire.hash_id_seq'::regclass);


--
-- Name: job id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.job ALTER COLUMN id SET DEFAULT nextval('hangfire.job_id_seq'::regclass);


--
-- Name: jobparameter id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.jobparameter ALTER COLUMN id SET DEFAULT nextval('hangfire.jobparameter_id_seq'::regclass);


--
-- Name: jobqueue id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.jobqueue ALTER COLUMN id SET DEFAULT nextval('hangfire.jobqueue_id_seq'::regclass);


--
-- Name: list id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.list ALTER COLUMN id SET DEFAULT nextval('hangfire.list_id_seq'::regclass);


--
-- Name: set id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.set ALTER COLUMN id SET DEFAULT nextval('hangfire.set_id_seq'::regclass);


--
-- Name: state id; Type: DEFAULT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.state ALTER COLUMN id SET DEFAULT nextval('hangfire.state_id_seq'::regclass);


--
-- Data for Name: aggregatedcounter; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.aggregatedcounter (id, key, value, expireat) FROM stdin;
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.counter (id, key, value, expireat) FROM stdin;
\.


--
-- Data for Name: hash; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.hash (id, key, field, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: job; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.job (id, stateid, statename, invocationdata, arguments, createdat, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: jobparameter; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.jobparameter (id, jobid, name, value, updatecount) FROM stdin;
\.


--
-- Data for Name: jobqueue; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.jobqueue (id, jobid, queue, fetchedat, updatecount) FROM stdin;
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.list (id, key, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: lock; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.lock (resource, updatecount, acquired) FROM stdin;
\.


--
-- Data for Name: schema; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.schema (version) FROM stdin;
\.


--
-- Data for Name: server; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.server (id, data, lastheartbeat, updatecount) FROM stdin;
\.


--
-- Data for Name: set; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.set (id, key, score, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: state; Type: TABLE DATA; Schema: hangfire; Owner: lis_app
--

COPY hangfire.state (id, jobid, name, reason, createdat, data, updatecount) FROM stdin;
\.


--
-- Data for Name: aud_event; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.aud_event (id, tenant_id, actor_user_id, event_type, occurred_at, before, after, pii, actor_display_name, actor_type, correlation_id, ip) FROM stdin;
\.


--
-- Data for Name: cmn_enum_record; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.cmn_enum_record (id, caption, code, enum_type, parent_id, value_type, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
01f0eff5-a698-4873-a45b-ad034a386d08	Жінка	F	Gender	\N	0	2026-10-13 20:26:21.588925	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
07b60329-7282-4262-9409-b24ea4440428	Чоловік	M	Gender	\N	0	2026-10-13 20:26:21.580911	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e001	Особа	person	PatientCardType	\N	0	2026-10-13 20:26:21.588996	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e003	Активне	active	MedicalReferralStatus	\N	0	2026-10-13 20:26:21.589001	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e004	Погашене	completed	MedicalReferralStatus	\N	0	2026-10-13 20:26:21.589007	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e005	Відкликане	recalled	MedicalReferralStatus	\N	0	2026-10-13 20:26:21.589012	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e006	Нове	new	MedicalReferralProcessingStatusInEhealth	\N	0	2026-10-13 20:26:21.589016	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e007	Взято в роботу	in_progress	MedicalReferralProcessingStatusInEhealth	\N	0	2026-10-13 20:26:21.589021	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0c000000-0000-0000-0000-00000000e008	Виконано	completed	MedicalReferralProcessingStatusInEhealth	\N	0	2026-10-13 20:26:21.589025	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0f284af5-ff01-4d12-93c1-410f4ec9f13f	Середній мед.персонал	0005	OrgPositionType	\N	0	2026-10-13 20:26:21.588983	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
1e17ba44-ec4a-4deb-bcc3-a006ea1bb138	Філія	05	DepartmentType	\N	0	2026-10-13 20:26:21.58896	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
401fc1d1-064d-43a5-b0b1-3db57201abdd	Лаборанти	0003	OrgPositionType	\N	0	2026-10-13 20:26:21.588979	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
4a27f64a-f484-4b8d-a0bd-17c242e2440e	Невідомий	U	Gender	\N	0	2026-10-13 20:26:21.588941	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
4fd18a0e-be63-42c3-8fa3-3f493679cd7d	Інші	0001	OrgPositionType	\N	0	2026-10-13 20:26:21.588969	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
570a6df1-ed44-4ab6-8c60-47b82daca201	Лікувальне	03	DepartmentType	\N	0	2026-10-13 20:26:21.588956	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
64b66b71-581b-4c52-aff4-abf352fa6a6d	Не опитували	Uknown	PrivacyRequestType	\N	0	2026-10-13 20:26:21.588987	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
6b1501dd-8780-45ea-9d3e-445b8ae7875a	Підрозділ	06	DepartmentType	\N	0	2026-10-13 20:26:21.588965	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
a40ae385-b6cb-467e-a8ef-7e35e111fd27	Лікарі	0002	OrgPositionType	\N	0	2026-10-13 20:26:21.588974	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
d95d3e30-15ea-421c-8785-8e80e60ffbbe	Амбулаторна карта	AmbCard	MedicalDocumentType	\N	0	2026-10-13 20:26:21.588992	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
e535bab7-0b06-4d9a-a76d-73fd5f77ef0b	Діагностичне	02	DepartmentType	\N	0	2026-10-13 20:26:21.588947	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0f207781-8e89-40ae-b907-fabf602c217b	DiagnosticReport	DiagnosticReport	MedicalDocumentType	\N	0	2026-10-27 08:24:19.811787	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
e1434f29-c0a5-4d7c-9c00-e4c890b4040f	Лабораторія	07	DepartmentType	\N	0	2026-10-27 19:30:42.309041	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: cmn_person; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.cmn_person (id, last_name, name, middle_name, birthday, gender_id, ipn, no_ipn, phone, email, location, caption, description, subscribed_to_notifications, user_id, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
4481c6be-a8ef-a387-7357-0d7a02d69889	Лаборант	Тест	Тестович	\N	\N	\N	t	+380501000003	emp3@example.com	\N	Лаборант Тест Тестович	\N	f	\N	2026-10-13 20:26:21.64282	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
95cc74e8-4631-8ee9-703b-b4c514221435	Медсестра	Забору	Тест	\N	\N	\N	t	+380501000004	emp4@example.com	\N	Медсестра Забору Тест	\N	f	\N	2026-10-13 20:26:21.642865	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
e59d651a-b8f8-4790-5418-ee1c15a00d73	Адміністратор	Лабораторії	Тест	\N	\N	\N	t	+380501000001	emp1@example.com	\N	Адміністратор Лабораторії Тест	\N	f	00000000-0000-4000-8000-00000000a001	2026-10-13 20:26:21.618792	00000000-0000-0000-0000-000000000000	2026-10-18 23:57:14.255423	00000000-0000-0000-0000-000000000000	2
e9692cbb-8a11-88ac-ebea-b2d28ee2000f	Реєстратор	Тест	Тестівна	\N	\N	\N	t	+380501000006	emp6@example.com	\N	Реєстратор Тест Тестівна	\N	f	\N	2026-10-13 20:26:21.642939	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
f225798d-0785-e068-6026-ad69168ef830	Лікар	Лаборант	Тест	\N	\N	\N	t	+380501000002	emp2@example.com	\N	Лікар Лаборант Тест	\N	f	\N	2026-10-13 20:26:21.642691	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
f5880b34-863a-05f4-9079-07fd5a583885	Кур'єр	Логіст	Тест	\N	\N	\N	t	+380501000005	emp5@example.com	\N	Кур'єр Логіст Тест	\N	f	\N	2026-10-13 20:26:21.642905	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
35f4722b-46db-d43a-3ecc-7a95cfa4a1f8	Коваленко	Олег	Іванович	1958-03-12 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	t	+380672000001	\N	м. Київ	Коваленко Олег Іванович	\N	f	\N	2026-10-13 20:26:21.645102	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
3f92a482-9c8b-e26a-b1d7-e2e757c66c41	Ткаченко	Максим	Дмитрович	2024-02-14 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	t	+380672000005	\N	м. Київ	Ткаченко Максим Дмитрович	\N	f	\N	2026-10-13 20:26:21.659013	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
4cacc2ef-39bb-e074-6e14-dc5e2cfdfb39	Кравчук	Василь	Степанович	1944-09-09 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	t	+380672000006	\N	м. Київ	Кравчук Василь Степанович	\N	f	\N	2026-10-13 20:26:21.659039	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
b95058e9-787f-761b-7507-aef5626bef03	Мельник	Ірина	Олексіївна	1996-05-30 00:00:00	01f0eff5-a698-4873-a45b-ad034a386d08	\N	t	+380672000004	\N	м. Київ	Мельник Ірина Олексіївна	\N	f	\N	2026-10-13 20:26:21.65898	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
d6f7f886-6718-1cb2-9af3-6d49f954235c	Шевченко	Марія	Петрівна	1985-07-21 00:00:00	01f0eff5-a698-4873-a45b-ad034a386d08	\N	t	+380672000002	\N	м. Київ	Шевченко Марія Петрівна	\N	f	\N	2026-10-13 20:26:21.658873	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
e82ca223-e0ce-2eb7-f5ef-fbef7d9246f3	Бондаренко	Андрій	Сергійович	1970-11-02 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	t	+380672000003	\N	м. Київ	Бондаренко Андрій Сергійович	\N	f	\N	2026-10-13 20:26:21.658938	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: ehd_dictionary; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehd_dictionary (id, name, is_active, code, value, is_own, hidden, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
997c126c-f167-4671-ac86-1295e9915555	MedicalReferralPriority	t	routine	routine	t	f	2026-10-27 08:58:46.563648	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
345b7770-899d-4849-9760-838ccab53fcf	MedicalServiceProgramType	t	NSZU	NSZU	t	f	2026-10-27 08:58:46.563648	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: ehe_incoming_medical_referral; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehe_incoming_medical_referral (id, reg_number, reg_date, caption, tenant_id, patient_card_id, patient_short_name, service_catalog_service_id, medical_referral_category_id, requester_id, status_id, priority_id, expiration_date, ehealth_id, patient_instruction, medical_service_program_id, processing_status_in_ehealth_id, take_in_work_date, complete_date_in_ehealth, completed_with_item_entity_id, completed_with_item_entity_name, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
0c0f0000-0000-0000-0000-000000000002	MOCK-0002-0002	2026-10-13 20:26:21.765783	Біохімія: базовий профіль	d0000000-0000-0000-0000-000000000001	0b000000-0000-0000-0000-000000000002	Шевченко Марія Петрівна	d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	0c000000-0000-0000-0000-00000000e002	\N	0c000000-0000-0000-0000-00000000e003	997c126c-f167-4671-ac86-1295e9915555	2026-11-12 00:00:00	\N	\N	\N	0c000000-0000-0000-0000-00000000e007	2026-10-13 20:26:23.349152	\N	\N	\N	2026-10-13 20:26:21.765784	00000000-0000-0000-0000-000000000000	2026-10-13 20:26:23.35955	0e000000-0000-0000-0000-000000000001	2
0c0f0000-0000-0000-0000-000000000001	MOCK-0001-0001	2026-10-13 20:26:21.749796	Біохімія: базовий профіль	d0000000-0000-0000-0000-000000000001	0b000000-0000-0000-0000-000000000001	Коваленко Олег Іванович	d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	0c000000-0000-0000-0000-00000000e002	\N	0c000000-0000-0000-0000-00000000e003	997c126c-f167-4671-ac86-1295e9915555	2026-11-12 00:00:00	\N	\N	f84fe59f-ba5c-4478-9382-84d755456d1b	0c000000-0000-0000-0000-00000000e006	\N	\N	\N	\N	2026-10-13 20:26:21.749797	00000000-0000-0000-0000-000000000000	2026-10-13 20:26:22.1844	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: ehe_medical_referral_category; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehe_medical_referral_category (id, code, name, ehealth_code, is_used_in_ehealth, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
0c000000-0000-0000-0000-00000000e002	laboratory_procedure	laboratory_procedure	laboratory_procedure	t	2026-10-27 08:24:14.86975	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: ehe_medical_service_program; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehe_medical_service_program (id, is_active, hidden, ehealth_id, type_id, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
f84fe59f-ba5c-4478-9382-84d755456d1b	t	f	6b4890ea-00c7-4f19-abaf-d6be2bcdad6b	345b7770-899d-4849-9760-838ccab53fcf	2026-10-27 08:59:00.685784	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: ehe_paper_medical_referral; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehe_paper_medical_referral (id, reg_number, reg_date, caption, tenant_id, patient_card_id, requester_employee_name, requester_legal_entity_name, requester_legal_entity_edrpou, status, processed_date, description, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
\.


--
-- Data for Name: ehe_service_catalog_service; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ehe_service_catalog_service (id, caption, code, name, is_active, is_composition, request_allowed, medical_referral_category_id, ehealth_id, inserted_at_in_ehealth, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
8f3979af-1c66-4a66-ba44-6ca5c5baffe5	Щитоподібна залоза	LAB-THYROID-001	Щитоподібна залоза	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.673439	2026-10-13 20:26:21.673439	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
a2d02e45-fdfd-ba67-04b9-91818bc5bb73	Загальний аналіз крові	LAB-CBC-001	Загальний аналіз крові	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.673413	2026-10-13 20:26:21.673413	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
c01c3e12-3f60-be81-ac61-08eab414d08d	Загальний аналіз сечі	LAB-URINE-001	Загальний аналіз сечі	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.67345	2026-10-13 20:26:21.67345	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	Біохімія: базовий профіль	LAB-BIOCHEM-001	Біохімія: базовий профіль	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.659824	2026-10-13 20:26:21.659825	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
db9ba637-71b1-e472-9329-c71deaa0e600	Коагулограма	LAB-COAG-001	Коагулограма	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.673426	2026-10-13 20:26:21.673427	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
f205b93d-c429-0c7f-fd3f-995b6e699954	Ліпідограма	LAB-LIPID-001	Ліпідограма	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-13 20:26:21.673378	2026-10-13 20:26:21.673379	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
4d743837-183f-4a76-9833-8c4f5947868a	Лабораторне дослідження (загальна послуга)	LAB-GENERIC	Лабораторне дослідження (загальна послуга)	t	f	t	0c000000-0000-0000-0000-00000000e002	\N	2026-10-27 08:35:42.285688	2026-10-27 08:35:42.285688	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: id_device_token; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_device_token (id, tenant_id, gateway_id, prefix, secret_hash, created_at, revoked_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: id_invitation; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_invitation (id, tenant_id, email, role_id, division_ids, token, expires_at, accepted_at, created_at) FROM stdin;
\.


--
-- Data for Name: id_membership; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_membership (id, tenant_id, user_id, role_id, is_active, created_at) FROM stdin;
d0000000-0000-0000-0000-000000000025	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000015	00000000-0000-0000-0000-000000000005	t	2026-10-25 23:34:15.802814+00
d0000000-0000-0000-0000-000000000021	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000011	00000000-0000-0000-0000-000000000001	t	2026-10-25 23:34:15.802814+00
d0000000-0000-0000-0000-000000000023	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000013	00000000-0000-0000-0000-000000000003	t	2026-10-25 23:34:15.802814+00
d0000000-0000-0000-0000-000000000024	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000014	00000000-0000-0000-0000-000000000004	t	2026-10-25 23:34:15.802814+00
d0000000-0000-0000-0000-000000000022	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000012	00000000-0000-0000-0000-000000000002	t	2026-10-25 23:34:15.802814+00
0e000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000001	e59d651a-b8f8-4790-5418-ee1c15a00d73	5ec00000-0000-0000-0000-0000000000b1	t	2026-10-26 11:52:43.388537+00
0e000000-0000-0000-0000-000000000002	d0000000-0000-0000-0000-000000000001	f225798d-0785-e068-6026-ad69168ef830	5ec00000-0000-0000-0000-0000000000b2	t	2026-10-26 11:52:43.415856+00
0e000000-0000-0000-0000-000000000003	d0000000-0000-0000-0000-000000000001	4481c6be-a8ef-a387-7357-0d7a02d69889	5ec00000-0000-0000-0000-0000000000b3	t	2026-10-26 11:52:43.417099+00
0e000000-0000-0000-0000-000000000004	d0000000-0000-0000-0000-000000000001	95cc74e8-4631-8ee9-703b-b4c514221435	5ec00000-0000-0000-0000-0000000000b4	t	2026-10-26 11:52:43.418452+00
0e000000-0000-0000-0000-000000000005	d0000000-0000-0000-0000-000000000001	f5880b34-863a-05f4-9079-07fd5a583885	5ec00000-0000-0000-0000-0000000000b5	t	2026-10-26 11:52:43.419526+00
0e000000-0000-0000-0000-000000000006	d0000000-0000-0000-0000-000000000001	e9692cbb-8a11-88ac-ebea-b2d28ee2000f	5ec00000-0000-0000-0000-0000000000b6	t	2026-10-26 11:52:43.420882+00
\.


--
-- Data for Name: id_membership_division; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_membership_division (membership_id, division_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: id_membership_role; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_membership_role (id, tenant_id, membership_id, role_id, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
\.


--
-- Data for Name: id_permission; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_permission (code, caption) FROM stdin;
analyzers.manage	Створення аналізатора; Редагування аналізатора; Видалення аналізатора
analyzers.message_delete	Видалення запису журналу
billing.charge_choice_change	Зміна оплати позиції
billing.insurances_manage	Поліси пацієнта
billing.invoice_cancel	Анулювання рахунку
billing.invoice_issue	Виставлення рахунку платнику
billing.invoice_mark_paid	Оплата рахунку платником
billing.payers_manage	Довідник платників
billing.payment_add	Прийом оплати
billing.period_invoice	Рахунок/акт за період
billing.price_lists_manage	Прайс-листи
biobank.cell_delete	Видалення комірки
biobank.cell_update	Редагування комірки
biobank.place	Розміщення зразка в біобанку
biobank.rack_create	Створення штатива
biobank.rack_delete	Видалення штатива
biobank.rack_update	Редагування штатива
biobank.remove	Вилучення зразка з біобанку
catalog.delete	Видалення запису довідника
catalog.import	Імпорт довідника
catalog.manage	Створення запису довідника; Редагування запису довідника
critical.acknowledge	Реєстрація панічного дзвінка
critical.call_delete	Видалення панічного дзвінка
critical.call_update	Редагування панічного дзвінка
documents.generate	Замовлення: Друк бланка
gateways.manage	Коннектор: Реєстрація інсталяції; Коннектор: Heartbeat; Коннектор: Позначити офлайн; Коннектор: Вимкнути; Коннектор: Увімкнути (повторна реєстрація); Коннектор: Перевипустити ключ; Коннектор: Редагувати; Коннектор: Видалити; Створення інсталяції коннектора; Команда коннектору
labels.print	Замовлення: Друк етикеток
logistics.manifest_create	Створення маніфесту
logistics.manifest_delete	Маніфест: Видалити маніфест
logistics.manifest_dispatch	Маніфест: Відправити
logistics.manifest_edit	Маніфест: Редагувати маніфест
logistics.manifest_receive	Маніфест: Прийняти в лабораторії
logistics.manifest_reject	Маніфест: Відхилити (порушення холодового ланцюга)
micro.culture_complete	Посів: Завершити посів
micro.culture_create	Створення посіву
micro.culture_delete	Посів: Видалити посів
micro.culture_edit	Посів: Редагувати посів
micro.culture_isolated	Посів: Ізоляти виділено
micro.culture_preliminary	Посів: Попередній результат
micro.isolate_add	Посів: Додати ізолят
micro.susceptibility_add	Посів: Антибіотикограма
norms.manage	Редагування норм; Видалення норм
orders.add_attachment	Завантаження бланка результатів
orders.add_specimen	Замовлення: Додати пробірку
orders.add_test	Замовлення: Додати тест
orders.cancel	Замовлення: Скасувати замовлення
orders.change_payer	Зміна платника замовлення
orders.complete	Замовлення: Завершити (усі тести верифіковано)
orders.create	Створення замовлення
orders.create_batch	Створення замовлень
orders.delete	Замовлення: Видалити замовлення
orders.dispatch	Замовлення: Відправити в лабораторію
orders.edit	Замовлення: Редагувати замовлення
orders.favorites_delete_other	Видалення обраних іншого співробітника
orders.favorites_edit_other	Редагування обраних іншого співробітника
orders.favorites_save	Збереження обраних наборів
orders.import_registry	Імпорт реєстру клініки
orders.read	Перегляд замовлень
orders.reject	Замовлення: Відхилити (брак біоматеріалу)
orders.release	Замовлення: Видати результати пацієнту
orders.remove_test	Замовлення: Прибрати тест
orders.reopen	Замовлення: Повернути в роботу
patients.delete	Видалення картки пацієнта
patients.manage	Створення картки пацієнта; Редагування картки пацієнта
platform.logs_retention_run	Очищення журналів
qc.lockout_create	Ручне блокування аналізатора
qc.lockout_delete	Видалення lockout
qc.lockout_resolve	Розблокування аналізатора
qc.material_create	Створення контрольного матеріалу
qc.material_delete	Видалення контрольного матеріалу
qc.material_update	Редагування контрольного матеріалу
qc.result_add	Внесення результату ВКЯ
qc.result_delete	Видалення результату ВКЯ
qc.result_update	Редагування результату ВКЯ
qc.target_delete	Видалення цільового значення
quarantine.delete	Видалення незв'язаного результату
quarantine.resolve	Зв'язування результату
reagents.consume	Списання реагенту
reagents.lot_create	Створення лоту реагенту
reagents.lot_delete	Видалення лоту реагенту
reagents.lot_update	Редагування лоту реагенту
reports.read	Перегляд звітів
results.assign_analyzer	Тест: Призначити аналізатор
results.autoverify	Автоверифікація
results.correct	Тест: Виправити результат (нова версія)
results.delete	Тест: Видалити результат
results.enter	Замовлення: Ввести результат; Тест: Ввести результат
results.import	Імпорт результатів
results.read	Перегляд результатів
results.reject	Тест: Відхилити тест
results.remove_item	Тест: Прибрати тест із замовлення
results.reopen	Тест: Відкрити повторно
results.rerun	Тест: Повторити дослідження
results.start_analysis	Тест: Передати на аналізатор
results.verify	Замовлення: Верифікувати результати; Тест: Верифікувати
sections.create	Створення підрозділу лабораторії
sections.delete	Видалення підрозділу лабораторії
sections.journal_status_change	Зміна статусу позиції журналу
sections.update	Редагування підрозділу лабораторії
sections.workflow_template_edit	Редагування шаблону робочого процесу
sendout.accept	Підтвердження приймання зовнішньою лабораторією
sendout.cancel	Скасування реєстру відправки
sendout.change_performer	Зміна виконавця дослідження
sendout.create	Формування реєстру відправки
sendout.dispatch	Відправка проб у зовнішню лабораторію
sendout.item_reject	Відмова/відкликання позиції реєстру
sendout.performer_delete	Видалення лабораторії-виконавця
sendout.performer_tests_manage	Прайс зовнішньої лабораторії
sendout.performers_manage	Довідник лабораторій-виконавців
sendout.recall_test	Тест: Відкликати з зовнішньої лабораторії
sendout.result_enter	Внесення результату зовнішньої лабораторії
sendout.results_import	Імпорт результатів зовнішньої лабораторії
sendout.send_test	Тест: Відправити в зовнішню лабораторію
specimens.collect	Замовлення: Забір біоматеріалу; Пробірка: Забір пробірки
specimens.delete	Пробірка: Видалити пробірку
specimens.dispatch	Пробірка: Відправити
specimens.dispose	Пробірка: Утилізувати
specimens.edit_flags	Пробірка: Відмітки гемоліз/ліпемія/іктеричність
specimens.process	Пробірка: В обробці (центрифугування/аналіз)
specimens.receive	Замовлення: Прийняти в лабораторії; Пробірка: Прийняти
specimens.reject	Пробірка: Відбракувати пробірку
specimens.replace	Пробірка: Замінити пробірку (новий штрихкод)
specimens.split	Алікотування / розділення проби
specimens.stage_add	Фіксація етапу обробки проби
specimens.stage_delete	Видалення події етапу
specimens.store	Пробірка: Розмістити в біобанку
specimens.uncollect	Пробірка: Скасувати відмітку забору
tenant.numerators.manage	Зміна нумератора
tenant.settings.manage	Зміна налаштувань лабораторії
users.manage	Збереження співробітника
worklists.manage	Створення робочого листа; Редагування робочого листа; Видалення робочого листа
\.


--
-- Data for Name: id_role; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_role (id, tenant_id, name, is_system_role) FROM stdin;
00000000-0000-0000-0000-000000000001	\N	Owner	t
00000000-0000-0000-0000-000000000002	\N	Administrator	t
00000000-0000-0000-0000-000000000003	\N	Lab Doctor	t
00000000-0000-0000-0000-000000000004	\N	Lab Technician	t
00000000-0000-0000-0000-000000000005	\N	Registrar	t
\.


--
-- Data for Name: id_role_permission; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_role_permission (role_id, permission) FROM stdin;
00000000-0000-0000-0000-000000000001	audit.read
00000000-0000-0000-0000-000000000001	catalog.manage
00000000-0000-0000-0000-000000000001	divisions.manage
00000000-0000-0000-0000-000000000001	gateways.manage
00000000-0000-0000-0000-000000000001	integrations.manage
00000000-0000-0000-0000-000000000001	orders.create
00000000-0000-0000-0000-000000000001	orders.read
00000000-0000-0000-0000-000000000001	results.verify
00000000-0000-0000-0000-000000000001	roles.manage
00000000-0000-0000-0000-000000000001	tenant.settings.manage
00000000-0000-0000-0000-000000000001	users.manage
00000000-0000-0000-0000-000000000002	audit.read
00000000-0000-0000-0000-000000000002	catalog.manage
00000000-0000-0000-0000-000000000002	divisions.manage
00000000-0000-0000-0000-000000000002	gateways.manage
00000000-0000-0000-0000-000000000002	integrations.manage
00000000-0000-0000-0000-000000000002	roles.manage
00000000-0000-0000-0000-000000000002	tenant.settings.manage
00000000-0000-0000-0000-000000000002	users.manage
00000000-0000-0000-0000-000000000003	orders.read
00000000-0000-0000-0000-000000000003	results.verify
00000000-0000-0000-0000-000000000004	orders.read
00000000-0000-0000-0000-000000000005	orders.create
00000000-0000-0000-0000-000000000005	orders.read
00000000-0000-0000-0000-000000000001	audit.read_pii
00000000-0000-0000-0000-000000000001	results.enter
00000000-0000-0000-0000-000000000001	results.read
00000000-0000-0000-0000-000000000003	results.enter
00000000-0000-0000-0000-000000000003	results.read
00000000-0000-0000-0000-000000000004	results.enter
00000000-0000-0000-0000-000000000004	results.read
00000000-0000-0000-0000-000000000003	catalog.manage
00000000-0000-0000-0000-000000000003	orders.create
\.


--
-- Data for Name: id_user; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.id_user (id, sub, email, name, created_at, default_tenant_id, is_platform_admin) FROM stdin;
d0000000-0000-0000-0000-000000000011	dev-owner	owner@demolab.dev	Demo Owner	2026-10-25 23:34:15.802814+00	\N	f
d0000000-0000-0000-0000-000000000012	dev-admin	admin@demolab.dev	Demo Administrator	2026-10-25 23:34:15.802814+00	\N	f
d0000000-0000-0000-0000-000000000013	dev-lab-doctor	labdoctor@demolab.dev	Demo Lab Doctor	2026-10-25 23:34:15.802814+00	\N	f
d0000000-0000-0000-0000-000000000014	dev-lab-tech	labtech@demolab.dev	Demo Lab Technician	2026-10-25 23:34:15.802814+00	\N	f
d0000000-0000-0000-0000-000000000015	dev-registrar	registrar@demolab.dev	Demo Registrar	2026-10-25 23:34:15.802814+00	\N	f
d0000000-0000-0000-0000-000000000016	dev-no-tenant	no-tenant@demolab.dev	Demo No Tenant	2026-10-25 23:34:15.802814+00	\N	f
4481c6be-a8ef-a387-7357-0d7a02d69889	emp3@example.com	emp3@example.com	Лаборант Тест Тестович	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
95cc74e8-4631-8ee9-703b-b4c514221435	emp4@example.com	emp4@example.com	Медсестра Забору Тест	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
e59d651a-b8f8-4790-5418-ee1c15a00d73	00000000-0000-4000-8000-00000000a001	emp1@example.com	Адміністратор Лабораторії Тест	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
e9692cbb-8a11-88ac-ebea-b2d28ee2000f	emp6@example.com	emp6@example.com	Реєстратор Тест Тестівна	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
f225798d-0785-e068-6026-ad69168ef830	emp2@example.com	emp2@example.com	Лікар Лаборант Тест	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
f5880b34-863a-05f4-9079-07fd5a583885	emp5@example.com	emp5@example.com	Кур'єр Логіст Тест	2026-10-26 20:59:47.714632+00	d0000000-0000-0000-0000-000000000001	f
6f538397-f195-4095-976f-9e08614bdb06	system	system@medlink.local	Системний користувач	2026-10-27 14:58:07.114767+00	\N	f
\.


--
-- Data for Name: ins_gateway; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.ins_gateway (id, tenant_id, name, status, created_at, enrollment_code, enrollment_code_expires_at, enrollment_code_used_at) FROM stdin;
\.


--
-- Data for Name: int_api_key; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.int_api_key (id, tenant_id, client_id, prefix, secret_hash, created_at, revoked_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: int_client; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.int_client (id, tenant_id, name, scopes, created_at) FROM stdin;
\.


--
-- Data for Name: lab_analyzer; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_analyzer (id, code, name, analyzer_type_id, connector_id, department_id, connection_mode, tcp_host, tcp_port, is_tcp_server, com_port, baud_rate, parity, data_bits, stop_bits, flow_control, file_path, file_poll_sec, auto_query_orders, is_active, is_online, last_message_at, last_error, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0a2a0000-0000-0000-0000-000000000002	MINDRAY-BS-1	Mindray BS-300 (mock)	37	0c0c0000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	TCP	127.0.0.1	5002	t	\N	9600	None	8	One	None	\N	10	t	t	t	2026-10-26 12:06:37.632078	\N	2026-10-13 20:26:22.091323	00000000-0000-0000-0000-000000000000	2026-10-26 12:06:38.067542	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0a2a0000-0000-0000-0000-000000000001	SYSMEX-XN-1	Sysmex XN-1000 (mock)	32	0c0c0000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	TCP	127.0.0.1	5001	t	\N	9600	None	8	One	None	\N	10	t	t	t	2026-10-26 12:20:01.499353	\N	2026-10-13 20:26:22.064041	00000000-0000-0000-0000-000000000000	2026-10-26 12:20:01.518901	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_analyzer_lockout; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_analyzer_lockout (id, analyzer_id, test_code, reason, qc_result_id, started_at, resolved_at, resolved_by_id, cause, action, comment, protocol_text, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
b9ae272a-afd0-48b1-bff4-ea33ef8c5248	0a2a0000-0000-0000-0000-000000000001	WBC	ВКЯ XN CHECK L2 (mock) (лот QC-MOCK-002): порушено 1_3s; z=+3.67	14e91f74-9a9b-480e-9cfb-664faaac796e	2026-10-13 19:46:24.7013	\N	\N	\N	\N	\N	\N	2026-10-13 20:26:24.706056	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_analyzer_message; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_analyzer_message (id, analyzer_id, direction, protocol, raw_text, parsed_ok, received_at, results_count, error, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
b05f783d-8cc6-497d-80f3-317dc4076801	0a2a0000-0000-0000-0000-000000000001	IN	ASTM	H|\\^&|||T-CHECK\rL|1|N\r	t	2026-10-26 12:00:00	0	\N	2026-10-26 11:59:28.191869	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ce732894-71f0-48df-bf7a-8231ce9377e3	0a2a0000-0000-0000-0000-000000000001	IN	ASTM	H|\\^&|||T-CHECK\rL|1|N\r	t	2026-10-26 12:00:00	0	\N	2026-10-26 12:06:05.630102	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
311db9e1-9f2b-4d26-9d39-5c42f8e699f2	0a2a0000-0000-0000-0000-000000000001	IN	ASTM	H|\\^&|||T-CHECK\rL|1|N\r	t	2026-10-26 12:00:00	0	\N	2026-10-26 12:20:01.406215	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_analyzer_parameter_map; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_analyzer_parameter_map (id, analyzer_id, analyzer_code, test_code, factor, "offset", unit_override, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
082852e7-da5a-4e51-9d99-f1660dcc8b10	0a2a0000-0000-0000-0000-000000000002	TG	TG	1	0	\N	2026-10-13 20:26:22.091389	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0a430aa1-8179-4be9-b2e8-abe38a5b3ad0	0a2a0000-0000-0000-0000-000000000002	GLU	GLU	1	0	\N	2026-10-13 20:26:22.091374	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
1a4f9599-3d26-44d2-a596-ea3ce4603f17	0a2a0000-0000-0000-0000-000000000002	UREA	UREA	1	0	\N	2026-10-13 20:26:22.091376	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2f2af427-d072-4db4-86e2-92c39509a7bd	0a2a0000-0000-0000-0000-000000000001	RBC	RBC	1	0	\N	2026-10-13 20:26:22.065454	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
62f5e3eb-7333-4ee9-838e-8eee602f0389	0a2a0000-0000-0000-0000-000000000002	CREAT	CREAT	1	0	\N	2026-10-13 20:26:22.091375	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6405509e-ce0b-4688-8b31-f68101790b13	0a2a0000-0000-0000-0000-000000000002	BIL_TOT	BIL_TOT	1	0	\N	2026-10-13 20:26:22.091379	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
88a89c9b-0455-4f91-9de3-95ffd066cde0	0a2a0000-0000-0000-0000-000000000002	HDL	HDL	1	0	\N	2026-10-13 20:26:22.091387	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
941b67f6-fa1b-49e4-9656-ada6194b86dc	0a2a0000-0000-0000-0000-000000000002	ALT	ALT	1	0	\N	2026-10-13 20:26:22.091377	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
976174f4-50ae-426f-9e9a-fce92f6bd581	0a2a0000-0000-0000-0000-000000000002	CHOL	CHOL	1	0	\N	2026-10-13 20:26:22.091386	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a2e1dfa2-010a-4f5d-ab28-c4b6b0d3345c	0a2a0000-0000-0000-0000-000000000001	PLT	PLT	1	0	\N	2026-10-13 20:26:22.065455	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a3d92192-2bc1-4488-85eb-3484c9ace4d8	0a2a0000-0000-0000-0000-000000000001	WBC	WBC	1	0	\N	2026-10-13 20:26:22.065398	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
bbd754da-03b8-4f60-a6fd-2529ea8e72cb	0a2a0000-0000-0000-0000-000000000002	LDL	LDL	1	0	\N	2026-10-13 20:26:22.091388	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
bcb566b7-c938-4318-8e87-c3b9254398e4	0a2a0000-0000-0000-0000-000000000002	K	K	1	0	\N	2026-10-13 20:26:22.091381	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
be4f083a-8f9c-4167-a277-31e29b4f7f1a	0a2a0000-0000-0000-0000-000000000002	AST	AST	1	0	\N	2026-10-13 20:26:22.091378	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
c08375e5-dbf6-49ba-bfe4-c7b0d91fa0e9	0a2a0000-0000-0000-0000-000000000002	NA	NA	1	0	\N	2026-10-13 20:26:22.091385	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
cb9e1a20-8637-4e88-b2f9-78bfdafd9b9c	0a2a0000-0000-0000-0000-000000000001	HGB	HGB	1	0	\N	2026-10-13 20:26:22.065453	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d642d90a-3c84-46a7-a3d8-1cdd9865c57a	0a2a0000-0000-0000-0000-000000000002	PROT_TOT	PROT_TOT	1	0	\N	2026-10-13 20:26:22.09138	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_analyzer_type; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_analyzer_type (id, code, name, manufacturer, category, exch_type, bop_base64, eop_base64, control_sum, sleep_ms, full_text, order_template, parser_kind, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	SYSMEX XS-1000I	Sysmex XS-1000i	Sysmex	HEMATOLOGY	ASTM	\N	\N	t	100	f	SYSMEX_XN	ASTM_SYSMEX	t	2026-10-13 20:26:21.805256	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	СOBAS 411	Сobas 111	Roche	BIOCHEM	ASTM	\N	\N	t	100	f	COBAS_C111	ASTM_COBAS	t	2026-10-13 20:26:21.814636	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	VITROS	Vitros	Ortho Clinical Diagnostics	BIOCHEM	ASTM	\N	\N	t	100	f	ASTM_GENERIC	ASTM_VITROS	t	2026-10-13 20:26:21.814673	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4	VITROS EVIQ	Vitros EViQ	Ortho Clinical Diagnostics	BIOCHEM	ASTM	\N	\N	t	100	f	ASTM_GENERIC	ASTM_VITROS	t	2026-10-13 20:26:21.814686	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5	AUTOVUE INOVA	AutoVue Inova	Ortho Clinical Diagnostics	IMMUNO	ASTM	\N	\N	t	100	f	ASTM_GENERIC	ASTM_GENERIC	t	2026-10-13 20:26:21.814697	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6	URISYS	Urisys 1100	Roche	URINE	ASTM	\N	\N	t	100	f	NONE	ASTM_URISYS	t	2026-10-13 20:26:21.814709	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7	STAGO START	Stago start	Diagnostica Stago	COAG	ASTM	\N	\N	t	100	f	STAGO	ASTM_STAGO	t	2026-10-13 20:26:21.814719	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
8	REFLOTRON	Reflotron	Roche	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.814728	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9	BIOKSEL	Bioksel	Bio-Ksel	COAG	ASTM	\N	\N	t	100	f	BIOKSEL	ASTM_BIOKSEL	t	2026-10-13 20:26:21.814738	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
10	TOSO	TOSO	Tosoh	IMMUNO	ASTM	\N	\N	t	100	f	TOSOH	ASTM_TOSOH	t	2026-10-13 20:26:21.814747	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
11	COBAS311	COBAS 311	Roche	BIOCHEM	ASTM	\N	\N	t	100	f	COBAS_C311	ASTM_COBAS	t	2026-10-13 20:26:21.814755	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
12	COBAS411	COBAS 411	Roche	IMMUNO	ASTM	\N	\N	t	100	f	COBAS_E411	ASTM_COBAS	t	2026-10-13 20:26:21.814764	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
13	SYSMEX2000	SYSMEX2000	Sysmex	HEMATOLOGY	ASTM	\N	\N	t	100	f	SYSMEX_XN	ASTM_SYSMEX	t	2026-10-13 20:26:21.814775	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
14	COBAS111	COBAS 111	Roche	BIOCHEM	ASTM	\N	\N	t	100	f	COBAS_C111	ASTM_COBAS	t	2026-10-13 20:26:21.814784	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
15	INTEGRA	INTEGRA	Roche	BIOCHEM	ASTM	\N	\N	t	100	f	INTEGRA	TEXT_INTEGRA	t	2026-10-13 20:26:21.814793	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
16	GEM4000	GEM 4000	Werfen (IL)	BLOODGAS	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.814802	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
17	SYSMEXSUIT	SYSMEXSUIT	Sysmex	HEMATOLOGY	ASTM	\N	\N	t	100	f	NONE	HL7_ORU	t	2026-10-13 20:26:21.814811	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
18	SYSMEX2500	SYSMEX2500	Sysmex	COAG	ASTM	\N	\N	t	100	f	SYSMEX_CS2500	ASTM_SYSMEX	t	2026-10-13 20:26:21.814821	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
19	SYSMEXCA600	SYSMEXCA600	Sysmex	COAG	ASTM	\N	\N	t	100	f	SYSMEX_CA600	ASTM_GENERIC	t	2026-10-13 20:26:21.814834	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
20	CLINTEC	CLINTEC	Siemens	URINE	TEXT	\N	DQ==	t	100	f	NONE	TEXT_CLINTEC	t	2026-10-13 20:26:21.814845	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
21	PENTRA	PENTRA	Horiba ABX	BIOCHEM	ASTM	\N	\N	t	100	f	PENTRA	ASTM_PENTRA	t	2026-10-13 20:26:21.814855	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
22	ABL80	RADIOMETER ABL80	Radiometer	BLOODGAS	ASTM	\N	\N	t	100	f	NONE	ASTM_ABL	t	2026-10-13 20:26:21.814864	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
23	AQT90	RADIOMETER AQT90	Radiometer	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_ABL	t	2026-10-13 20:26:21.814873	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
24	SIEMENS	SIEMENS VANTAGE	Siemens	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.814883	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
25	BIOSYSTEMA15	BIOSYSTEM A15	BioSystems	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	TEXT_TABULAR	t	2026-10-13 20:26:21.814894	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
26	NIHON9100	Nihon 9100	Nihon Kohden	HEMATOLOGY	ASTM	\N	\N	t	100	f	NONE	HL7_ORU	t	2026-10-13 20:26:21.814909	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
27	HUMACOUNT5D	Huma Count 5D	Human	HEMATOLOGY	ASTM	\N	\N	t	100	f	NONE	HL7_MINDRAY	t	2026-10-13 20:26:21.814918	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
28	HUMACOUNT5L	Huma Count 5L	Human	HEMATOLOGY	HUMA5L	AQ==	BA==	t	100	t	NONE	TEXT_CYAN	t	2026-10-13 20:26:21.814926	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
29	MAGLUMI	MAGLUMI	Snibe	IMMUNO	ASTM	\N	\N	t	100	f	MAGLUMI	ASTM_MAGLUMI	t	2026-10-13 20:26:21.814935	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
30	HUMASTAR	Huma Star	Human	BIOCHEM	ASTM	\N	\N	t	100	f	HUMASTAR	ASTM_HUMASTAR	t	2026-10-13 20:26:21.814943	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
31	PRESTIGE	PRESTIGE	Tokyo Boeki (BiOLiS/Prestige 24i)	BIOCHEM	ASTM	\N	\N	t	100	f	PRESTIGE	ASTM_COBAS	t	2026-10-13 20:26:21.814951	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
32	SYSMEXXN	SYSMEXXN	Sysmex	HEMATOLOGY	ASTM_ASK	\N	\N	t	100	f	SYSMEX_XN	ASTM_SYSMEX	t	2026-10-13 20:26:21.814961	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
33	MINDRAY	MINDRAY	Mindray	BIOCHEM	ASTM	\N	\N	t	100	f	MINDRAY_ASTM_BS	ASTM_MINDRAY	t	2026-10-13 20:26:21.814974	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
34	ACCESS	ACCESS	Beckman Coulter	IMMUNO	ASTM	\N	\N	t	100	f	ACCESS_ASTM	ASTM_GENERIC	t	2026-10-13 20:26:21.814985	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
36	BECKMAN	BECKMAN	Beckman Coulter	IMMUNO	ASTM	\N	\N	t	100	f	BECKMAN_ACCESS	ASTM_COBAS	t	2026-10-13 20:26:21.814995	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
37	MINDRAYBS30	MINDRAYBS30	Mindray	BIOCHEM	HL7	\N	\N	t	100	f	NONE	HL7_MINDRAY	t	2026-10-13 20:26:21.815006	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
38	MINDRAY240	MINDRAY240	Mindray	BIOCHEM	HL7	\N	\N	t	100	f	MINDRAY_HL7	HL7_MINDRAY	t	2026-10-13 20:26:21.815016	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
39	MINDRAY3100	MINDRAY3100	Mindray	COAG	HL7	\N	\N	t	100	f	NONE	HL7_MINDRAY	t	2026-10-13 20:26:21.815026	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
40	VITROS5600	VITROS5600	Ortho Clinical Diagnostics	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_VITROS	t	2026-10-13 20:26:21.815039	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
41	ACLTOP300	ACLTOP300	Werfen (IL)	COAG	ASTM	\N	\N	t	500	f	ACLTOP	ASTM_ACLTOP	t	2026-10-13 20:26:21.815049	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
42	URILYZER100PRO	URILYZER100PRO	Analyticon	URINE	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815058	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
43	BECKMANCOULTER500	BECKMANCOULTER500	Beckman Coulter	HEMATOLOGY	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815067	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
44	WONDFOFINECARE	WONDFOFINECARE	Wondfo	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815074	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
45	CYAN	CYAN	Cypress Diagnostics	HEMATOLOGY	CYAN	\N	\N	t	100	f	NONE	TEXT_CYAN	t	2026-10-13 20:26:21.815083	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
46	UWAM	UWAM	77 Elektronika	URINE	ASTM	\N	\N	t	100	f	NONE	ASTM_UWAM	t	2026-10-13 20:26:21.815093	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
47	BIOSYSTEMS	BIOSYSTEMS	BioSystems	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815101	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
48	JUNIOR	JUNIOR	Vital Scientific	BIOCHEM	JUNIOR	\N	\N	t	100	f	NONE	TEXT_JUNIOR	t	2026-10-13 20:26:21.815109	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
49	ACCESS2	ACCESS2	Beckman Coulter	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815119	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
50	UC1000	UC-1000	Urit	URINE	UC1000	Ag==	Aw==	t	100	f	NONE	TEXT_UC1000	t	2026-10-13 20:26:21.81513	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
51	ABL9	RADIOMETER ABL9	Radiometer	BLOODGAS	ASTM	AQ==	\N	t	100	f	NONE	ASTM_ABL	t	2026-10-13 20:26:21.81514	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
52	ICHROMA3	iChroma III	Boditech	IMMUNO	HL7	Cw==	HA==	t	100	f	NONE	HL7_ICHROMA	t	2026-10-13 20:26:21.81515	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
53	IRISIQ200	IRIS IQ 200	Iris / Beckman Coulter	URINE	IRIS	\N	\N	t	100	f	NONE	TEXT_IRIS	t	2026-10-13 20:26:21.815163	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
54	MEK7300	MEK-7300	Nihon Kohden	HEMATOLOGY	ASTM	\N	\N	t	100	f	NONE	ASTM_MEK7300	t	2026-10-13 20:26:21.815174	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
55	APOTI	APOTI	APOTI	IMMUNO	ASTM	\N	DQ==	t	100	f	NONE	TEXT_APOTI	t	2026-10-13 20:26:21.815183	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
56	RAPID	RAPID	Siemens	BLOODGAS	RAPID	Ag==	BA==	t	100	f	RAPID	TEXT_RAPID	t	2026-10-13 20:26:21.815192	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
57	EASYRA	EASYRA	Medica	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815202	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
58	FUJI	FUJI	Fujifilm	BIOCHEM	FUJI	Ag==	Aw==	t	100	f	NONE	TEXT_FUJI	t	2026-10-13 20:26:21.81521	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
59	IFLASH	iFlash	YHLO	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_IFLASH	t	2026-10-13 20:26:21.815218	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
60	BA200	BA200	BioSystems	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815226	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
61	DIRUI_H100	DIRUI H100	Dirui	URINE	TXT	Ag==	Aw==	t	100	f	NONE	TEXT_KEYVALUE	t	2026-10-13 20:26:21.815235	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
62	Phadia 250	Phadia 250	Thermo Fisher (Phadia)	IMMUNO	TXT	Ag==	Aw==	t	100	f	NONE	ASTM_PHADIA	t	2026-10-13 20:26:21.815246	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
63	ELYTEPLUS	ELYTEPLUS	Elyte	BLOODGAS	TXT	U2FtcGxlIFJlcG9ydA==	RW5k	t	100	f	NONE	TEXT_KEYVALUE	t	2026-10-13 20:26:21.815261	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
64	ERBA	ERBA	Erba Mannheim	BIOCHEM	ASTM	\N	\N	t	100	f	NONE	ASTM_ERBA	t	2026-10-13 20:26:21.815271	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
65	TOUCHPRO	TOUCHPRO	TouchPro	IMMUNO	ASTM	\N	\N	t	100	f	NONE	ASTM_GENERIC	t	2026-10-13 20:26:21.815279	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_antibiotic; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_antibiotic (id, code, name, group_name, atc_code, eucast_code, default_disk_content_mcg, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	CIP	Ципрофлоксацин	Фторхінолони	J01MA02	CIP	\N	t	2026-10-13 20:26:21.992421	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	CTX	Цефотаксим	Цефалоспорини	J01DD01	CTX	\N	t	2026-10-13 20:26:21.99266	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	CAZ	Цефтазидим	Цефалоспорини	J01DD02	CAZ	\N	t	2026-10-13 20:26:21.992662	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4	MEM	Меропенем	Карбапенеми	J01DH02	MEM	\N	t	2026-10-13 20:26:21.992664	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5	NIT	Нітрофурантоїн	Нітрофурани	J01XE01	NIT	\N	t	2026-10-13 20:26:21.992665	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6	GEN	Гентаміцин	Аміноглікозиди	J01GB03	GEN	\N	t	2026-10-13 20:26:21.992666	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_archive_cell; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_archive_cell (id, rack_id, row_num, col_num, sample_id, barcode, stored_at, stored_by_id, expiry_at, is_disposed, disposed_at, disposal_reason, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
9d61cc29-b8bd-43cc-afae-f1737a61f3e7	1a1ca3f2-5f6d-4549-a81c-678aa428a936	1	1	2b8abeda-1644-4059-a9d2-6b26d17eefaf	10048016	2026-10-13 20:26:24.978411	0e000000-0000-0000-0000-000000000001	2027-04-11 20:26:24.96066	f	\N	\N	2026-10-13 20:26:24.978332	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f1a725ff-3324-430f-a048-414ffb3aadfe	1a1ca3f2-5f6d-4549-a81c-678aa428a936	1	2	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	10048023	2026-10-13 20:26:25.005153	0e000000-0000-0000-0000-000000000001	2027-04-11 20:26:25.004341	f	\N	\N	2026-10-13 20:26:25.005152	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_archive_rack; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_archive_rack (id, code, name, room_number, freezer_name, shelf_number, temperature_celsius, rows_count, cols_count, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1a1ca3f2-5f6d-4549-a81c-678aa428a936	RACK-A1	Штатив A1 (сироватки, 6 міс.)	104	Морозильник Liebherr LGex-3410 №1	2	-20	8	12	t	2026-10-13 20:26:24.926883	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a27daeda-7310-4f6e-b1a6-dfadd60615fe	RACK-B1	Штатив B1 (кріоархів, -80°C)	104	Ультранизькотемпературний морозильник Haier DW-86L	1	-80	8	12	t	2026-10-13 20:26:25.021523	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_audit_log; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_audit_log (id, user_id, user_name, action, entity, entity_id, before_json, after_json, at, ip, comment, tenant_id) FROM stdin;
17da758d-f89e-4dfe-8195-bfd0a693f72c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	114408bc-3e27-48da-a3da-6cad07265a3d	\N	{"orderNumber":"2610-000001","patientId":"0b000000-0000-0000-0000-000000000001","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT","K","NA"],"samples":["10048016"]}	2026-10-13 20:26:22.413943	seed	\N	d0000000-0000-0000-0000-000000000001
cad23b0e-a37b-4baa-9962-4ab6398103e4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	2b8abeda-1644-4059-a9d2-6b26d17eefaf	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:22.634014Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:22.638089	seed	\N	d0000000-0000-0000-0000-000000000001
963d1ba0-312a-40e0-9aa8-587b14657e8e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	8f40c09c-be25-426b-976e-bd71be23c964	\N	{"code":"BIOCHEM","number":"2026-000001","barcode":"10048016","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT","K","NA"]}	2026-10-13 20:26:22.678073	seed	\N	d0000000-0000-0000-0000-000000000001
cc0c4eb6-fa52-44f2-9d63-f7668a050694	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	2b8abeda-1644-4059-a9d2-6b26d17eefaf	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:22.645542Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:22.67893	seed	\N	d0000000-0000-0000-0000-000000000001
00c2059a-45f9-4c41-9940-1ce1b3301086	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	7964def1-22c9-4015-ba33-98b6d83f262d	\N	{"testCode":"GLU","numeric":5.4,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0413\\u043B\\u044E\\u043A\\u043E\\u0437\\u0430 \\u043D\\u0430\\u0442\\u0449\\u0435"}	2026-10-13 20:26:22.801448	seed	\N	d0000000-0000-0000-0000-000000000001
7c44d242-5b02-4713-8bb2-94ad5cf924fe	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	7f110624-c85b-4411-981a-2caa688e771f	\N	{"testCode":"GLU","releasedAt":"2026-10-13T20:26:22.774439Z"}	2026-10-13 20:26:22.775428	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
3340b3b4-888e-432b-8e90-3c61ac929977	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	ab82ee3c-0c7e-4803-8501-4f84fb670060	\N	{"testCode":"CREAT","numeric":168,"flag":"HIGH","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (HIGH)","layer":"\\u041A\\u0440\\u0435\\u0430\\u0442\\u0438\\u043D\\u0456\\u043D (\\u0447\\u043E\\u043B.)"}	2026-10-13 20:26:22.816215	seed	\N	d0000000-0000-0000-0000-000000000001
e43c9bca-7b93-4919-a496-e69826b5c6e8	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	17f7ceb4-cc4f-4c51-986b-5a0c74e6812e	\N	{"testCode":"UREA","numeric":12.1,"flag":"HIGH","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (HIGH)","layer":"\\u0421\\u0435\\u0447\\u043E\\u0432\\u0438\\u043D\\u0430"}	2026-10-13 20:26:22.823972	seed	\N	d0000000-0000-0000-0000-000000000001
0e2b7049-b3c6-461c-860e-b68287e9799e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	f825460d-a54c-49f9-aabe-cc7091189551	\N	{"testCode":"ALT","releasedAt":"2026-10-13T20:26:22.833726Z"}	2026-10-13 20:26:22.833735	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
1a1281ee-018d-4cb8-8fb7-43fae3ba439e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	0747357d-274c-4c28-91ef-4a1b00dc29eb	\N	{"testCode":"ALT","numeric":28,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u041B\\u0422"}	2026-10-13 20:26:22.836036	seed	\N	d0000000-0000-0000-0000-000000000001
5c8cd403-422a-46bb-af54-10db395e93a1	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	44c2fe4e-03b0-4789-97e5-5b09772cde61	\N	{"testCode":"AST","releasedAt":"2026-10-13T20:26:22.845629Z"}	2026-10-13 20:26:22.84564	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
837d76af-dc94-4e9a-8fb2-8405ed0ba2ba	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	cd39d3aa-2abf-426d-a8f6-d9064237f5af	\N	{"testCode":"AST","numeric":24,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u0421\\u0422"}	2026-10-13 20:26:22.847852	seed	\N	d0000000-0000-0000-0000-000000000001
5db4af38-1830-4195-bca7-f6dc35345fb4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	b80b666b-291c-444e-83a6-8893beca5f6a	\N	{"testCode":"BIL_TOT","numeric":11.2,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0411\\u0456\\u043B\\u0456\\u0440\\u0443\\u0431\\u0456\\u043D \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-13 20:26:22.860044	seed	\N	d0000000-0000-0000-0000-000000000001
9e2674b0-03ed-44a8-8073-11840ac64992	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	059f6563-49ba-4cdc-bd27-ac17b9d9e36a	\N	{"testCode":"BIL_TOT","releasedAt":"2026-10-13T20:26:22.857588Z"}	2026-10-13 20:26:22.857606	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
1157c052-5457-4277-8c92-79fe56fd1d50	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	c566874b-5979-4eef-8f00-a7bd2d020914	\N	{"testCode":"PROT_TOT","numeric":71,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0411\\u0456\\u043B\\u043E\\u043A \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-13 20:26:22.872235	seed	\N	d0000000-0000-0000-0000-000000000001
4f95ecb3-eca5-4e50-b3af-5e31f1b4dd7c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	4e1a6b24-2ff4-49dd-bb27-a711976ff771	\N	{"testCode":"PROT_TOT","releasedAt":"2026-10-13T20:26:22.870076Z"}	2026-10-13 20:26:22.870084	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
f9cf05a5-17ce-49aa-b2f1-a200a7b570ec	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	09f66487-3a79-463a-99bf-d8549909f744	\N	{"testCode":"K","numeric":6.8,"flag":"CRIT_HIGH","isAlert":false,"autoVerified":false,"block":"\\u041A\\u0440\\u0438\\u0442\\u0438\\u0447\\u043D\\u0435 (\\u043F\\u0430\\u043D\\u0456\\u0447\\u043D\\u0435) \\u0437\\u043D\\u0430\\u0447\\u0435\\u043D\\u043D\\u044F \\u2014 \\u043F\\u043E\\u0442\\u0440\\u0456\\u0431\\u0435\\u043D \\u043B\\u0456\\u043A\\u0430\\u0440-\\u043B\\u0430\\u0431\\u043E\\u0440\\u0430\\u043D\\u0442","layer":"\\u041A\\u0430\\u043B\\u0456\\u0439"}	2026-10-13 20:26:22.880375	seed	\N	d0000000-0000-0000-0000-000000000001
5a67bae4-9fa4-4a88-99e4-2c5496a07b83	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	bcf34132-f53c-4919-8087-64b25e2eac34	\N	{"testCode":"GLU","measuredValue":4.3,"zScore":0.8,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.869749	seed	\N	d0000000-0000-0000-0000-000000000001
7af64832-7d7f-4eef-a0db-19c56d542336	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	c279bc98-a741-4831-b5a0-d96ac7abb262	\N	{"testCode":"NA","numeric":134,"flag":"LOW","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (LOW)","layer":"\\u041D\\u0430\\u0442\\u0440\\u0456\\u0439"}	2026-10-13 20:26:22.888814	seed	\N	d0000000-0000-0000-0000-000000000001
380c726f-aa38-4f9c-bc29-33384573917f	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	TEST_RELEASED	lab_order_test	d6039ece-8620-408f-890f-b550e5568dc8	\N	{"testCode":"CREAT","releasedAt":"2026-10-13T20:26:22.907812Z"}	2026-10-13 20:26:22.907859	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
99c8abac-15c6-4107-827c-cb777b7b6853	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	VERIFY	lab_test_result	ab82ee3c-0c7e-4803-8501-4f84fb670060	{"status":"RESULTED"}	{"status":"VERIFIED","override":false,"lockoutOverride":false}	2026-10-13 20:26:22.911307	seed	\N	d0000000-0000-0000-0000-000000000001
39cec538-b037-4ff4-b02d-a6e5bb237991	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	VERIFY	lab_test_result	17f7ceb4-cc4f-4c51-986b-5a0c74e6812e	{"status":"RESULTED"}	{"status":"VERIFIED","override":false,"lockoutOverride":false}	2026-10-13 20:26:22.923911	seed	\N	d0000000-0000-0000-0000-000000000001
61d1d357-171a-4856-8589-52401d539e9b	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	TEST_RELEASED	lab_order_test	05d422f7-71b2-4fa9-ad42-3a2e688e1430	\N	{"testCode":"UREA","releasedAt":"2026-10-13T20:26:22.921707Z"}	2026-10-13 20:26:22.921723	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
9f693532-4759-4652-9238-ff291bb9fb62	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	VERIFY	lab_test_result	09f66487-3a79-463a-99bf-d8549909f744	{"status":"NEEDS_REVIEW"}	{"status":"VERIFIED","comment":"\\u041A\\u0440\\u0438\\u0442\\u0438\\u0447\\u043D\\u0430 \\u0433\\u0456\\u043F\\u0435\\u0440\\u043A\\u0430\\u043B\\u0456\\u0454\\u043C\\u0456\\u044F 6.8 \\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B \\u2014 \\u043F\\u043E\\u0432\\u0456\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u043E \\u043B\\u0456\\u043A\\u0443\\u044E\\u0447\\u043E\\u0433\\u043E \\u043B\\u0456\\u043A\\u0430\\u0440\\u044F \\u0442\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\\u043E\\u043C","override":false,"lockoutOverride":false}	2026-10-13 20:26:22.936649	seed	\N	d0000000-0000-0000-0000-000000000001
a7a07ef7-d546-464c-862e-8b545f19f512	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	TEST_RELEASED	lab_order_test	84e295a9-d52f-4d29-926a-d2a78dadd0e6	\N	{"testCode":"K","releasedAt":"2026-10-13T20:26:22.934299Z"}	2026-10-13 20:26:22.934321	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
28d85b6a-5a62-4372-96b3-e9660960698d	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	TEST_RELEASED	lab_order_test	016beec8-2e7f-4071-8246-528692149153	\N	{"testCode":"NA","releasedAt":"2026-10-13T20:26:22.947814Z"}	2026-10-13 20:26:22.947852	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
720f88a4-6fa5-424d-ac01-ea314b751b2f	0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	VERIFY	lab_test_result	c279bc98-a741-4831-b5a0-d96ac7abb262	{"status":"RESULTED"}	{"status":"VERIFIED","override":false,"lockoutOverride":false}	2026-10-13 20:26:22.9506	seed	\N	d0000000-0000-0000-0000-000000000001
65ab11ee-dad8-4586-a9f3-8adeb7f6a995	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RELEASE	lab_order	114408bc-3e27-48da-a3da-6cad07265a3d	{"status":"COMPLETED"}	{"status":"RELEASED","releasedAt":"2026-10-13T20:26:22.966674Z","verifyToken":"s40paRplqtFucxPXli-3CshDHZRTrPNjoAvXf1MsdtM"}	2026-10-13 20:26:22.994198	seed	\N	d0000000-0000-0000-0000-000000000001
0e9d3720-bef1-4dbb-86ba-f5d9a00fb724	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_panic_call	aecd5fa5-ccd9-4b28-a28c-cc25cecf6eeb	\N	{"resultId":"09f66487-3a79-463a-99bf-d8549909f744","orderId":"114408bc-3e27-48da-a3da-6cad07265a3d","patientName":"\\u041A\\u043E\\u0432\\u0430\\u043B\\u0435\\u043D\\u043A\\u043E \\u041E\\u043B\\u0435\\u0433 \\u0406\\u0432\\u0430\\u043D\\u043E\\u0432\\u0438\\u0447","testCode":"K","value":"6.80 \\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","doctorNotifiedName":"\\u0406\\u0432\\u0430\\u043D\\u0447\\u0443\\u043A \\u041C.\\u041F. (\\u043D\\u0435\\u0444\\u0440\\u043E\\u043B\\u043E\\u0433)","phone":"\\u002B380501234567","department":"\\u041D\\u0435\\u0444\\u0440\\u043E\\u043B\\u043E\\u0433\\u0456\\u0447\\u043D\\u0435 \\u0432\\u0456\\u0434\\u0434\\u0456\\u043B\\u0435\\u043D\\u043D\\u044F","readbackConfirmed":true,"notifiedById":"0e000000-0000-0000-0000-000000000001","notifiedAt":"2026-10-13T20:26:23.023313Z","comments":"\\u041F\\u043E\\u0432\\u0456\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u043E \\u043F\\u0440\\u043E \\u041A 6.8 \\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B, \\u043F\\u0440\\u0438\\u0437\\u043D\\u0430\\u0447\\u0435\\u043D\\u043E \\u0415\\u041A\\u0413 \\u0442\\u0430 \\u043A\\u043E\\u0440\\u0435\\u043A\\u0446\\u0456\\u044E","id":"aecd5fa5-ccd9-4b28-a28c-cc25cecf6eeb","createdOn":"2026-10-13T20:26:23.023148Z","createdBy":"00000000-0000-0000-0000-000000000000","modifiedBy":"00000000-0000-0000-0000-000000000000","recordState":2}	2026-10-13 20:26:23.032241	seed	\N	d0000000-0000-0000-0000-000000000001
bacf00b5-57c6-41b2-9439-ffe7a66f297f	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	e22b5f66-51fd-4228-aec6-0d40ffe71e59	\N	{"orderNumber":"2610-000002","patientId":"0b000000-0000-0000-0000-000000000002","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT"],"samples":["10048023"]}	2026-10-13 20:26:23.067221	seed	\N	d0000000-0000-0000-0000-000000000001
3bbc3052-4b32-42d1-9fb7-2fc0235c06e2	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.078008Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.078057	seed	\N	d0000000-0000-0000-0000-000000000001
50c706b7-ece0-4fdc-b990-89d3a644d4db	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	ee9c53db-17b7-4054-95a6-9ce47756bae2	\N	{"code":"BIOCHEM","number":"2026-000002","barcode":"10048023","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT"]}	2026-10-13 20:26:23.090891	seed	\N	d0000000-0000-0000-0000-000000000001
a9fb59e8-b101-4051-bce1-c94d794076d6	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.084841Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.090973	seed	\N	d0000000-0000-0000-0000-000000000001
2655d449-10c3-4bb4-a3d1-fdaf75d1e77e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	3ff7b478-e872-4003-97dd-cc8a3543dac9	\N	{"testCode":"GLU","releasedAt":"2026-10-13T20:26:23.107243Z"}	2026-10-13 20:26:23.10729	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
f6ea6c4b-13b7-4e24-ab85-d815bc558d60	CONNECTOR:0c0c0000-0000-0000-0000-000000000001	Демо-коннектор (mock)	REGISTER	lab_connector_installation	0c0c0000-0000-0000-0000-000000000001	\N	{"HostName":"t-check","OsDescription":"macOS","Version":"t-check"}	2026-10-26 11:58:34.264475	\N	\N	d0000000-0000-0000-0000-000000000001
5ef3873b-70bc-4fa8-8074-703d3fe35d48	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	c43b5ed8-27a9-4509-8727-ca00b4d00425	\N	{"testCode":"GLU","numeric":5.1,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0413\\u043B\\u044E\\u043A\\u043E\\u0437\\u0430 \\u043D\\u0430\\u0442\\u0449\\u0435"}	2026-10-13 20:26:23.112736	seed	\N	d0000000-0000-0000-0000-000000000001
5809c375-3330-46a5-8eef-817568a94482	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	64d67447-5181-43f4-a551-5c8c102385fb	\N	{"testCode":"CREAT","releasedAt":"2026-10-13T20:26:23.125171Z"}	2026-10-13 20:26:23.125194	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
61bfb042-5ec5-45ac-a385-20d492e16a87	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	5d84bbf9-23dd-4340-8527-04bb07c160b5	\N	{"testCode":"CREAT","numeric":74,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u041A\\u0440\\u0435\\u0430\\u0442\\u0438\\u043D\\u0456\\u043D (\\u0436\\u0456\\u043D.)"}	2026-10-13 20:26:23.127614	seed	\N	d0000000-0000-0000-0000-000000000001
1306c47c-e844-4001-92c0-ae22ec3df7d4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	1435ed7d-85ab-41ee-a0e2-d9240b5aa4c1	\N	{"testCode":"UREA","numeric":4.9,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0421\\u0435\\u0447\\u043E\\u0432\\u0438\\u043D\\u0430"}	2026-10-13 20:26:23.141087	seed	\N	d0000000-0000-0000-0000-000000000001
4bf5cb28-9af3-41a4-8c05-830670f7f661	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	d7ef4b25-87fe-4bab-93e0-c883f08f8fa6	\N	{"testCode":"UREA","releasedAt":"2026-10-13T20:26:23.138661Z"}	2026-10-13 20:26:23.138673	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
cba416a8-a67d-4af3-9b61-1ffa6680f54f	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	6c1c37da-c906-461a-8443-03944caeff85	\N	{"testCode":"ALT","numeric":22,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u041B\\u0422"}	2026-10-13 20:26:23.15608	seed	\N	d0000000-0000-0000-0000-000000000001
d19e40a6-5cb8-4c9e-bbb7-18c5e47252f4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	b72e059f-c55c-4bab-8cbb-7cad8a4f41a7	\N	{"testCode":"ALT","releasedAt":"2026-10-13T20:26:23.153265Z"}	2026-10-13 20:26:23.153304	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
548c4017-4f27-4363-8179-b6cdaf6cdbb5	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	83c647cc-65ac-45d9-a1cd-90b5c8a6b2f6	\N	{"testCode":"AST","numeric":20,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u0421\\u0422"}	2026-10-13 20:26:23.169809	seed	\N	d0000000-0000-0000-0000-000000000001
b91ba463-1368-4c1f-a3c6-185c10695753	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	31ea1f40-2ebb-430a-a184-b4a3d7fa2828	\N	{"testCode":"AST","releasedAt":"2026-10-13T20:26:23.167156Z"}	2026-10-13 20:26:23.167176	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
23b1899a-5d4c-4a95-8617-56d4cfcebcef	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	4b785e89-c2fd-4c32-a0a5-f61119670a95	\N	{"testCode":"BIL_TOT","numeric":9.8,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0411\\u0456\\u043B\\u0456\\u0440\\u0443\\u0431\\u0456\\u043D \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-13 20:26:23.18385	seed	\N	d0000000-0000-0000-0000-000000000001
f2390d70-000d-475c-944c-74031363c96c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	9d217a05-6d9d-44ab-a281-a3052e8cdb6b	\N	{"testCode":"BIL_TOT","releasedAt":"2026-10-13T20:26:23.181266Z"}	2026-10-13 20:26:23.181275	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
87565444-451e-4832-8685-5f0653464494	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	a3f4e07b-1b8a-414f-bcf5-5f837596d5e1	\N	{"testCode":"PROT_TOT","numeric":73,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0411\\u0456\\u043B\\u043E\\u043A \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-13 20:26:23.199673	seed	\N	d0000000-0000-0000-0000-000000000001
f000fae3-7be9-4cc9-bdc2-8bc12119440e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	dc1789e1-b032-4056-a21f-d3f0dc675b2b	\N	{"testCode":"PROT_TOT","releasedAt":"2026-10-13T20:26:23.19699Z"}	2026-10-13 20:26:23.197014	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
e73eb948-a3f0-42fb-b01c-e2e15f44d997	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RELEASE	lab_order	e22b5f66-51fd-4228-aec6-0d40ffe71e59	{"status":"COMPLETED"}	{"status":"RELEASED","releasedAt":"2026-10-13T20:26:23.216755Z","verifyToken":"RybG4E2jJdC3PtBRZ4Vaikml0LZ6sbvDE5dYF2s0HQM"}	2026-10-13 20:26:23.217134	seed	\N	d0000000-0000-0000-0000-000000000001
3a48707c-e57f-4e84-8dcb-3084ccaa0885	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	EHEALTH_REFERRAL_USE	ehe_incoming_medical_referral	0c0f0000-0000-0000-0000-000000000002	\N	{"regNumber":"MOCK-0002-0002","orderNumber":"2610-000003"}	2026-10-13 20:26:23.354669	seed	\N	d0000000-0000-0000-0000-000000000001
f5ff4b58-212d-4c54-a73d-7e74fba02daa	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	b76dd818-1d59-47bb-953c-35e581dd8fa1	\N	{"orderNumber":"2610-000003","patientId":"0b000000-0000-0000-0000-000000000002","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT"],"samples":["10048030"]}	2026-10-13 20:26:23.359532	seed	\N	d0000000-0000-0000-0000-000000000001
069a4880-4e31-4ad6-a419-56127c51508f	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	9e651e03-452e-4a9f-9de9-387c2e51caaf	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.373816Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.373857	seed	\N	d0000000-0000-0000-0000-000000000001
76d75d14-7781-4084-8ce3-11c60de1ffae	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	c680b967-75f3-4502-8371-9712d59060ab	\N	{"code":"BIOCHEM","number":"2026-000003","barcode":"10048030","tests":["GLU","CREAT","UREA","ALT","AST","BIL_TOT","PROT_TOT"]}	2026-10-13 20:26:23.387672	seed	\N	d0000000-0000-0000-0000-000000000001
a58a61ed-093b-4836-9ab6-cb5e9c487850	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	9e651e03-452e-4a9f-9de9-387c2e51caaf	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.382579Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.387717	seed	\N	d0000000-0000-0000-0000-000000000001
28d6d328-9722-4bec-9e17-5cdaeaaf013c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	78b9024c-5154-45ec-b98a-557370793b4a	\N	{"testCode":"GLU","numeric":7.9,"flag":"HIGH","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (HIGH)","layer":"\\u0413\\u043B\\u044E\\u043A\\u043E\\u0437\\u0430 \\u043D\\u0430\\u0442\\u0449\\u0435"}	2026-10-13 20:26:23.401178	seed	\N	d0000000-0000-0000-0000-000000000001
ab3ca627-7ea5-4ed4-9cae-3d6d0921b2a6	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	962c53a9-c43e-49b4-9063-4030fc8eae43	\N	{"testCode":"CREAT","numeric":76,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u041A\\u0440\\u0435\\u0430\\u0442\\u0438\\u043D\\u0456\\u043D (\\u0436\\u0456\\u043D.)"}	2026-10-13 20:26:23.421076	seed	\N	d0000000-0000-0000-0000-000000000001
ff298d44-fbe7-49be-bc70-c5392070cb49	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	ac4a2f93-b7aa-4626-a04e-bce186a8e98f	\N	{"testCode":"CREAT","releasedAt":"2026-10-13T20:26:23.416957Z"}	2026-10-13 20:26:23.417006	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
581bffb2-9b27-440c-8ce4-f9b5406373c7	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	7a553110-fda7-472b-a23f-ac1f54833c27	\N	{"testCode":"UREA","numeric":5.2,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0421\\u0435\\u0447\\u043E\\u0432\\u0438\\u043D\\u0430"}	2026-10-13 20:26:23.44019	seed	\N	d0000000-0000-0000-0000-000000000001
a6da830f-3a12-4a9f-8c71-552b426a625d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	613b3264-5098-4615-927a-5bbd7879a99a	\N	{"testCode":"UREA","releasedAt":"2026-10-13T20:26:23.436453Z"}	2026-10-13 20:26:23.436477	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
2aabdc30-b055-4ef1-b634-73c103c7c185	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	8d41a71e-c391-48c1-bf82-7cb736d79f75	\N	{"testCode":"ALT","releasedAt":"2026-10-13T20:26:23.454876Z"}	2026-10-13 20:26:23.454902	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
adc1f325-3d4f-4cff-8d6e-2f0a74a2a148	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	9b43db16-6326-4f31-859d-2fad738f8ae2	\N	{"testCode":"ALT","numeric":24,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u041B\\u0422"}	2026-10-13 20:26:23.458696	seed	\N	d0000000-0000-0000-0000-000000000001
bd6e175b-0a09-41af-8cac-ae111db10a55	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	71596032-c634-4499-af42-7563c4e2b6b1	\N	{"testCode":"AST","numeric":21,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u0421\\u0422"}	2026-10-13 20:26:23.476758	seed	\N	d0000000-0000-0000-0000-000000000001
eeb988ab-45d5-4675-9120-69f0d2e8c719	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	7499aa35-d33d-4443-9a19-a91e1562b1a6	\N	{"testCode":"AST","releasedAt":"2026-10-13T20:26:23.473161Z"}	2026-10-13 20:26:23.473171	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
56623fdf-0d0b-450c-a619-7c990c0c3355	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	65cf762d-b666-41f7-bdf6-e7fcac26995a	\N	{"orderNumber":"2610-000004","patientId":"0b000000-0000-0000-0000-000000000003","tests":["PT","INR","APTT","FIBRINOGEN","PSA"],"samples":["10048047","10048054"]}	2026-10-13 20:26:23.500102	seed	\N	d0000000-0000-0000-0000-000000000001
2240f212-9049-42c2-b2d9-8d1f9d686d72	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	fec1fff2-f554-4327-b431-28f39f1784b6	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.513755Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.513802	seed	\N	d0000000-0000-0000-0000-000000000001
36bc0268-8577-4426-9f8e-aa474da4a605	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	0b186f9a-0cd4-405a-89cc-9d1bfd801a30	\N	{"code":"COAG","number":"2026-000001","barcode":"10048047","tests":["PT","INR","APTT","FIBRINOGEN"]}	2026-10-13 20:26:23.543554	seed	\N	d0000000-0000-0000-0000-000000000001
4be090bb-881e-4c04-b9bb-cc288f75831b	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	fec1fff2-f554-4327-b431-28f39f1784b6	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.522645Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.543592	seed	\N	d0000000-0000-0000-0000-000000000001
14a4a79c-c85b-4de2-94e2-db2702848cdb	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	61493080-29f3-4505-bf3e-f3e4a992953c	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.552622Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.552647	seed	\N	d0000000-0000-0000-0000-000000000001
554b59ab-f3af-446a-8ec9-fa63c2b90cbf	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	dbf515ae-6fb2-4fce-a0ab-1d2be9c5dc01	\N	{"code":"IMMUNO","number":"2026-000001","barcode":"10048054","tests":["PSA"]}	2026-10-13 20:26:23.581218	seed	\N	d0000000-0000-0000-0000-000000000001
d4000335-b83c-4674-8921-d003db30eb68	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	61493080-29f3-4505-bf3e-f3e4a992953c	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.561242Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.581246	seed	\N	d0000000-0000-0000-0000-000000000001
7f46a815-5348-4823-85fd-247a51303949	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	6dd75bb6-4788-4a55-9171-1dafda27eb0a	\N	{"testCode":"PT","releasedAt":"2026-10-13T20:26:23.597688Z"}	2026-10-13 20:26:23.597707	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
b8a052e2-3d80-4b0f-aa27-29c09a90d1b7	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	af08200d-61b5-459c-9e44-c2d8ded7868b	\N	{"testCode":"PT","numeric":13.1,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u041F\\u0440\\u043E\\u0442\\u0440\\u043E\\u043C\\u0431\\u0456\\u043D\\u043E\\u0432\\u0438\\u0439 \\u0447\\u0430\\u0441"}	2026-10-13 20:26:23.601656	seed	\N	d0000000-0000-0000-0000-000000000001
9380af92-e67b-4134-a7fc-236b0577c888	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	657c9446-85ad-4edb-a604-98c96b744258	\N	{"testCode":"GLU","measuredValue":4.15,"zScore":-0.7,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.880538	seed	\N	d0000000-0000-0000-0000-000000000001
25342476-b09e-44f2-a256-8e363275acf2	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	c6dd2b05-0463-46c2-8906-f4e3ede4e6ab	\N	{"testCode":"INR","numeric":2.6,"flag":"HIGH","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (HIGH)","layer":"\\u041C\\u041D\\u0412"}	2026-10-13 20:26:23.613037	seed	\N	d0000000-0000-0000-0000-000000000001
0594911a-3b30-4c7c-a0dc-d99316bcd1f2	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	d6efb458-7bd7-4cdb-8975-3ba9bf52eaa0	\N	{"testCode":"APTT","numeric":31,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0410\\u0427\\u0422\\u0427"}	2026-10-13 20:26:23.631483	seed	\N	d0000000-0000-0000-0000-000000000001
e4468069-0f8a-4b0b-9077-be6082496333	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	241d88c6-7efa-46a8-83fc-91870d3ada30	\N	{"testCode":"APTT","releasedAt":"2026-10-13T20:26:23.627641Z"}	2026-10-13 20:26:23.627651	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
011492a5-aa84-4513-95de-cdd7fbc88400	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	facd213b-5bb6-4de2-9e70-6a1c9d5cf4da	\N	{"testCode":"FIBRINOGEN","releasedAt":"2026-10-13T20:26:23.64638Z"}	2026-10-13 20:26:23.646389	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
5849c7e9-5b2a-459b-a888-03eb21d9a143	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	6d62a5ab-e1c4-4ffc-96fc-e7e358bdfa30	\N	{"testCode":"FIBRINOGEN","numeric":3.1,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0424\\u0456\\u0431\\u0440\\u0438\\u043D\\u043E\\u0433\\u0435\\u043D"}	2026-10-13 20:26:23.650313	seed	\N	d0000000-0000-0000-0000-000000000001
0aa242f3-0329-4c0e-897d-2df9ea55f25a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	222a9697-e00c-4a63-b057-f52e2d173c5f	\N	{"testCode":"PSA","numeric":5.2,"flag":"HIGH","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (HIGH)","layer":"\\u041F\\u0421\\u0410 \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-13 20:26:23.667012	seed	\N	d0000000-0000-0000-0000-000000000001
876b9a42-7f1e-4552-9961-c68976c064f7	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	REFLEX_CREATED	lab_order_test	31743f9f-e5af-4240-97f7-db32e41e81c7	\N	{"id":"0f1e0000-0000-0000-0000-000000000001","reason":"PSA = 5.2 \\u003E 4 \\u2192 \\u0434\\u043E\\u0434\\u0430\\u043D\\u043E FPSA","testCode":"FPSA","reflexNeedsConfirmation":false}	2026-10-13 20:26:23.666955	seed	ПСА > 4 нг/мл → додати вільний ПСА	d0000000-0000-0000-0000-000000000001
fd8eafe1-12f6-4d01-8191-840b1fbfc4aa	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	bcf1d023-88a2-494b-bee3-1ed451977065	\N	{"orderNumber":"2610-000005","patientId":"0b000000-0000-0000-0000-000000000004","tests":["TSH","FT4","GLU","HGB"],"samples":["10048061","10048078"]}	2026-10-13 20:26:23.690531	seed	\N	d0000000-0000-0000-0000-000000000001
ec4db17d-3bfa-43d4-97a0-87cd9025d329	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	0f58869c-1172-4434-b957-b763b05c34a0	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.705254Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.70529	seed	\N	d0000000-0000-0000-0000-000000000001
31e3462c-6565-499d-9395-912cf3fa5a95	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	dce6d055-ba9b-4407-895d-a867946fa7e5	\N	{"code":"BIOCHEM","number":"2026-000004","barcode":"10048061","tests":["GLU"]}	2026-10-13 20:26:23.725088	seed	\N	d0000000-0000-0000-0000-000000000001
64419745-0a0b-4774-9081-350269c4788a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	0f58869c-1172-4434-b957-b763b05c34a0	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.714992Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.725112	seed	\N	d0000000-0000-0000-0000-000000000001
73d3f901-2d82-43da-80ee-75b6f62c91e4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	be88ed22-4ea6-40fe-8a83-1d058ccc6388	\N	{"code":"IMMUNO","number":"2026-000002","barcode":"10048061","tests":["TSH","FT4"]}	2026-10-13 20:26:23.720192	seed	\N	d0000000-0000-0000-0000-000000000001
dd72edbb-ab73-44f6-a180-a9eac4140755	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	f9331816-6c3a-4992-b300-15ba7d743ac2	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.734971Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.734994	seed	\N	d0000000-0000-0000-0000-000000000001
5aae0397-13bf-425b-afea-065a3d1326ab	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	f9331816-6c3a-4992-b300-15ba7d743ac2	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.744704Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.766336	seed	\N	d0000000-0000-0000-0000-000000000001
e909e8b2-f6e7-4caf-b408-becd638b3c99	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	310bae07-17eb-42e9-b7d1-26fcdc7a0ff4	\N	{"code":"HEMA","number":"2026-000001","barcode":"10048078","tests":["HGB"]}	2026-10-13 20:26:23.766306	seed	\N	d0000000-0000-0000-0000-000000000001
050aea90-3980-46a0-a2b4-6b003db824dc	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	44810dce-2ac6-474e-9dd6-20791ec23cd3	\N	{"testCode":"GLU","releasedAt":"2026-10-13T20:26:23.784024Z"}	2026-10-13 20:26:23.784039	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
a20a451b-369f-4a7b-bebb-3bdaa97ac72d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	f5780c0a-01d3-456b-9b65-2e541fd9ebd8	\N	{"testCode":"GLU","numeric":5.2,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0413\\u043B\\u044E\\u043A\\u043E\\u0437\\u0430 \\u043D\\u0430\\u0442\\u0449\\u0435"}	2026-10-13 20:26:23.788285	seed	\N	d0000000-0000-0000-0000-000000000001
4f59bfb0-d206-40e5-83c4-66af8c4b36bf	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	3bf2cc20-7e64-46e3-9304-02e3d4df958d	\N	{"testCode":"TSH","numeric":3.5,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0422\\u0422\\u0413"}	2026-10-13 20:26:23.808151	seed	\N	d0000000-0000-0000-0000-000000000001
cacb946e-77f4-4960-8dba-c28184117aaa	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	14f33f52-b961-407b-8d6a-d6ddf8701287	\N	{"testCode":"TSH","releasedAt":"2026-10-13T20:26:23.803843Z"}	2026-10-13 20:26:23.803853	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
04def3f0-aa22-4207-b02c-e2974f991ef1	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	\N	{"orderNumber":"2610-000006","patientId":"0b000000-0000-0000-0000-000000000005","tests":["WBC","HGB","RBC","PLT"],"samples":["10048085"]}	2026-10-13 20:26:23.831638	seed	\N	d0000000-0000-0000-0000-000000000001
d25d5183-3d18-45db-a0be-c45a36108ce8	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	4034c91e-665b-4903-a8f1-d053d0c27082	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.845086Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.845116	seed	\N	d0000000-0000-0000-0000-000000000001
15caaf2f-0a66-4560-903c-24f99c94f4ac	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_sample_logistics	663f0f1c-3676-4bc2-985b-2122e15b0602	\N	{"manifestNumber":"MAN-261013-0001","status":"DISPATCHED","barcodes":["10048085"]}	2026-10-13 20:26:23.894267	seed	\N	d0000000-0000-0000-0000-000000000001
10cc2894-2b73-4372-8cc5-779c78c042a0	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	89300002-0d46-4073-b5c6-271443e1ea3d	\N	{"orderNumber":"2610-000007","patientId":"0b000000-0000-0000-0000-000000000006","tests":["U_COLOR","U_CLARITY","U_SG","U_PH","U_PRO","U_GLU","U_KET","U_LEU","U_ERY","U_NIT","URINE_CULTURE"],"samples":["10048092","10048108"]}	2026-10-13 20:26:23.925249	seed	\N	d0000000-0000-0000-0000-000000000001
7a1f2264-4107-4b74-9c00-507ef4ba90dd	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	536f7f44-6cd8-4283-acf8-3883bfe18dd7	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.942268Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.942303	seed	\N	d0000000-0000-0000-0000-000000000001
34a3eea8-f63e-45a6-85cc-0dc20744c7a5	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	536f7f44-6cd8-4283-acf8-3883bfe18dd7	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.95307Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:23.976235	seed	\N	d0000000-0000-0000-0000-000000000001
e28e8277-17cf-4369-ad84-13c86eb42314	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	8d3494be-2b7d-4e8d-a855-de8a2bfdbfbf	\N	{"code":"URINE","number":"2026-000001","barcode":"10048092","tests":["U_COLOR","U_CLARITY","U_SG","U_PH","U_PRO","U_GLU","U_KET","U_LEU","U_ERY","U_NIT"]}	2026-10-13 20:26:23.976208	seed	\N	d0000000-0000-0000-0000-000000000001
b1fef867-1418-4adc-a2f7-c09457dc7aec	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	COLLECT	lab_order_sample	42e9f3d4-cd58-4081-ab17-87bea65efcbc	{"status":"PENDING"}	{"status":"COLLECTED","collectedAt":"2026-10-13T20:26:23.986287Z","checklist":{"idVerified":true,"fasting":true,"orderOfDraw":true,"mixing":true}}	2026-10-13 20:26:23.986306	seed	\N	d0000000-0000-0000-0000-000000000001
72f1ac44-0ce6-4e24-b094-37b996bb3285	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	JOURNAL_REGISTER	lab_section_journal_entry	b7783d74-4ec2-4374-b276-b6e6aa6b2d28	\N	{"code":"MICRO","number":"2026-000001","barcode":"10048108","tests":["URINE_CULTURE"]}	2026-10-13 20:26:24.019089	seed	\N	d0000000-0000-0000-0000-000000000001
ffd2ea1e-bfef-4802-892d-1584b92fbe0c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RECEIVE	lab_order_sample	42e9f3d4-cd58-4081-ab17-87bea65efcbc	{"status":"COLLECTED"}	{"status":"RECEIVED","receivedAt":"2026-10-13T20:26:23.996264Z","req":{"isHemolyzed":false,"isLipemic":false,"isIcteric":false,"isClotted":false,"isInsufficientVolume":false}}	2026-10-13 20:26:24.019116	seed	\N	d0000000-0000-0000-0000-000000000001
74655a53-b017-430c-a3e5-9a72225f9d11	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	a75219d2-b1af-4045-bb9d-218cd7645f35	\N	{"testCode":"U_COLOR","text":"\\u0436\\u043E\\u0432\\u0442\\u0438\\u0439","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.035684	seed	\N	d0000000-0000-0000-0000-000000000001
7f262aec-ac41-45a9-b821-cb537cb4f021	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	f77fd11c-2c15-40be-89d8-2ac09ab917c7	\N	{"testCode":"U_CLARITY","text":"\\u043C\\u0443\\u0442\\u043D\\u0430","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.048736	seed	\N	d0000000-0000-0000-0000-000000000001
eedf804f-e508-4a70-9583-c5c3691d1f54	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	ca11ac3b-c0eb-4d93-8588-5116fe7e9418	\N	{"testCode":"U_PRO","text":"\\u0441\\u043B\\u0456\\u0434\\u0438","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.061706	seed	\N	d0000000-0000-0000-0000-000000000001
96d22fcc-0476-4568-8efc-d904026a4010	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	6e7e9d62-cfad-47d3-aee9-1d9d08eb4ca3	\N	{"testCode":"U_GLU","text":"\\u043D\\u0435 \\u0432\\u0438\\u044F\\u0432\\u043B\\u0435\\u043D\\u043E","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.075152	seed	\N	d0000000-0000-0000-0000-000000000001
59f80eae-4758-4bf4-abb1-ddfd86823ef0	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	38b71a30-a867-4f93-9755-2565b1f5b6e5	\N	{"testCode":"U_KET","text":"\\u043D\\u0435 \\u0432\\u0438\\u044F\\u0432\\u043B\\u0435\\u043D\\u043E","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.089234	seed	\N	d0000000-0000-0000-0000-000000000001
6b2e5ac2-7ab4-4784-ad7a-e3029f42fdf9	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	83649285-9e83-446b-9150-f70e19bcf3af	\N	{"testCode":"U_LEU","text":"\\u002B\\u002B\\u002B","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.102315	seed	\N	d0000000-0000-0000-0000-000000000001
cdeab61e-f9e4-459f-b8a1-1d6b720101f1	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	cdc1cf59-5a03-44c1-8238-e74020e90251	\N	{"testCode":"U_ERY","text":"\\u002B","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.116264	seed	\N	d0000000-0000-0000-0000-000000000001
c902afb2-f559-4bff-b24d-746a96b67d93	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	80d4b5b7-b2cf-42cf-a409-c413cab37ef0	\N	{"testCode":"U_NIT","text":"\\u043F\\u043E\\u0437\\u0438\\u0442\\u0438\\u0432\\u043D\\u043E","flag":"NONE","isAlert":false,"autoVerified":false,"block":"\\u0420\\u0435\\u0437\\u0443\\u043B\\u044C\\u0442\\u0430\\u0442 \\u043F\\u043E\\u0437\\u0430 \\u043D\\u043E\\u0440\\u043C\\u043E\\u044E (NONE)"}	2026-10-13 20:26:24.130548	seed	\N	d0000000-0000-0000-0000-000000000001
51056bfa-9e8c-4e01-9109-be9a39e34772	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	5e632bc0-34e8-440b-ae88-61126f1dbfc4	\N	{"testCode":"U_SG","releasedAt":"2026-10-13T20:26:24.153656Z"}	2026-10-13 20:26:24.153688	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
c17dd333-8314-4502-893e-7ae12803703a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	ea900a56-f18d-4055-a726-4d3d77fd9433	\N	{"testCode":"U_SG","numeric":1.018,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u041F\\u0438\\u0442\\u043E\\u043C\\u0430 \\u0432\\u0430\\u0433\\u0430 \\u0441\\u0435\\u0447\\u0456"}	2026-10-13 20:26:24.158602	seed	\N	d0000000-0000-0000-0000-000000000001
614a4bcf-85eb-4998-9624-61f3970c1b3a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	RESULT_ENTERED	lab_test_result	dc0163c3-2fa2-42fb-a9ba-e2f72013d074	\N	{"testCode":"U_PH","numeric":6,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"pH \\u0441\\u0435\\u0447\\u0456"}	2026-10-13 20:26:24.181648	seed	\N	d0000000-0000-0000-0000-000000000001
9449d3dd-b952-46df-95b5-922c6fc115bf	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	TEST_RELEASED	lab_order_test	30c2bcac-31c0-48d7-b9f8-966dd4e872e0	\N	{"testCode":"U_PH","releasedAt":"2026-10-13T20:26:24.176927Z"}	2026-10-13 20:26:24.176939	seed	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
66bbbb5a-6a1e-4f60-9f16-0eba252a8892	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_culture_order	e15c6e80-f196-4e29-afc0-58ba46ff28c4	\N	{"orderTestId":"6055fbc9-c68e-4b61-bc15-8d345f9c5dca","specimenLocus":"\\u0421\\u0435\\u0447\\u0430 (\\u0441\\u0435\\u0440\\u0435\\u0434\\u043D\\u044F \\u043F\\u043E\\u0440\\u0446\\u0456\\u044F)","cultureMedium":"CLED / MacConkey","incubationHoursRecommended":24,"incubationStart":"2026-10-12T18:26:24.197863Z"}	2026-10-13 20:26:24.217589	seed	\N	d0000000-0000-0000-0000-000000000001
07c8ff80-ae77-449c-b8bf-05d27b90c09c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	UPDATE	lab_culture_order	e15c6e80-f196-4e29-afc0-58ba46ff28c4	{"specimenLocus":"\\u0421\\u0435\\u0447\\u0430 (\\u0441\\u0435\\u0440\\u0435\\u0434\\u043D\\u044F \\u043F\\u043E\\u0440\\u0446\\u0456\\u044F)","cultureMedium":"CLED / MacConkey"}	{"growthDetected":true,"growthIntensity":"HEAVY_3\\u002B","cfuPerMl":"10^6 \\u041A\\u0423\\u041E/\\u043C\\u043B","preliminaryReport":"\\u0420\\u0456\\u0441\\u0442 \\u0433\\u0440\\u0430\\u043C\\u043D\\u0435\\u0433\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438\\u0445 \\u043F\\u0430\\u043B\\u0438\\u0447\\u043E\\u043A, \\u043B\\u0430\\u043A\\u0442\\u043E\\u0437\\u043E\\u043F\\u043E\\u0437\\u0438\\u0442\\u0438\\u0432\\u043D\\u0456 \\u043A\\u043E\\u043B\\u043E\\u043D\\u0456\\u0457","finalMicroscopyDescription":"\\u041B\\u0435\\u0439\\u043A\\u043E\\u0446\\u0438\\u0442\\u0438 30\\u201340 \\u0443 \\u043F/\\u0437, \\u0431\\u0430\\u043A\\u0442\\u0435\\u0440\\u0456\\u0457 \\u002B\\u002B\\u002B"}	2026-10-13 20:26:24.257875	seed	\N	d0000000-0000-0000-0000-000000000001
be93ead0-c10d-409b-af55-6065dfda7634	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	ADD_ISOLATE	lab_isolate	af06255f-31b5-4826-abd2-c12be0bbc59a	\N	{"code":"ECOL","quantitativeCount":"10^6 \\u041A\\u0423\\u041E/\\u043C\\u043B"}	2026-10-13 20:26:24.276678	seed	\N	d0000000-0000-0000-0000-000000000001
87b9b34d-0234-4258-a13b-fa01424a4fbc	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	12109e9b-3c2e-446e-abb8-a19b72e979b7	\N	{"code":"CIP","zoneMm":18,"interpretation":"R","phenotypes":[]}	2026-10-13 20:26:24.352739	seed	\N	d0000000-0000-0000-0000-000000000001
41e07b98-c40a-44c9-993c-b81f6f03271b	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	0e1467e6-487f-4146-be75-a8c05f0c9e9c	\N	{"code":"CTX","zoneMm":14,"interpretation":"R","phenotypes":["ESBL"]}	2026-10-13 20:26:24.383719	seed	\N	d0000000-0000-0000-0000-000000000001
370b9244-b627-4c46-a40e-de8b8ba112cd	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	eda27b72-1e4a-4aed-943e-178c4a1ee2bf	\N	{"code":"CAZ","zoneMm":16,"interpretation":"R","phenotypes":["ESBL"]}	2026-10-13 20:26:24.413524	seed	\N	d0000000-0000-0000-0000-000000000001
f662502b-949c-4a64-bdba-f11739e939c2	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	a0dfcf1e-4434-469f-9101-290bbef05280	\N	{"code":"MEM","zoneMm":27,"interpretation":"S","phenotypes":["ESBL"]}	2026-10-13 20:26:24.443893	seed	\N	d0000000-0000-0000-0000-000000000001
71ec0273-3b8c-4b35-8677-93b6a1242152	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	22d7e1cf-9d77-4672-8015-cc1830822133	\N	{"code":"NIT","zoneMm":20,"interpretation":"S","phenotypes":["ESBL"]}	2026-10-13 20:26:24.473264	seed	\N	d0000000-0000-0000-0000-000000000001
cad53823-7803-4306-a64a-092c9c633361	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	SUSCEPTIBILITY	lab_susceptibility_result	4ee248b0-f7bf-486f-8c0b-0b848c23dbf9	\N	{"code":"GEN","zoneMm":19,"interpretation":"S","phenotypes":["ESBL"]}	2026-10-13 20:26:24.502877	seed	\N	d0000000-0000-0000-0000-000000000001
88f47c65-2e08-4670-8a70-89ed8a99180a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	ISOLATE	lab_culture_order	e15c6e80-f196-4e29-afc0-58ba46ff28c4	{"status":"PRELIMINARY"}	{"status":"ISOLATED"}	2026-10-13 20:26:24.515145	seed	\N	d0000000-0000-0000-0000-000000000001
820514d2-2a83-4e69-8007-19836f2a947a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_order	42e59603-75e2-4535-bfcd-3326e137e894	\N	{"orderNumber":"2610-000008","patientId":"0b000000-0000-0000-0000-000000000001","tests":["CHOL","HDL","LDL","TG"],"samples":["10048115"]}	2026-10-13 20:26:24.540649	seed	\N	d0000000-0000-0000-0000-000000000001
a6999d0a-bdd1-442c-b009-df3d27672f92	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	240c6f45-a19d-42b4-bc35-65922f182320	\N	{"testCode":"WBC","measuredValue":7.18,"zScore":-0.067,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.581566	seed	\N	d0000000-0000-0000-0000-000000000001
e7dc9e72-ee29-4f9d-84c2-313ac4441176	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	3dfee22b-6660-4eb1-820c-ab6dfb60fab0	\N	{"testCode":"WBC","measuredValue":7.22,"zScore":0.067,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.597169	seed	\N	d0000000-0000-0000-0000-000000000001
dedd7c1c-8d5a-4a0b-99fa-0e0f4f3c2ed3	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	1e78825a-678f-4520-9475-2d5dd6332d75	\N	{"testCode":"WBC","measuredValue":7.15,"zScore":-0.167,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.609009	seed	\N	d0000000-0000-0000-0000-000000000001
87ccdcf8-db78-4f2b-867d-949201b388d1	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	78e4fce3-ec32-4b88-8f7e-8fd097406ed5	\N	{"testCode":"WBC","measuredValue":7.28,"zScore":0.267,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.622085	seed	\N	d0000000-0000-0000-0000-000000000001
61446208-d4a6-4ec6-9796-0aaf71c537e2	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	40773913-f3cb-4908-9f34-c1b32f3f5059	\N	{"testCode":"WBC","measuredValue":7.2,"zScore":0,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.634006	seed	\N	d0000000-0000-0000-0000-000000000001
3f3d8a4c-0f28-4abc-b572-24a39180a89c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	3f56a6f3-5d47-4431-bd37-ea3f776c190b	\N	{"testCode":"WBC","measuredValue":7.32,"zScore":0.4,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.644659	seed	\N	d0000000-0000-0000-0000-000000000001
652f99a2-1e07-4230-a999-28cbc2793db6	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	75ff55af-82bf-4b35-b048-294dd24ae420	\N	{"testCode":"WBC","measuredValue":7.19,"zScore":-0.033,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.655468	seed	\N	d0000000-0000-0000-0000-000000000001
f905126f-015d-4262-a5dd-9bd53709cfc7	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	786cf2b1-60d7-4da4-b16d-0861b84a0ac6	\N	{"testCode":"WBC","measuredValue":7.25,"zScore":0.167,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.666291	seed	\N	d0000000-0000-0000-0000-000000000001
70374e6f-e91a-4b9b-9f99-823f91d8f1f1	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	7ca727d9-8a1d-4f4c-a2f1-e72b003289fe	\N	{"testCode":"WBC","measuredValue":7.1,"zScore":-0.333,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.676981	seed	\N	d0000000-0000-0000-0000-000000000001
8d979e6d-f31f-45a7-b41f-e4d313dda1c3	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	8914da65-c524-4329-80ec-f8e63ef635cc	\N	{"testCode":"WBC","measuredValue":7.27,"zScore":0.233,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.688223	seed	\N	d0000000-0000-0000-0000-000000000001
16203a40-0053-4a42-b8dc-76f63c557f1e	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	14e91f74-9a9b-480e-9cfb-664faaac796e	\N	{"testCode":"WBC","measuredValue":8.3,"zScore":3.667,"violatedRules":["1_2s","1_3s"],"lockoutEnforced":true}	2026-10-13 20:26:24.716935	seed	\N	d0000000-0000-0000-0000-000000000001
3a952dcb-f3c6-4c7d-84e1-8b85446fac34	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	LOCKOUT	lab_analyzer_lockout	b9ae272a-afd0-48b1-bff4-ea33ef8c5248	\N	{"analyzerId":"0a2a0000-0000-0000-0000-000000000001","testCode":"WBC","reason":"\\u0412\\u041A\\u042F XN CHECK L2 (mock) (\\u043B\\u043E\\u0442 QC-MOCK-002): \\u043F\\u043E\\u0440\\u0443\\u0448\\u0435\\u043D\\u043E 1_3s; z=\\u002B3.67"}	2026-10-13 20:26:24.716797	seed	\N	d0000000-0000-0000-0000-000000000001
3f1406b3-a258-4b7b-ae46-acc0f9d0e932	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	e25948f6-659d-4676-84fc-efd193e49370	\N	{"testCode":"HGB","measuredValue":137,"zScore":-0.667,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.732442	seed	\N	d0000000-0000-0000-0000-000000000001
9856341b-f317-45e4-b105-dcdef5d1287d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	003e5d2d-cdd3-47ab-b920-a8113864e4fa	\N	{"testCode":"HGB","measuredValue":139,"zScore":0.667,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.745346	seed	\N	d0000000-0000-0000-0000-000000000001
f00713eb-2152-4ea5-bbfe-543518885e60	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	7154d383-f1d5-4a39-a234-144ea32dd95f	\N	{"testCode":"HGB","measuredValue":138.5,"zScore":0.333,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.756181	seed	\N	d0000000-0000-0000-0000-000000000001
86f5d088-9939-4e1f-bebd-691d667120b0	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	2b08c7c7-f08e-4d7a-b7ce-8b8329a2c7a3	\N	{"testCode":"HGB","measuredValue":136.8,"zScore":-0.8,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.766911	seed	\N	d0000000-0000-0000-0000-000000000001
3517b2f6-abe7-4d9b-88bb-86bc988f7fed	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	d9f94cfa-352c-41b3-8c35-d5edb212a985	\N	{"testCode":"HGB","measuredValue":138,"zScore":0,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.788935	seed	\N	d0000000-0000-0000-0000-000000000001
77e5d2c8-e889-45aa-ba72-a1e101be129b	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	20d8024e-aaec-46c9-913f-50264024895e	\N	{"testCode":"HGB","measuredValue":139.5,"zScore":1,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.800937	seed	\N	d0000000-0000-0000-0000-000000000001
b63cc55d-e093-4031-9103-67d1ecac894f	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	bd87f72f-7af7-44ab-b1f9-0e3ef2a3a686	\N	{"testCode":"HGB","measuredValue":137.2,"zScore":-0.533,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.812893	seed	\N	d0000000-0000-0000-0000-000000000001
8dd0d70e-5431-40c4-86b0-31f80785d7b6	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	c2b6ecf0-20ba-41a6-a59c-713b3cd79353	\N	{"testCode":"HGB","measuredValue":138.8,"zScore":0.533,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.824581	seed	\N	d0000000-0000-0000-0000-000000000001
a5982094-15e7-4c0b-98fa-9a39fd5ec0f4	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	94e602ca-92b3-474b-88ad-59bc70de3c85	\N	{"testCode":"GLU","measuredValue":4.21,"zScore":-0.1,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.836049	seed	\N	d0000000-0000-0000-0000-000000000001
22914624-d178-472e-be32-02ec5632e0ed	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	3ea6b170-9c64-4da4-8ed6-cecb148c9e30	\N	{"testCode":"GLU","measuredValue":4.18,"zScore":-0.4,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.847558	seed	\N	d0000000-0000-0000-0000-000000000001
52672e3c-c620-40e0-9f00-be9144b07b37	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	f8680297-84e4-48f4-b7bf-6019969e9961	\N	{"testCode":"GLU","measuredValue":4.25,"zScore":0.3,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.858622	seed	\N	d0000000-0000-0000-0000-000000000001
81f5e418-9e8f-4fa0-979d-75858096863c	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	3e56a70c-227d-4849-a2a6-1140f9426f82	\N	{"testCode":"GLU","measuredValue":4.22,"zScore":0,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.891214	seed	\N	d0000000-0000-0000-0000-000000000001
03849fb3-375d-4c0e-8b30-1cdeb98f0ce0	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	fd22a73e-d04c-4e5c-8acc-a6544481d48e	\N	{"testCode":"GLU","measuredValue":4.19,"zScore":-0.3,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.902268	seed	\N	d0000000-0000-0000-0000-000000000001
20cebad3-9d7a-4c0e-aee9-53b54b40b526	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_qc_result	68a020a4-050c-4cd3-b764-906fbf7c3e8c	\N	{"testCode":"GLU","measuredValue":4.24,"zScore":0.2,"violatedRules":[],"lockoutEnforced":false}	2026-10-13 20:26:24.9134	seed	\N	d0000000-0000-0000-0000-000000000001
09640079-b18c-4038-9135-f0e8280103c8	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_archive_rack	1a1ca3f2-5f6d-4549-a81c-678aa428a936	\N	{"code":"RACK-A1","name":"\\u0428\\u0442\\u0430\\u0442\\u0438\\u0432 A1 (\\u0441\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u043A\\u0438, 6 \\u043C\\u0456\\u0441.)","roomNumber":"104","freezerName":"\\u041C\\u043E\\u0440\\u043E\\u0437\\u0438\\u043B\\u044C\\u043D\\u0438\\u043A Liebherr LGex-3410 \\u21161","shelfNumber":"2","temperatureCelsius":-20,"rowsCount":8,"colsCount":12,"isActive":true}	2026-10-13 20:26:24.935776	seed	\N	d0000000-0000-0000-0000-000000000001
0983c830-bddd-4b70-b537-1cf854b64911	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	PLACE	lab_archive_cell	9d61cc29-b8bd-43cc-afae-f1737a61f3e7	\N	{"code":"RACK-A1","row":1,"col":1,"barcode":"10048016","expiryAt":"2027-04-11T20:26:24.96066Z"}	2026-10-13 20:26:24.978977	seed	\N	d0000000-0000-0000-0000-000000000001
5fc9300e-cc80-414e-896c-d366dbf367bd	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	PLACE	lab_archive_cell	f1a725ff-3324-430f-a048-414ffb3aadfe	\N	{"code":"RACK-A1","row":1,"col":2,"barcode":"10048023","expiryAt":"2027-04-11T20:26:25.004341Z"}	2026-10-13 20:26:25.005171	seed	\N	d0000000-0000-0000-0000-000000000001
0a0dda87-34c9-4092-bf39-9eb918e64729	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_archive_rack	a27daeda-7310-4f6e-b1a6-dfadd60615fe	\N	{"code":"RACK-B1","name":"\\u0428\\u0442\\u0430\\u0442\\u0438\\u0432 B1 (\\u043A\\u0440\\u0456\\u043E\\u0430\\u0440\\u0445\\u0456\\u0432, -80\\u00B0C)","roomNumber":"104","freezerName":"\\u0423\\u043B\\u044C\\u0442\\u0440\\u0430\\u043D\\u0438\\u0437\\u044C\\u043A\\u043E\\u0442\\u0435\\u043C\\u043F\\u0435\\u0440\\u0430\\u0442\\u0443\\u0440\\u043D\\u0438\\u0439 \\u043C\\u043E\\u0440\\u043E\\u0437\\u0438\\u043B\\u044C\\u043D\\u0438\\u043A Haier DW-86L","shelfNumber":"1","temperatureCelsius":-80,"rowsCount":8,"colsCount":12,"isActive":true}	2026-10-13 20:26:25.021618	seed	\N	d0000000-0000-0000-0000-000000000001
b320f472-21da-468d-942b-6adfd069019d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_reagent_lot	74a1bd9b-7974-4358-9a39-ede32d697e1c	\N	{"analyzerId":"0a2a0000-0000-0000-0000-000000000002","testCode":"GLU","reagentName":"Glucose HK Gen.3","lotNumber":"GLU-77812","manufacturer":"Mindray","testsInitial":800,"testsRemaining":612,"minimumTests":100,"expiryDate":"2027-06-13T20:26:25.036242Z","openedAt":"2026-10-01T20:26:25.036258Z","onboardStabilityDays":60,"isActive":true}	2026-10-13 20:26:25.047918	seed	\N	d0000000-0000-0000-0000-000000000001
7c9936fc-4390-48dd-8876-40dc4524614a	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_reagent_lot	711f63ab-243c-4ddc-9fb3-a666485e949d	\N	{"analyzerId":"0a2a0000-0000-0000-0000-000000000002","testCode":"CREAT","reagentName":"Creatinine (Jaffe compensated)","lotNumber":"CRE-55120","manufacturer":"Mindray","testsInitial":400,"testsRemaining":38,"minimumTests":50,"expiryDate":"2027-03-13T20:26:25.065273Z","openedAt":"2026-09-03T20:26:25.065274Z","onboardStabilityDays":45,"isActive":true}	2026-10-13 20:26:25.065555	seed	\N	d0000000-0000-0000-0000-000000000001
3e5e8673-8fff-4d22-a40e-9e3d1541925d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_reagent_lot	758f0c86-dc3e-4c7a-8e08-e2d9f1fcee85	\N	{"analyzerId":"0a2a0000-0000-0000-0000-000000000001","reagentName":"CELLPACK DCL","lotNumber":"CP-24091A","manufacturer":"Sysmex","testsInitial":2000,"testsRemaining":1420,"minimumTests":300,"expiryDate":"2026-10-23T20:26:25.080168Z","openedAt":"2026-09-23T20:26:25.080168Z","isActive":true}	2026-10-13 20:26:25.080427	seed	\N	d0000000-0000-0000-0000-000000000001
f711b288-8e07-4b63-8181-abd0a343392d	0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	CREATE	lab_reagent_lot	8f2ea7bb-fac8-487a-8bc1-4ce28d738dd2	\N	{"analyzerId":"0a2a0000-0000-0000-0000-000000000001","reagentName":"SULFOLYSER","lotNumber":"SL-24110","manufacturer":"Sysmex","testsInitial":1500,"testsRemaining":1500,"minimumTests":200,"expiryDate":"2027-12-13T20:26:25.094615Z","isActive":true}	2026-10-13 20:26:25.094767	seed	\N	d0000000-0000-0000-0000-000000000001
7b25558f-519b-4d6d-87fe-98a1d18ffa7d		\N	RESULT_ENTERED	lab_test_result	5835cd38-57bb-4d5c-958a-46ea95a8ba7e	\N	{"testCode":"BIL_TOT","numeric":12.3,"flag":"NORMAL","isAlert":false,"autoVerified":true,"layer":"\\u0411\\u0456\\u043B\\u0456\\u0440\\u0443\\u0431\\u0456\\u043D \\u0437\\u0430\\u0433\\u0430\\u043B\\u044C\\u043D\\u0438\\u0439"}	2026-10-26 12:06:38.063631	127.0.0.1	\N	d0000000-0000-0000-0000-000000000001
bde12c0e-4408-4e2b-9501-1bd0c4786273		\N	TEST_RELEASED	lab_order_test	10f336d2-2de0-4ec8-b9dc-b7ddc066bae3	\N	{"testCode":"BIL_TOT","releasedAt":"2026-10-26T12:06:38.023512Z"}	2026-10-26 12:06:38.026081	127.0.0.1	Прогресивна видача результату пацієнту	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_biomaterial_type; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_biomaterial_type (id, code, name, default_container, stability_hours, temperature_regime, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	SERUM	Сироватка крові	Пробірка із гелем	48	+2..+8°C	t	2026-10-13 20:26:21.773677	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	WB_EDTA	Цільна кров (EDTA)	Пробірка EDTA	24	+2..+8°C	t	2026-10-13 20:26:21.774139	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	PLASMA_CIT	Плазма (цитрат)	Пробірка цитрат	4	+15..+25°C	t	2026-10-13 20:26:21.774142	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4	URINE	Сеча	Контейнер для сечі	4	+2..+8°C	t	2026-10-13 20:26:21.774143	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5	URINE_STERILE	Сеча (стерильна)	Стерильний контейнер	2	+2..+8°C	t	2026-10-13 20:26:21.774145	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_connector_command; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_connector_command (id, connector_id, type, payload, is_delivered, delivered_at, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_connector_installation; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_connector_installation (id, name, host_name, os_description, version, install_key, install_key_used, api_key_hash, status, last_heartbeat_at, registered_at, buffered_count, uptime_sec, config_version, poll_interval_sec, heartbeat_interval_sec, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0c0c0000-0000-0000-0000-000000000001	Демо-коннектор (mock)	t-check	macOS	t-check	DEMO-INSTALL-KEY-0001	t	2714d6d3bf93a2fc448bc2a546de4340c713d70f37d1d5092ed946a2bc133bf1	ACTIVE	2026-10-26 12:20:01.309851	2026-10-26 11:58:34.26431	0	60	1	30	30	2026-10-13 20:26:22.041901	00000000-0000-0000-0000-000000000000	2026-10-26 12:20:01.351235	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_connector_log; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_connector_log (id, connector_id, at, level, message, analyzer_id, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
992c1b4a-ea0e-420d-93ef-c4f94d840565	0c0c0000-0000-0000-0000-000000000001	2026-10-26 12:00:00	Information	t-check log entry	0a2a0000-0000-0000-0000-000000000001	2026-10-26 11:59:28.221724	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a2c78035-f3dc-4e54-a5eb-6ae898ca9618	0c0c0000-0000-0000-0000-000000000001	2026-10-26 12:00:00	Information	t-check log entry	0a2a0000-0000-0000-0000-000000000001	2026-10-26 12:06:05.67972	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ac55afea-1d21-40c1-809e-dc104dc4ecf3	0c0c0000-0000-0000-0000-000000000001	2026-10-26 12:00:00	Information	t-check log entry	0a2a0000-0000-0000-0000-000000000001	2026-10-26 12:20:01.451399	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_culture_order; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_culture_order (id, order_test_id, order_id, specimen_locus, incubation_start, incubation_hours_recommended, culture_medium, growth_detected, growth_intensity, cfu_per_ml, preliminary_report, final_microscopy_description, status, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
e15c6e80-f196-4e29-afc0-58ba46ff28c4	6055fbc9-c68e-4b61-bc15-8d345f9c5dca	89300002-0d46-4073-b5c6-271443e1ea3d	Сеча (середня порція)	2026-10-12 18:26:24.197863	24	CLED / MacConkey	t	HEAVY_3+	10^6 КУО/мл	Ріст грамнегативних паличок, лактозопозитивні колонії	Лейкоцити 30–40 у п/з, бактерії +++	ISOLATED	2026-10-13 20:26:24.205275	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.515178	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_ehealth_exchange_log; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_ehealth_exchange_log (id, mode, method, url, request_json, status_code, response_json, duration_ms, at, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
72147ed5-e493-4d3f-968c-11efbc1c9f86	MOCK	GET	patients/service_requests?requisition=MOCK-0002-0002&status=&page_size=50&page=1	\N	200	{"data":[{"id":"0c0f0000-0000-0000-0000-000000000002","requisition":"MOCK-0002-0002","status":"active","category":"laboratory_procedure","subject":{"identifier":{"type":{"coding":[{"system":"eHealth/resources","code":"patient"}]},"value":"0b000000-0000-0000-0000-000000000002"}},"code":{"identifier":{"type":{"coding":[{"system":"eHealth/resources","code":"service"}]},"value":"LAB-BIOCHEM-001"}},"expiration_date":"2026-11-12","used_by_legal_entity":null}],"meta":{"code":200,"type":"object","request_id":"33c74991-ab69-4a93-bf85-ef26ea0d22c7","url":"mock"},"paging":{"page_number":1,"page_size":50,"total_entries":1,"total_pages":1}}	39	2026-10-13 20:26:23.270318	2026-10-13 20:26:23.309975	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
004290e5-44b8-4720-9ecd-f2692c592247	MOCK	PATCH	patients/service_requests/0c0f0000-0000-0000-0000-000000000002/actions/use	{"used_by_employee":{"identifier":{"type":{"coding":[{"system":"eHealth/resources","code":"employee"}]},"value":"0e000000-0000-0000-0000-000000000001"}},"used_by_legal_entity":{"identifier":{"type":{"coding":[{"system":"eHealth/resources","code":"legal_entity"}]},"value":"0a000000-0000-0000-0000-000000000001"}}}	202	{"data":{"id":"5cd6ad20-d7f6-41e9-9c66-4462e569f4d3","status":"processed","status_code":200,"entity_id":"0c0f0000-0000-0000-0000-000000000002","eta":"2026-10-13T20:26:23.3526720Z"},"meta":{"code":202,"type":"object","request_id":"2efb3658-175a-457f-9177-3cc92079cfad","url":"mock"}}	3	2026-10-13 20:26:23.349881	2026-10-13 20:26:23.353206	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_employee_settings; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_employee_settings (employee_id, lab_role, position_name, digital_signature_cert_id, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0e000000-0000-0000-0000-000000000001	LAB_ADMIN	Завідувач лабораторії	\N	t	2026-10-26 11:52:43.388742	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e000000-0000-0000-0000-000000000002	LAB_DOCTOR	Лікар-лаборант	\N	t	2026-10-26 11:52:43.415858	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e000000-0000-0000-0000-000000000003	LAB_TECHNICIAN	Лаборант	\N	t	2026-10-26 11:52:43.4171	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e000000-0000-0000-0000-000000000004	PHLEBOTOMIST	Процедурна медсестра	\N	t	2026-10-26 11:52:43.418452	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e000000-0000-0000-0000-000000000005	LOGISTICS_COURIER	Кур'єр	\N	t	2026-10-26 11:52:43.419526	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e000000-0000-0000-0000-000000000006	REGISTRAR	Реєстратор	\N	t	2026-10-26 11:52:43.420883	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_eucast_breakpoint; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_eucast_breakpoint (id, organism_id, antibiotic_id, eucast_version, mic_susceptible_le, mic_resistant_gt, zone_susceptible_ge, zone_resistant_lt, intrinsic_resistance, guidance_notes, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
25a7d4db-600d-74fc-4b0e-a5386936facc	1	1	v14.0_2024	\N	\N	25	22	f	\N	2026-10-13 20:26:22.011549	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4378be79-7135-103c-bd30-df0039277b35	1	6	v14.0_2024	\N	\N	17	17	f	\N	2026-10-13 20:26:22.018977	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6d2ce3f5-51f1-6308-3782-d3e491cc5843	1	3	v14.0_2024	\N	\N	22	19	f	\N	2026-10-13 20:26:22.01893	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
849fb106-21c3-c022-6e5c-e4c9ceaa03a8	1	5	v14.0_2024	\N	\N	11	11	f	\N	2026-10-13 20:26:22.018962	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
8d006569-778d-bb4c-a269-26eff6f45c1c	1	4	v14.0_2024	\N	\N	22	16	f	\N	2026-10-13 20:26:22.018947	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d4278d76-176a-65dc-a1b1-5a4b04fba712	1	2	v14.0_2024	\N	\N	20	17	f	\N	2026-10-13 20:26:22.018896	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_invoice; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_invoice (id, number, payer_id, order_id, period_from, period_to, amount, status, issued_at, paid_at, charge_ids_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_isolate; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_isolate (id, culture_order_id, isolate_number, organism_id, quantitative_count, is_clinically_significant, colony_morphology, resistance_phenotypes, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
af06255f-31b5-4826-abd2-c12be0bbc59a	e15c6e80-f196-4e29-afc0-58ba46ff28c4	1	1	10^6 КУО/мл	t	Рожеві лактозопозитивні колонії на MacConkey	ESBL	2026-10-13 20:26:24.276251	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.373782	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_method_type; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_method_type (id, code, name, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	PHOTOMETRY	Фотометрія	t	2026-10-13 20:26:21.798011	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	ISE	Іон-селективний електрод	t	2026-10-13 20:26:21.798116	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	IMPEDANCE	Імпеданс / проточна цитометрія	t	2026-10-13 20:26:21.798118	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4	CLOT	Коагулометрія	t	2026-10-13 20:26:21.798119	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5	CLIA	Хемілюмінесцентний імуноаналіз	t	2026-10-13 20:26:21.79812	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6	DIPSTICK	Тест-смужка	t	2026-10-13 20:26:21.79812	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7	CULTURE	Культуральний метод	t	2026-10-13 20:26:21.798121	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_micro_organism; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_micro_organism (id, code, latin_name, common_name, kingdom, gram_stain, morphology, is_pathogen, is_opportunistic, alert_critical_organism, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	ECOL	Escherichia coli	Кишкова паличка	BACTERIA	NEGATIVE	ROD	t	f	f	t	2026-10-13 20:26:21.984176	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	KPNE	Klebsiella pneumoniae	Клебсієла	BACTERIA	NEGATIVE	ROD	t	f	f	t	2026-10-13 20:26:21.984471	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	SAUR	Staphylococcus aureus	Золотистий стафілокок	BACTERIA	POSITIVE	COCCI	t	f	f	t	2026-10-13 20:26:21.984474	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_numerator; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_numerator (code, name, mask, reset_by_period, modified_on, tenant_id) FROM stdin;
lab_batch_code	Код робочого листа	WL-{yyMMdd}-{000}	t	\N	d0000000-0000-0000-0000-000000000001
lab_manifest_number	Номер маніфесту логістики	MAN-{yyMMdd}-{0000}	t	2026-10-13 20:26:23.857587	d0000000-0000-0000-0000-000000000001
lab_order_number	Номер замовлення	{yyMM}-{000000}	t	2026-10-13 20:26:24.537644	d0000000-0000-0000-0000-000000000001
journal:BIOCHEM	Журнал Клінічна біохімія	{seq}	t	2026-10-13 20:26:23.724519	d0000000-0000-0000-0000-000000000001
journal_day:BIOCHEM	Денний номер Клінічна біохімія	{seq}	t	2026-10-13 20:26:23.724872	d0000000-0000-0000-0000-000000000001
journal:COAG	Журнал Коагулологія	{seq}	t	2026-10-13 20:26:23.534894	d0000000-0000-0000-0000-000000000001
journal_day:COAG	Денний номер Коагулологія	{seq}	t	2026-10-13 20:26:23.543133	d0000000-0000-0000-0000-000000000001
journal:IMMUNO	Журнал Імунологія	{seq}	t	2026-10-13 20:26:23.719558	d0000000-0000-0000-0000-000000000001
journal_day:IMMUNO	Денний номер Імунологія	{seq}	t	2026-10-13 20:26:23.719906	d0000000-0000-0000-0000-000000000001
journal:HEMA	Журнал Гематологія	{seq}	t	2026-10-13 20:26:23.757356	d0000000-0000-0000-0000-000000000001
journal_day:HEMA	Денний номер Гематологія	{seq}	t	2026-10-13 20:26:23.765969	d0000000-0000-0000-0000-000000000001
journal:URINE	Журнал Загальний аналіз сечі	{seq}	t	2026-10-13 20:26:23.966941	d0000000-0000-0000-0000-000000000001
journal_day:URINE	Денний номер Загальний аналіз сечі	{seq}	t	2026-10-13 20:26:23.975909	d0000000-0000-0000-0000-000000000001
journal:MICRO	Журнал Мікробіологія	{seq}	t	2026-10-13 20:26:24.009817	d0000000-0000-0000-0000-000000000001
journal_day:MICRO	Денний номер Мікробіологія	{seq}	t	2026-10-13 20:26:24.018816	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_order; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order (id, order_number, patient_id, doctor_id, department_id, order_datetime, status, is_urgent_cito, ehealth_referral_id, clinical_notes, is_pregnant, pregnancy_week, menstrual_phase, icd10_code, total_price, created_by_id, completed_at, released_at, released_by_id, verify_token, cancel_reason, repeat_of_order_id, referral_type, paper_referral_id, referrer_organization_name, referrer_organization_edrpou, referrer_doctor_name, referrer_number, payer_id, patient_insurance_id, insurance_policy_number, authorization_number, payer_amount, patient_amount, paid_amount, tenant_id, diagnostic_report_id, created_on, created_by, modified_on, modified_by, record_state, requester_id) FROM stdin;
114408bc-3e27-48da-a3da-6cad07265a3d	2610-000001	0b000000-0000-0000-0000-000000000001	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000001	2026-10-12 14:26:23.054269	RELEASED	t	\N	Хронічна хвороба нирок, контроль електролітів	f	\N	\N	N18.3	450.00	0e000000-0000-0000-0000-000000000001	2026-10-12 15:36:23.054269	2026-10-12 15:46:23.054269	0e000000-0000-0000-0000-000000000001	s40paRplqtFucxPXli-3CshDHZRTrPNjoAvXf1MsdtM	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	450.00	0.00	d0000000-0000-0000-0000-000000000001	f1afc2e4-775d-4678-a804-c0087a19bc55	2026-10-13 20:26:22.268157	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	\N
e22b5f66-51fd-4228-aec6-0d40ffe71e59	2610-000002	0b000000-0000-0000-0000-000000000002	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000002	2026-10-08 20:26:23.231316	RELEASED	f	\N	Плановий профілактичний огляд	f	\N	\N	\N	350.00	0e000000-0000-0000-0000-000000000001	2026-10-08 23:36:23.231316	2026-10-08 23:56:23.231316	0e000000-0000-0000-0000-000000000001	RybG4E2jJdC3PtBRZ4Vaikml0LZ6sbvDE5dYF2s0HQM	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	350.00	0.00	d0000000-0000-0000-0000-000000000001	94b72fc2-1cdc-42c2-8691-3bc100450fcf	2026-10-13 20:26:23.062165	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	\N
b76dd818-1d59-47bb-953c-35e581dd8fa1	2610-000003	0b000000-0000-0000-0000-000000000002	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000002	2026-10-13 17:26:23.487223	PARTIALLY_COMPLETED	f	0c0f0000-0000-0000-0000-000000000002	Контроль глюкози через 5 днів	f	\N	\N	\N	350.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	EHEALTH	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	350.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:23.2418	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	\N
65cf762d-b666-41f7-bdf6-e7fcac26995a	2610-000004	0b000000-0000-0000-0000-000000000003	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000001	2026-10-13 15:26:23.677932	PARTIALLY_COMPLETED	f	\N	Контроль антикоагулянтної терапії, скринінг ПЗ	f	\N	\N	\N	480.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	480.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:23.495979	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	\N
bcf1d023-88a2-494b-bee3-1ed451977065	2610-000005	0b000000-0000-0000-0000-000000000004	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000002	2026-10-13 18:26:23.819395	PARTIALLY_COMPLETED	f	\N	Вагітність 24 тиж., скринінг	t	24	\N	\N	385.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	385.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:23.686674	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.8194	0e000000-0000-0000-0000-000000000001	2	\N
bf4f18ba-40ce-4087-9a01-8ca61f5fea46	2610-000006	0b000000-0000-0000-0000-000000000005	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000002	2026-10-13 20:26:23.82834	IN_TRANSIT	f	\N	Субфебрилітет 3 дні	f	\N	\N	\N	180.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	180.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:23.828342	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.894293	0e000000-0000-0000-0000-000000000001	2	\N
89300002-0d46-4073-b5c6-271443e1ea3d	2610-000007	0b000000-0000-0000-0000-000000000006	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000001	2026-10-12 16:26:24.526791	PARTIALLY_COMPLETED	f	\N	Дизурія, підозра на ІСШ	f	\N	\N	\N	400.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	400.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:23.920065	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	\N
42e59603-75e2-4535-bfcd-3326e137e894	2610-000008	0b000000-0000-0000-0000-000000000001	0e000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.537513	NEW	f	\N	Дисліпідемія, контроль статинотерапії	f	\N	\N	\N	250.00	0e000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	\N	INTERNAL	\N	\N	\N	\N	\N	74f2894c-bf86-d78b-6f2d-98556da93854	\N	\N	\N	0.00	250.00	0.00	d0000000-0000-0000-0000-000000000001	\N	2026-10-13 20:26:24.537515	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	\N
\.


--
-- Data for Name: lab_order_attachment; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order_attachment (id, order_id, send_out_id, performer_id, kind, file_name, content_type, size_bytes, sha256, content, visible_to_patient, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_order_charge; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order_charge (id, order_id, profile_id, test_id, package_id, code, name, payer_id, payer_kind, price_list_id, amount, payer_amount, patient_amount, is_not_covered, is_patient_choice, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
457d517f-66b2-4f32-afdb-3a53543c7a7d	114408bc-3e27-48da-a3da-6cad07265a3d	\N	4b9abf1e-f687-3227-cd6d-a9750772996b	\N	K	Калій	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	50.00	0.00	50.00	f	f	2026-10-13 20:26:22.39768	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5f5b1cfb-116d-4024-9b60-d337da349147	114408bc-3e27-48da-a3da-6cad07265a3d	d20d145b-5d7d-eb73-4222-2d5a961e5084	\N	\N	PROF_BIOCHEM_BASE	Біохімія: базовий профіль	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	350.00	0.00	350.00	f	f	2026-10-13 20:26:22.397394	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
918ff802-e41d-4991-b3cc-897cd5d927f5	114408bc-3e27-48da-a3da-6cad07265a3d	\N	5727e22c-9fe6-5f77-3938-31fa39031a51	\N	NA	Натрій	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	50.00	0.00	50.00	f	f	2026-10-13 20:26:22.39768	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3e6f1a21-98c8-404f-a414-b20bd4e4903b	e22b5f66-51fd-4228-aec6-0d40ffe71e59	d20d145b-5d7d-eb73-4222-2d5a961e5084	\N	\N	PROF_BIOCHEM_BASE	Біохімія: базовий профіль	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	350.00	0.00	350.00	f	f	2026-10-13 20:26:23.067125	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
1cb461b8-b4f1-4e18-a36e-d1826b487f25	b76dd818-1d59-47bb-953c-35e581dd8fa1	d20d145b-5d7d-eb73-4222-2d5a961e5084	\N	\N	PROF_BIOCHEM_BASE	Біохімія: базовий профіль	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	350.00	0.00	350.00	f	f	2026-10-13 20:26:23.359434	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
671aae54-b0b1-4e67-9056-1aff27f7b8e1	65cf762d-b666-41f7-bdf6-e7fcac26995a	\N	b377d2d6-d0ae-5cff-2461-3aa50773e41f	\N	PSA	ПСА загальний	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	180.00	0.00	180.00	f	f	2026-10-13 20:26:23.499985	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
72477533-3ae8-4197-9f85-c92200c4a7b2	65cf762d-b666-41f7-bdf6-e7fcac26995a	6d576e14-c3af-5463-1b22-acde70083262	\N	\N	PROF_COAG	Коагулограма	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	300.00	0.00	300.00	f	f	2026-10-13 20:26:23.499983	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
1ef4264b-6cfc-4d11-a726-994ed8826ad6	bcf1d023-88a2-494b-bee3-1ed451977065	9dcf14c3-3078-6958-4235-5cd6f98faf54	\N	\N	PROF_THYROID	Щитоподібна залоза	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	280.00	0.00	280.00	f	f	2026-10-13 20:26:23.690416	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
bbe69e13-aeea-4c59-a18c-e4304100561d	bcf1d023-88a2-494b-bee3-1ed451977065	\N	385b6b33-16ea-cd96-f163-0146b79658bc	\N	HGB	Гемоглобін	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	45.00	0.00	45.00	f	f	2026-10-13 20:26:23.690419	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cca77b4b-0fab-4a45-beb4-e5c4f042af3c	bcf1d023-88a2-494b-bee3-1ed451977065	\N	e97a0a77-84c5-7b12-20f5-f81360c31a8f	\N	GLU	Глюкоза	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	60.00	0.00	60.00	f	f	2026-10-13 20:26:23.690418	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b5f767c8-a5a8-4825-a61e-e6b15e8d4e68	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	15c0e450-bd3b-f3a5-6df0-0a1504167016	\N	\N	PROF_CBC	Загальний аналіз крові	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	180.00	0.00	180.00	f	f	2026-10-13 20:26:23.831563	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3f0a8683-0bb7-433b-a78f-37201ef994dd	89300002-0d46-4073-b5c6-271443e1ea3d	20f8d458-4c0a-6d73-4767-180e83ac2d47	\N	\N	PROF_URINE	Загальний аналіз сечі	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	150.00	0.00	150.00	f	f	2026-10-13 20:26:23.925154	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5b41ffbd-f3a3-4727-93e4-59f29f3638e8	89300002-0d46-4073-b5c6-271443e1ea3d	\N	8a7c22a5-e31d-14d9-0dd6-c619faac4340	\N	URINE_CULTURE	Посів сечі з визначенням чутливості	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	250.00	0.00	250.00	f	f	2026-10-13 20:26:23.925155	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
0da56501-8b5d-482f-8a42-fd9c01f613d5	42e59603-75e2-4535-bfcd-3326e137e894	58d7c11d-d86e-6345-bca4-37787eb49e73	\N	\N	PROF_LIPID	Ліпідограма	74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	4fc38a94-da4a-4c39-3482-edcb99219abe	250.00	0.00	250.00	f	f	2026-10-13 20:26:24.540584	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_order_favorite; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order_favorite (id, employee_id, name, profile_ids_json, test_ids_json, display_order, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_order_sample; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order_sample (id, order_id, barcode, tube_type_id, biomaterial_type_id, group_numb, plan_reasons, parent_sample_id, derivation_type, derivation_index, container_type, lab_section_id, current_stage, status, collected_at, collected_by_id, received_at, received_by_id, volume_ml, is_hemolyzed, is_lipemic, is_icteric, is_clotted, is_insufficient_volume, reject_reason, collect_checklist_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
2b8abeda-1644-4059-a9d2-6b26d17eefaf	114408bc-3e27-48da-a3da-6cad07265a3d	10048016	1	1	1	\N	\N	PRIMARY	0	\N	\N	\N	STORED	2026-10-12 14:38:23.054269	0e000000-0000-0000-0000-000000000001	2026-10-12 14:51:23.054269	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:22.353857	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.979007	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
2d88446e-7ab8-40c3-a68d-89064c4ebcc7	e22b5f66-51fd-4228-aec6-0d40ffe71e59	10048023	1	1	1	\N	\N	PRIMARY	0	\N	\N	\N	STORED	2026-10-08 20:38:23.231316	0e000000-0000-0000-0000-000000000001	2026-10-08 21:36:23.231316	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.064957	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:25.005197	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
9e651e03-452e-4a9f-9de9-387c2e51caaf	b76dd818-1d59-47bb-953c-35e581dd8fa1	10048030	1	1	1	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-13 17:38:23.487223	0e000000-0000-0000-0000-000000000001	2026-10-13 18:36:23.487223	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.35614	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
61493080-29f3-4505-bf3e-f3e4a992953c	65cf762d-b666-41f7-bdf6-e7fcac26995a	10048054	1	1	2	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-13 15:38:23.677932	0e000000-0000-0000-0000-000000000001	2026-10-13 16:36:23.677932	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.498206	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
fec1fff2-f554-4327-b431-28f39f1784b6	65cf762d-b666-41f7-bdf6-e7fcac26995a	10048047	3	3	1	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-13 15:38:23.677932	0e000000-0000-0000-0000-000000000001	2026-10-13 16:36:23.677932	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.497814	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
0f58869c-1172-4434-b957-b763b05c34a0	bcf1d023-88a2-494b-bee3-1ed451977065	10048061	1	1	1	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-13 18:38:23.819395	0e000000-0000-0000-0000-000000000001	2026-10-13 19:36:23.819395	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.688388	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.8194	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f9331816-6c3a-4992-b300-15ba7d743ac2	bcf1d023-88a2-494b-bee3-1ed451977065	10048078	2	2	2	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-13 18:38:23.819395	0e000000-0000-0000-0000-000000000001	2026-10-13 19:36:23.819395	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.68873	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.8194	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
4034c91e-665b-4903-a8f1-d053d0c27082	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	10048085	2	2	1	\N	\N	PRIMARY	0	\N	\N	\N	IN_TRANSIT	2026-10-13 20:26:23.845086	0e000000-0000-0000-0000-000000000001	\N	\N	1.5	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.829805	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.894293	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
42e9f3d4-cd58-4081-ab17-87bea65efcbc	89300002-0d46-4073-b5c6-271443e1ea3d	10048108	5	5	2	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-12 16:38:24.526791	0e000000-0000-0000-0000-000000000001	2026-10-12 17:36:24.526791	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.923421	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
536f7f44-6cd8-4283-acf8-3883bfe18dd7	89300002-0d46-4073-b5c6-271443e1ea3d	10048092	4	4	1	\N	\N	PRIMARY	0	\N	\N	\N	RECEIVED	2026-10-12 16:38:24.526791	0e000000-0000-0000-0000-000000000001	2026-10-12 17:36:24.526791	0e000000-0000-0000-0000-000000000001	3	f	f	f	f	f	\N	{"IdVerified":true,"Fasting":true,"OrderOfDraw":true,"Mixing":true}	2026-10-13 20:26:23.922929	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
95d36a3a-0345-42fb-a1e5-fb7f3089802e	42e59603-75e2-4535-bfcd-3326e137e894	10048115	1	1	1	\N	\N	PRIMARY	0	\N	\N	\N	PENDING	\N	\N	\N	\N	\N	f	f	f	f	f	\N	\N	2026-10-13 20:26:24.538934	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_order_test; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_order_test (id, order_id, sample_id, profile_id, test_id, test_code, test_name, status, assigned_analyzer_id, is_reflex, reflex_from_test_id, reflex_needs_confirmation, reject_reason, display_order, released_at, performer_id, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
016beec8-2e7f-4071-8246-528692149153	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	\N	5727e22c-9fe6-5f77-3938-31fa39031a51	NA	Натрій	VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	9	2026-10-13 20:26:22.947814	\N	2026-10-13 20:26:22.357716	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.950613	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
059f6563-49ba-4cdc-bd27-ac17b9d9e36a	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	6d3046d3-9cb0-71d0-b5d3-632f12bed916	BIL_TOT	Білірубін загальний	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	6	2026-10-13 20:26:22.857588	\N	2026-10-13 20:26:22.357715	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.860055	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
05d422f7-71b2-4fa9-ad42-3a2e688e1430	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	dc9a931d-5851-e01b-e2f2-fc46621ea597	UREA	Сечовина	VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	3	2026-10-13 20:26:22.921707	\N	2026-10-13 20:26:22.357714	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.92392	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
44c2fe4e-03b0-4789-97e5-5b09772cde61	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	17f44917-1e73-c00d-1f94-829b314117d2	AST	АСТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	5	2026-10-13 20:26:22.845629	\N	2026-10-13 20:26:22.357714	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.847862	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
4e1a6b24-2ff4-49dd-bb27-a711976ff771	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	7056a922-9eaa-71db-8831-89963768bd12	PROT_TOT	Білок загальний	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	7	2026-10-13 20:26:22.870076	\N	2026-10-13 20:26:22.357715	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.872245	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7f110624-c85b-4411-981a-2caa688e771f	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	Глюкоза	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	1	2026-10-13 20:26:22.774439	\N	2026-10-13 20:26:22.357592	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.801469	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
84e295a9-d52f-4d29-926a-d2a78dadd0e6	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	\N	4b9abf1e-f687-3227-cd6d-a9750772996b	K	Калій	VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	8	2026-10-13 20:26:22.934299	\N	2026-10-13 20:26:22.357716	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.936656	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
d6039ece-8620-408f-890f-b550e5568dc8	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	Креатинін	VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	2	2026-10-13 20:26:22.907812	\N	2026-10-13 20:26:22.357713	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.911324	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
f825460d-a54c-49f9-aabe-cc7091189551	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	b52ad812-14fc-017f-8043-9d4065b00912	ALT	АЛТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	4	2026-10-13 20:26:22.833726	\N	2026-10-13 20:26:22.357714	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:22.836045	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
31ea1f40-2ebb-430a-a184-b4a3d7fa2828	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	17f44917-1e73-c00d-1f94-829b314117d2	AST	АСТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	5	2026-10-13 20:26:23.167156	\N	2026-10-13 20:26:23.065511	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.169819	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3ff7b478-e872-4003-97dd-cc8a3543dac9	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	Глюкоза	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	1	2026-10-13 20:26:23.107243	\N	2026-10-13 20:26:23.065508	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.112772	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
64d67447-5181-43f4-a551-5c8c102385fb	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	Креатинін	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	2	2026-10-13 20:26:23.125171	\N	2026-10-13 20:26:23.06551	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.127624	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
9d217a05-6d9d-44ab-a281-a3052e8cdb6b	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	6d3046d3-9cb0-71d0-b5d3-632f12bed916	BIL_TOT	Білірубін загальний	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	6	2026-10-13 20:26:23.181266	\N	2026-10-13 20:26:23.065512	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.18386	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b72e059f-c55c-4bab-8cbb-7cad8a4f41a7	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	b52ad812-14fc-017f-8043-9d4065b00912	ALT	АЛТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	4	2026-10-13 20:26:23.153265	\N	2026-10-13 20:26:23.065511	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.156092	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d7ef4b25-87fe-4bab-93e0-c883f08f8fa6	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	dc9a931d-5851-e01b-e2f2-fc46621ea597	UREA	Сечовина	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	3	2026-10-13 20:26:23.138661	\N	2026-10-13 20:26:23.06551	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.141097	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dc1789e1-b032-4056-a21f-d3f0dc675b2b	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	d20d145b-5d7d-eb73-4222-2d5a961e5084	7056a922-9eaa-71db-8831-89963768bd12	PROT_TOT	Білок загальний	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	7	2026-10-13 20:26:23.19699	\N	2026-10-13 20:26:23.065512	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.199683	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
613b3264-5098-4615-927a-5bbd7879a99a	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	dc9a931d-5851-e01b-e2f2-fc46621ea597	UREA	Сечовина	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	3	2026-10-13 20:26:23.436453	\N	2026-10-13 20:26:23.356673	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.440206	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7499aa35-d33d-4443-9a19-a91e1562b1a6	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	17f44917-1e73-c00d-1f94-829b314117d2	AST	АСТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	5	2026-10-13 20:26:23.473161	\N	2026-10-13 20:26:23.356674	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.47677	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8d41a71e-c391-48c1-bf82-7cb736d79f75	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	b52ad812-14fc-017f-8043-9d4065b00912	ALT	АЛТ	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	4	2026-10-13 20:26:23.454876	\N	2026-10-13 20:26:23.356673	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.45871	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
960996bd-e7f3-4df2-8bec-35781537f928	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	7056a922-9eaa-71db-8831-89963768bd12	PROT_TOT	Білок загальний	PENDING	\N	f	\N	f	\N	7	\N	\N	2026-10-13 20:26:23.356674	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ac4a2f93-b7aa-4626-a04e-bce186a8e98f	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	Креатинін	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	2	2026-10-13 20:26:23.416957	\N	2026-10-13 20:26:23.356672	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.421103	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d6c2e511-756f-4ade-80f0-9bcd5b5a06d5	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	Глюкоза	RESULTED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	1	\N	\N	2026-10-13 20:26:23.356671	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.401193	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
241d88c6-7efa-46a8-83fc-91870d3ada30	65cf762d-b666-41f7-bdf6-e7fcac26995a	fec1fff2-f554-4327-b431-28f39f1784b6	6d576e14-c3af-5463-1b22-acde70083262	26e9c43c-eb4f-4b10-1489-87f7febd4943	APTT	АЧТЧ	AUTO_VERIFIED	\N	f	\N	f	\N	3	2026-10-13 20:26:23.627641	\N	2026-10-13 20:26:23.498512	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.631493	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6dd75bb6-4788-4a55-9171-1dafda27eb0a	65cf762d-b666-41f7-bdf6-e7fcac26995a	fec1fff2-f554-4327-b431-28f39f1784b6	6d576e14-c3af-5463-1b22-acde70083262	aa0f5a5a-f0ee-c2a9-5627-2ef8b023c646	PT	Протромбіновий час	AUTO_VERIFIED	\N	f	\N	f	\N	1	2026-10-13 20:26:23.597688	\N	2026-10-13 20:26:23.49851	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.601666	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8f776604-3f43-412e-98a4-7b768e917438	65cf762d-b666-41f7-bdf6-e7fcac26995a	fec1fff2-f554-4327-b431-28f39f1784b6	6d576e14-c3af-5463-1b22-acde70083262	9a41c97e-a1ff-3057-51c8-7227b8a34eca	INR	МНВ	RESULTED	\N	f	\N	f	\N	2	\N	\N	2026-10-13 20:26:23.498512	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.61305	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c7c78c00-705a-40a3-a890-603987bdbed2	65cf762d-b666-41f7-bdf6-e7fcac26995a	61493080-29f3-4505-bf3e-f3e4a992953c	\N	b377d2d6-d0ae-5cff-2461-3aa50773e41f	PSA	ПСА загальний	RESULTED	\N	f	\N	f	\N	5	\N	\N	2026-10-13 20:26:23.498513	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.667021	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
facd213b-5bb6-4de2-9e70-6a1c9d5cf4da	65cf762d-b666-41f7-bdf6-e7fcac26995a	fec1fff2-f554-4327-b431-28f39f1784b6	6d576e14-c3af-5463-1b22-acde70083262	a4a22087-0271-8aeb-b832-d77465333a2b	FIBRINOGEN	Фібриноген	AUTO_VERIFIED	\N	f	\N	f	\N	4	2026-10-13 20:26:23.64638	\N	2026-10-13 20:26:23.498512	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.650323	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
31743f9f-e5af-4240-97f7-db32e41e81c7	65cf762d-b666-41f7-bdf6-e7fcac26995a	61493080-29f3-4505-bf3e-f3e4a992953c	\N	3ab55622-32af-eef0-0224-0b3ad5d96d6f	FPSA	ПСА вільний	PENDING	\N	t	c7c78c00-705a-40a3-a890-603987bdbed2	f	\N	6	\N	\N	2026-10-13 20:26:23.665507	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
14f33f52-b961-407b-8d6a-d6ddf8701287	bcf1d023-88a2-494b-bee3-1ed451977065	0f58869c-1172-4434-b957-b763b05c34a0	9dcf14c3-3078-6958-4235-5cd6f98faf54	a9396732-a004-f61b-52b3-b79513ec3633	TSH	ТТГ	AUTO_VERIFIED	\N	f	\N	f	\N	1	2026-10-13 20:26:23.803843	\N	2026-10-13 20:26:23.689011	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.808166	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
44810dce-2ac6-474e-9dd6-20791ec23cd3	bcf1d023-88a2-494b-bee3-1ed451977065	0f58869c-1172-4434-b957-b763b05c34a0	\N	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	Глюкоза	AUTO_VERIFIED	\N	f	\N	f	\N	3	2026-10-13 20:26:23.784024	\N	2026-10-13 20:26:23.689013	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.788299	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8c56ed6e-7d15-4f37-b6cc-7af4e2b1d428	bcf1d023-88a2-494b-bee3-1ed451977065	f9331816-6c3a-4992-b300-15ba7d743ac2	\N	385b6b33-16ea-cd96-f163-0146b79658bc	HGB	Гемоглобін	PENDING	\N	f	\N	f	\N	4	\N	\N	2026-10-13 20:26:23.689013	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ac66c76c-d4e3-40d9-9f77-8c242533c782	bcf1d023-88a2-494b-bee3-1ed451977065	0f58869c-1172-4434-b957-b763b05c34a0	9dcf14c3-3078-6958-4235-5cd6f98faf54	cb7ec275-c691-451e-c6a2-50b68ad556cc	FT4	Т4 вільний	PENDING	\N	f	\N	f	\N	2	\N	\N	2026-10-13 20:26:23.689012	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
65be5151-f0e9-46b8-a0a8-34cf202b2ca2	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	4034c91e-665b-4903-a8f1-d053d0c27082	15c0e450-bd3b-f3a5-6df0-0a1504167016	2d02abde-3000-bfdd-4d01-bf4f7b5efb40	WBC	Лейкоцити	PENDING	\N	f	\N	f	\N	1	\N	\N	2026-10-13 20:26:23.830153	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6c9cf534-6b42-4185-94c3-bd25b68529d3	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	4034c91e-665b-4903-a8f1-d053d0c27082	15c0e450-bd3b-f3a5-6df0-0a1504167016	385b6b33-16ea-cd96-f163-0146b79658bc	HGB	Гемоглобін	PENDING	\N	f	\N	f	\N	2	\N	\N	2026-10-13 20:26:23.830155	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6ea385fb-8473-4bc4-b3a2-c1ba2a267a4e	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	4034c91e-665b-4903-a8f1-d053d0c27082	15c0e450-bd3b-f3a5-6df0-0a1504167016	58a8f55f-964b-c194-0eb7-a7421875d22c	RBC	Еритроцити	PENDING	\N	f	\N	f	\N	3	\N	\N	2026-10-13 20:26:23.830155	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7d813302-2589-4523-a5d6-a0f828232a67	bf4f18ba-40ce-4087-9a01-8ca61f5fea46	4034c91e-665b-4903-a8f1-d053d0c27082	15c0e450-bd3b-f3a5-6df0-0a1504167016	9a0184d8-1d16-8fb3-e23d-daf43523e669	PLT	Тромбоцити	PENDING	\N	f	\N	f	\N	4	\N	\N	2026-10-13 20:26:23.830156	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
03210845-013b-4c3d-9159-973a8de1a7af	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	f9e0e0ee-f205-2d99-101f-e6ddd5b21168	U_CLARITY	Прозорість сечі	RESULTED	\N	f	\N	f	\N	2	\N	\N	2026-10-13 20:26:23.923725	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.048748	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
30c2bcac-31c0-48d7-b9f8-966dd4e872e0	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	5846d6ec-098e-d107-7ca9-76e04c5ac760	U_PH	pH сечі	AUTO_VERIFIED	\N	f	\N	f	\N	4	2026-10-13 20:26:24.176927	\N	2026-10-13 20:26:23.923726	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.18166	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5e632bc0-34e8-440b-ae88-61126f1dbfc4	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	e2e92758-4a2b-69a0-63c7-f2d972e5d6de	U_SG	Питома вага сечі	AUTO_VERIFIED	\N	f	\N	f	\N	3	2026-10-13 20:26:24.153656	\N	2026-10-13 20:26:23.923725	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.158616	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6055fbc9-c68e-4b61-bc15-8d345f9c5dca	89300002-0d46-4073-b5c6-271443e1ea3d	42e9f3d4-cd58-4081-ab17-87bea65efcbc	\N	8a7c22a5-e31d-14d9-0dd6-c619faac4340	URINE_CULTURE	Посів сечі з визначенням чутливості	IN_ANALYSIS	\N	f	\N	f	\N	11	\N	\N	2026-10-13 20:26:23.923729	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.217611	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
9e9dedb9-b1e3-4790-b9b2-afcbe04f0e7c	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	69eb4fe0-b6a1-6186-06ca-03557bcbd34f	U_NIT	Нітрити у сечі	RESULTED	\N	f	\N	f	\N	10	\N	\N	2026-10-13 20:26:23.923728	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.130561	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a1afc828-ef1b-4b6c-b0dc-64d2be8c294e	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	ff3ffbe9-faa7-fc07-7abc-925c715ea80e	U_ERY	Еритроцити у сечі	RESULTED	\N	f	\N	f	\N	9	\N	\N	2026-10-13 20:26:23.923728	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.116282	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a52636a9-11d5-4e1f-8814-7f26030adc88	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	772a9b8b-36ea-119f-adee-bad2b39bca28	U_PRO	Білок у сечі	RESULTED	\N	f	\N	f	\N	5	\N	\N	2026-10-13 20:26:23.923726	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.061719	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b21d25aa-487b-40c3-8284-ecb2a2111ef0	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	e1dfea1c-3bbd-42f4-097d-f4246fb85bc4	U_LEU	Лейкоцити у сечі	RESULTED	\N	f	\N	f	\N	8	\N	\N	2026-10-13 20:26:23.923727	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.102327	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b3d0e365-ec21-4839-883f-73277e56de91	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	d6221062-0137-ce7c-5e94-e03c6078f6cc	U_COLOR	Колір сечі	RESULTED	\N	f	\N	f	\N	1	\N	\N	2026-10-13 20:26:23.923722	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.035696	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dc9fd361-77ad-48cc-b7f6-bd6f4d9ace37	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	5f4b3231-e2b4-3ba9-7ec3-336b196082ff	U_GLU	Глюкоза у сечі	RESULTED	\N	f	\N	f	\N	6	\N	\N	2026-10-13 20:26:23.923727	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.075167	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f6a16ae3-7345-4029-b529-aba0d286f864	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	20f8d458-4c0a-6d73-4767-180e83ac2d47	37645829-c22b-9ac4-ecaf-6702303061c1	U_KET	Кетони у сечі	RESULTED	\N	f	\N	f	\N	7	\N	\N	2026-10-13 20:26:23.923727	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.089249	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
69e4a87a-6f35-4b02-aced-134ff2e27239	42e59603-75e2-4535-bfcd-3326e137e894	95d36a3a-0345-42fb-a1e5-fb7f3089802e	58d7c11d-d86e-6345-bca4-37787eb49e73	2390521a-4884-14a4-7e9b-e521a2f6d403	TG	Тригліцериди	PENDING	\N	f	\N	f	\N	4	\N	\N	2026-10-13 20:26:24.539252	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ca26324a-31e8-4810-a6f9-338d5e530153	42e59603-75e2-4535-bfcd-3326e137e894	95d36a3a-0345-42fb-a1e5-fb7f3089802e	58d7c11d-d86e-6345-bca4-37787eb49e73	b9180163-fed0-792b-8397-7a264a2ffb71	CHOL	Холестерин загальний	PENDING	\N	f	\N	f	\N	1	\N	\N	2026-10-13 20:26:24.53925	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ccbf99b1-3af4-47f4-aa3f-be6b04db7022	42e59603-75e2-4535-bfcd-3326e137e894	95d36a3a-0345-42fb-a1e5-fb7f3089802e	58d7c11d-d86e-6345-bca4-37787eb49e73	151cdd48-ad74-66fd-6a6f-caa3190d7521	LDL	ЛПНЩ	PENDING	\N	f	\N	f	\N	3	\N	\N	2026-10-13 20:26:24.539252	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d183e30c-bfed-4aeb-97cb-e8b88ed6a8f5	42e59603-75e2-4535-bfcd-3326e137e894	95d36a3a-0345-42fb-a1e5-fb7f3089802e	58d7c11d-d86e-6345-bca4-37787eb49e73	8a26d96f-50d9-09e0-13b2-d927525708ca	HDL	ЛПВЩ	PENDING	\N	f	\N	f	\N	2	\N	\N	2026-10-13 20:26:24.539251	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
10f336d2-2de0-4ec8-b9dc-b7ddc066bae3	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	d20d145b-5d7d-eb73-4222-2d5a961e5084	6d3046d3-9cb0-71d0-b5d3-632f12bed916	BIL_TOT	Білірубін загальний	AUTO_VERIFIED	0a2a0000-0000-0000-0000-000000000002	f	\N	f	\N	6	2026-10-26 12:06:38.023512	\N	2026-10-13 20:26:23.356674	0e000000-0000-0000-0000-000000000001	2026-10-26 12:06:38.067542	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_panic_call; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_panic_call (id, result_id, order_id, patient_name, test_code, value, doctor_notified_name, phone, department, readback_confirmed, notified_by_id, notified_at, comments, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
aecd5fa5-ccd9-4b28-a28c-cc25cecf6eeb	09f66487-3a79-463a-99bf-d8549909f744	114408bc-3e27-48da-a3da-6cad07265a3d	Коваленко Олег Іванович	K	6.80 ммоль/л	Іванчук М.П. (нефролог)	+380501234567	Нефрологічне відділення	t	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.023313	Повідомлено про К 6.8 ммоль/л, призначено ЕКГ та корекцію	2026-10-13 20:26:23.023148	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_patient_notification; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_patient_notification (id, patient_id, order_id, channel, payload, status, sent_at, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
503ae30d-d0f3-41cc-bd3c-c763f3c4d514	0b000000-0000-0000-0000-000000000001	114408bc-3e27-48da-a3da-6cad07265a3d	SMS	Готові нові результати за замовленням №2610-000001 (Глюкоза). Перегляд: /portal/0b000000-0000-0000-0000-000000000001/orders/114408bc-3e27-48da-a3da-6cad07265a3d	QUEUED	\N	2026-10-13 20:26:22.774439	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ee0652cb-c20f-4cfd-9df0-ad7c7492d1f9	0b000000-0000-0000-0000-000000000001	114408bc-3e27-48da-a3da-6cad07265a3d	SMS	Результати дослідження №2610-000001 готові. Перегляд: /portal/0b000000-0000-0000-0000-000000000001/orders/114408bc-3e27-48da-a3da-6cad07265a3d	QUEUED	\N	2026-10-13 20:26:22.993714	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
2826897a-84af-465c-9078-900434360b06	0b000000-0000-0000-0000-000000000002	e22b5f66-51fd-4228-aec6-0d40ffe71e59	SMS	Готові нові результати за замовленням №2610-000002 (Глюкоза). Перегляд: /portal/0b000000-0000-0000-0000-000000000002/orders/e22b5f66-51fd-4228-aec6-0d40ffe71e59	QUEUED	\N	2026-10-13 20:26:23.107243	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
03751857-1179-40a1-af46-bcf0b76971fd	0b000000-0000-0000-0000-000000000002	e22b5f66-51fd-4228-aec6-0d40ffe71e59	SMS	Результати дослідження №2610-000002 готові. Перегляд: /portal/0b000000-0000-0000-0000-000000000002/orders/e22b5f66-51fd-4228-aec6-0d40ffe71e59	QUEUED	\N	2026-10-13 20:26:23.21708	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
2af2caaf-0d16-421d-81bf-6ff7dda4b063	0b000000-0000-0000-0000-000000000002	b76dd818-1d59-47bb-953c-35e581dd8fa1	SMS	Готові нові результати за замовленням №2610-000003 (Креатинін). Перегляд: /portal/0b000000-0000-0000-0000-000000000002/orders/b76dd818-1d59-47bb-953c-35e581dd8fa1	QUEUED	\N	2026-10-13 20:26:23.416957	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8793fac2-0a5e-4ff8-8db2-bcfc92316688	0b000000-0000-0000-0000-000000000003	65cf762d-b666-41f7-bdf6-e7fcac26995a	SMS	Готові нові результати за замовленням №2610-000004 (Протромбіновий час). Перегляд: /portal/0b000000-0000-0000-0000-000000000003/orders/65cf762d-b666-41f7-bdf6-e7fcac26995a	QUEUED	\N	2026-10-13 20:26:23.597688	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5a445564-cc2e-432b-a26e-d8b728527e17	0b000000-0000-0000-0000-000000000004	bcf1d023-88a2-494b-bee3-1ed451977065	SMS	Готові нові результати за замовленням №2610-000005 (Глюкоза). Перегляд: /portal/0b000000-0000-0000-0000-000000000004/orders/bcf1d023-88a2-494b-bee3-1ed451977065	QUEUED	\N	2026-10-13 20:26:23.784024	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d5856ab9-b0ad-4c5e-910b-13f20c4b5ab2	0b000000-0000-0000-0000-000000000006	89300002-0d46-4073-b5c6-271443e1ea3d	SMS	Готові нові результати за замовленням №2610-000007 (Питома вага сечі). Перегляд: /portal/0b000000-0000-0000-0000-000000000006/orders/89300002-0d46-4073-b5c6-271443e1ea3d	QUEUED	\N	2026-10-13 20:26:24.153656	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
06eb549a-5eaf-4b72-be2c-0ae114e83f40	0b000000-0000-0000-0000-000000000002	b76dd818-1d59-47bb-953c-35e581dd8fa1	SMS	Готові нові результати за замовленням №2610-000003 (Білірубін загальний). Перегляд: /portal/0b000000-0000-0000-0000-000000000002/orders/b76dd818-1d59-47bb-953c-35e581dd8fa1	QUEUED	\N	2026-10-26 12:06:38.023512	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_payer; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_payer (id, code, name, kind, organization_name, edrpou, contract_number, contract_date, contract_valid_to, price_list_id, coverage_pct, franchise_amount, requires_policy, requires_authorization, medical_program_id, medlink_contract_id, contact_person, phone, email, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
74f2894c-bf86-d78b-6f2d-98556da93854	PATIENT	Пацієнт (каса)	PATIENT	\N	\N	\N	\N	\N	4fc38a94-da4a-4c39-3482-edcb99219abe	0.00	0.00	f	f	\N	\N	\N	\N	\N	t	2026-10-13 20:26:22.160481	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
cb257162-eaab-8088-9fbf-9d4b04f6a545	INS-MOCK	Страхова компанія (mock)	INSURANCE	\N	\N	MOCK-001	\N	2030-12-31 02:00:00	18b80088-b39e-e400-b5e6-f0ccb14bfec3	100.00	0.00	t	f	\N	\N	\N	\N	\N	t	2026-10-13 20:26:22.173883	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
23bc1a71-7e5d-78ba-ad7c-ed274385ca30	NSZU	НСЗУ	NSZU	\N	\N	\N	\N	\N	4fc38a94-da4a-4c39-3482-edcb99219abe	100.00	0.00	f	f	f84fe59f-ba5c-4478-9382-84d755456d1b	\N	\N	\N	\N	t	2026-10-13 20:26:22.173847	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_payment; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_payment (id, order_id, amount, method, receipt_number, paid_at, cashier_id, note, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_performer; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_performer (id, code, name, kind, exchange_mode, medlink_provider, edrpou, license_number, address, phone, email, contract_number, contract_date, default_tat_hours, report_note, department_id, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0ef00000-0000-0000-0000-000000000001	OWN	Власна лабораторія	INTERNAL	MANUAL	\N	\N	\N	\N	\N	\N	\N	\N	24	\N	\N	t	2026-10-13 20:26:22.107091	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0ef00000-0000-0000-0000-000000000002	EXT-MOCK	Зовнішня лабораторія (mock)	EXTERNAL	FILE	\N	\N	\N	м. Київ	\N	\N	\N	\N	72	\N	\N	t	2026-10-13 20:26:22.126323	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_performer_test; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_performer_test (id, performer_id, test_id, external_code, external_name, cost, tat_hours, is_default_route, specimen_requirements, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
33a1ff4f-a32c-4fac-9a7f-73ebd05c6958	0ef00000-0000-0000-0000-000000000002	b377d2d6-d0ae-5cff-2461-3aa50773e41f	EXT-PSA	PSA total	120.00	48	f	\N	t	2026-10-13 20:26:22.127012	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
508d83af-f0c6-4029-8d85-f3c138586794	0ef00000-0000-0000-0000-000000000001	419ce4ee-1b76-f290-0e1c-549102baae72	\N	\N	\N	\N	t	\N	t	2026-10-13 20:26:22.107561	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
edc83d22-72bb-4eb2-87b0-423f9d7301ea	0ef00000-0000-0000-0000-000000000001	e97a0a77-84c5-7b12-20f5-f81360c31a8f	\N	\N	\N	\N	t	\N	t	2026-10-13 20:26:22.107521	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_price_list; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_price_list (id, code, name, valid_from, valid_to, is_default, currency, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
18b80088-b39e-e400-b5e6-f0ccb14bfec3	INSURANCE	Прайс ДМС	2024-01-01 02:00:00	\N	f	UAH	t	2026-10-13 20:26:22.159445	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4fc38a94-da4a-4c39-3482-edcb99219abe	RETAIL	Роздрібний прайс	2024-01-01 02:00:00	\N	t	UAH	t	2026-10-13 20:26:22.140104	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_price_list_item; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_price_list_item (id, price_list_id, profile_id, test_id, price, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
00ff9695-2484-4390-a82c-e506ba0056ce	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	cb7ec275-c691-451e-c6a2-50b68ad556cc	150.00	2026-10-13 20:26:22.146226	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
062d6ff0-02ef-4479-90b0-0f8dd60978e2	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	dc9a931d-5851-e01b-e2f2-fc46621ea597	50.00	2026-10-13 20:26:22.146214	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
06a4e43a-8575-4c30-887b-45b6224eebfc	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	e97a0a77-84c5-7b12-20f5-f81360c31a8f	60.00	2026-10-13 20:26:22.146213	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
07786c9a-2d9b-49d9-87d3-1e5febe1a3db	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	5846d6ec-098e-d107-7ca9-76e04c5ac760	20.00	2026-10-13 20:26:22.146228	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
089f335b-ae8c-4a38-9ddd-0513bdba9ed5	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	4b9abf1e-f687-3227-cd6d-a9750772996b	50.00	2026-10-13 20:26:22.14622	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0efb60bf-195a-4b98-b50f-d1a0b516cc6c	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	f9e0e0ee-f205-2d99-101f-e6ddd5b21168	20.00	2026-10-13 20:26:22.146229	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
16ca8933-c245-479e-8a7a-58e729a7cf0f	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	b377d2d6-d0ae-5cff-2461-3aa50773e41f	180.00	2026-10-13 20:26:22.146225	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
1b8f447c-4a5e-4553-99e9-48abe501f477	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	9a0184d8-1d16-8fb3-e23d-daf43523e669	45.00	2026-10-13 20:26:22.146222	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
1c41a378-cbd6-4cea-926f-d991da9ae749	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	58a8f55f-964b-c194-0eb7-a7421875d22c	45.00	2026-10-13 20:26:22.146222	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
26ca7964-d3ef-45cc-b6a4-fb5bae5f2360	4fc38a94-da4a-4c39-3482-edcb99219abe	20f8d458-4c0a-6d73-4767-180e83ac2d47	\N	150.00	2026-10-13 20:26:22.146213	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2ce3d4be-7d0e-4862-9639-78d518e4b42f	18b80088-b39e-e400-b5e6-f0ccb14bfec3	20f8d458-4c0a-6d73-4767-180e83ac2d47	\N	135.00	2026-10-13 20:26:22.159464	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2e2afc59-ee42-4c2e-a005-1f6454ecae2f	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	b9180163-fed0-792b-8397-7a264a2ffb71	60.00	2026-10-13 20:26:22.146217	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3300f4a7-11e6-45d8-af27-cd52b84504af	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	ff3ffbe9-faa7-fc07-7abc-925c715ea80e	20.00	2026-10-13 20:26:22.146232	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
34f6e764-d26c-4874-b4ab-4478c430a7b8	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	5f4b3231-e2b4-3ba9-7ec3-336b196082ff	20.00	2026-10-13 20:26:22.14623	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
39243a17-2d91-4c9d-ba13-e660aaf44acb	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	26e9c43c-eb4f-4b10-1489-87f7febd4943	70.00	2026-10-13 20:26:22.146224	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
44165aa2-265b-4beb-a7ea-4c88a01e4574	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	8a26d96f-50d9-09e0-13b2-d927525708ca	70.00	2026-10-13 20:26:22.146218	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
44814ad4-b730-4695-8e1e-4600f5999837	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	17f44917-1e73-c00d-1f94-829b314117d2	55.00	2026-10-13 20:26:22.146216	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
493a7521-c2e0-4ba8-95de-63135dfe5a91	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	385b6b33-16ea-cd96-f163-0146b79658bc	45.00	2026-10-13 20:26:22.146221	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5497e676-139b-481f-b4ae-4681f621eb04	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	b52ad812-14fc-017f-8043-9d4065b00912	55.00	2026-10-13 20:26:22.146215	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6797284d-0e50-4718-9f01-3ccd37204d2a	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	9a41c97e-a1ff-3057-51c8-7227b8a34eca	70.00	2026-10-13 20:26:22.146223	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
702b4383-dfe7-4e98-853c-99e49077cc60	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	e1dfea1c-3bbd-42f4-097d-f4246fb85bc4	20.00	2026-10-13 20:26:22.146231	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
74160153-c926-44a8-82c8-d17b1c2b798d	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	d6221062-0137-ce7c-5e94-e03c6078f6cc	20.00	2026-10-13 20:26:22.146228	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
74fb3748-5f78-48e8-8785-7951d0b6ef3e	4fc38a94-da4a-4c39-3482-edcb99219abe	9dcf14c3-3078-6958-4235-5cd6f98faf54	\N	280.00	2026-10-13 20:26:22.146212	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
8469e1f4-7f93-490c-a1fa-f654351f16e8	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	7056a922-9eaa-71db-8831-89963768bd12	50.00	2026-10-13 20:26:22.146217	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9004e89c-46b5-4ed5-bbec-fea1c8556760	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	6d3046d3-9cb0-71d0-b5d3-632f12bed916	55.00	2026-10-13 20:26:22.146216	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
925c7f6f-a03a-4a38-8481-cc01c73d1990	18b80088-b39e-e400-b5e6-f0ccb14bfec3	6d576e14-c3af-5463-1b22-acde70083262	\N	270.00	2026-10-13 20:26:22.159463	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
989b585b-bf65-49bd-bcc5-d8ec90314e23	18b80088-b39e-e400-b5e6-f0ccb14bfec3	58d7c11d-d86e-6345-bca4-37787eb49e73	\N	225.00	2026-10-13 20:26:22.159462	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9edde3bd-45d0-473a-ba7c-70398933a743	18b80088-b39e-e400-b5e6-f0ccb14bfec3	15c0e450-bd3b-f3a5-6df0-0a1504167016	\N	162.00	2026-10-13 20:26:22.159463	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9f5e0375-1173-4e4a-800f-025654896ca0	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	e2e92758-4a2b-69a0-63c7-f2d972e5d6de	20.00	2026-10-13 20:26:22.146227	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9f812a20-c1fb-41f0-94ec-b20bdee42c8a	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	3ab55622-32af-eef0-0224-0b3ad5d96d6f	180.00	2026-10-13 20:26:22.146225	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a930668b-258c-44c1-aa2d-0ee23de78c15	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	a9396732-a004-f61b-52b3-b79513ec3633	150.00	2026-10-13 20:26:22.146226	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a9ae8c30-3aaf-48fb-9759-8d90bed11da8	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	772a9b8b-36ea-119f-adee-bad2b39bca28	20.00	2026-10-13 20:26:22.146229	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ac4631a0-8f44-4fb0-8ffc-8713ef5e5883	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	8a7c22a5-e31d-14d9-0dd6-c619faac4340	250.00	2026-10-13 20:26:22.146233	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b1321dce-7958-4e48-9957-379daea39f23	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	151cdd48-ad74-66fd-6a6f-caa3190d7521	70.00	2026-10-13 20:26:22.146218	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b653164f-d91e-4273-a755-b955f31b2b75	4fc38a94-da4a-4c39-3482-edcb99219abe	58d7c11d-d86e-6345-bca4-37787eb49e73	\N	250.00	2026-10-13 20:26:22.14621	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
bd89cca8-558c-44df-9f27-1cf2ec57f935	4fc38a94-da4a-4c39-3482-edcb99219abe	15c0e450-bd3b-f3a5-6df0-0a1504167016	\N	180.00	2026-10-13 20:26:22.146211	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
bf6c6a3d-af94-47eb-adce-6c884b93db00	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	419ce4ee-1b76-f290-0e1c-549102baae72	55.00	2026-10-13 20:26:22.146214	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
c5c32b52-11fd-48ea-bc08-5a5243996ec0	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	5727e22c-9fe6-5f77-3938-31fa39031a51	50.00	2026-10-13 20:26:22.14622	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d8941c42-c542-49f0-9c79-26c507276f47	18b80088-b39e-e400-b5e6-f0ccb14bfec3	d20d145b-5d7d-eb73-4222-2d5a961e5084	\N	315.00	2026-10-13 20:26:22.159461	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
daa4b955-4145-43a5-8bfe-cc243363a41e	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	2d02abde-3000-bfdd-4d01-bf4f7b5efb40	45.00	2026-10-13 20:26:22.146221	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e0710c90-1987-4a3f-9c97-8522e826a726	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	aa0f5a5a-f0ee-c2a9-5627-2ef8b023c646	70.00	2026-10-13 20:26:22.146223	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e357175e-2bbc-4025-8920-d781c7096570	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	69eb4fe0-b6a1-6186-06ca-03557bcbd34f	20.00	2026-10-13 20:26:22.146232	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e71c4142-302d-4827-b778-6d2a87d710c3	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	37645829-c22b-9ac4-ecaf-6702303061c1	20.00	2026-10-13 20:26:22.14623	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
f16cdcf4-cfef-4854-b118-e02910a4ab8b	18b80088-b39e-e400-b5e6-f0ccb14bfec3	9dcf14c3-3078-6958-4235-5cd6f98faf54	\N	252.00	2026-10-13 20:26:22.159464	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
f6b5b616-bb4f-449e-b08d-885e550365aa	4fc38a94-da4a-4c39-3482-edcb99219abe	d20d145b-5d7d-eb73-4222-2d5a961e5084	\N	350.00	2026-10-13 20:26:22.146143	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
fa8e2ed8-8943-453f-ac54-82c84c6302ba	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	a4a22087-0271-8aeb-b832-d77465333a2b	70.00	2026-10-13 20:26:22.146224	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
fd575d46-8b38-402d-9141-0d171a7a99ee	4fc38a94-da4a-4c39-3482-edcb99219abe	6d576e14-c3af-5463-1b22-acde70083262	\N	300.00	2026-10-13 20:26:22.146212	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
fe2b9bde-857d-458a-844a-5fcb5d1b7172	4fc38a94-da4a-4c39-3482-edcb99219abe	\N	2390521a-4884-14a4-7e9b-e521a2f6d403	60.00	2026-10-13 20:26:22.146219	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_price_package; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_price_package (id, price_list_id, code, name, price, member_ids_json, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_qc_material; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_qc_material (id, analyzer_id, name, level, lot_number, manufacturer, expiry_date, opened_at, open_stability_days, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
09c00000-0000-0000-0000-000000000001	0a2a0000-0000-0000-0000-000000000002	Біохімічний контроль L2 (mock)	LEVEL_2_NORMAL	QC-MOCK-001	Mock	2030-12-31 00:00:00	\N	30	t	2026-10-13 20:26:22.202109	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	XN CHECK L2 (mock)	LEVEL_2_NORMAL	QC-MOCK-002	Mock	2030-12-31 00:00:00	\N	30	t	2026-10-13 20:26:22.216765	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	Біохімічний контроль L1 (mock)	LEVEL_1_LOW	QC-MOCK-003	Mock	2030-12-31 00:00:00	\N	30	t	2026-10-13 20:26:22.216844	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_qc_result; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_qc_result (id, qc_material_id, analyzer_id, test_code, measured_value, target_mean, target_sd, z_score, violated_rules_json, is_warning, is_rejection, lockout_enforced, lockout_id, resolved_by_id, resolved_at, resolution_action, run_at, operator_id, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
240c6f45-a19d-42b4-bc35-65922f182320	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.18	7.2	0.3	-0.067	[]	f	f	f	\N	\N	\N	\N	2026-10-03 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.57015	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3dfee22b-6660-4eb1-820c-ab6dfb60fab0	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.22	7.2	0.3	0.067	[]	f	f	f	\N	\N	\N	\N	2026-10-04 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.597061	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
1e78825a-678f-4520-9475-2d5dd6332d75	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.15	7.2	0.3	-0.167	[]	f	f	f	\N	\N	\N	\N	2026-10-05 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.608909	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
78e4fce3-ec32-4b88-8f7e-8fd097406ed5	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.28	7.2	0.3	0.267	[]	f	f	f	\N	\N	\N	\N	2026-10-06 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.621961	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
40773913-f3cb-4908-9f34-c1b32f3f5059	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.2	7.2	0.3	0	[]	f	f	f	\N	\N	\N	\N	2026-10-07 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.633923	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3f56a6f3-5d47-4431-bd37-ea3f776c190b	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.32	7.2	0.3	0.4	[]	f	f	f	\N	\N	\N	\N	2026-10-08 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.64462	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
75ff55af-82bf-4b35-b048-294dd24ae420	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.19	7.2	0.3	-0.033	[]	f	f	f	\N	\N	\N	\N	2026-10-09 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.655414	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
786cf2b1-60d7-4da4-b16d-0861b84a0ac6	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.25	7.2	0.3	0.167	[]	f	f	f	\N	\N	\N	\N	2026-10-10 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.666248	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7ca727d9-8a1d-4f4c-a2f1-e72b003289fe	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.1	7.2	0.3	-0.333	[]	f	f	f	\N	\N	\N	\N	2026-10-11 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.676864	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8914da65-c524-4329-80ec-f8e63ef635cc	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	7.27	7.2	0.3	0.233	[]	f	f	f	\N	\N	\N	\N	2026-10-12 07:45:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.688167	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
14e91f74-9a9b-480e-9cfb-664faaac796e	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	WBC	8.3	7.2	0.3	3.667	["1_2s","1_3s"]	f	t	t	b9ae272a-afd0-48b1-bff4-ea33ef8c5248	\N	\N	\N	2026-10-13 19:46:24.7013	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.702456	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
e25948f6-659d-4676-84fc-efd193e49370	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	137	138	1.5	-0.667	[]	f	f	f	\N	\N	\N	\N	2026-10-05 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.732324	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
003e5d2d-cdd3-47ab-b920-a8113864e4fa	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	139	138	1.5	0.667	[]	f	f	f	\N	\N	\N	\N	2026-10-06 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.745284	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7154d383-f1d5-4a39-a234-144ea32dd95f	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	138.5	138	1.5	0.333	[]	f	f	f	\N	\N	\N	\N	2026-10-07 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.756105	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
2b08c7c7-f08e-4d7a-b7ce-8b8329a2c7a3	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	136.8	138	1.5	-0.8	[]	f	f	f	\N	\N	\N	\N	2026-10-08 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.76683	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d9f94cfa-352c-41b3-8c35-d5edb212a985	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	138	138	1.5	0	[]	f	f	f	\N	\N	\N	\N	2026-10-09 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.788704	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
20d8024e-aaec-46c9-913f-50264024895e	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	139.5	138	1.5	1	[]	f	f	f	\N	\N	\N	\N	2026-10-10 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.800866	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
bd87f72f-7af7-44ab-b1f9-0e3ef2a3a686	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	137.2	138	1.5	-0.533	[]	f	f	f	\N	\N	\N	\N	2026-10-11 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.812838	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c2b6ecf0-20ba-41a6-a59c-713b3cd79353	09c00000-0000-0000-0000-000000000002	0a2a0000-0000-0000-0000-000000000001	HGB	138.8	138	1.5	0.533	[]	f	f	f	\N	\N	\N	\N	2026-10-12 07:50:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.824471	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
94e602ca-92b3-474b-88ad-59bc70de3c85	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.21	4.22	0.1	-0.1	[]	f	f	f	\N	\N	\N	\N	2026-10-05 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.835982	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3ea6b170-9c64-4da4-8ed6-cecb148c9e30	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.18	4.22	0.1	-0.4	[]	f	f	f	\N	\N	\N	\N	2026-10-06 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.847515	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f8680297-84e4-48f4-b7bf-6019969e9961	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.25	4.22	0.1	0.3	[]	f	f	f	\N	\N	\N	\N	2026-10-07 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.858567	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
bcf34132-f53c-4919-8087-64b25e2eac34	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.3	4.22	0.1	0.8	[]	f	f	f	\N	\N	\N	\N	2026-10-08 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.869708	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
657c9446-85ad-4edb-a604-98c96b744258	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.15	4.22	0.1	-0.7	[]	f	f	f	\N	\N	\N	\N	2026-10-09 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.880501	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3e56a70c-227d-4849-a2a6-1140f9426f82	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.22	4.22	0.1	0	[]	f	f	f	\N	\N	\N	\N	2026-10-10 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.891176	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
fd22a73e-d04c-4e5c-8acc-a6544481d48e	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.19	4.22	0.1	-0.3	[]	f	f	f	\N	\N	\N	\N	2026-10-11 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.902225	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
68a020a4-050c-4cd3-b764-906fbf7c3e8c	09c00000-0000-0000-0000-000000000003	0a2a0000-0000-0000-0000-000000000002	GLU	4.24	4.22	0.1	0.2	[]	f	f	f	\N	\N	\N	\N	2026-10-12 08:00:00	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.913326	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_qc_target; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_qc_target (id, qc_material_id, test_code, target_mean, target_sd, unit, tea_pct, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
09d00000-0000-0000-0000-000000000001	09c00000-0000-0000-0000-000000000001	GLU	8	0.3	ммоль/л	\N	2026-10-13 20:26:22.202925	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09d00000-0000-0000-0000-000000000002	09c00000-0000-0000-0000-000000000001	CREAT	150	6	мкмоль/л	\N	2026-10-13 20:26:22.202928	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09d00000-0000-0000-0000-000000000003	09c00000-0000-0000-0000-000000000002	WBC	7.2	0.3	10^9/л	\N	2026-10-13 20:26:22.216781	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09d00000-0000-0000-0000-000000000004	09c00000-0000-0000-0000-000000000002	HGB	138	1.5	г/л	\N	2026-10-13 20:26:22.216784	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
09d00000-0000-0000-0000-000000000005	09c00000-0000-0000-0000-000000000003	GLU	4.22	0.1	ммоль/л	\N	2026-10-13 20:26:22.216851	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_reagent_lot; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_reagent_lot (id, analyzer_id, test_code, reagent_name, lot_number, manufacturer, tests_initial, tests_remaining, minimum_tests, expiry_date, opened_at, onboard_stability_days, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
74a1bd9b-7974-4358-9a39-ede32d697e1c	0a2a0000-0000-0000-0000-000000000002	GLU	Glucose HK Gen.3	GLU-77812	Mindray	800	612	100	2027-06-13 20:26:25.036242	2026-10-01 20:26:25.036258	60	t	2026-10-13 20:26:25.038247	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
711f63ab-243c-4ddc-9fb3-a666485e949d	0a2a0000-0000-0000-0000-000000000002	CREAT	Creatinine (Jaffe compensated)	CRE-55120	Mindray	400	38	50	2027-03-13 20:26:25.065273	2026-09-03 20:26:25.065274	45	t	2026-10-13 20:26:25.065481	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
758f0c86-dc3e-4c7a-8e08-e2d9f1fcee85	0a2a0000-0000-0000-0000-000000000001	\N	CELLPACK DCL	CP-24091A	Sysmex	2000	1420	300	2026-10-23 20:26:25.080168	2026-09-23 20:26:25.080168	\N	t	2026-10-13 20:26:25.080353	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8f2ea7bb-fac8-487a-8bc1-4ce28d738dd2	0a2a0000-0000-0000-0000-000000000001	\N	SULFOLYSER	SL-24110	Sysmex	1500	1500	200	2027-12-13 20:26:25.094615	\N	\N	t	2026-10-13 20:26:25.094723	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_reference_layer; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_reference_layer (id, test_id, test_code, method_code, method_name, layer_type, priority_order, norm_name, gender, is_gender, age_unit, age_from, age_to, is_age, is_menstrual_phase, menstrual_phase, is_pregnancy, pregnancy_week_from, pregnancy_week_to, icd10_code, norm_low, norm_high, crit_low, crit_high, norm_text, unit, delta_check_max_pct, analyzer_code, dilution, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
01ad82ff-91ee-cdca-7822-8cc06ed8db3d	b9180163-fed0-792b-8397-7a264a2ffb71	CHOL	\N	\N	DEMOGRAPHIC	40	Холестерин	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	5.2	\N	\N	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.9384	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
02ce36b1-4d26-638b-72c5-7dd0de7f7f9e	a9396732-a004-f61b-52b3-b79513ec3633	TSH	\N	\N	PREGNANCY	10	ТТГ (вагітні)	ANY	f	YEARS	0	120	f	f	\N	t	1	40	\N	0.1	3	\N	\N	\N	мМО/л	\N	\N	\N	t	2026-10-13 20:26:21.938465	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
10d10bed-859e-9029-6971-fced2ec9e964	e2e92758-4a2b-69a0-63c7-f2d972e5d6de	U_SG	\N	\N	DEMOGRAPHIC	40	Питома вага сечі	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	1.005	1.03	\N	\N	\N		\N	\N	\N	t	2026-10-13 20:26:21.938472	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
15bf14be-6d0a-38d5-50e2-22ed6b9ac815	385b6b33-16ea-cd96-f163-0146b79658bc	HGB	\N	\N	DEMOGRAPHIC	40	Гемоглобін (жін.)	F	t	YEARS	0	120	f	f	\N	f	\N	\N	\N	120	150	70	\N	\N	г/л	\N	\N	\N	t	2026-10-13 20:26:21.938431	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2e16d034-63fd-1ba6-3a99-9c3421d82c2e	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	\N	\N	PREGNANCY	10	Глюкоза (вагітні)	ANY	f	YEARS	0	120	f	f	\N	t	1	40	\N	3.3	5.1	2.8	25	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.937908	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3447dd84-5a55-c6ba-d1dd-bc72b83bf0d4	b52ad812-14fc-017f-8043-9d4065b00912	ALT	\N	\N	DEMOGRAPHIC	40	АЛТ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	41	\N	\N	\N	Од/л	\N	\N	\N	t	2026-10-13 20:26:21.938384	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
398a7968-cad8-bb2d-043a-7e35c089476e	e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	\N	\N	DEMOGRAPHIC	40	Глюкоза натще	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	3.9	5.9	2.8	25	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.936876	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
39dbc265-02a4-0de2-1cba-75645787ba80	dc9a931d-5851-e01b-e2f2-fc46621ea597	UREA	\N	\N	DEMOGRAPHIC	40	Сечовина	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	2.5	8.3	\N	40	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.93838	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
40bc2d38-67c0-8f8d-0b84-c96c5a350efe	2d02abde-3000-bfdd-4d01-bf4f7b5efb40	WBC	\N	\N	DEMOGRAPHIC	40	Лейкоцити (дорослі)	ANY	f	YEARS	18	120	t	f	\N	f	\N	\N	\N	4	9	1.5	30	\N	10^9/л	\N	\N	\N	t	2026-10-13 20:26:21.938421	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
41469d5a-3b95-21f9-fd46-5f58b28217b9	419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	\N	\N	DEMOGRAPHIC	40	Креатинін (жін.)	F	t	YEARS	0	120	f	f	\N	f	\N	\N	\N	44	80	\N	700	\N	мкмоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938376	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
43660e43-eb8b-475a-794b-edbb0ad9e36a	26e9c43c-eb4f-4b10-1489-87f7febd4943	APTT	\N	\N	DEMOGRAPHIC	40	АЧТЧ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	25	37	\N	\N	\N	с	\N	\N	\N	t	2026-10-13 20:26:21.938448	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4a1a8329-33b7-ea32-e12f-edcd934fda31	4b9abf1e-f687-3227-cd6d-a9750772996b	K	\N	\N	DEMOGRAPHIC	40	Калій	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	3.5	5.1	2.8	6.5	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938414	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
559a1bf4-d1b4-92be-8c16-716a54820af8	5846d6ec-098e-d107-7ca9-76e04c5ac760	U_PH	\N	\N	DEMOGRAPHIC	40	pH сечі	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	5	8	\N	\N	\N		\N	\N	\N	t	2026-10-13 20:26:21.938476	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
576258f5-bccd-6ed9-1fa5-b575f2718e3f	17f44917-1e73-c00d-1f94-829b314117d2	AST	\N	\N	DEMOGRAPHIC	40	АСТ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	40	\N	\N	\N	Од/л	\N	\N	\N	t	2026-10-13 20:26:21.938387	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5b5ae9b5-c180-3a88-3d0f-96883146e904	b377d2d6-d0ae-5cff-2461-3aa50773e41f	PSA	\N	\N	DEMOGRAPHIC	40	ПСА загальний	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	4	\N	\N	\N	нг/мл	\N	\N	\N	t	2026-10-13 20:26:21.938455	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5d02466d-2550-8f95-39c2-0838615c365a	6d3046d3-9cb0-71d0-b5d3-632f12bed916	BIL_TOT	\N	\N	DEMOGRAPHIC	40	Білірубін загальний	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	3.4	20.5	\N	300	\N	мкмоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938391	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7207e16b-16b6-fe2d-481b-acc9cc079903	385b6b33-16ea-cd96-f163-0146b79658bc	HGB	\N	\N	DEMOGRAPHIC	40	Гемоглобін (чол.)	M	t	YEARS	0	120	f	f	\N	f	\N	\N	\N	130	170	70	\N	\N	г/л	\N	\N	\N	t	2026-10-13 20:26:21.938428	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
726d7027-3090-5477-2f94-f1e055909ff5	58a8f55f-964b-c194-0eb7-a7421875d22c	RBC	\N	\N	DEMOGRAPHIC	40	Еритроцити	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	3.8	5.5	\N	\N	\N	10^12/л	\N	\N	\N	t	2026-10-13 20:26:21.938434	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7d1a2848-34f1-6c96-c61a-f7f14337a9c6	2d02abde-3000-bfdd-4d01-bf4f7b5efb40	WBC	\N	\N	DEMOGRAPHIC	40	Лейкоцити (діти до 18)	ANY	f	YEARS	0	18	t	f	\N	f	\N	\N	\N	5	14.5	1.5	30	\N	10^9/л	\N	\N	\N	t	2026-10-13 20:26:21.938424	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
934feee6-9ee5-c756-2645-c5efe63ee384	3ab55622-32af-eef0-0224-0b3ad5d96d6f	FPSA	\N	\N	DEMOGRAPHIC	40	ПСА вільний	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	1	\N	\N	\N	нг/мл	\N	\N	\N	t	2026-10-13 20:26:21.938458	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9feb86a2-d5d4-89c1-c673-3a447207da38	419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	\N	\N	DEMOGRAPHIC	40	Креатинін (чол.)	M	t	YEARS	0	120	f	f	\N	f	\N	\N	\N	62	106	\N	700	\N	мкмоль/л	\N	\N	\N	t	2026-10-13 20:26:21.93836	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a4871541-d4e4-c75b-3675-361a880f7954	7056a922-9eaa-71db-8831-89963768bd12	PROT_TOT	\N	\N	DEMOGRAPHIC	40	Білок загальний	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	64	83	\N	\N	\N	г/л	\N	\N	\N	t	2026-10-13 20:26:21.938394	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a8be7892-0409-95cf-d841-22df7d96c570	a4a22087-0271-8aeb-b832-d77465333a2b	FIBRINOGEN	\N	\N	DEMOGRAPHIC	40	Фібриноген	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	2	4	\N	\N	\N	г/л	\N	\N	\N	t	2026-10-13 20:26:21.938452	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ab44bae0-5ba8-adc0-9db0-cce39d9c98e1	8a26d96f-50d9-09e0-13b2-d927525708ca	HDL	\N	\N	DEMOGRAPHIC	40	ЛПВЩ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	1	3	\N	\N	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938404	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
acadbe75-3ee6-abd6-619c-6455645dfeba	151cdd48-ad74-66fd-6a6f-caa3190d7521	LDL	\N	\N	DEMOGRAPHIC	40	ЛПНЩ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	3	\N	\N	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938407	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b5475ecf-4df8-0e34-f289-5c8f5e3d1863	2390521a-4884-14a4-7e9b-e521a2f6d403	TG	\N	\N	DEMOGRAPHIC	40	Тригліцериди	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0	1.7	\N	\N	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938411	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b9314d12-48d2-c4c4-f6c7-425e4be6cb8d	5727e22c-9fe6-5f77-3938-31fa39031a51	NA	\N	\N	DEMOGRAPHIC	40	Натрій	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	136	145	120	160	\N	ммоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938417	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
bf60b949-38d4-4c4a-afb7-dd6bfd662ad1	cb7ec275-c691-451e-c6a2-50b68ad556cc	FT4	\N	\N	DEMOGRAPHIC	40	Т4 вільний	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	9	22	\N	\N	\N	пмоль/л	\N	\N	\N	t	2026-10-13 20:26:21.938469	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d69659f4-2844-da99-7534-a88919fc8195	aa0f5a5a-f0ee-c2a9-5627-2ef8b023c646	PT	\N	\N	DEMOGRAPHIC	40	Протромбіновий час	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	11	15	\N	\N	\N	с	\N	\N	\N	t	2026-10-13 20:26:21.938442	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e68615ab-cbe6-1287-b799-20ac355717a7	9a41c97e-a1ff-3057-51c8-7227b8a34eca	INR	\N	\N	DEMOGRAPHIC	40	МНВ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0.8	1.2	\N	5	\N		\N	\N	\N	t	2026-10-13 20:26:21.938445	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
f9380e70-25b4-f038-2bae-ea0b8bbfe2e6	a9396732-a004-f61b-52b3-b79513ec3633	TSH	\N	\N	DEMOGRAPHIC	40	ТТГ	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	0.4	4	\N	\N	\N	мМО/л	\N	\N	\N	t	2026-10-13 20:26:21.938462	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
fd8c4b51-fb6b-4c00-6578-25e6db85e57f	9a0184d8-1d16-8fb3-e23d-daf43523e669	PLT	\N	\N	DEMOGRAPHIC	40	Тромбоцити	ANY	f	YEARS	0	120	f	f	\N	f	\N	\N	\N	150	400	20	1000	\N	10^9/л	\N	\N	\N	t	2026-10-13 20:26:21.938438	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_reflex_rule; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_reflex_rule (id, trigger_test_code, condition_operator, threshold_value, reflex_test_code, auto_approve, requires_same_sample, description, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0f1e0000-0000-0000-0000-000000000001	PSA	>	4	FPSA	f	t	ПСА > 4 нг/мл → додати вільний ПСА	t	2026-10-13 20:26:21.969437	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_result_history; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_result_history (id, order_test_id, result_id, version, action, numeric_value, string_value, flag, actor_id, at, comment, snapshot_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
9b0d3b3d-9de6-490b-b930-a86cde5f4d9e	7f110624-c85b-4411-981a-2caa688e771f	7964def1-22c9-4015-ba33-98b6d83f262d	1	ENTERED	5.4	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.734769	\N	{"NumericValue":5.4,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.9,"NormHigh":5.9,"CritLow":2.8,"CritHigh":25,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:22.734769Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.734769Z","Version":1}	2026-10-13 20:26:22.786418	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a39fd9d4-0f7f-4835-b875-a6c4dddb0551	d6039ece-8620-408f-890f-b550e5568dc8	ab82ee3c-0c7e-4803-8501-4f84fb670060	1	ENTERED	168	\N	HIGH	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.815219	\N	{"NumericValue":168,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"HIGH","NormLow":62,"NormHigh":106,"CritLow":null,"CritHigh":700,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.815219Z","Version":1}	2026-10-13 20:26:22.816058	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b4bc64a2-363b-487b-a929-ad0cbd8daed1	05d422f7-71b2-4fa9-ad42-3a2e688e1430	17f7ceb4-cc4f-4c51-986b-5a0c74e6812e	1	ENTERED	12.1	\N	HIGH	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.823484	\N	{"NumericValue":12.1,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"HIGH","NormLow":2.5,"NormHigh":8.3,"CritLow":null,"CritHigh":40,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.823484Z","Version":1}	2026-10-13 20:26:22.823855	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
bfcd596a-078b-4ade-9867-56432a7dc68a	f825460d-a54c-49f9-aabe-cc7091189551	0747357d-274c-4c28-91ef-4a1b00dc29eb	1	ENTERED	28	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.831304	\N	{"NumericValue":28,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":41,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:22.831304Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.831304Z","Version":1}	2026-10-13 20:26:22.83591	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
067d8725-101f-4605-b0a2-83d0545544a0	44c2fe4e-03b0-4789-97e5-5b09772cde61	cd39d3aa-2abf-426d-a8f6-d9064237f5af	1	ENTERED	24	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.843177	\N	{"NumericValue":24,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":40,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:22.843177Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.843177Z","Version":1}	2026-10-13 20:26:22.847721	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5daf3bc6-ceda-4a91-9ef1-d066f74baa10	059f6563-49ba-4cdc-bd27-ac17b9d9e36a	b80b666b-291c-444e-83a6-8893beca5f6a	1	ENTERED	11.2	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.855001	\N	{"NumericValue":11.2,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.4,"NormHigh":20.5,"CritLow":null,"CritHigh":300,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:22.855001Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.855001Z","Version":1}	2026-10-13 20:26:22.85983	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
43160fc6-05bf-49e2-9aa0-27fa4449b81f	4e1a6b24-2ff4-49dd-bb27-a711976ff771	c566874b-5979-4eef-8f00-a7bd2d020914	1	ENTERED	71	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.867549	\N	{"NumericValue":71,"StringValue":null,"Unit":"\\u0433/\\u043B","Flag":"NORMAL","NormLow":64,"NormHigh":83,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:22.867549Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.867549Z","Version":1}	2026-10-13 20:26:22.87211	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b3ee4914-1443-4061-8724-3283dc9d650c	84e295a9-d52f-4d29-926a-d2a78dadd0e6	09f66487-3a79-463a-99bf-d8549909f744	1	ENTERED	6.8	\N	CRIT_HIGH	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.879639	\N	{"NumericValue":6.8,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"CRIT_HIGH","NormLow":3.5,"NormHigh":5.1,"CritLow":2.8,"CritHigh":6.5,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.879639Z","Version":1}	2026-10-13 20:26:22.880195	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
65293cab-e67f-400e-8ad8-0f9a300c530f	016beec8-2e7f-4071-8246-528692149153	c279bc98-a741-4831-b5a0-d96ac7abb262	1	ENTERED	134	\N	LOW	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:22.888247	\N	{"NumericValue":134,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"LOW","NormLow":136,"NormHigh":145,"CritLow":120,"CritHigh":160,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.888247Z","Version":1}	2026-10-13 20:26:22.888683	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7b47875b-8a6b-4b43-ae41-74b8cb22388e	d6039ece-8620-408f-890f-b550e5568dc8	ab82ee3c-0c7e-4803-8501-4f84fb670060	1	VERIFIED	168	\N	HIGH	0e000000-0000-0000-0000-000000000002	2026-10-13 20:26:22.910166	\N	{"NumericValue":168,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"HIGH","NormLow":62,"NormHigh":106,"CritLow":null,"CritHigh":700,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":"0e000000-0000-0000-0000-000000000002","VerifiedAt":"2026-10-13T20:26:22.905352Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.815219Z","Version":1}	2026-10-13 20:26:22.910168	0e000000-0000-0000-0000-000000000002	\N	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
8fcf698f-7bf8-439a-9d8d-6132d739631f	05d422f7-71b2-4fa9-ad42-3a2e688e1430	17f7ceb4-cc4f-4c51-986b-5a0c74e6812e	1	VERIFIED	12.1	\N	HIGH	0e000000-0000-0000-0000-000000000002	2026-10-13 20:26:22.923867	\N	{"NumericValue":12.1,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"HIGH","NormLow":2.5,"NormHigh":8.3,"CritLow":null,"CritHigh":40,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":"0e000000-0000-0000-0000-000000000002","VerifiedAt":"2026-10-13T20:26:22.919525Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.823484Z","Version":1}	2026-10-13 20:26:22.923867	0e000000-0000-0000-0000-000000000002	\N	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
4d856b13-3b80-40b5-9774-795e4f9be9a2	84e295a9-d52f-4d29-926a-d2a78dadd0e6	09f66487-3a79-463a-99bf-d8549909f744	1	VERIFIED	6.8	\N	CRIT_HIGH	0e000000-0000-0000-0000-000000000002	2026-10-13 20:26:22.93659	Критична гіперкаліємія 6.8 ммоль/л — повідомлено лікуючого лікаря телефоном	{"NumericValue":6.8,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"CRIT_HIGH","NormLow":3.5,"NormHigh":5.1,"CritLow":2.8,"CritHigh":6.5,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":"0e000000-0000-0000-0000-000000000002","VerifiedAt":"2026-10-13T20:26:22.932017Z","VerificationComment":"\\u041A\\u0440\\u0438\\u0442\\u0438\\u0447\\u043D\\u0430 \\u0433\\u0456\\u043F\\u0435\\u0440\\u043A\\u0430\\u043B\\u0456\\u0454\\u043C\\u0456\\u044F 6.8 \\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B \\u2014 \\u043F\\u043E\\u0432\\u0456\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u043E \\u043B\\u0456\\u043A\\u0443\\u044E\\u0447\\u043E\\u0433\\u043E \\u043B\\u0456\\u043A\\u0430\\u0440\\u044F \\u0442\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\\u043E\\u043C","OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.879639Z","Version":1}	2026-10-13 20:26:22.936591	0e000000-0000-0000-0000-000000000002	\N	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
e9e1aed0-e9a8-48c6-a3df-878ba522656a	016beec8-2e7f-4071-8246-528692149153	c279bc98-a741-4831-b5a0-d96ac7abb262	1	VERIFIED	134	\N	LOW	0e000000-0000-0000-0000-000000000002	2026-10-13 20:26:22.950382	\N	{"NumericValue":134,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"LOW","NormLow":136,"NormHigh":145,"CritLow":120,"CritHigh":160,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":"0e000000-0000-0000-0000-000000000002","VerifiedAt":"2026-10-13T20:26:22.945355Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:22.888247Z","Version":1}	2026-10-13 20:26:22.950384	0e000000-0000-0000-0000-000000000002	\N	0e000000-0000-0000-0000-000000000002	2	d0000000-0000-0000-0000-000000000001
86698135-db1d-44a7-b051-ad27fb718630	3ff7b478-e872-4003-97dd-cc8a3543dac9	c43b5ed8-27a9-4509-8727-ca00b4d00425	1	ENTERED	5.1	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.103701	\N	{"NumericValue":5.1,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.9,"NormHigh":5.9,"CritLow":2.8,"CritHigh":25,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.103701Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.103701Z","Version":1}	2026-10-13 20:26:23.112264	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cb5d1438-861b-42a4-85b5-5e80fc3f0aa7	64d67447-5181-43f4-a551-5c8c102385fb	5d84bbf9-23dd-4340-8527-04bb07c160b5	1	ENTERED	74	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.122258	\N	{"NumericValue":74,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":44,"NormHigh":80,"CritLow":null,"CritHigh":700,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.122258Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.122258Z","Version":1}	2026-10-13 20:26:23.127463	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
1d92a078-d20b-47a9-87f3-aaf4f48cfff7	d7ef4b25-87fe-4bab-93e0-c883f08f8fa6	1435ed7d-85ab-41ee-a0e2-d9240b5aa4c1	1	ENTERED	4.9	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.135954	\N	{"NumericValue":4.9,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":2.5,"NormHigh":8.3,"CritLow":null,"CritHigh":40,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.135954Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.135954Z","Version":1}	2026-10-13 20:26:23.140962	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
18f54025-6799-4835-8ac1-69f09ed591c5	b72e059f-c55c-4bab-8cbb-7cad8a4f41a7	6c1c37da-c906-461a-8443-03944caeff85	1	ENTERED	22	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.150195	\N	{"NumericValue":22,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":41,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.150195Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.150195Z","Version":1}	2026-10-13 20:26:23.155901	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f819c167-a205-4885-b7f8-9ca877122780	31ea1f40-2ebb-430a-a184-b4a3d7fa2828	83c647cc-65ac-45d9-a1cd-90b5c8a6b2f6	1	ENTERED	20	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.164033	\N	{"NumericValue":20,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":40,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.164033Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.164033Z","Version":1}	2026-10-13 20:26:23.169652	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dd47917d-ae4a-469e-b174-f39e3d5798dc	9d217a05-6d9d-44ab-a281-a3052e8cdb6b	4b785e89-c2fd-4c32-a0a5-f61119670a95	1	ENTERED	9.8	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.178465	\N	{"NumericValue":9.8,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.4,"NormHigh":20.5,"CritLow":null,"CritHigh":300,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.178465Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.178465Z","Version":1}	2026-10-13 20:26:23.183725	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7640e6c2-d607-42cd-bd5e-00fc4d069585	dc1789e1-b032-4056-a21f-d3f0dc675b2b	a3f4e07b-1b8a-414f-bcf5-5f837596d5e1	1	ENTERED	73	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.193829	\N	{"NumericValue":73,"StringValue":null,"Unit":"\\u0433/\\u043B","Flag":"NORMAL","NormLow":64,"NormHigh":83,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.193829Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.193829Z","Version":1}	2026-10-13 20:26:23.199502	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
179697b1-69ff-4b23-afdb-73a3b9bc02f8	d6c2e511-756f-4ade-80f0-9bcd5b5a06d5	78b9024c-5154-45ec-b98a-557370793b4a	1	ENTERED	7.9	\N	HIGH	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.400207	\N	{"NumericValue":7.9,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"HIGH","NormLow":3.9,"NormHigh":5.9,"CritLow":2.8,"CritHigh":25,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.400207Z","Version":1}	2026-10-13 20:26:23.400987	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
e243cc28-8261-4e9f-9ad3-e55420739ea2	ac4a2f93-b7aa-4626-a04e-bce186a8e98f	962c53a9-c43e-49b4-9063-4030fc8eae43	1	ENTERED	76	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.411818	\N	{"NumericValue":76,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":44,"NormHigh":80,"CritLow":null,"CritHigh":700,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.411818Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.411818Z","Version":1}	2026-10-13 20:26:23.420792	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
96380914-8e3c-43e3-94f1-7dfe1ca92645	613b3264-5098-4615-927a-5bbd7879a99a	7a553110-fda7-472b-a23f-ac1f54833c27	1	ENTERED	5.2	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.432305	\N	{"NumericValue":5.2,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":2.5,"NormHigh":8.3,"CritLow":null,"CritHigh":40,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.432305Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.432305Z","Version":1}	2026-10-13 20:26:23.439998	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
970c8768-d760-425d-a995-299fd2596707	8d41a71e-c391-48c1-bf82-7cb736d79f75	9b43db16-6326-4f31-859d-2fad738f8ae2	1	ENTERED	24	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.450779	\N	{"NumericValue":24,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":41,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.450779Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.450779Z","Version":1}	2026-10-13 20:26:23.458477	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d85a12d8-e5b2-4f2b-ab23-61e975a313ec	7499aa35-d33d-4443-9a19-a91e1562b1a6	71596032-c634-4499-af42-7563c4e2b6b1	1	ENTERED	21	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-13 20:26:23.469258	\N	{"NumericValue":21,"StringValue":null,"Unit":"\\u041E\\u0434/\\u043B","Flag":"NORMAL","NormLow":0,"NormHigh":40,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":"N","IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.469258Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-13T20:26:23.469258Z","Version":1}	2026-10-13 20:26:23.476584	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
538f50ce-70de-49bd-97da-3661127e74cc	6dd75bb6-4788-4a55-9171-1dafda27eb0a	af08200d-61b5-459c-9e44-c2d8ded7868b	1	ENTERED	13.1	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.593535	\N	{"NumericValue":13.1,"StringValue":null,"Unit":"\\u0441","Flag":"NORMAL","NormLow":11,"NormHigh":15,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.593535Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.593535Z","Version":1}	2026-10-13 20:26:23.601482	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
364f42f0-1664-4f01-a3e3-60eb9337dcec	8f776604-3f43-412e-98a4-7b768e917438	c6dd2b05-0463-46c2-8906-f4e3ede4e6ab	1	ENTERED	2.6	\N	HIGH	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.612491	\N	{"NumericValue":2.6,"StringValue":null,"Unit":"","Flag":"HIGH","NormLow":0.8,"NormHigh":1.2,"CritLow":null,"CritHigh":5,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.612491Z","Version":1}	2026-10-13 20:26:23.6129	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8f51ee9f-3711-4ca0-a8ef-a44713dd8e02	241d88c6-7efa-46a8-83fc-91870d3ada30	d6efb458-7bd7-4cdb-8975-3ba9bf52eaa0	1	ENTERED	31	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.623576	\N	{"NumericValue":31,"StringValue":null,"Unit":"\\u0441","Flag":"NORMAL","NormLow":25,"NormHigh":37,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.623576Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.623576Z","Version":1}	2026-10-13 20:26:23.631349	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cc9a3424-7230-4354-b616-adc959a18662	facd213b-5bb6-4de2-9e70-6a1c9d5cf4da	6d62a5ab-e1c4-4ffc-96fc-e7e358bdfa30	1	ENTERED	3.1	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.642268	\N	{"NumericValue":3.1,"StringValue":null,"Unit":"\\u0433/\\u043B","Flag":"NORMAL","NormLow":2,"NormHigh":4,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.642268Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.642268Z","Version":1}	2026-10-13 20:26:23.650165	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
580596d0-1203-4d81-b897-9aa27065b000	c7c78c00-705a-40a3-a890-603987bdbed2	222a9697-e00c-4a63-b057-f52e2d173c5f	1	ENTERED	5.2	\N	HIGH	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.660894	\N	{"NumericValue":5.2,"StringValue":null,"Unit":"\\u043D\\u0433/\\u043C\\u043B","Flag":"HIGH","NormLow":0,"NormHigh":4,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.660894Z","Version":1}	2026-10-13 20:26:23.661294	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
98619e50-9ea5-41e4-8cb3-0b70826f37fb	44810dce-2ac6-474e-9dd6-20791ec23cd3	f5780c0a-01d3-456b-9b65-2e541fd9ebd8	1	ENTERED	5.2	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.779424	\N	{"NumericValue":5.2,"StringValue":null,"Unit":"\\u043C\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.9,"NormHigh":5.9,"CritLow":2.8,"CritHigh":25,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.779424Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.779424Z","Version":1}	2026-10-13 20:26:23.788111	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8ba6cb12-d41d-4a60-a92f-d97afef7b827	14f33f52-b961-407b-8d6a-d6ddf8701287	3bf2cc20-7e64-46e3-9304-02e3d4df958d	1	ENTERED	3.5	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.799486	\N	{"NumericValue":3.5,"StringValue":null,"Unit":"\\u043C\\u041C\\u041E/\\u043B","Flag":"NORMAL","NormLow":0.4,"NormHigh":4,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:23.799486Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:23.799486Z","Version":1}	2026-10-13 20:26:23.807975	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5b710448-522c-4a16-ba76-fa388fba25dd	b3d0e365-ec21-4839-883f-73277e56de91	a75219d2-b1af-4045-bb9d-218cd7645f35	1	ENTERED	\N	жовтий	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.034844	\N	{"NumericValue":null,"StringValue":"\\u0436\\u043E\\u0432\\u0442\\u0438\\u0439","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.034844Z","Version":1}	2026-10-13 20:26:24.035492	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6d830bbb-9d3b-4c3d-9bbf-f1ef70328d64	03210845-013b-4c3d-9159-973a8de1a7af	f77fd11c-2c15-40be-89d8-2ac09ab917c7	1	ENTERED	\N	мутна	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.048424	\N	{"NumericValue":null,"StringValue":"\\u043C\\u0443\\u0442\\u043D\\u0430","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.048424Z","Version":1}	2026-10-13 20:26:24.048595	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
10d61617-fbf5-4c48-8122-8914c3440642	a52636a9-11d5-4e1f-8814-7f26030adc88	ca11ac3b-c0eb-4d93-8588-5116fe7e9418	1	ENTERED	\N	сліди	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.061342	\N	{"NumericValue":null,"StringValue":"\\u0441\\u043B\\u0456\\u0434\\u0438","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.061342Z","Version":1}	2026-10-13 20:26:24.061564	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
266b8b6b-ee8c-4851-a453-71a5d92e1ef8	dc9fd361-77ad-48cc-b7f6-bd6f4d9ace37	6e7e9d62-cfad-47d3-aee9-1d9d08eb4ca3	1	ENTERED	\N	не виявлено	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.074791	\N	{"NumericValue":null,"StringValue":"\\u043D\\u0435 \\u0432\\u0438\\u044F\\u0432\\u043B\\u0435\\u043D\\u043E","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.074791Z","Version":1}	2026-10-13 20:26:24.074998	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cdb463d4-1c11-44b7-a685-87e0c6532a0d	f6a16ae3-7345-4029-b529-aba0d286f864	38b71a30-a867-4f93-9755-2565b1f5b6e5	1	ENTERED	\N	не виявлено	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.088816	\N	{"NumericValue":null,"StringValue":"\\u043D\\u0435 \\u0432\\u0438\\u044F\\u0432\\u043B\\u0435\\u043D\\u043E","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.088816Z","Version":1}	2026-10-13 20:26:24.089066	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8d0f197a-ed81-4a33-8e60-3135090ccc47	b21d25aa-487b-40c3-8284-ecb2a2111ef0	83649285-9e83-446b-9150-f70e19bcf3af	1	ENTERED	\N	+++	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.102006	\N	{"NumericValue":null,"StringValue":"\\u002B\\u002B\\u002B","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.102006Z","Version":1}	2026-10-13 20:26:24.102179	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a8753a17-6bd8-44cf-92f8-b885751f1e20	a1afc828-ef1b-4b6c-b0dc-64d2be8c294e	cdc1cf59-5a03-44c1-8238-e74020e90251	1	ENTERED	\N	+	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.115788	\N	{"NumericValue":null,"StringValue":"\\u002B","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.115788Z","Version":1}	2026-10-13 20:26:24.116061	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d4e1e245-5d98-4096-8b0b-07d5c75c1530	9e9dedb9-b1e3-4790-b9b2-afcbe04f0e7c	80d4b5b7-b2cf-42cf-a409-c413cab37ef0	1	ENTERED	\N	позитивно	NONE	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.130167	\N	{"NumericValue":null,"StringValue":"\\u043F\\u043E\\u0437\\u0438\\u0442\\u0438\\u0432\\u043D\\u043E","Unit":"","Flag":"NONE","NormLow":null,"NormHigh":null,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":false,"VerifiedById":null,"VerifiedAt":null,"VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.130167Z","Version":1}	2026-10-13 20:26:24.130403	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
af631811-783c-421f-88e2-3ef0c50f9a29	5e632bc0-34e8-440b-ae88-61126f1dbfc4	ea900a56-f18d-4055-a726-4d3d77fd9433	1	ENTERED	1.018	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.148007	\N	{"NumericValue":1.018,"StringValue":null,"Unit":"","Flag":"NORMAL","NormLow":1.005,"NormHigh":1.03,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:24.148007Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.148007Z","Version":1}	2026-10-13 20:26:24.158418	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ff4f8c68-ec0f-4eb9-a8fd-65f36a6a6b65	30c2bcac-31c0-48d7-b9f8-966dd4e872e0	dc0163c3-2fa2-42fb-a9ba-e2f72013d074	1	ENTERED	6	\N	NORMAL	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.171957	\N	{"NumericValue":6,"StringValue":null,"Unit":"","Flag":"NORMAL","NormLow":5,"NormHigh":8,"CritLow":null,"CritHigh":null,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":null,"AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-13T20:26:24.171957Z","VerificationComment":null,"OperatorComment":null,"EnteredById":"0e000000-0000-0000-0000-000000000001","EnteredAt":"2026-10-13T20:26:24.171957Z","Version":1}	2026-10-13 20:26:24.181495	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
341464c7-5dad-4b29-be21-50b6692c0706	10f336d2-2de0-4ec8-b9dc-b7ddc066bae3	5835cd38-57bb-4d5c-958a-46ea95a8ba7e	1	ENTERED	12.3	\N	NORMAL	SYSTEM:0a2a0000-0000-0000-0000-000000000002	2026-10-26 12:06:37.942052	\N	{"NumericValue":12.3,"StringValue":null,"Unit":"\\u043C\\u043A\\u043C\\u043E\\u043B\\u044C/\\u043B","Flag":"NORMAL","NormLow":3.4,"NormHigh":20.5,"CritLow":null,"CritHigh":300,"DeltaPercent":null,"DeltaAlert":false,"AnalyzerId":"0a2a0000-0000-0000-0000-000000000002","AnalyzerFlags":null,"IsAutoVerified":true,"VerifiedById":null,"VerifiedAt":"2026-10-26T12:06:37.942052Z","VerificationComment":null,"OperatorComment":null,"EnteredById":null,"EnteredAt":"2026-10-26T12:06:37.942052Z","Version":1}	2026-10-26 12:06:38.046692	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_sample_logistics; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_sample_logistics (id, manifest_number, origin_department_id, destination_department_id, courier_name, courier_phone, dispatched_at, dispatched_by_id, temperature_dispatch, received_at, received_by_id, temperature_receipt, is_cold_chain_violated, status, notes, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
663f0f1c-3676-4bc2-985b-2122e15b0602	MAN-261013-0001	0d000000-0000-0000-0000-000000000002	0d000000-0000-0000-0000-000000000001	Ткаченко А.М.	+380671000005	2026-10-13 20:26:23.880912	0e000000-0000-0000-0000-000000000001	4.5	\N	\N	\N	f	DISPATCHED	\N	2026-10-13 20:26:23.857319	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_sample_logistics_item; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_sample_logistics_item (id, logistics_id, sample_id, barcode, status, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
28c93516-c272-4302-a07b-78fc024557c0	663f0f1c-3676-4bc2-985b-2122e15b0602	4034c91e-665b-4903-a8f1-d053d0c27082	10048085	EN_ROUTE	2026-10-13 20:26:23.880421	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_sample_stage_event; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_sample_stage_event (id, sample_id, stage_code, at, by_id, note, temperature, instrument_id, data_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_section; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_section (id, code, name, section_type, department_id, journal_mask, journal_reset_period, secondary_mask, auto_release_verified, workflow_template_code, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
0e5e0000-0000-0000-0000-000000000001	BIOCHEM	Клінічна біохімія	CLINICAL_BIOCHEM	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.841773	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e5e0000-0000-0000-0000-000000000002	HEMA	Гематологія	HEMATOLOGY	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.842133	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e5e0000-0000-0000-0000-000000000003	COAG	Коагулологія	COAG	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.842137	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e5e0000-0000-0000-0000-000000000004	IMMUNO	Імунологія	IMMUNO	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.842139	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e5e0000-0000-0000-0000-000000000005	URINE	Загальний аналіз сечі	URINALYSIS	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.842141	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
0e5e0000-0000-0000-0000-000000000006	MICRO	Мікробіологія	MICROBIOLOGY	\N	{yyyy}-{seq6}	YEAR	\N	t	CLINICAL	t	2026-10-13 20:26:21.842143	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_section_journal_entry; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_section_journal_entry (id, lab_section_id, order_id, sample_id, order_test_ids_json, journal_number, sequence_value, day_number, secondary_number, period_key, registered_at, registered_by_id, status, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
8f40c09c-be25-426b-976e-bd71be23c964	0e5e0000-0000-0000-0000-000000000001	114408bc-3e27-48da-a3da-6cad07265a3d	2b8abeda-1644-4059-a9d2-6b26d17eefaf	["7f110624-c85b-4411-981a-2caa688e771f","d6039ece-8620-408f-890f-b550e5568dc8","05d422f7-71b2-4fa9-ad42-3a2e688e1430","f825460d-a54c-49f9-aabe-cc7091189551","44c2fe4e-03b0-4789-97e5-5b09772cde61","059f6563-49ba-4cdc-bd27-ac17b9d9e36a","4e1a6b24-2ff4-49dd-bb27-a711976ff771","84e295a9-d52f-4d29-926a-d2a78dadd0e6","016beec8-2e7f-4071-8246-528692149153"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:22.649268	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:22.668837	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ee9c53db-17b7-4054-95a6-9ce47756bae2	0e5e0000-0000-0000-0000-000000000001	e22b5f66-51fd-4228-aec6-0d40ffe71e59	2d88446e-7ab8-40c3-a68d-89064c4ebcc7	["3ff7b478-e872-4003-97dd-cc8a3543dac9","64d67447-5181-43f4-a551-5c8c102385fb","d7ef4b25-87fe-4bab-93e0-c883f08f8fa6","b72e059f-c55c-4bab-8cbb-7cad8a4f41a7","31ea1f40-2ebb-430a-a184-b4a3d7fa2828","9d217a05-6d9d-44ab-a281-a3052e8cdb6b","dc1789e1-b032-4056-a21f-d3f0dc675b2b"]	2026-000002	2	2	\N	2026	2026-10-13 20:26:23.085117	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.090736	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c680b967-75f3-4502-8371-9712d59060ab	0e5e0000-0000-0000-0000-000000000001	b76dd818-1d59-47bb-953c-35e581dd8fa1	9e651e03-452e-4a9f-9de9-387c2e51caaf	["d6c2e511-756f-4ade-80f0-9bcd5b5a06d5","ac4a2f93-b7aa-4626-a04e-bce186a8e98f","613b3264-5098-4615-927a-5bbd7879a99a","8d41a71e-c391-48c1-bf82-7cb736d79f75","7499aa35-d33d-4443-9a19-a91e1562b1a6","10f336d2-2de0-4ec8-b9dc-b7ddc066bae3","960996bd-e7f3-4df2-8bec-35781537f928"]	2026-000003	3	3	\N	2026	2026-10-13 20:26:23.382839	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.387514	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
0b186f9a-0cd4-405a-89cc-9d1bfd801a30	0e5e0000-0000-0000-0000-000000000003	65cf762d-b666-41f7-bdf6-e7fcac26995a	fec1fff2-f554-4327-b431-28f39f1784b6	["6dd75bb6-4788-4a55-9171-1dafda27eb0a","8f776604-3f43-412e-98a4-7b768e917438","241d88c6-7efa-46a8-83fc-91870d3ada30","facd213b-5bb6-4de2-9e70-6a1c9d5cf4da"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:23.522813	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.543438	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dbf515ae-6fb2-4fce-a0ab-1d2be9c5dc01	0e5e0000-0000-0000-0000-000000000004	65cf762d-b666-41f7-bdf6-e7fcac26995a	61493080-29f3-4505-bf3e-f3e4a992953c	["c7c78c00-705a-40a3-a890-603987bdbed2"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:23.561445	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.581136	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
be88ed22-4ea6-40fe-8a83-1d058ccc6388	0e5e0000-0000-0000-0000-000000000004	bcf1d023-88a2-494b-bee3-1ed451977065	0f58869c-1172-4434-b957-b763b05c34a0	["14f33f52-b961-407b-8d6a-d6ddf8701287","ac66c76c-d4e3-40d9-9f77-8c242533c782"]	2026-000002	2	2	\N	2026	2026-10-13 20:26:23.715171	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.720104	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dce6d055-ba9b-4407-895d-a867946fa7e5	0e5e0000-0000-0000-0000-000000000001	bcf1d023-88a2-494b-bee3-1ed451977065	0f58869c-1172-4434-b957-b763b05c34a0	["44810dce-2ac6-474e-9dd6-20791ec23cd3"]	2026-000004	4	4	\N	2026	2026-10-13 20:26:23.715171	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.725036	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
310bae07-17eb-42e9-b7d1-26fcdc7a0ff4	0e5e0000-0000-0000-0000-000000000002	bcf1d023-88a2-494b-bee3-1ed451977065	f9331816-6c3a-4992-b300-15ba7d743ac2	["8c56ed6e-7d15-4f37-b6cc-7af4e2b1d428"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:23.744897	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.766213	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
8d3494be-2b7d-4e8d-a855-de8a2bfdbfbf	0e5e0000-0000-0000-0000-000000000005	89300002-0d46-4073-b5c6-271443e1ea3d	536f7f44-6cd8-4283-acf8-3883bfe18dd7	["b3d0e365-ec21-4839-883f-73277e56de91","03210845-013b-4c3d-9159-973a8de1a7af","5e632bc0-34e8-440b-ae88-61126f1dbfc4","30c2bcac-31c0-48d7-b9f8-966dd4e872e0","a52636a9-11d5-4e1f-8814-7f26030adc88","dc9fd361-77ad-48cc-b7f6-bd6f4d9ace37","f6a16ae3-7345-4029-b529-aba0d286f864","b21d25aa-487b-40c3-8284-ecb2a2111ef0","a1afc828-ef1b-4b6c-b0dc-64d2be8c294e","9e9dedb9-b1e3-4790-b9b2-afcbe04f0e7c"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:23.953273	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:23.976124	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b7783d74-4ec2-4374-b276-b6e6aa6b2d28	0e5e0000-0000-0000-0000-000000000006	89300002-0d46-4073-b5c6-271443e1ea3d	42e9f3d4-cd58-4081-ab17-87bea65efcbc	["6055fbc9-c68e-4b61-bc15-8d345f9c5dca"]	2026-000001	1	1	\N	2026	2026-10-13 20:26:23.996406	0e000000-0000-0000-0000-000000000001	REGISTERED	2026-10-13 20:26:24.019021	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_send_out; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_send_out (id, number, performer_id, status, external_batch_number, courier_name, temperature_dispatch, dispatched_at, dispatched_by_id, accepted_at, completed_at, notes, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_send_out_item; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_send_out_item (id, send_out_id, order_test_id, sample_id, external_order_number, external_code, status, due_at, result_received_at, reject_reason, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: lab_settings; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_settings (id, director_name, working_hours, order_number_mask, barcode_prefix, report_footer, panic_phone, cold_chain_min_c, cold_chain_max_c, label_printer_host, label_printer_port, label_printer_name, report_templates_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
f4cd300a-48f6-8125-4db0-1ea902a5df72	Тестовий Директор Т.Т.	Пн–Пт 08:00–18:00	{yyMM}-{000000}	ML	Тестові (mock) дані. Не для клінічного використання.	+380441000001	2	8	\N	9100	\N	{"final":true,"preliminary":true,"cito":true,"showPreviousValues":true,"showQr":true}	2026-10-13 20:26:21.499538	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_susceptibility_result; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_susceptibility_result (id, isolate_id, antibiotic_id, method, zone_diameter_mm, mic_value_mg_l, interpretation, is_intrinsic_resistance, breakpoint_id, override_reason, overridden_by_id, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
12109e9b-3c2e-446e-abb8-a19b72e979b7	af06255f-31b5-4826-abd2-c12be0bbc59a	1	DISK_DIFFUSION	18	\N	R	f	25a7d4db-600d-74fc-4b0e-a5386936facc	\N	\N	2026-10-13 20:26:24.312897	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
0e1467e6-487f-4146-be75-a8c05f0c9e9c	af06255f-31b5-4826-abd2-c12be0bbc59a	2	DISK_DIFFUSION	14	\N	R	f	d4278d76-176a-65dc-a1b1-5a4b04fba712	\N	\N	2026-10-13 20:26:24.36341	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
eda27b72-1e4a-4aed-943e-178c4a1ee2bf	af06255f-31b5-4826-abd2-c12be0bbc59a	3	DISK_DIFFUSION	16	\N	R	f	6d2ce3f5-51f1-6308-3782-d3e491cc5843	\N	\N	2026-10-13 20:26:24.394401	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a0dfcf1e-4434-469f-9101-290bbef05280	af06255f-31b5-4826-abd2-c12be0bbc59a	4	DISK_DIFFUSION	27	\N	S	f	8d006569-778d-bb4c-a269-26eff6f45c1c	\N	\N	2026-10-13 20:26:24.424071	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
22d7e1cf-9d77-4672-8015-cc1830822133	af06255f-31b5-4826-abd2-c12be0bbc59a	5	DISK_DIFFUSION	20	\N	S	f	849fb106-21c3-c022-6e5c-e4c9ceaa03a8	\N	\N	2026-10-13 20:26:24.453921	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
4ee248b0-f7bf-486f-8c0b-0b848c23dbf9	af06255f-31b5-4826-abd2-c12be0bbc59a	6	DISK_DIFFUSION	19	\N	S	f	4378be79-7135-103c-bd30-df0039277b35	\N	\N	2026-10-13 20:26:24.483496	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_test_definition; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_test_definition (id, code, name, short_name, loinc_code, unit, decimal_places, result_type, dropdown_options_json, formula, category, biomaterial_type_id, tube_type_id, method_id, method_code, lab_section_id, delta_check_max_pct, delta_check_hours, requires_manual_verification, is_qc_tracked, requires_separate_tube, max_tests_per_tube, required_volume_ml, tube_compatibility_group, price, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
151cdd48-ad74-66fd-6a6f-caa3190d7521	LDL	ЛПНЩ	LDL	\N	ммоль/л	2	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.892802	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
17f44917-1e73-c00d-1f94-829b314117d2	AST	АСТ	AST	\N	Од/л	0	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	55.00	t	2026-10-13 20:26:21.892692	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2390521a-4884-14a4-7e9b-e521a2f6d403	TG	Тригліцериди	TG	\N	ммоль/л	2	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	60.00	t	2026-10-13 20:26:21.892822	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
26e9c43c-eb4f-4b10-1489-87f7febd4943	APTT	АЧТЧ	APTT	\N	с	1	NUMERIC	\N	\N	COAG	3	3	\N	CLOT	0e5e0000-0000-0000-0000-000000000003	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.893027	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2d02abde-3000-bfdd-4d01-bf4f7b5efb40	WBC	Лейкоцити	WBC	\N	10^9/л	2	NUMERIC	\N	\N	HEMATOLOGY	2	2	\N	IMPEDANCE	0e5e0000-0000-0000-0000-000000000002	\N	72	f	t	f	\N	\N	\N	45.00	t	2026-10-13 20:26:21.892896	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
37645829-c22b-9ac4-ecaf-6702303061c1	U_KET	Кетони у сечі	U_KET	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893288	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
385b6b33-16ea-cd96-f163-0146b79658bc	HGB	Гемоглобін	HGB	\N	г/л	0	NUMERIC	\N	\N	HEMATOLOGY	2	2	\N	IMPEDANCE	0e5e0000-0000-0000-0000-000000000002	\N	72	f	t	f	\N	\N	\N	45.00	t	2026-10-13 20:26:21.892918	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3ab55622-32af-eef0-0224-0b3ad5d96d6f	FPSA	ПСА вільний	FPSA	\N	нг/мл	2	NUMERIC	\N	\N	IMMUNO	1	1	\N	CLIA	0e5e0000-0000-0000-0000-000000000004	\N	72	f	t	f	\N	\N	\N	180.00	t	2026-10-13 20:26:21.893095	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
419ce4ee-1b76-f290-0e1c-549102baae72	CREAT	Креатинін	CREAT	\N	мкмоль/л	0	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	55.00	t	2026-10-13 20:26:21.892465	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4b9abf1e-f687-3227-cd6d-a9750772996b	K	Калій	K	\N	ммоль/л	1	NUMERIC	\N	\N	BIOCHEM	1	1	\N	ISE	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	50.00	t	2026-10-13 20:26:21.892847	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5727e22c-9fe6-5f77-3938-31fa39031a51	NA	Натрій	NA	\N	ммоль/л	1	NUMERIC	\N	\N	BIOCHEM	1	1	\N	ISE	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	50.00	t	2026-10-13 20:26:21.892871	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5846d6ec-098e-d107-7ca9-76e04c5ac760	U_PH	pH сечі	U_PH	\N		1	NUMERIC	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893179	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
58a8f55f-964b-c194-0eb7-a7421875d22c	RBC	Еритроцити	RBC	\N	10^12/л	2	NUMERIC	\N	\N	HEMATOLOGY	2	2	\N	IMPEDANCE	0e5e0000-0000-0000-0000-000000000002	\N	72	f	t	f	\N	\N	\N	45.00	t	2026-10-13 20:26:21.892941	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5f4b3231-e2b4-3ba9-7ec3-336b196082ff	U_GLU	Глюкоза у сечі	U_GLU	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893267	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
69eb4fe0-b6a1-6186-06ca-03557bcbd34f	U_NIT	Нітрити у сечі	U_NIT	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893345	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6d3046d3-9cb0-71d0-b5d3-632f12bed916	BIL_TOT	Білірубін загальний	BIL_TOT	\N	мкмоль/л	1	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	55.00	t	2026-10-13 20:26:21.892715	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7056a922-9eaa-71db-8831-89963768bd12	PROT_TOT	Білок загальний	PROT_TOT	\N	г/л	0	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	50.00	t	2026-10-13 20:26:21.892737	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
772a9b8b-36ea-119f-adee-bad2b39bca28	U_PRO	Білок у сечі	U_PRO	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893248	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
8a26d96f-50d9-09e0-13b2-d927525708ca	HDL	ЛПВЩ	HDL	\N	ммоль/л	2	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.892782	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
8a7c22a5-e31d-14d9-0dd6-c619faac4340	URINE_CULTURE	Посів сечі з визначенням чутливості	URINE_CULTURE	\N		0	REPORT	\N	\N	MICROBIOLOGY	5	5	\N	CULTURE	0e5e0000-0000-0000-0000-000000000006	\N	72	f	t	f	\N	\N	\N	250.00	t	2026-10-13 20:26:21.893367	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9a0184d8-1d16-8fb3-e23d-daf43523e669	PLT	Тромбоцити	PLT	\N	10^9/л	0	NUMERIC	\N	\N	HEMATOLOGY	2	2	\N	IMPEDANCE	0e5e0000-0000-0000-0000-000000000002	\N	72	f	t	f	\N	\N	\N	45.00	t	2026-10-13 20:26:21.892962	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9a41c97e-a1ff-3057-51c8-7227b8a34eca	INR	МНВ	INR	\N		2	NUMERIC	\N	\N	COAG	3	3	\N	CLOT	0e5e0000-0000-0000-0000-000000000003	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.893004	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a4a22087-0271-8aeb-b832-d77465333a2b	FIBRINOGEN	Фібриноген	FIBRINOGEN	\N	г/л	1	NUMERIC	\N	\N	COAG	3	3	\N	CLOT	0e5e0000-0000-0000-0000-000000000003	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.893047	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a9396732-a004-f61b-52b3-b79513ec3633	TSH	ТТГ	TSH	\N	мМО/л	2	NUMERIC	\N	\N	IMMUNO	1	1	\N	CLIA	0e5e0000-0000-0000-0000-000000000004	\N	72	f	t	f	\N	\N	\N	150.00	t	2026-10-13 20:26:21.893118	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
aa0f5a5a-f0ee-c2a9-5627-2ef8b023c646	PT	Протромбіновий час	PT	\N	с	1	NUMERIC	\N	\N	COAG	3	3	\N	CLOT	0e5e0000-0000-0000-0000-000000000003	\N	72	f	t	f	\N	\N	\N	70.00	t	2026-10-13 20:26:21.892983	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b377d2d6-d0ae-5cff-2461-3aa50773e41f	PSA	ПСА загальний	PSA	\N	нг/мл	2	NUMERIC	\N	\N	IMMUNO	1	1	\N	CLIA	0e5e0000-0000-0000-0000-000000000004	\N	72	f	t	f	\N	\N	\N	180.00	t	2026-10-13 20:26:21.893075	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b52ad812-14fc-017f-8043-9d4065b00912	ALT	АЛТ	ALT	\N	Од/л	0	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	55.00	t	2026-10-13 20:26:21.892658	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
b9180163-fed0-792b-8397-7a264a2ffb71	CHOL	Холестерин загальний	CHOL	\N	ммоль/л	2	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	60.00	t	2026-10-13 20:26:21.89276	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
cb7ec275-c691-451e-c6a2-50b68ad556cc	FT4	Т4 вільний	FT4	\N	пмоль/л	1	NUMERIC	\N	\N	IMMUNO	1	1	\N	CLIA	0e5e0000-0000-0000-0000-000000000004	\N	72	f	t	f	\N	\N	\N	150.00	t	2026-10-13 20:26:21.893138	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d6221062-0137-ce7c-5e94-e03c6078f6cc	U_COLOR	Колір сечі	U_COLOR	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893203	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
dc9a931d-5851-e01b-e2f2-fc46621ea597	UREA	Сечовина	UREA	\N	ммоль/л	1	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	50.00	t	2026-10-13 20:26:21.892622	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e1dfea1c-3bbd-42f4-097d-f4246fb85bc4	U_LEU	Лейкоцити у сечі	U_LEU	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893307	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e2e92758-4a2b-69a0-63c7-f2d972e5d6de	U_SG	Питома вага сечі	U_SG	\N		3	NUMERIC	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893159	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e97a0a77-84c5-7b12-20f5-f81360c31a8f	GLU	Глюкоза	GLU	\N	ммоль/л	2	NUMERIC	\N	\N	BIOCHEM	1	1	\N	PHOTOMETRY	0e5e0000-0000-0000-0000-000000000001	\N	72	f	t	f	\N	\N	\N	60.00	t	2026-10-13 20:26:21.871657	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
f9e0e0ee-f205-2d99-101f-e6ddd5b21168	U_CLARITY	Прозорість сечі	U_CLARITY	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893223	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ff3ffbe9-faa7-fc07-7abc-925c715ea80e	U_ERY	Еритроцити у сечі	U_ERY	\N		0	TEXT	\N	\N	URINE	4	4	\N	DIPSTICK	0e5e0000-0000-0000-0000-000000000005	\N	72	f	t	f	\N	\N	\N	20.00	t	2026-10-13 20:26:21.893326	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_test_profile; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_test_profile (id, code, name, category, turnaround_hours, fasting_required, price, default_biomaterial_type_id, default_tube_type_id, organization_service_id, ehealth_service_catalog_service_id, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
15c0e450-bd3b-f3a5-6df0-0a1504167016	PROF_CBC	Загальний аналіз крові	Гематологія	4	f	180.00	2	2	05e00000-0000-0000-0000-000000000003	a2d02e45-fdfd-ba67-04b9-91818bc5bb73	t	2026-10-13 20:26:21.914428	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
20f8d458-4c0a-6d73-4767-180e83ac2d47	PROF_URINE	Загальний аналіз сечі	Сеча	4	f	150.00	4	4	05e00000-0000-0000-0000-000000000006	c01c3e12-3f60-be81-ac61-08eab414d08d	t	2026-10-13 20:26:21.91464	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
58d7c11d-d86e-6345-bca4-37787eb49e73	PROF_LIPID	Ліпідограма	Біохімія	24	t	250.00	1	1	05e00000-0000-0000-0000-000000000002	f205b93d-c429-0c7f-fd3f-995b6e699954	t	2026-10-13 20:26:21.914278	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6d576e14-c3af-5463-1b22-acde70083262	PROF_COAG	Коагулограма	Коагулологія	6	f	300.00	3	3	05e00000-0000-0000-0000-000000000004	db9ba637-71b1-e472-9329-c71deaa0e600	t	2026-10-13 20:26:21.914516	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9dcf14c3-3078-6958-4235-5cd6f98faf54	PROF_THYROID	Щитоподібна залоза	Імунологія	48	t	280.00	1	1	05e00000-0000-0000-0000-000000000005	8f3979af-1c66-4a66-ba44-6ca5c5baffe5	t	2026-10-13 20:26:21.914592	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d20d145b-5d7d-eb73-4222-2d5a961e5084	PROF_BIOCHEM_BASE	Біохімія: базовий профіль	Біохімія	24	t	350.00	1	1	05e00000-0000-0000-0000-000000000001	d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	t	2026-10-13 20:26:21.896754	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_test_profile_item; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_test_profile_item (id, profile_id, test_id, display_order, is_required, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
04cea3b1-f23c-4656-ac83-9e810effbdab	20f8d458-4c0a-6d73-4767-180e83ac2d47	f9e0e0ee-f205-2d99-101f-e6ddd5b21168	2	t	2026-10-13 20:26:21.914654	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
100fa0e9-906a-4497-8600-d9647e5e3d10	15c0e450-bd3b-f3a5-6df0-0a1504167016	2d02abde-3000-bfdd-4d01-bf4f7b5efb40	1	t	2026-10-13 20:26:21.914441	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
15e82d86-3244-42a6-bcc6-70057414a3c5	58d7c11d-d86e-6345-bca4-37787eb49e73	2390521a-4884-14a4-7e9b-e521a2f6d403	4	t	2026-10-13 20:26:21.914323	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
171e8bed-faf7-47f8-8e68-67f36f802bf2	6d576e14-c3af-5463-1b22-acde70083262	a4a22087-0271-8aeb-b832-d77465333a2b	4	t	2026-10-13 20:26:21.914528	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
32eb28b6-15de-4765-8be9-4e48747799ef	20f8d458-4c0a-6d73-4767-180e83ac2d47	772a9b8b-36ea-119f-adee-bad2b39bca28	5	t	2026-10-13 20:26:21.914657	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
35c5bf52-4783-46c6-8c8a-933f2db32133	20f8d458-4c0a-6d73-4767-180e83ac2d47	e1dfea1c-3bbd-42f4-097d-f4246fb85bc4	8	t	2026-10-13 20:26:21.914659	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3e23e987-3306-40df-ae66-89255e6caaa1	20f8d458-4c0a-6d73-4767-180e83ac2d47	69eb4fe0-b6a1-6186-06ca-03557bcbd34f	10	t	2026-10-13 20:26:21.914661	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
41d3fda0-fb62-4cad-b732-92c41921636d	d20d145b-5d7d-eb73-4222-2d5a961e5084	b52ad812-14fc-017f-8043-9d4065b00912	4	t	2026-10-13 20:26:21.897326	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
538c3fe7-fb25-442e-864d-291b34a9e327	58d7c11d-d86e-6345-bca4-37787eb49e73	8a26d96f-50d9-09e0-13b2-d927525708ca	2	t	2026-10-13 20:26:21.914322	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5d29cba5-ffd2-46fb-86f7-e3441b44ee66	6d576e14-c3af-5463-1b22-acde70083262	9a41c97e-a1ff-3057-51c8-7227b8a34eca	2	t	2026-10-13 20:26:21.914526	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
606ff686-ab04-4b36-9128-640bff925631	15c0e450-bd3b-f3a5-6df0-0a1504167016	58a8f55f-964b-c194-0eb7-a7421875d22c	3	t	2026-10-13 20:26:21.914443	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
60a7daaf-61e2-42cc-b755-f0445f276267	9dcf14c3-3078-6958-4235-5cd6f98faf54	cb7ec275-c691-451e-c6a2-50b68ad556cc	2	t	2026-10-13 20:26:21.9146	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
6468a98c-a074-482f-8e47-19b283e41b30	d20d145b-5d7d-eb73-4222-2d5a961e5084	17f44917-1e73-c00d-1f94-829b314117d2	5	t	2026-10-13 20:26:21.897327	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
79f331a4-2c38-4226-bb37-d9b6565fecf4	20f8d458-4c0a-6d73-4767-180e83ac2d47	5f4b3231-e2b4-3ba9-7ec3-336b196082ff	6	t	2026-10-13 20:26:21.914658	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
7b91c26c-f9c6-473e-b2b3-245889b8caff	20f8d458-4c0a-6d73-4767-180e83ac2d47	37645829-c22b-9ac4-ecaf-6702303061c1	7	t	2026-10-13 20:26:21.914659	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
83b0caa8-3599-48fb-b8df-05f067a2ee33	20f8d458-4c0a-6d73-4767-180e83ac2d47	e2e92758-4a2b-69a0-63c7-f2d972e5d6de	3	t	2026-10-13 20:26:21.914655	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
84383387-0f86-455a-aeb1-dd2e464cbee6	15c0e450-bd3b-f3a5-6df0-0a1504167016	9a0184d8-1d16-8fb3-e23d-daf43523e669	4	t	2026-10-13 20:26:21.914444	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
84a2ce32-ea77-40ff-aaa6-434a2c4543a1	d20d145b-5d7d-eb73-4222-2d5a961e5084	e97a0a77-84c5-7b12-20f5-f81360c31a8f	1	t	2026-10-13 20:26:21.897292	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
9f1b9993-2ea7-4f00-ba54-8b0dab2ee406	20f8d458-4c0a-6d73-4767-180e83ac2d47	ff3ffbe9-faa7-fc07-7abc-925c715ea80e	9	t	2026-10-13 20:26:21.91466	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
a0957b87-ec95-40b3-919b-ee2e064346cc	9dcf14c3-3078-6958-4235-5cd6f98faf54	a9396732-a004-f61b-52b3-b79513ec3633	1	t	2026-10-13 20:26:21.914599	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
aeebc0fe-f075-4b7e-b9da-32d72fe4afe8	d20d145b-5d7d-eb73-4222-2d5a961e5084	419ce4ee-1b76-f290-0e1c-549102baae72	2	t	2026-10-13 20:26:21.897324	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
be676a6b-dabb-44c5-a656-201beefa7d4c	d20d145b-5d7d-eb73-4222-2d5a961e5084	6d3046d3-9cb0-71d0-b5d3-632f12bed916	6	t	2026-10-13 20:26:21.897328	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
c6ac7368-10d1-402d-bd95-07720d271998	d20d145b-5d7d-eb73-4222-2d5a961e5084	7056a922-9eaa-71db-8831-89963768bd12	7	t	2026-10-13 20:26:21.897328	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
caf125a3-7603-40f5-be60-49536a6f02f2	58d7c11d-d86e-6345-bca4-37787eb49e73	151cdd48-ad74-66fd-6a6f-caa3190d7521	3	t	2026-10-13 20:26:21.914322	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
cce7d3a3-1b06-4ff7-be31-ab4e5f6161b2	20f8d458-4c0a-6d73-4767-180e83ac2d47	d6221062-0137-ce7c-5e94-e03c6078f6cc	1	t	2026-10-13 20:26:21.914653	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d0967f3c-ec56-4a72-b085-4f1afb978510	20f8d458-4c0a-6d73-4767-180e83ac2d47	5846d6ec-098e-d107-7ca9-76e04c5ac760	4	t	2026-10-13 20:26:21.914656	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
d54c1afb-b572-41f5-9ae0-ebace02e05f5	d20d145b-5d7d-eb73-4222-2d5a961e5084	dc9a931d-5851-e01b-e2f2-fc46621ea597	3	t	2026-10-13 20:26:21.897325	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
da6a7978-1617-4b9f-b4a6-5e4dfaa08664	58d7c11d-d86e-6345-bca4-37787eb49e73	b9180163-fed0-792b-8397-7a264a2ffb71	1	t	2026-10-13 20:26:21.91432	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e329e762-9fb5-440a-9317-aca6cd12e3e4	15c0e450-bd3b-f3a5-6df0-0a1504167016	385b6b33-16ea-cd96-f163-0146b79658bc	2	t	2026-10-13 20:26:21.914442	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
e35b8524-210c-4f72-bc4f-1db0121c2993	6d576e14-c3af-5463-1b22-acde70083262	aa0f5a5a-f0ee-c2a9-5627-2ef8b023c646	1	t	2026-10-13 20:26:21.914525	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
ed03555f-1adf-4b09-9673-3f83d8a22d13	6d576e14-c3af-5463-1b22-acde70083262	26e9c43c-eb4f-4b10-1489-87f7febd4943	3	t	2026-10-13 20:26:21.914527	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_test_result; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_test_result (id, order_test_id, numeric_value, string_value, unit, norm_low, norm_high, crit_low, crit_high, reference_display, flag, applied_layer_id, applied_layer_name, delta_percent, delta_alert, previous_value, previous_at, analyzer_id, analyzer_flags, raw_message_id, is_auto_verified, auto_verify_block_reason, verified_by_id, verified_at, verification_comment, operator_comment, report_text, entered_by_id, entered_at, measured_at, version, performer_id, external_reference, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
7964def1-22c9-4015-ba33-98b6d83f262d	7f110624-c85b-4411-981a-2caa688e771f	5.4	\N	ммоль/л	3.9	5.9	2.8	25	3.9 – 5.9	NORMAL	398a7968-cad8-bb2d-043a-7e35c089476e	Глюкоза натще	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-12 15:26:23.054269	\N	\N	\N	\N	2026-10-12 15:16:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.746998	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ab82ee3c-0c7e-4803-8501-4f84fb670060	d6039ece-8620-408f-890f-b550e5568dc8	168	\N	мкмоль/л	62	106	\N	700	62 – 106	HIGH	9feb86a2-d5d4-89c1-c673-3a447207da38	Креатинін (чол.)	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	f	Результат поза нормою (HIGH)	0e000000-0000-0000-0000-000000000002	2026-10-12 15:27:23.054269	\N	\N	\N	\N	2026-10-12 15:17:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.815931	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
17f7ceb4-cc4f-4c51-986b-5a0c74e6812e	05d422f7-71b2-4fa9-ad42-3a2e688e1430	12.1	\N	ммоль/л	2.5	8.3	\N	40	2.5 – 8.3	HIGH	39dbc265-02a4-0de2-1cba-75645787ba80	Сечовина	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	f	Результат поза нормою (HIGH)	0e000000-0000-0000-0000-000000000002	2026-10-12 15:28:23.054269	\N	\N	\N	\N	2026-10-12 15:18:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.82381	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
0747357d-274c-4c28-91ef-4a1b00dc29eb	f825460d-a54c-49f9-aabe-cc7091189551	28	\N	Од/л	0	41	\N	\N	0 – 41	NORMAL	3447dd84-5a55-c6ba-d1dd-bc72b83bf0d4	АЛТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-12 15:29:23.054269	\N	\N	\N	\N	2026-10-12 15:19:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.831619	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cd39d3aa-2abf-426d-a8f6-d9064237f5af	44c2fe4e-03b0-4789-97e5-5b09772cde61	24	\N	Од/л	0	40	\N	\N	0 – 40	NORMAL	576258f5-bccd-6ed9-1fa5-b575f2718e3f	АСТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-12 15:30:23.054269	\N	\N	\N	\N	2026-10-12 15:20:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.843525	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
b80b666b-291c-444e-83a6-8893beca5f6a	059f6563-49ba-4cdc-bd27-ac17b9d9e36a	11.2	\N	мкмоль/л	3.4	20.5	\N	300	3.4 – 20.5	NORMAL	5d02466d-2550-8f95-39c2-0838615c365a	Білірубін загальний	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-12 15:31:23.054269	\N	\N	\N	\N	2026-10-12 15:21:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.855342	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c566874b-5979-4eef-8f00-a7bd2d020914	4e1a6b24-2ff4-49dd-bb27-a711976ff771	71	\N	г/л	64	83	\N	\N	64 – 83	NORMAL	a4871541-d4e4-c75b-3675-361a880f7954	Білок загальний	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-12 15:32:23.054269	\N	\N	\N	\N	2026-10-12 15:22:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.867976	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
09f66487-3a79-463a-99bf-d8549909f744	84e295a9-d52f-4d29-926a-d2a78dadd0e6	6.8	\N	ммоль/л	3.5	5.1	2.8	6.5	3.5 – 5.1	CRIT_HIGH	4a1a8329-33b7-ea32-e12f-edcd934fda31	Калій	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	f	Критичне (панічне) значення — потрібен лікар-лаборант	0e000000-0000-0000-0000-000000000002	2026-10-12 15:33:23.054269	Критична гіперкаліємія 6.8 ммоль/л — повідомлено лікуючого лікаря телефоном	\N	\N	\N	2026-10-12 15:23:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.880095	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c279bc98-a741-4831-b5a0-d96ac7abb262	016beec8-2e7f-4071-8246-528692149153	134	\N	ммоль/л	136	145	120	160	136 – 145	LOW	b9314d12-48d2-c4c4-f6c7-425e4be6cb8d	Натрій	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	f	Результат поза нормою (LOW)	0e000000-0000-0000-0000-000000000002	2026-10-12 15:34:23.054269	\N	\N	\N	\N	2026-10-12 15:24:23.054269	\N	1	\N	\N	2026-10-13 20:26:22.888634	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.054394	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c43b5ed8-27a9-4509-8727-ca00b4d00425	3ff7b478-e872-4003-97dd-cc8a3543dac9	5.1	\N	ммоль/л	3.9	5.9	2.8	25	3.9 – 5.9	NORMAL	398a7968-cad8-bb2d-043a-7e35c089476e	Глюкоза натще	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:11:23.231316	\N	\N	\N	\N	2026-10-08 22:36:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.104384	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5d84bbf9-23dd-4340-8527-04bb07c160b5	64d67447-5181-43f4-a551-5c8c102385fb	74	\N	мкмоль/л	44	80	\N	700	44 – 80	NORMAL	41469d5a-3b95-21f9-fd46-5f58b28217b9	Креатинін (жін.)	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:12:23.231316	\N	\N	\N	\N	2026-10-08 22:37:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.122811	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
1435ed7d-85ab-41ee-a0e2-d9240b5aa4c1	d7ef4b25-87fe-4bab-93e0-c883f08f8fa6	4.9	\N	ммоль/л	2.5	8.3	\N	40	2.5 – 8.3	NORMAL	39dbc265-02a4-0de2-1cba-75645787ba80	Сечовина	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:13:23.231316	\N	\N	\N	\N	2026-10-08 22:38:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.136306	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6c1c37da-c906-461a-8443-03944caeff85	b72e059f-c55c-4bab-8cbb-7cad8a4f41a7	22	\N	Од/л	0	41	\N	\N	0 – 41	NORMAL	3447dd84-5a55-c6ba-d1dd-bc72b83bf0d4	АЛТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:14:23.231316	\N	\N	\N	\N	2026-10-08 22:39:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.150559	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
83c647cc-65ac-45d9-a1cd-90b5c8a6b2f6	31ea1f40-2ebb-430a-a184-b4a3d7fa2828	20	\N	Од/л	0	40	\N	\N	0 – 40	NORMAL	576258f5-bccd-6ed9-1fa5-b575f2718e3f	АСТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:15:23.231316	\N	\N	\N	\N	2026-10-08 22:40:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.164413	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
4b785e89-c2fd-4c32-a0a5-f61119670a95	9d217a05-6d9d-44ab-a281-a3052e8cdb6b	9.8	\N	мкмоль/л	3.4	20.5	\N	300	3.4 – 20.5	NORMAL	5d02466d-2550-8f95-39c2-0838615c365a	Білірубін загальний	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:16:23.231316	\N	\N	\N	\N	2026-10-08 22:41:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.178827	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a3f4e07b-1b8a-414f-bcf5-5f837596d5e1	dc1789e1-b032-4056-a21f-d3f0dc675b2b	73	\N	г/л	64	83	\N	\N	64 – 83	NORMAL	a4871541-d4e4-c75b-3675-361a880f7954	Білок загальний	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-08 23:17:23.231316	\N	\N	\N	\N	2026-10-08 22:42:23.231316	\N	1	\N	\N	2026-10-13 20:26:23.194287	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.231322	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
78b9024c-5154-45ec-b98a-557370793b4a	d6c2e511-756f-4ade-80f0-9bcd5b5a06d5	7.9	\N	ммоль/л	3.9	5.9	2.8	25	3.9 – 5.9	HIGH	398a7968-cad8-bb2d-043a-7e35c089476e	Глюкоза натще	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	f	Результат поза нормою (HIGH)	\N	\N	\N	\N	\N	\N	2026-10-13 19:36:23.487223	\N	1	\N	\N	2026-10-13 20:26:23.400913	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
962c53a9-c43e-49b4-9063-4030fc8eae43	ac4a2f93-b7aa-4626-a04e-bce186a8e98f	76	\N	мкмоль/л	44	80	\N	700	44 – 80	NORMAL	41469d5a-3b95-21f9-fd46-5f58b28217b9	Креатинін (жін.)	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-13 20:12:23.487223	\N	\N	\N	\N	2026-10-13 19:37:23.487223	\N	1	\N	\N	2026-10-13 20:26:23.412768	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
7a553110-fda7-472b-a23f-ac1f54833c27	613b3264-5098-4615-927a-5bbd7879a99a	5.2	\N	ммоль/л	2.5	8.3	\N	40	2.5 – 8.3	NORMAL	39dbc265-02a4-0de2-1cba-75645787ba80	Сечовина	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-13 20:13:23.487223	\N	\N	\N	\N	2026-10-13 19:38:23.487223	\N	1	\N	\N	2026-10-13 20:26:23.432884	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
9b43db16-6326-4f31-859d-2fad738f8ae2	8d41a71e-c391-48c1-bf82-7cb736d79f75	24	\N	Од/л	0	41	\N	\N	0 – 41	NORMAL	3447dd84-5a55-c6ba-d1dd-bc72b83bf0d4	АЛТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-13 20:14:23.487223	\N	\N	\N	\N	2026-10-13 19:39:23.487223	\N	1	\N	\N	2026-10-13 20:26:23.45131	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
71596032-c634-4499-af42-7563c4e2b6b1	7499aa35-d33d-4443-9a19-a91e1562b1a6	21	\N	Од/л	0	40	\N	\N	0 – 40	NORMAL	576258f5-bccd-6ed9-1fa5-b575f2718e3f	АСТ	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	N	\N	t	\N	\N	2026-10-13 20:15:23.487223	\N	\N	\N	\N	2026-10-13 19:40:23.487223	\N	1	\N	\N	2026-10-13 20:26:23.469731	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.487231	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
af08200d-61b5-459c-9e44-c2d8ded7868b	6dd75bb6-4788-4a55-9171-1dafda27eb0a	13.1	\N	с	11	15	\N	\N	11 – 15	NORMAL	d69659f4-2844-da99-7534-a88919fc8195	Протромбіновий час	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-13 18:11:23.677932	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 17:36:23.677932	\N	1	\N	\N	2026-10-13 20:26:23.593955	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
c6dd2b05-0463-46c2-8906-f4e3ede4e6ab	8f776604-3f43-412e-98a4-7b768e917438	2.6	\N		0.8	1.2	\N	5	0.8 – 1.2	HIGH	e68615ab-cbe6-1287-b799-20ac355717a7	МНВ	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (HIGH)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 17:37:23.677932	\N	1	\N	\N	2026-10-13 20:26:23.612849	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
d6efb458-7bd7-4cdb-8975-3ba9bf52eaa0	241d88c6-7efa-46a8-83fc-91870d3ada30	31	\N	с	25	37	\N	\N	25 – 37	NORMAL	43660e43-eb8b-475a-794b-edbb0ad9e36a	АЧТЧ	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-13 18:13:23.677932	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 17:38:23.677932	\N	1	\N	\N	2026-10-13 20:26:23.623915	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6d62a5ab-e1c4-4ffc-96fc-e7e358bdfa30	facd213b-5bb6-4de2-9e70-6a1c9d5cf4da	3.1	\N	г/л	2	4	\N	\N	2 – 4	NORMAL	a8be7892-0409-95cf-d841-22df7d96c570	Фібриноген	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-13 18:14:23.677932	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 17:39:23.677932	\N	1	\N	\N	2026-10-13 20:26:23.642631	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
222a9697-e00c-4a63-b057-f52e2d173c5f	c7c78c00-705a-40a3-a890-603987bdbed2	5.2	\N	нг/мл	0	4	\N	\N	0 – 4	HIGH	5b5ae9b5-c180-3a88-3d0f-96883146e904	ПСА загальний	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (HIGH)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 17:40:23.677932	\N	1	\N	\N	2026-10-13 20:26:23.661247	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.67794	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f5780c0a-01d3-456b-9b65-2e541fd9ebd8	44810dce-2ac6-474e-9dd6-20791ec23cd3	5.2	\N	ммоль/л	3.9	5.9	2.8	25	3.9 – 5.9	NORMAL	398a7968-cad8-bb2d-043a-7e35c089476e	Глюкоза натще	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-13 21:12:23.819395	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 20:37:23.819395	\N	1	\N	\N	2026-10-13 20:26:23.780029	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.8194	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
3bf2cc20-7e64-46e3-9304-02e3d4df958d	14f33f52-b961-407b-8d6a-d6ddf8701287	3.5	\N	мМО/л	0.4	4	\N	\N	0.4 – 4	NORMAL	f9380e70-25b4-f038-2bae-ea0b8bbfe2e6	ТТГ	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-13 21:11:23.819395	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-13 20:36:23.819395	\N	1	\N	\N	2026-10-13 20:26:23.799863	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:23.8194	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
a75219d2-b1af-4045-bb9d-218cd7645f35	b3d0e365-ec21-4839-883f-73277e56de91	\N	жовтий		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:36:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.035399	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
f77fd11c-2c15-40be-89d8-2ac09ab917c7	03210845-013b-4c3d-9159-973a8de1a7af	\N	мутна		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:37:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.048549	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ca11ac3b-c0eb-4d93-8588-5116fe7e9418	a52636a9-11d5-4e1f-8814-7f26030adc88	\N	сліди		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:40:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.061511	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
6e7e9d62-cfad-47d3-aee9-1d9d08eb4ca3	dc9fd361-77ad-48cc-b7f6-bd6f4d9ace37	\N	не виявлено		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:41:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.074943	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
38b71a30-a867-4f93-9755-2565b1f5b6e5	f6a16ae3-7345-4029-b529-aba0d286f864	\N	не виявлено		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:42:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.089001	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
83649285-9e83-446b-9150-f70e19bcf3af	b21d25aa-487b-40c3-8284-ecb2a2111ef0	\N	+++		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:43:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.102134	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
cdc1cf59-5a03-44c1-8238-e74020e90251	a1afc828-ef1b-4b6c-b0dc-64d2be8c294e	\N	+		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:44:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.115961	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
80d4b5b7-b2cf-42cf-a409-c413cab37ef0	9e9dedb9-b1e3-4790-b9b2-afcbe04f0e7c	\N	позитивно		\N	\N	\N	\N		NONE	\N	\N	\N	f	\N	\N	\N	\N	\N	f	Результат поза нормою (NONE)	\N	\N	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:45:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.13035	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
ea900a56-f18d-4055-a726-4d3d77fd9433	5e632bc0-34e8-440b-ae88-61126f1dbfc4	1.018	\N		1.005	1.03	\N	\N	1.01 – 1.03	NORMAL	10d10bed-859e-9029-6971-fced2ec9e964	Питома вага сечі	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-12 19:13:24.526791	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:38:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.148497	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
dc0163c3-2fa2-42fb-a9ba-e2f72013d074	30c2bcac-31c0-48d7-b9f8-966dd4e872e0	6	\N		5	8	\N	\N	5 – 8	NORMAL	559a1bf4-d1b4-92be-8c16-716a54820af8	pH сечі	\N	f	\N	\N	\N	\N	\N	t	\N	\N	2026-10-12 19:14:24.526791	\N	\N	\N	0e000000-0000-0000-0000-000000000001	2026-10-12 18:39:24.526791	\N	1	\N	\N	2026-10-13 20:26:24.172341	0e000000-0000-0000-0000-000000000001	2026-10-13 20:26:24.526799	0e000000-0000-0000-0000-000000000001	2	d0000000-0000-0000-0000-000000000001
5835cd38-57bb-4d5c-958a-46ea95a8ba7e	10f336d2-2de0-4ec8-b9dc-b7ddc066bae3	12.3	\N	мкмоль/л	3.4	20.5	\N	300	3.4 – 20.5	NORMAL	5d02466d-2550-8f95-39c2-0838615c365a	Білірубін загальний	\N	f	\N	\N	0a2a0000-0000-0000-0000-000000000002	\N	\N	t	\N	\N	2026-10-26 12:06:37.942052	\N	\N	\N	\N	2026-10-26 12:06:37.942052	\N	1	\N	\N	2026-10-26 12:06:37.96486	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_tube_type; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_tube_type (id, code, name, color_code, anticoagulant, volume_ml, order_of_draw_index, inversions_count, usable_volume_ml, max_tests_per_tube, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
1	RED_GEL	Сироватка з гелем (жовта)	#E8C547	\N	5	3	5	\N	\N	t	2026-10-13 20:26:21.784986	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
2	LAV_EDTA	EDTA (фіолетова)	#8E5BB5	EDTA K2	3	5	8	\N	\N	t	2026-10-13 20:26:21.787249	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
3	BLUE_CIT	Цитрат натрію (блакитна)	#4A90D9	Цитрат 3.2%	2.7	2	3	\N	\N	t	2026-10-13 20:26:21.787254	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
4	URINE_CUP	Контейнер для сечі	#F5F5F5	\N	10	99	0	\N	\N	t	2026-10-13 20:26:21.787256	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
5	URINE_ST	Стерильний контейнер	#E0F2F1	\N	10	99	0	\N	\N	t	2026-10-13 20:26:21.787258	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_unmatched_result; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_unmatched_result (id, analyzer_id, barcode, analyzer_code, value, unit, flags, measured_at, raw_message_id, reason, is_linked, linked_order_test_id, received_at, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
378678c0-d5ae-43e6-b56f-38cd5533eab2	0a2a0000-0000-0000-0000-000000000001	99999999	WBC	6.1	10^9/L	\N	\N	\N	Штрихкод '99999999' не знайдено	f	\N	2026-10-26 12:00:00	2026-10-26 11:59:28.266295	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
54b30298-30fc-4b13-86b0-9678141021b8	0a2a0000-0000-0000-0000-000000000001	99999999	WBC	6.1	10^9/L	\N	\N	\N	Штрихкод '99999999' не знайдено	f	\N	2026-10-26 12:00:00	2026-10-26 12:06:05.73679	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
519165ee-df99-437e-b9d3-5d45268da468	0a2a0000-0000-0000-0000-000000000001	99999999	WBC	6.1	10^9/L	\N	\N	\N	Штрихкод '99999999' не знайдено	f	\N	2026-10-26 12:00:00	2026-10-26 12:20:01.504861	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_workflow_template; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_workflow_template (code, name, stages_json, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
CLINICAL	Клінічний (стандартний)	[{"code":"REGISTERED","name":"\\u0417\\u0430\\u0440\\u0435\\u0454\\u0441\\u0442\\u0440\\u043E\\u0432\\u0430\\u043D\\u043E","isRequired":true,"allowedNext":["IN_PROGRESS"]},{"code":"IN_PROGRESS","name":"\\u0412 \\u0440\\u043E\\u0431\\u043E\\u0442\\u0456","isRequired":true,"allowedNext":["DONE"]},{"code":"DONE","name":"\\u0417\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043D\\u043E","isRequired":true,"allowedNext":[]}]	t	2026-10-13 20:26:21.834612	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: lab_worklist_batch; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.lab_worklist_batch (id, batch_code, analyzer_id, status, created_by_id, items_json, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: mis_diagnostic_report; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.mis_diagnostic_report (id, reg_number, reg_date, caption, status, patient_card_id, tenant_id, legal_entity_id, division_id, document_type_id, ehealth_service_catalog_service_id, ehealth_incoming_medical_referral_id, diagnostic_report_category_id, description, comment, effective_date_time_start, effective_date_time_end, issued_at, performer_id, performer_string, is_performer_string, recorded_by_id, ehealth_id, is_primary_source, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
f1afc2e4-775d-4678-a804-c0087a19bc55	2610-000001	2026-10-13 20:26:22.966674	Біохімія: базовий профіль; Калій; Натрій	0	0b000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	0f207781-8e89-40ae-b907-fabf602c217b	d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	\N	\N	Лабораторне дослідження №2610-000001: 9 показників, критичних: 1	\N	2026-10-13 20:26:22.634014	2026-10-13 20:26:22.966674	2026-10-13 20:26:22.966674	\N	Лікар Лаборант Тест	t	\N	\N	t	2026-10-13 20:26:22.972748	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2
94b72fc2-1cdc-42c2-8691-3bc100450fcf	2610-000002	2026-10-13 20:26:23.216755	Біохімія: базовий профіль	0	0b000000-0000-0000-0000-000000000002	d0000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000002	0f207781-8e89-40ae-b907-fabf602c217b	d7bff8fa-3b26-aa8b-3664-f9beed7afd8a	\N	\N	Лабораторне дослідження №2610-000002: 7 показників, критичних: 0	\N	2026-10-13 20:26:23.078008	2026-10-13 20:26:23.216755	2026-10-13 20:26:23.216755	\N	Адміністратор Лабораторії Тест	t	\N	\N	t	2026-10-13 20:26:23.216993	0e000000-0000-0000-0000-000000000001	\N	0e000000-0000-0000-0000-000000000001	2
\.


--
-- Data for Name: mis_patient_insurance; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.mis_patient_insurance (id, patient_card_id, payer_id, policy_number, valid_from, valid_to, note, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
fc9a3d29-5dd1-45fa-bf5a-e98d1b6097fb	0b000000-0000-0000-0000-000000000003	cb257162-eaab-8088-9fbf-9d4b04f6a545	POL-0003	2024-01-01 02:00:00	2030-12-31 02:00:00	\N	t	2026-10-13 20:26:22.174212	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: ord_order_identifier; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.ord_order_identifier (id, tenant_id, order_id, system, value, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
\.


--
-- Data for Name: ord_patient; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.ord_patient (id, last_name, name, middle_name, caption, birthday, gender_id, ipn, phone, email, location, last_name_latin, first_name_latin, created_on, created_by, modified_on, modified_by, record_state, tenant_id, sex) FROM stdin;
0b000000-0000-0000-0000-000000000002	Шевченко	Марія	Петрівна	Шевченко Марія Петрівна	1985-07-21 00:00:00	01f0eff5-a698-4873-a45b-ad034a386d08	\N	+380672000002	\N	м. Київ	Shevchenko	Mariia	2026-10-13 20:26:21.658874	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	female
0b000000-0000-0000-0000-000000000004	Мельник	Ірина	Олексіївна	Мельник Ірина Олексіївна	1996-05-30 00:00:00	01f0eff5-a698-4873-a45b-ad034a386d08	\N	+380672000004	\N	м. Київ	Melnyk	Iryna	2026-10-13 20:26:21.658981	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	female
0b000000-0000-0000-0000-000000000001	Коваленко	Олег	Іванович	Коваленко Олег Іванович	1958-03-12 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	+380672000001	\N	м. Київ	Kovalenko	Oleh	2026-10-13 20:26:21.645133	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	male
0b000000-0000-0000-0000-000000000003	Бондаренко	Андрій	Сергійович	Бондаренко Андрій Сергійович	1970-11-02 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	+380672000003	\N	м. Київ	Bondarenko	Andrii	2026-10-13 20:26:21.658939	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	male
0b000000-0000-0000-0000-000000000005	Ткаченко	Максим	Дмитрович	Ткаченко Максим Дмитрович	2024-02-14 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	+380672000005	\N	м. Київ	Tkachenko	Maksym	2026-10-13 20:26:21.659013	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	male
0b000000-0000-0000-0000-000000000006	Кравчук	Василь	Степанович	Кравчук Василь Степанович	1944-09-09 00:00:00	07b60329-7282-4262-9409-b24ea4440428	\N	+380672000006	\N	м. Київ	Kravchuk	Vasyl	2026-10-13 20:26:21.65904	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2	d0000000-0000-0000-0000-000000000001	male
\.


--
-- Data for Name: ord_patient_identifier; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.ord_patient_identifier (id, tenant_id, patient_id, system, value, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
\.


--
-- Data for Name: ord_patient_insurance; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.ord_patient_insurance (id, patient_card_id, payer_id, policy_number, valid_from, valid_to, note, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) FROM stdin;
\.


--
-- Data for Name: ord_requester; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.ord_requester (id, tenant_id, name, organization, identifiers, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
\.


--
-- Data for Name: org_employee; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.org_employee (id, caption, person_id, tenant_id, department_id, department_section_id, position_type_id, working_start_date, has_schedule_with_partner, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
0e000000-0000-0000-0000-000000000001	Адміністратор Лабораторії Тест	e59d651a-b8f8-4790-5418-ee1c15a00d73	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	\N	a40ae385-b6cb-467e-a8ef-7e35e111fd27	2020-01-01 00:00:00	f	2026-10-26 11:52:43.388277	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0e000000-0000-0000-0000-000000000002	Лікар Лаборант Тест	f225798d-0785-e068-6026-ad69168ef830	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	\N	a40ae385-b6cb-467e-a8ef-7e35e111fd27	2020-01-01 00:00:00	f	2026-10-26 11:52:43.415854	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0e000000-0000-0000-0000-000000000003	Лаборант Тест Тестович	4481c6be-a8ef-a387-7357-0d7a02d69889	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000001	\N	401fc1d1-064d-43a5-b0b1-3db57201abdd	2020-01-01 00:00:00	f	2026-10-26 11:52:43.417098	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0e000000-0000-0000-0000-000000000004	Медсестра Забору Тест	95cc74e8-4631-8ee9-703b-b4c514221435	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000002	\N	0f284af5-ff01-4d12-93c1-410f4ec9f13f	2020-01-01 00:00:00	f	2026-10-26 11:52:43.41845	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0e000000-0000-0000-0000-000000000005	Кур'єр Логіст Тест	f5880b34-863a-05f4-9079-07fd5a583885	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000002	\N	4fd18a0e-be63-42c3-8fa3-3f493679cd7d	2020-01-01 00:00:00	f	2026-10-26 11:52:43.419524	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0e000000-0000-0000-0000-000000000006	Реєстратор Тест Тестівна	e9692cbb-8a11-88ac-ebea-b2d28ee2000f	d0000000-0000-0000-0000-000000000001	0d000000-0000-0000-0000-000000000002	\N	4fd18a0e-be63-42c3-8fa3-3f493679cd7d	2020-01-01 00:00:00	f	2026-10-26 11:52:43.420881	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: org_organization_service; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.org_organization_service (id, caption, tenant_id, price, duration, profile_id) FROM stdin;
05e00000-0000-0000-0000-000000000001	Біохімія: базовий профіль	d0000000-0000-0000-0000-000000000001	350.00	15	00000000-0000-0000-0000-000000000000
05e00000-0000-0000-0000-000000000002	Ліпідограма	d0000000-0000-0000-0000-000000000001	250.00	15	00000000-0000-0000-0000-000000000000
05e00000-0000-0000-0000-000000000003	Загальний аналіз крові	d0000000-0000-0000-0000-000000000001	180.00	15	00000000-0000-0000-0000-000000000000
05e00000-0000-0000-0000-000000000004	Коагулограма	d0000000-0000-0000-0000-000000000001	300.00	15	00000000-0000-0000-0000-000000000000
05e00000-0000-0000-0000-000000000005	Щитоподібна залоза	d0000000-0000-0000-0000-000000000001	280.00	15	00000000-0000-0000-0000-000000000000
05e00000-0000-0000-0000-000000000006	Загальний аналіз сечі	d0000000-0000-0000-0000-000000000001	150.00	15	00000000-0000-0000-0000-000000000000
\.


--
-- Data for Name: sys_application_row_level_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_application_row_level_right (id, entity_name, is_active, is_hierarchical, hierarchy_field_name, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
\.


--
-- Data for Name: sys_field_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_field_right (id, right_id, field_name, access_level, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
\.


--
-- Data for Name: sys_operation_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_operation_right (id, operation_name, access_level, is_active, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
007dd9c4-d4b2-4da8-8275-17db8239610f	ManifestReceive	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Прийняти в лабораторії: Режим перегляду
015c26f8-9d69-4020-92b2-d49630e9cacc	OrderPrintLabels	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк етикеток: Ні
033742ec-4105-4e2b-bc8b-3e138ec7563c	BiobankCellDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення комірки: Повний доступ
03578c22-9e58-4735-9e75-268e1a2ff7c5	FavoritesDeleteOther	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення обраних іншого співробітника: Повний доступ
0382de4e-fcee-4a63-a70b-40820373f971	QcResultAdd	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату ВКЯ: Режим перегляду
038cd2c4-2f00-4ac8-9efd-2f3b6cd81568	QcResultDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення результату ВКЯ: Повний доступ
03eab55c-1fdd-475b-9cfc-78efb2bf3e7b	ManifestReceive	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Прийняти в лабораторії: Повний доступ
046135ee-5d53-4db0-9458-bf7b4c0fe428	OrderTestDeleteResult	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Видалити результат: Режим перегляду
05bc14c5-ee8b-4d33-ae1e-be89f0b45484	PerformersEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник лабораторій-виконавців: Ні
05d290d8-3f5e-41fb-9f19-50de9614ba10	OrderEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Редагувати замовлення: Режим перегляду
067483ae-ad7b-4d37-8016-54a86abfcf77	CultureEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Редагувати посів: Режим перегляду
06b920de-74e5-45bb-b16b-a62aab9d0568	WorklistBatchCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення робочого листа: Повний доступ
07305882-d9a2-474a-8912-e02f4784d5c4	OrderReopen	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Повернути в роботу: Ні
073f2cb0-5e9e-402e-8f5f-5ce6e4ddbef3	PayersEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник платників: Повний доступ
0765d767-50e2-4ab6-bc84-b2fbeda20637	AnalyzerMessageDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису журналу: Повний доступ
082d0e36-d561-4cb0-9431-0af4bfe80add	SampleEditFlags	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відмітки гемоліз/ліпемія/іктеричність: Ні
0a21d3da-9223-44ab-8f25-c6ff12562b8d	OrderEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Редагувати замовлення: Ні
0a7aaf6a-dcb3-45d8-96d8-bc1a75974eda	SendOutCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Формування реєстру відправки: Ні
0b1db92e-58a1-451e-82e4-48d930395edc	SampleReplace	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Замінити пробірку (новий штрихкод): Повний доступ
0b3c80ac-b2bd-4d5d-9b95-b2de92041b17	BiobankPlace	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розміщення зразка в біобанку: Режим перегляду
0b94936b-4b43-4852-b02c-b027ab041cee	SendOutItemReject	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відмова/відкликання позиції реєстру: Повний доступ
0c3c03bb-93c0-49e1-9b27-9b08b82545d0	OrderReceive	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прийняти в лабораторії: Повний доступ
0d7c9a1e-fdd0-46f3-92f1-f38097755b3c	CultureComplete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Завершити посів: Ні
0d9e6f8d-479d-4742-a5a0-39633c88b095	AnalyzerMessageDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису журналу: Ні
0fe45734-750f-47a5-bb22-9db901ab591a	DictionaryImport	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт довідника: Ні
11feac05-77fd-4ac0-b494-01da28867c02	PerformerDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лабораторії-виконавця: Повний доступ
1284b7df-6df0-4996-9444-be92562f0780	LockoutDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення lockout: Режим перегляду
132dce6e-c7ea-4392-8b18-b413057b65d6	AnalyzerUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування аналізатора: Режим перегляду
138465c7-6db9-43a4-95b3-dba5806c8bf3	UnmatchedResultLink	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зв'язування результату: Повний доступ
13fbe487-853b-445d-847b-fc8ec1731b6d	OrderAttachmentAdd	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Завантаження бланка результатів: Ні
1586687c-d061-426a-8256-76b191a4a15b	PerformersEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник лабораторій-виконавців: Повний доступ
159905b7-9380-4306-963e-1f951ff790e6	SendOutResultEnter	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату зовнішньої лабораторії: Ні
165c276f-2caf-4f73-a8a0-73e3f2be448a	FavoritesDeleteOther	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення обраних іншого співробітника: Ні
1688af21-deae-4db6-8bfe-1dbf5f1b7679	InvoiceMarkPaid	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Оплата рахунку платником: Ні
17ea5f30-3a3f-47a6-8e36-f1b5f27cb6df	AnalyzerUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування аналізатора: Повний доступ
18356373-728e-47de-83ea-771a791a02fa	DictionaryEntryCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення запису довідника: Повний доступ
1a2c8132-3bdb-414c-aaa4-be883b2bfe57	QcResultDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення результату ВКЯ: Режим перегляду
1b130a99-333f-4ac3-adbb-a09f2e991d0c	QcMaterialDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення контрольного матеріалу: Режим перегляду
1b1eb079-2f0b-49d3-9efd-45560c3ed57c	OrderCollect	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Забір біоматеріалу: Повний доступ
1c5738ee-4934-4f4b-8ecb-802ac8eace68	ConnectorEnable	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Увімкнути (повторна реєстрація): Ні
1d3ee900-522c-4b3a-8dff-329ab52e3e4b	SendOutResultsImport	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів зовнішньої лабораторії: Ні
1d4592f6-a3b2-4d8c-bfd6-ee34eb544d96	BiobankRemove	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Вилучення зразка з біобанку: Ні
1df8b387-8b05-4bd4-9090-4dbe8cd91e06	SampleStageAdd	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Фіксація етапу обробки проби: Ні
1e772fe2-a8a0-480f-a012-064843dd672c	ConnectorDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Видалити: Повний доступ
1ea76980-5354-451e-ba60-0e5a1c9f4a08	OrderTestRecallSendOut	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкликати з зовнішньої лабораторії: Ні
1f3313d2-8d39-45fb-9e49-462835e090c8	PanicCallCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Реєстрація панічного дзвінка: Режим перегляду
1fe6303e-a663-4f0d-b9d7-e994f5b4b243	OrderCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлення: Повний доступ
207345e6-e3b8-495a-9378-ab5ef04545ac	OrderPrintLabels	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк етикеток: Повний доступ
21635388-7e9c-481a-8f5e-fa7e6753fbb7	SampleDispose	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Утилізувати: Ні
217bcc3a-f18e-4b25-8862-9603bdffcc0e	PatientInsurancesEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Поліси пацієнта: Ні
2258ac08-5321-4e10-ba16-fd8713235daa	SampleProcess	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: В обробці (центрифугування/аналіз): Ні
22aad8fa-115c-4a0e-bb2a-74008f143d6f	SendOutCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Формування реєстру відправки: Режим перегляду
23e69ef9-d63b-4160-95d0-b2cb03a4028d	SendOutCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Формування реєстру відправки: Повний доступ
240d1a90-b188-4f15-b51f-4cfb1dac3714	OrderAddTest	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати тест: Повний доступ
242b9aa5-e492-4591-8ee0-480260f8da78	SampleProcess	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: В обробці (центрифугування/аналіз): Повний доступ
24a9cce7-f9d8-459a-b6e5-513a8d899edc	InvoiceMarkPaid	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Оплата рахунку платником: Повний доступ
24e5484f-d338-45d5-ab3c-367b9bc98eb9	OrderTestRerun	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Повторити дослідження: Режим перегляду
24ea0367-7d6c-4484-87a5-f5a07828abbe	DictionaryEntryDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису довідника: Ні
261bb3df-7a1e-46a9-95c8-4e396b4ff51f	OrderPrintReport	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк бланка: Ні
26763c12-790c-4b95-ab2e-4706779f45c5	PanicCallDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення панічного дзвінка: Режим перегляду
272073ec-87f8-4133-8d6e-41198c03e269	LockoutResolve	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розблокування аналізатора: Повний доступ
28b1756b-929c-45ee-a839-93061f2abc16	SampleReject	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відбракувати пробірку: Ні
2918fcdd-bbd5-47cb-8b28-0c38bcc8284c	SectionUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування підрозділу лабораторії: Ні
2941d6ef-5048-489f-bf0a-00e6906c0d05	PayerPeriodInvoice	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Рахунок/акт за період: Ні
296ad840-cc73-44e6-bb40-6235f9425d59	OrderTestSendOut	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відправити в зовнішню лабораторію: Режим перегляду
2a0e43d8-aca2-4759-aa7c-93e5d00b7fd2	CulturePreliminary	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Попередній результат: Режим перегляду
2a1bb96e-f2bf-464c-a8ec-cf6c19c3c797	QcMaterialUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування контрольного матеріалу: Режим перегляду
2b7190b7-2de4-437e-9001-1d3d285908d7	DictionaryEntryUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування запису довідника: Ні
2bf8553b-a3c0-41b6-b5c1-709892c39c65	OrderReceive	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прийняти в лабораторії: Режим перегляду
2c76f11a-9b56-4574-a43e-b9e1999b0697	LockoutResolve	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розблокування аналізатора: Ні
2ce63862-b09d-4eb6-82b6-d43406e4eb6c	OrderTestReopen	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкрити повторно: Режим перегляду
2d000536-63c8-4d6e-aaaa-3e7857e74363	SampleUncollect	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Скасувати відмітку забору: Повний доступ
2db83939-04ec-47c8-8c32-9394bed4d519	DictionaryImport	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт довідника: Повний доступ
2dd92f45-374a-4433-b8a3-f642ff867c3e	SectionDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення підрозділу лабораторії: Повний доступ
2fcce59a-ccf8-480c-b45e-f5e26d62e867	OrderTestRemove	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Прибрати тест із замовлення: Режим перегляду
30027bd0-46e3-4ecd-977e-9d523718578d	PatientInsurancesEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Поліси пацієнта: Режим перегляду
30409657-7d57-4ba8-92c6-9101c6db673e	OrderDispatch	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відправити в лабораторію: Повний доступ
30476297-d6fd-4f3e-aacd-a9602592fcd5	SampleStore	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Розмістити в біобанку: Ні
31607c0d-c964-4e0a-8a0b-426fc89a4273	SendOutItemReject	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відмова/відкликання позиції реєстру: Режим перегляду
32576a1c-5b9c-4a5d-92c4-c0b5c683c9c3	ManifestReject	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відхилити (порушення холодового ланцюга): Ні
32e6ed17-606d-4fbb-a822-9b7a0acb4e47	ManifestDispatch	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відправити: Ні
33dd9859-f7e2-4d2e-b447-f1099244f852	ResultsAutoVerify	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Автоверифікація: Ні
34105972-1736-4872-bf60-a6801d4f88ad	ConnectorDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Видалити: Режим перегляду
3560835d-4ab5-4ac2-a10b-c379bb2bae7a	SampleDispatch	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відправити: Режим перегляду
3570c1b3-fb0e-478d-ab47-157e31e71831	OrderTestRerun	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Повторити дослідження: Повний доступ
363e4291-aff5-46da-abfb-40a648fa2cad	RackDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення штатива: Повний доступ
37304490-8ade-4b77-88f1-efc333879e9a	PaymentAdd	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прийом оплати: Режим перегляду
383dbb89-eba0-45ad-8155-5a334dc33720	AnalyzerUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування аналізатора: Ні
389731ea-773b-4cf0-9a80-cd927ce05ab4	QcMaterialDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення контрольного матеріалу: Ні
391b2821-58b5-493e-9b1f-c8e4c6077ef0	ClientRegistryImport	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт реєстру клініки: Повний доступ
3938ab1d-72da-4f28-9240-f94904f87d6b	NormsDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення норм: Повний доступ
3abfd167-4fae-4449-9e1b-2af242cf1fcb	ConnectorEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Редагувати: Режим перегляду
3b7d5549-7abe-48fe-8c19-85c563b2ae01	SampleReplace	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Замінити пробірку (новий штрихкод): Ні
3b9a19bd-8e0f-47d5-89a8-115a3ada68c9	SampleUncollect	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Скасувати відмітку забору: Ні
3c82770f-6c13-4766-bdea-2b308a1191ad	OrderAddSample	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати пробірку: Режим перегляду
3d19fd11-15b9-4aae-becd-66169daf47e6	RackUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування штатива: Режим перегляду
3de65242-6275-4bc7-a099-d60a2f412655	CultureComplete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Завершити посів: Режим перегляду
3e361c0f-3671-4bda-a65c-3f67c8cf03da	AnalyzerDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення аналізатора: Режим перегляду
3f2ff6ad-d131-4eba-91c2-6a7c0f16cf98	OrderEnterResult	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Ввести результат: Повний доступ
3f9e7166-8262-4ee6-ac06-4ef671531d1b	OrderTestEditResult	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Виправити результат (нова версія): Режим перегляду
3fa4b80d-1c37-4c67-8aa9-c58150de053f	OrderVerify	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Верифікувати результати: Ні
40cb1b31-7093-4f7c-a344-2da9b77bfa94	OrderTestEditResult	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Виправити результат (нова версія): Ні
40e912ba-afc5-4dcd-8b0c-f1699fd4d9ae	FavoritesEditOther	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування обраних іншого співробітника: Ні
410eff2d-77f2-4815-a05e-d45cf6b64bda	OrderTestSendOut	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відправити в зовнішню лабораторію: Ні
41d48079-11a7-485a-a1da-12235c1b886c	OrderTestEnterResult	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Ввести результат: Режим перегляду
421ade92-ac72-4297-ac32-407cc17595a6	OrderRelease	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видати результати пацієнту: Режим перегляду
424d95d8-c5bb-4451-a6c0-89097cbcdc79	ConnectorCommand	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Команда коннектору: Повний доступ
4266b01f-5f3d-4987-aa14-ab072afa05ec	ConnectorMarkOffline	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Позначити офлайн: Повний доступ
42828cc8-18ae-4333-bfa9-29ad6ac14fed	ConnectorHeartbeat	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Heartbeat: Ні
42c98b5c-6c10-40af-a820-51de40a1a1d3	OrderTestEditResult	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Виправити результат (нова версія): Повний доступ
43af30a7-9f6f-45d5-a539-541183dd42e6	SendOutAccept	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Підтвердження приймання зовнішньою лабораторією: Режим перегляду
43f52649-3790-4b99-a6b0-2e9ad6d799e5	SendOutResultEnter	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату зовнішньої лабораторії: Режим перегляду
43fca59b-efcc-47e8-b989-97ec745e8529	PaymentAdd	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прийом оплати: Ні
446fdcee-9717-4e78-af5d-49f03b35fa53	OrderReceive	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прийняти в лабораторії: Ні
4474a9ec-d301-41fd-9476-a71fa89c2552	WorklistBatchCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення робочого листа: Режим перегляду
44eb3d63-cb35-4303-b9de-9fbc9c8907c5	ReagentLotUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування лоту реагенту: Ні
45413c76-0018-4ae8-9f8c-4cd34cebf09f	ReagentLotUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування лоту реагенту: Повний доступ
4732d4c6-491d-44dc-9494-81035a4c5b6b	OrdersRead	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд замовлень: Повний доступ
473425b2-4dc0-42cd-a907-93f68e57e786	InvoiceIssue	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Виставлення рахунку платнику: Повний доступ
48062e29-1244-45f6-bc3f-a275365901af	ConnectorCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення інсталяції коннектора: Ні
48e3bdf9-75d9-4e9d-ad08-2e0bc271d61e	RackCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення штатива: Ні
49cf836f-d742-4ab2-8246-b1b8f36d139e	BiobankRemove	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Вилучення зразка з біобанку: Повний доступ
4a19076a-4258-4fb4-bd26-e88bdd99434d	CultureComplete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Завершити посів: Повний доступ
4a9418a1-29aa-4994-95ec-47497c58c1f8	PatientCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення картки пацієнта: Режим перегляду
4c4d47f0-b242-4491-a1b7-82a1411ddd60	CultureAddIsolate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Додати ізолят: Режим перегляду
4c5583a4-8734-4099-8c13-bd94c52ab824	ChargePatientChoiceChange	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна оплати позиції: Ні
4c8bdd44-c6bd-4a50-b72b-61cf2fbb7d60	JournalEntryStatusChange	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна статусу позиції журналу: Повний доступ
4c9a26ff-47c8-4813-81ce-d5a4a6e2ad36	PatientCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення картки пацієнта: Повний доступ
4d46697b-99b4-4a49-b748-1b5a736cc873	ManifestDispatch	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відправити: Повний доступ
4e10e1a0-694d-4af2-9cde-3113452ea6ba	DictionaryImport	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт довідника: Режим перегляду
4e487f9a-5667-428d-8ba8-9234f8f3b066	NormsEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування норм: Ні
4ead7a2b-aeef-4ffa-9c05-87efc3b89d40	CultureAddIsolate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Додати ізолят: Ні
4f1e4e86-df39-4f95-98df-aec50ddda1d4	OrderTestSendOut	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відправити в зовнішню лабораторію: Повний доступ
4f6349b7-b572-41a6-bba3-c10a71f895c9	InvoiceMarkPaid	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Оплата рахунку платником: Режим перегляду
4fbd150d-1b09-42b3-bd2b-e0fbe48d6b12	PatientDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення картки пацієнта: Режим перегляду
502c414f-cecf-47b8-9268-159e35ef5916	ReagentLotDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лоту реагенту: Режим перегляду
5038c88a-e24e-497b-8083-8211f72807e9	ManifestCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення маніфесту: Повний доступ
5109f564-c5f5-42a9-af4a-ed705b21a556	OrderReject	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відхилити (брак біоматеріалу): Повний доступ
5207280f-2218-448b-85e1-bd624120a7bd	InvoiceCancel	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Анулювання рахунку: Режим перегляду
52a3c68f-d24a-4808-8e5c-5215fc2ccab9	OrderAttachmentAdd	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Завантаження бланка результатів: Режим перегляду
5321143b-3e52-43eb-b240-af8c8b189f61	ConnectorRegister	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Реєстрація інсталяції: Режим перегляду
53c15e8b-dede-433a-983e-222a8b49ca24	BiobankCellUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування комірки: Повний доступ
53d2d645-9250-4719-a1a6-bda99c773f23	OrderDispatch	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відправити в лабораторію: Ні
54131698-97b2-4c88-82e8-4ea46b944a52	SectionDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення підрозділу лабораторії: Ні
554dc748-d0b5-4c74-9182-1bcdec831629	OrderCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлення: Ні
556d8b0c-e252-4960-8d78-09dba0cee965	PanicCallUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування панічного дзвінка: Повний доступ
55bdcdd5-d3ac-410a-a050-8aa33ee9da36	ConnectorRotateKey	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Перевипустити ключ: Ні
562c8e6b-cf44-47df-928e-cd42a4287e48	ReagentLotDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лоту реагенту: Ні
569acce4-a21c-4f04-9f56-0dfd6ef79a26	LogsRetentionRun	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Очищення журналів: Повний доступ
57cdad4c-5a37-4916-a417-34e8637c6c5c	ConnectorEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Редагувати: Повний доступ
58d94b2f-0e1e-4c66-b65d-5a02031e6596	OrderPrintReport	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк бланка: Режим перегляду
59522167-e8db-482a-a1e6-5c61dc1b31ba	OrderEnterResult	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Ввести результат: Режим перегляду
5974aaf5-7647-4cd3-bc8c-9bbedc6e1a03	UnmatchedResultDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення незв'язаного результату: Повний доступ
5b5a81c4-bfb5-48b4-802a-cdad3c5bfb30	ResultsImport	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів: Повний доступ
5c36269f-033a-4ce8-b9a5-3474b2d294c0	ConnectorEnable	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Увімкнути (повторна реєстрація): Повний доступ
5ce1ac42-2a2d-4614-ba37-391ee3d78ee5	OrderComplete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Завершити (усі тести верифіковано): Режим перегляду
5d0aa2dd-6612-49d4-b435-5bf7745f479f	OrderAddSample	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати пробірку: Повний доступ
5d7c8ea4-5850-409b-9be8-88fd75ee31d4	OrderDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видалити замовлення: Режим перегляду
5e271d18-eaa5-4ec8-ac84-60c60770601e	ResultsAutoVerify	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Автоверифікація: Режим перегляду
5e38edd7-a4fa-4253-b335-05b03364021b	OrderPrintLabels	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк етикеток: Режим перегляду
5e81644c-deb4-4c5e-a784-e788baba35d0	CultureIsolate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Ізоляти виділено: Повний доступ
5f7573f1-de2a-4f3f-82de-6abdaf9d4b42	SampleEditFlags	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відмітки гемоліз/ліпемія/іктеричність: Повний доступ
5fad38d1-cee2-4fcf-b517-5280ae35f7e7	ManifestReceive	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Прийняти в лабораторії: Ні
61046ea5-efe4-41cf-b3c2-fa946cf114a8	ResultsImport	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів: Режим перегляду
610fdfb7-7616-41af-84db-9a08c13d11fd	ManifestEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Редагувати маніфест: Режим перегляду
62238887-4e68-4346-bf5e-b94551b40cf6	LogsRetentionRun	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Очищення журналів: Режим перегляду
62b17453-d8d9-4b9f-8fc0-8b7b556d1bee	OrderTestVerify	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Верифікувати: Режим перегляду
62f53b42-2933-48ae-9830-92eb018e3e02	QcResultAdd	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату ВКЯ: Повний доступ
633326fd-2c9a-48cd-ab1b-8bccc93a1de6	OrderCreateBatch	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлень: Режим перегляду
641bc5e8-62ae-4429-a66e-a8f5d36772b7	OrderTestVerify	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Верифікувати: Повний доступ
64be26fa-e0b2-4195-b5e8-b72245252986	SampleDispose	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Утилізувати: Повний доступ
650d428b-7817-4349-b02d-11bed3119d8c	ConnectorDisable	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Вимкнути: Режим перегляду
65b372ec-2d56-4c43-bc0f-cc3765162c9b	SectionUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування підрозділу лабораторії: Режим перегляду
65d56f03-82aa-46c4-b97b-eb5058f3d13f	ReagentLotCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення лоту реагенту: Ні
66646112-bc72-4765-8bd9-02f8e8b26c24	SendOutDispatch	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відправка проб у зовнішню лабораторію: Повний доступ
66defff9-27f0-4204-93b0-596464fad852	OrderTestRemove	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Прибрати тест із замовлення: Повний доступ
67110076-092d-4691-8ce3-654091094789	OrderReopen	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Повернути в роботу: Режим перегляду
67711b98-e2fd-4ed7-9a74-2d04b4d0564a	PayersEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник платників: Ні
686fc8d8-6673-4189-a7b6-05a71c8f2b53	NumeratorUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна нумератора: Ні
6b47c0c9-23f8-48e3-ab91-2dc5a873ab73	LabSettingsUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна налаштувань лабораторії: Ні
6bad6043-1f04-41a1-b71a-79b2fb0d9b83	OrderTestStartAnalysis	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Передати на аналізатор: Режим перегляду
6ce02c50-59b4-428f-8e22-bb4f5af202ca	SampleReject	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відбракувати пробірку: Повний доступ
6cf417df-a53c-45b1-aa14-28c9f9364d8a	ConnectorEnable	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Увімкнути (повторна реєстрація): Режим перегляду
6d01a7de-a893-4e3f-85e5-f04a84800415	ReagentLotUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування лоту реагенту: Режим перегляду
6e4ddc8c-6c5d-4117-83c6-921168e41af2	NormsEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування норм: Режим перегляду
6e854819-7ad4-429b-8ba1-182c86b404a9	OrderEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Редагувати замовлення: Повний доступ
6ed84722-ae18-45fa-b772-fe8519fbb217	FavoritesEditOther	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування обраних іншого співробітника: Повний доступ
6f5eef87-d4e5-4e77-b2e8-f79f410d4ae7	BiobankPlace	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розміщення зразка в біобанку: Повний доступ
706f4985-b37f-47bf-9fec-e95518cbb3f2	ManifestDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Видалити маніфест: Ні
718cf868-10c7-45b9-8f39-6adf5b0c871c	OrderTestPerformerChange	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна виконавця дослідження: Ні
71ca47cb-7839-43a0-ae6f-fba18be7533b	OrderAddTest	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати тест: Режим перегляду
71fae09d-cd8d-4625-8250-657e754e1b8c	OrderTestReopen	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкрити повторно: Ні
73298f3a-5a59-41ac-8707-93197eebd9f9	AnalyzerCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення аналізатора: Ні
737c8fb7-1d64-4f00-b4df-170662ede199	OrderCreateBatch	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлень: Повний доступ
73be9ca0-df8b-4c1c-b552-eb84b1e88cda	CultureCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення посіву: Повний доступ
73c7ab98-3671-482c-b3d8-52ebc559cd2f	PanicCallDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення панічного дзвінка: Ні
74154d57-f8d8-4c2c-8af3-59911bcc09c3	LabSettingsUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна налаштувань лабораторії: Повний доступ
7550b01c-32b8-4483-bd96-930bab99b22f	PayerPeriodInvoice	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Рахунок/акт за період: Режим перегляду
759154a0-f79e-470c-aa61-0d0f45276ad2	ConnectorRegister	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Реєстрація інсталяції: Ні
766e9076-f17e-438c-8ead-e0abf65716a2	OrderTestDeleteResult	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Видалити результат: Ні
772ac057-328d-4965-b2ce-c052eeda2603	WorklistBatchUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування робочого листа: Режим перегляду
788aabb3-4687-4af6-bb0a-2e84b42b8983	CultureDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Видалити посів: Повний доступ
7890da75-bce5-44e6-9c62-410eb60c4a93	SendOutAccept	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Підтвердження приймання зовнішньою лабораторією: Повний доступ
79117a0f-8692-4433-b5e4-142f845b595d	PayersEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник платників: Режим перегляду
794ede96-754d-43d7-9111-896b9845240c	BiobankCellDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення комірки: Режим перегляду
7afeab50-dff4-42ec-8770-169ec08fd4aa	OrderTestPerformerChange	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна виконавця дослідження: Повний доступ
7b5168a4-5404-441d-b224-c1e4cd4bce09	AnalyzerCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення аналізатора: Повний доступ
7ba10bb4-17ac-46f6-84a9-2e66e09f372f	ReagentLotCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення лоту реагенту: Режим перегляду
7cb8c1ff-ff34-4c57-bef2-dcb8dba2ee89	JournalEntryStatusChange	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна статусу позиції журналу: Режим перегляду
7cd4973c-3b0f-416e-9694-b178e7841bc4	FavoritesSave	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження обраних наборів: Режим перегляду
7d0f3624-7c4e-4abf-81a4-c3e26067e882	PerformerTestsEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс зовнішньої лабораторії: Повний доступ
7db97b62-af4e-4e2c-84de-88c8ecad487e	BiobankCellUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування комірки: Ні
7ef0d556-2e09-49c1-9727-7aa4534b4613	CultureAddSusceptibility	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Антибіотикограма: Повний доступ
7fab9ae1-e97b-423a-bba7-eb94c990e5a8	BiobankPlace	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розміщення зразка в біобанку: Ні
8009125f-dcab-4582-bed4-3407a6e49a0c	FavoritesSave	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження обраних наборів: Ні
8031fbef-5eb9-4fb4-a147-0c9fd8489920	ConnectorRegister	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Реєстрація інсталяції: Повний доступ
80685073-bf63-4eb4-bc0e-2c6b77dbe513	AnalyzerMessageDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису журналу: Режим перегляду
8088b2a3-4d37-4187-9d1b-c51ec20f3cef	OrderCancel	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Скасувати замовлення: Ні
814f27cc-ba77-4405-855b-a6769bf3353f	QcMaterialDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення контрольного матеріалу: Повний доступ
82cad8a4-c690-49e3-be6f-b81ba096377c	ChargePatientChoiceChange	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна оплати позиції: Повний доступ
8388d48e-f708-49fa-b967-c022b7ac0989	QcResultDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення результату ВКЯ: Ні
83ccf1cc-9271-4aec-bd68-4c921f46b836	OrderTestAssignAnalyzer	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Призначити аналізатор: Повний доступ
83eb6243-bc73-4ff2-a532-b70e254b865c	SampleDispatch	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відправити: Повний доступ
8474e635-aa0d-4553-ba30-cb7f660b5df4	NormsEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування норм: Повний доступ
8538ff0a-ce28-4de8-a2b2-18baf81a0117	ReagentConsume	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Списання реагенту: Режим перегляду
8539214d-4b33-448e-8dd3-f6dd42138890	ManifestDispatch	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відправити: Режим перегляду
858851cb-ef8c-4b4d-9c9e-9a59a7f6e1fd	ConnectorCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення інсталяції коннектора: Режим перегляду
85e22e24-e448-4d70-b58d-733082a86027	RackDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення штатива: Режим перегляду
8645587f-82d9-4caf-9865-06dce9e32c15	ReagentLotCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення лоту реагенту: Повний доступ
86569a63-0992-4c15-8f15-7977b709675a	PatientCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення картки пацієнта: Ні
8693cc50-2029-4ad7-b194-07e5c8f0bf83	QcResultUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування результату ВКЯ: Повний доступ
86c5784e-2a0e-418e-8567-0d860b1407e0	OrderTestReject	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відхилити тест: Ні
8770c19b-c0f8-4d5e-a084-324476d9dd25	DictionaryEntryDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису довідника: Повний доступ
8824dba9-ea75-4f87-aa91-ad8ef6ca873f	SendOutCancel	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Скасування реєстру відправки: Режим перегляду
8ab95d96-25b2-413a-9398-a6685afc5163	WorkflowTemplateEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування шаблону робочого процесу: Ні
8d080dfa-ba69-44e8-80bc-5951641e24e6	OrderTestRecallSendOut	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкликати з зовнішньої лабораторії: Повний доступ
8e0e58e6-a28f-4bd2-aa6e-674b77e4d626	OrderPayerChange	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна платника замовлення: Повний доступ
8e329248-62c8-4127-bcb6-c87122af44d7	DictionaryEntryUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування запису довідника: Повний доступ
8e8d06a3-5562-4bfb-804a-9e827412f3a6	ManifestCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення маніфесту: Режим перегляду
90303088-a5a7-491a-9868-116cfe781d6f	SampleDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Видалити пробірку: Повний доступ
910cbfbb-fd67-4cf5-8017-1a89b86da068	PerformersEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Довідник лабораторій-виконавців: Режим перегляду
91693b08-6675-40b8-9b84-cde9a29e0447	SampleDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Видалити пробірку: Режим перегляду
91f4bd70-52c6-451f-b1e5-27944156cd04	PatientUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування картки пацієнта: Режим перегляду
9210f69a-2875-4709-b7fe-ad49cd8ded1c	LabSettingsUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна налаштувань лабораторії: Режим перегляду
9221efe8-6ee7-4ac4-b84a-73eb54ea6a0f	CultureCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення посіву: Ні
92751fa0-d3d7-46d9-a3f8-ae6c773f7d0f	CultureCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення посіву: Режим перегляду
936b7b9f-d56f-45e1-8abe-cc86ca39c8ba	OrderTestReject	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відхилити тест: Повний доступ
93b34df0-a380-4cdd-8794-4f2bbcee941b	LockoutDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення lockout: Ні
93cc4166-7d28-44da-a91a-59068aa8909f	ResultsRead	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд результатів: Повний доступ
9419f48b-476c-4d0b-ab3d-207db7c8fd31	OrderReject	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відхилити (брак біоматеріалу): Ні
942008e4-432b-4a74-8073-06ac52c7624f	ClientRegistryImport	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт реєстру клініки: Ні
945f4baf-cc5c-4c7e-894c-145995c87b19	SampleStore	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Розмістити в біобанку: Повний доступ
94825d4d-a7e2-4d8d-b7fc-16fa44ce268b	OrderTestRecallSendOut	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкликати з зовнішньої лабораторії: Режим перегляду
94968f91-f5a2-4548-9609-1678686d9de8	WorklistBatchCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення робочого листа: Ні
949c0087-39fa-4953-b193-ed2cf93ddacb	SendOutCancel	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Скасування реєстру відправки: Повний доступ
94cf6b77-5a81-4f08-93e7-65b8fa80c5a7	ReagentLotDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лоту реагенту: Повний доступ
95786984-f1a0-4117-baa1-ae1b76d2f8c2	QcResultUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування результату ВКЯ: Режим перегляду
96302acd-fe6c-4e2b-bf72-206d69c3ab2a	PriceListsEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс-листи: Режим перегляду
97eba645-0c26-4457-bf76-6e275ce0316b	OrderTestPerformerChange	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна виконавця дослідження: Режим перегляду
97f3cc4b-e48d-44ce-b26e-7c115f1468b8	ConnectorRotateKey	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Перевипустити ключ: Режим перегляду
988685a9-5925-4402-8cfc-68b5fdd97af8	AnalyzerDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення аналізатора: Ні
99a41267-4872-41bc-b45d-6c5401e8a4fa	CulturePreliminary	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Попередній результат: Повний доступ
9a33cafb-d370-470b-81db-e5b9ee923001	SampleDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Видалити пробірку: Ні
9a3ee45a-af02-44cc-8ee4-e62237055034	ConnectorDisable	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Вимкнути: Ні
9a6c328c-af97-42ce-b5ac-546e73b47b24	PaymentAdd	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прийом оплати: Повний доступ
9a853380-1b50-41cf-9810-50bcb2a93322	QcMaterialUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування контрольного матеріалу: Ні
9bafc379-c31c-4f83-91c7-8bd9884b6675	CultureAddSusceptibility	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Антибіотикограма: Ні
9bb63f23-7ec1-4535-862c-ca156d041a35	PanicCallCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Реєстрація панічного дзвінка: Повний доступ
9be4dfd5-5d93-4596-8a6a-f795cc88faa5	ConnectorHeartbeat	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Heartbeat: Режим перегляду
9c3028dd-27da-498a-8e92-6acc3e7fdcba	OrderTestStartAnalysis	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Передати на аналізатор: Повний доступ
9c8eef5b-945f-4377-bfd7-be9c7bd2772d	OrderTestAssignAnalyzer	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Призначити аналізатор: Режим перегляду
9d266474-2788-4701-8edb-57916af5c72f	RackDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення штатива: Ні
9d26e43e-15bb-4809-877a-7f5f21728965	OrderRemoveTest	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прибрати тест: Повний доступ
9dd1d042-a6f4-4098-b3de-38a028a670ce	EmployeeSave	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження співробітника: Повний доступ
9eef9610-6465-4afa-a7e6-c1666b5d3a5a	FavoritesDeleteOther	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення обраних іншого співробітника: Режим перегляду
9f42ab57-53f5-4099-9e7f-008e64042b37	ConnectorHeartbeat	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Heartbeat: Повний доступ
9f91662d-a15e-4219-802b-37fec8d6a343	QcMaterialCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення контрольного матеріалу: Ні
9fabdcc7-f46f-4941-b395-8b170a8cbccf	DictionaryEntryCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення запису довідника: Ні
9fb30780-7fd0-49d0-8b73-4d4ed5067086	BiobankCellUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування комірки: Режим перегляду
a18be720-3af4-44e5-b256-3f8bdf77c82e	WorklistBatchUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування робочого листа: Ні
a294d19c-5c42-4958-81ed-3cab314c6168	OrderPrintReport	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Друк бланка: Повний доступ
a32f1d39-1f2b-4a2b-88af-c7d1a2a38163	OrderTestReopen	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відкрити повторно: Повний доступ
a3ba84c0-6b42-491d-8b78-7522e7d2c874	LockoutCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Ручне блокування аналізатора: Режим перегляду
a4f00701-44f8-4e51-9f49-13dc8b8fe5db	PatientDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення картки пацієнта: Ні
a640f004-fe6e-41c3-870a-f7cb45b33e6c	SendOutResultEnter	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату зовнішньої лабораторії: Повний доступ
a7ea6a20-4158-43cd-be04-82e3711ae057	SampleReceive	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Прийняти: Ні
a8e7ac06-382d-41be-8314-a72ef3d4c145	UnmatchedResultDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення незв'язаного результату: Ні
a9aa929d-466f-428b-8aa4-67a998e51323	OrderAddSample	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати пробірку: Ні
aadefa70-567d-4be6-bdc4-b9086661840c	PerformerTestsEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс зовнішньої лабораторії: Ні
aba8f6f5-f78f-44a5-bf77-6602644f54e3	FavoritesSave	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження обраних наборів: Повний доступ
abc19540-9f27-4121-83e1-399a552c193c	OrderCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлення: Режим перегляду
ac67960c-97bb-4f4f-a371-33630756eac3	WorkflowTemplateEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування шаблону робочого процесу: Режим перегляду
ad863845-80e0-45b8-b5e4-756f6fb7cc33	OrderRemoveTest	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прибрати тест: Ні
ae36b820-615a-4db0-babd-5afe4ba6593f	ResultsRead	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд результатів: Режим перегляду
aeb8e79b-90b5-41fe-902e-7907283aea8b	OrderComplete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Завершити (усі тести верифіковано): Ні
aef75e72-fa40-4082-8e50-5dc7c1056515	SampleStageAdd	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Фіксація етапу обробки проби: Повний доступ
af1db18e-4787-45d7-a77f-3f674e2d361a	RackCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення штатива: Повний доступ
b06eb3c6-9d31-454b-b752-207c223e57f3	OrderDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видалити замовлення: Повний доступ
b0f10564-620c-411e-b4b3-c77794f15848	WorkflowTemplateEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування шаблону робочого процесу: Повний доступ
b118193e-0b58-4d51-a598-77bc16e6b678	SampleDispatch	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відправити: Ні
b227e6e4-9eb9-4ef0-affc-e3e6da02e7e0	QcMaterialCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення контрольного матеріалу: Повний доступ
b267b68c-e96c-4881-8f7d-979c2298d07b	EmployeeSave	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження співробітника: Ні
b29c664b-bf00-4d24-b650-0f4e4ce5b693	SectionCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення підрозділу лабораторії: Повний доступ
b2be2eb3-60fc-4b87-9292-faa98c035ccf	LogsRetentionRun	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Очищення журналів: Ні
b2e0084c-9a62-48d1-807e-6b2b6fab5b19	UnmatchedResultLink	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зв'язування результату: Ні
b319b79f-6862-4dc7-a64f-55929eb2f3fb	SampleUncollect	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Скасувати відмітку забору: Режим перегляду
b32f4c6c-9341-4b23-b360-d17c2bb0ffd7	ConnectorCommand	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Команда коннектору: Режим перегляду
b3a709b8-9408-4e81-a61c-e0d4418797d5	PatientDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення картки пацієнта: Повний доступ
b3b537a2-138d-4526-8fef-cff6ed22bb57	LockoutCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Ручне блокування аналізатора: Ні
b3d626a3-1533-4c65-8578-24df405bc681	NormsDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення норм: Режим перегляду
b4f0650d-1372-4689-9154-024e533f6f51	PanicCallUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування панічного дзвінка: Режим перегляду
b58420c3-d94a-4db4-ba17-dfba5100596d	DictionaryEntryDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення запису довідника: Режим перегляду
b6f00abe-643a-4bd7-8b1f-313763743455	RackUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування штатива: Ні
b7529bb8-bd85-4e47-a2a0-9aca9409c9e0	QcResultUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування результату ВКЯ: Ні
b788d48e-cf1a-4797-84dd-8de58b45ba45	OrderTestStartAnalysis	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Передати на аналізатор: Ні
b8a4a589-9725-4739-9310-85d118fe8b21	ManifestDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Видалити маніфест: Повний доступ
b8b6abb1-70b2-4b95-86b8-10c6d923e65f	PanicCallDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення панічного дзвінка: Повний доступ
b92d0a78-7189-4cdb-be08-f2ba6c05a9d6	OrderDispatch	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відправити в лабораторію: Режим перегляду
b9cefa15-52f8-4de0-8341-1affa921b7ee	ClientRegistryImport	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт реєстру клініки: Режим перегляду
b9d23732-ef02-4912-9d12-99288e92bb91	PerformerDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лабораторії-виконавця: Ні
ba2745c0-90c4-4ec3-b146-f04b9f9b194a	OrderTestEnterResult	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Ввести результат: Повний доступ
ba551bea-d661-4a65-94e8-9943084b1149	WorklistBatchDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення робочого листа: Повний доступ
bac69f85-4f86-47ae-98f8-d8bf1b5c7071	SampleCollect	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Забір пробірки: Ні
bba014bc-e7c1-412a-a20a-620e0459bb5c	CultureIsolate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Ізоляти виділено: Ні
bbc9ad1f-36a9-4976-864d-88c97baa343a	OrderVerify	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Верифікувати результати: Режим перегляду
bbe3ba6c-d4e8-433b-a5eb-652e8c0d8106	SampleStageEventDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення події етапу: Повний доступ
bc8eb7e7-1b5e-40e9-83e6-d08e3c0ebc8b	QcResultAdd	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Внесення результату ВКЯ: Ні
bdc9402b-8c56-402c-b338-45ac5a660f35	SampleCollect	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Забір пробірки: Режим перегляду
be1368b8-252c-4db9-bc41-72ec1e6b2fa7	ConnectorMarkOffline	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Позначити офлайн: Режим перегляду
c0321514-f57e-459f-bd52-7091a7e575c1	OrderCollect	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Забір біоматеріалу: Режим перегляду
c046ddac-0b5e-44f3-bb26-7c632680e592	ReagentConsume	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Списання реагенту: Повний доступ
c059f3ac-c7c7-478c-a62c-cd45f6d848d6	SampleStageEventDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення події етапу: Режим перегляду
c15319de-8f93-4fb6-ac00-118148af18c1	SendOutCancel	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Скасування реєстру відправки: Ні
c1e7e565-9274-498c-b323-8dbee9f14a05	SendOutResultsImport	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів зовнішньої лабораторії: Режим перегляду
c298cf10-0741-4556-a108-eb99747aba2c	SampleProcess	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: В обробці (центрифугування/аналіз): Режим перегляду
c2e16e9c-8d00-4c2e-8686-fac2645af09a	SampleSplit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Алікотування / розділення проби: Ні
c372487a-e811-41ad-a681-19788f037a53	FavoritesEditOther	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування обраних іншого співробітника: Режим перегляду
c3766418-d64d-471f-a24c-b9599a3005d0	OrdersRead	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд замовлень: Режим перегляду
c3c08a31-bc32-4485-b406-4b02da66a689	QcTargetDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення цільового значення: Повний доступ
c4a2849e-fe3b-4dcd-89b1-c078b905aaf3	WorklistBatchDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення робочого листа: Ні
c50d2c44-e7b5-4b80-921a-17273ae9bd5f	OrderPayerChange	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна платника замовлення: Режим перегляду
c5209ba0-6ad3-452b-8001-ab431a2e965d	PatientUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування картки пацієнта: Ні
c5f277df-44ce-44ae-9a24-f08b0705add5	InvoiceIssue	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Виставлення рахунку платнику: Ні
c7570d62-8e5b-49c2-8d1b-0c76b784bddd	OrderVerify	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Верифікувати результати: Повний доступ
c7fa5ae5-a113-41b6-9aaf-452a81bd804e	ConnectorRotateKey	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Перевипустити ключ: Повний доступ
c8db36bf-44dd-4140-9a18-df22cd819dbc	PriceListsEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс-листи: Ні
c8fd733c-c318-48b7-a1ea-a068079b4310	SendOutDispatch	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відправка проб у зовнішню лабораторію: Режим перегляду
c94bf6db-ed6f-441a-81e9-9833e478db51	ManifestEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Редагувати маніфест: Ні
c9cbcfda-7ede-466b-b5f5-91a9df56118c	CultureEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Редагувати посів: Повний доступ
ca0227ae-f8ac-4b7d-ac5d-5c4a27ed25f9	PatientUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування картки пацієнта: Повний доступ
ca48635f-0034-4097-8220-36ccf26ee25a	BiobankRemove	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Вилучення зразка з біобанку: Режим перегляду
cab43a48-0657-45bf-a4f2-2bb60147284b	SendOutDispatch	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відправка проб у зовнішню лабораторію: Ні
cae8bea9-d6ea-43f7-ab63-95965cf84fc0	QcMaterialUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування контрольного матеріалу: Повний доступ
cc17d4db-e5a2-415d-92d4-8b4f849a74ec	OrderTestEnterResult	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Ввести результат: Ні
ccd52bee-8746-406b-af70-7451e6dc6808	SendOutAccept	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Підтвердження приймання зовнішньою лабораторією: Ні
ccf8bfa2-58ed-4de0-a041-1934cb8dff68	SectionCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення підрозділу лабораторії: Ні
ccfd5a51-b833-456c-87de-bf84000d495d	PerformerDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення лабораторії-виконавця: Режим перегляду
cd050bc7-cdf8-4578-b358-de523bf07fc8	SampleStageEventDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення події етапу: Ні
cd6ef43f-ed85-4eee-bb5e-c69d82467b58	OrderCollect	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Забір біоматеріалу: Ні
cebf8252-4c98-412a-96d0-c2acc8d1ca8b	SampleReceive	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Прийняти: Режим перегляду
d07110bc-1eaf-47fe-beff-83a5bec32deb	SendOutResultsImport	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів зовнішньої лабораторії: Повний доступ
d0f48621-4d96-4062-93fe-77434242b9ba	OrderCreateBatch	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення замовлень: Ні
d1216fea-2175-4738-a611-d2a6393b92fc	OrdersRead	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд замовлень: Ні
d13a7025-0835-468f-8c09-51ac73dcdc39	PatientInsurancesEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Поліси пацієнта: Повний доступ
d159d4c1-7506-4c6d-871a-f8d829410e2d	OrderReject	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Відхилити (брак біоматеріалу): Режим перегляду
d200b7cd-0ba9-4655-b4fd-efc98a43fc09	QcTargetDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення цільового значення: Режим перегляду
d22bc141-6d83-4ca6-92ce-bfbd817a22d2	ResultsRead	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Перегляд результатів: Ні
d269cd02-6338-4f2f-8e88-49fa38993d2b	OrderReopen	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Повернути в роботу: Повний доступ
d2cbc60c-5c26-4d4a-9795-eac279042f02	ResultsAutoVerify	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Автоверифікація: Повний доступ
d2ea8320-cae2-4183-b46f-872cf98c795b	LockoutCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Ручне блокування аналізатора: Повний доступ
d2ebd47b-18fb-4c5c-a3f4-9d733da7bf80	OrderEnterResult	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Ввести результат: Ні
d3afd4a3-3de9-4997-953b-c17aa78208ea	ConnectorDisable	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Вимкнути: Повний доступ
d3b47946-79ee-4be7-8075-8e167d15ba7b	SectionCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення підрозділу лабораторії: Режим перегляду
d3cd5407-fa66-41d4-be33-4225c8e7a404	NumeratorUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна нумератора: Режим перегляду
d460aeed-14f7-4a25-b3fe-6612f676b2f2	DictionaryEntryUpdate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування запису довідника: Режим перегляду
d46c02c0-a6ca-4541-801f-82813316b670	SampleReceive	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Прийняти: Повний доступ
d4c48d24-1b39-41da-ac7f-16868ba96817	OrderRelease	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видати результати пацієнту: Повний доступ
d5b1452c-6194-4aee-979b-6e7514ca7d82	RackUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування штатива: Повний доступ
d7a0eafe-6a87-4124-a700-1a3c2b448eaa	WorklistBatchDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення робочого листа: Режим перегляду
d7d1f06b-ab90-4b60-9adb-4b36c612c07e	OrderCancel	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Скасувати замовлення: Повний доступ
d816153b-f9b0-409b-a393-0abb8149f1ad	BiobankCellDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення комірки: Ні
d9e46d9c-5ad8-44f6-82a5-544bddab76f0	ReagentConsume	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Списання реагенту: Ні
da8bafc3-0886-4a1e-ba31-7a2d3ebc5a92	PriceListsEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс-листи: Повний доступ
dbaa8d06-b475-4fd4-a94c-cc154701b7ae	OrderTestVerify	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Верифікувати: Ні
dc5bdea0-be36-4b7a-b817-bbc7d54f7582	NormsDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення норм: Ні
dce1c5bc-15ab-43ec-bb24-5af5498c90c2	OrderTestRemove	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Прибрати тест із замовлення: Ні
ddf89aea-7bb1-4470-b7ac-1bc45459af6b	RackCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення штатива: Режим перегляду
dee96473-57a3-48b4-8bce-6baf8f75cd99	ManifestReject	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відхилити (порушення холодового ланцюга): Повний доступ
df8b5965-a3d8-4415-bb6d-7833cd1e9d68	OrderTestAssignAnalyzer	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Призначити аналізатор: Ні
e08380f7-8a4f-437e-8f57-2d766e43a72a	EmployeeSave	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Збереження співробітника: Режим перегляду
e0a10e30-b6de-4af2-9845-f67e18b81c7b	LockoutDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення lockout: Повний доступ
e0bcab01-a56c-4806-ad9c-e7caca9350f5	OrderTestReject	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Відхилити тест: Режим перегляду
e11bacc7-5e2a-4cfa-9c7d-e76fe2494516	SampleSplit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Алікотування / розділення проби: Повний доступ
e1fd8b5a-b3b8-4dc6-bb71-eafad802f317	DictionaryEntryCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення запису довідника: Режим перегляду
e24068d5-d6f9-4057-afac-cdaaf3975bc5	PerformerTestsEdit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Прайс зовнішньої лабораторії: Режим перегляду
e377b96f-f6e9-4214-8c4c-29de53895064	CultureDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Видалити посів: Режим перегляду
e38e9da0-6db0-494c-877d-16d0977058ce	OrderTestRerun	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Повторити дослідження: Ні
e3a87043-f9ed-481e-9a1f-f1890e129e3d	AnalyzerCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення аналізатора: Режим перегляду
e3b9e5ba-0189-4677-bd09-9de2a3756567	ChargePatientChoiceChange	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна оплати позиції: Режим перегляду
e4214f98-959c-4416-aab7-f0f7f72a69d6	JournalEntryStatusChange	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна статусу позиції журналу: Ні
e42c89d0-15fb-4e18-89cf-00707c374ac4	SampleCollect	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Забір пробірки: Повний доступ
e521e4ec-92f4-457c-be95-9df0229f7490	CultureIsolate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Ізоляти виділено: Режим перегляду
e5ac74d0-fd7f-4e2d-9f03-f85e55b0f64e	CultureEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Редагувати посів: Ні
e60d4235-82d6-4788-aa1a-d52e5bade2f9	OrderRemoveTest	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Прибрати тест: Режим перегляду
e60f7cfd-02e6-45e0-8b15-7c82e59df2fb	CultureAddIsolate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Додати ізолят: Повний доступ
e7174897-b063-4044-a5c8-d0ead927e9c9	InvoiceCancel	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Анулювання рахунку: Повний доступ
e80a54c8-0c35-4906-b4e0-3f95a7a049e1	OrderDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видалити замовлення: Ні
e82e402a-24ae-4de2-903f-ac7a530b4aca	QcMaterialCreate	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення контрольного матеріалу: Режим перегляду
e9c25951-e85e-41dd-b97a-81d1e8e21dfa	ConnectorDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Видалити: Ні
e9d1d958-dc67-4aef-aabc-ef0e5d8a1a1a	SampleDispose	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Утилізувати: Режим перегляду
ea1fc0c8-21dc-4a05-bc15-5bfc743b7a32	ConnectorEdit	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Редагувати: Ні
eaf16230-627d-412c-8260-ec62b2a7dd87	OrderComplete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Завершити (усі тести верифіковано): Повний доступ
eb173f95-4feb-4c19-9a43-d2e3a8a7fa3c	ManifestReject	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Відхилити (порушення холодового ланцюга): Режим перегляду
ec728fea-7cd3-4cd8-9545-46ab77a9685a	PanicCallCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Реєстрація панічного дзвінка: Ні
ec961700-c0a8-472b-8793-2676794c2cea	OrderAttachmentAdd	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Завантаження бланка результатів: Повний доступ
ed431cf8-7333-48b1-93d1-9c9b887d27df	OrderCancel	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Скасувати замовлення: Режим перегляду
ee124c92-7ee1-4f7c-8343-51f89a70a1f9	SectionDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення підрозділу лабораторії: Режим перегляду
efb9fde2-4262-417e-b9ec-91e3c56e317c	WorklistBatchUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування робочого листа: Повний доступ
f07ff92b-8684-4574-8d51-aae6384b14e2	OrderAddTest	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Додати тест: Ні
f0bb019d-197f-496d-ac5f-63672329b73c	ConnectorCommand	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Команда коннектору: Ні
f0ced314-e4cf-4e2b-b400-7accefd0b228	SampleReject	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відбракувати пробірку: Режим перегляду
f0e03fc9-a308-4212-8fa5-ffbd467952dc	InvoiceIssue	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Виставлення рахунку платнику: Режим перегляду
f17547e7-02c6-48cd-8037-d0148e51472f	PanicCallUpdate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування панічного дзвінка: Ні
f1f98d76-39fe-400b-a201-3525e7742c45	LockoutResolve	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Розблокування аналізатора: Режим перегляду
f2da56b2-5d64-4e8c-8e33-cd669d9f6107	ConnectorMarkOffline	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Коннектор: Позначити офлайн: Ні
f4af7ee1-a163-4305-bbad-89fa3271f842	OrderRelease	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Замовлення: Видати результати пацієнту: Ні
f4b4f33a-9591-477d-a313-5dc7d42696cd	SampleEditFlags	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Відмітки гемоліз/ліпемія/іктеричність: Режим перегляду
f4b9337c-9225-4f6c-87ca-c3d7278809dd	ManifestDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Видалити маніфест: Режим перегляду
f5dd5a8a-4071-40e6-8393-b1b50582b373	UnmatchedResultLink	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зв'язування результату: Режим перегляду
f64a5c86-77e7-4e9c-ae21-10250f71da3a	ConnectorCreate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення інсталяції коннектора: Повний доступ
f6ebc510-0fd1-4aa9-8ea0-68262d1f01d8	SectionUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Редагування підрозділу лабораторії: Повний доступ
f6efb59e-bb3b-42c9-b998-9d4860d687ac	NumeratorUpdate	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна нумератора: Повний доступ
f893dcfc-bb2c-4b47-be6f-01cfc2ed90e1	PayerPeriodInvoice	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Рахунок/акт за період: Повний доступ
fa0116a7-8eea-417e-8a3b-2f980979b012	ManifestEdit	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Маніфест: Редагувати маніфест: Повний доступ
fb69dcbd-ae12-41ea-9822-da0603697f7e	SampleSplit	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Алікотування / розділення проби: Режим перегляду
fb7a9902-e5a9-4fd7-a1df-b3ed33dda518	CultureDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Видалити посів: Ні
fb9fd0ae-df02-44f5-9247-4dcb6fba22b8	OrderPayerChange	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Зміна платника замовлення: Ні
fc0600f4-dccd-4aa5-83b6-243f76cff559	CultureAddSusceptibility	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Антибіотикограма: Режим перегляду
fc07c9ef-e68c-4e8f-b0de-5daaa07e7006	SampleStageAdd	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Фіксація етапу обробки проби: Режим перегляду
fce73bb6-1b05-4949-ac82-a0d8b08709a2	SampleReplace	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Замінити пробірку (новий штрихкод): Режим перегляду
fcf550b9-ad5e-422c-bfb1-ab169ea6d4e3	ResultsImport	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Імпорт результатів: Ні
fd6bc516-60f9-4a8f-ab95-8ab42c80250c	SampleStore	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Пробірка: Розмістити в біобанку: Режим перегляду
fd961056-3038-47fb-b193-39450f2359c7	CulturePreliminary	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Посів: Попередній результат: Ні
fde014f8-c2bf-4d07-b4d7-f810b2b1abac	ManifestCreate	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Створення маніфесту: Ні
fe72a7fe-5a34-4d4e-a2e7-ade674b03826	UnmatchedResultDelete	1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення незв'язаного результату: Режим перегляду
fe7c88f9-2ac9-47d9-a32e-2115859fc614	SendOutItemReject	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Відмова/відкликання позиції реєстру: Ні
ff1c607f-d46c-4c87-a537-6e8c4c3a9b27	QcTargetDelete	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення цільового значення: Ні
ff4e107a-3b8b-45c8-ad23-bf593911c582	OrderTestDeleteResult	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Тест: Видалити результат: Повний доступ
ff5d97ba-c9a0-41b0-af20-db6b6a19167f	AnalyzerDelete	2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Видалення аналізатора: Повний доступ
ffa76b05-6c63-40ca-a608-9ac97328266d	InvoiceCancel	0	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.526807	Анулювання рахунку: Ні
\.


--
-- Data for Name: sys_profile; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_profile (id, is_active, type_id, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
5ec00000-0000-0000-0000-000000000001	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-18 23:57:14.146252	Адміністратор лабораторії
5ec00000-0000-0000-0000-000000000002	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Лікар-лаборант / завідувач
5ec00000-0000-0000-0000-000000000003	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Фельдшер-лаборант
5ec00000-0000-0000-0000-000000000004	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Медсестра пункту забору
5ec00000-0000-0000-0000-000000000005	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Кур'єр / логіст
5ec00000-0000-0000-0000-000000000006	t	\N	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Реєстратор
\.


--
-- Data for Name: sys_profile_operation_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_profile_operation_right (id, profile_id, operation_right_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
\.


--
-- Data for Name: sys_profile_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_profile_right (id, profile_id, right_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
\.


--
-- Data for Name: sys_profile_role; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_profile_role (id, profile_id, role_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
5ec00000-0000-0000-0000-0000000000c1	5ec00000-0000-0000-0000-000000000001	5ec00000-0000-0000-0000-0000000000b1	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ec00000-0000-0000-0000-0000000000c2	5ec00000-0000-0000-0000-000000000002	5ec00000-0000-0000-0000-0000000000b2	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ec00000-0000-0000-0000-0000000000c3	5ec00000-0000-0000-0000-000000000003	5ec00000-0000-0000-0000-0000000000b3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ec00000-0000-0000-0000-0000000000c4	5ec00000-0000-0000-0000-000000000004	5ec00000-0000-0000-0000-0000000000b4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ec00000-0000-0000-0000-0000000000c5	5ec00000-0000-0000-0000-000000000005	5ec00000-0000-0000-0000-0000000000b5	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ec00000-0000-0000-0000-0000000000c6	5ec00000-0000-0000-0000-000000000006	5ec00000-0000-0000-0000-0000000000b6	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
\.


--
-- Data for Name: sys_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_right (id, entity_name, entity_access_level, is_active, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
\.


--
-- Data for Name: sys_role; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_role (id, is_active, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
5ec00000-0000-0000-0000-0000000000b1	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Адміністратор лабораторії
5ec00000-0000-0000-0000-0000000000b2	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Лікар-лаборант / завідувач
5ec00000-0000-0000-0000-0000000000b3	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Фельдшер-лаборант
5ec00000-0000-0000-0000-0000000000b4	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Медсестра пункту забору
5ec00000-0000-0000-0000-0000000000b5	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Кур'єр / логіст
5ec00000-0000-0000-0000-0000000000b6	t	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087	Реєстратор
\.


--
-- Data for Name: sys_role_operation_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_role_operation_right (id, role_id, operation_right_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
012769c9-9f18-4ec0-9316-5cfbc241f606	5ec00000-0000-0000-0000-0000000000b6	1fe6303e-a663-4f0d-b9d7-e994f5b4b243	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
03fa755f-e604-4187-8791-41c5f0e1e4c5	5ec00000-0000-0000-0000-0000000000b1	5f7573f1-de2a-4f3f-82de-6abdaf9d4b42	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0407d077-f064-4b95-ac77-ccc9c743a7ef	5ec00000-0000-0000-0000-0000000000b4	9a6c328c-af97-42ce-b5ac-546e73b47b24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
04adae9a-6c08-41e1-b709-231fac8e554a	5ec00000-0000-0000-0000-0000000000b1	af1db18e-4787-45d7-a77f-3f674e2d361a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
058100f2-fb89-4b00-be6f-6a8aef22bcad	5ec00000-0000-0000-0000-0000000000b3	06b920de-74e5-45bb-b16b-a62aab9d0568	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
05d80be6-2ce8-4f23-abf2-77924a6d8d24	5ec00000-0000-0000-0000-0000000000b3	a294d19c-5c42-4958-81ed-3cab314c6168	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
08e66b11-c47b-4b16-9682-c629b76c8961	5ec00000-0000-0000-0000-0000000000b1	c3c08a31-bc32-4485-b406-4b02da66a689	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
093975d6-d597-49a0-abb4-f4cc33e56f36	5ec00000-0000-0000-0000-0000000000b3	23e69ef9-d63b-4160-95d0-b2cb03a4028d	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
09e5ad88-c1ae-448b-9909-e0afe365b43b	5ec00000-0000-0000-0000-0000000000b1	eaf16230-627d-412c-8260-ec62b2a7dd87	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0a5fcc9c-cf05-4eb1-8e4a-b408e4cd9f5d	5ec00000-0000-0000-0000-0000000000b1	936b7b9f-d56f-45e1-8abe-cc86ca39c8ba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0a6a2c1a-3be4-46b2-93b8-60ba2a31f30b	5ec00000-0000-0000-0000-0000000000b2	d46c02c0-a6ca-4541-801f-82813316b670	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0a80247d-c9fa-44b1-8ba9-d786047673a0	5ec00000-0000-0000-0000-0000000000b1	033742ec-4105-4e2b-bc8b-3e138ec7563c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0af14539-bfb0-4248-b109-9da7384ceef8	5ec00000-0000-0000-0000-0000000000b3	737c8fb7-1d64-4f00-b4df-170662ede199	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0b4bea59-5bb2-4d00-bc27-a0a0c5fad54b	5ec00000-0000-0000-0000-0000000000b1	f64a5c86-77e7-4e9c-ae21-10250f71da3a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0b7b55df-586c-4ee0-8fe9-0ea840afedcc	5ec00000-0000-0000-0000-0000000000b2	eaf16230-627d-412c-8260-ec62b2a7dd87	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0b9c4f3a-93d0-4dfc-b0da-bc1b7b9edf01	5ec00000-0000-0000-0000-0000000000b1	d07110bc-1eaf-47fe-beff-83a5bec32deb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0bdb4020-2d4d-4b41-b579-c701f94df226	5ec00000-0000-0000-0000-0000000000b1	f6ebc510-0fd1-4aa9-8ea0-68262d1f01d8	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0be1496d-4c72-444a-b8b2-95f68baf71dc	5ec00000-0000-0000-0000-0000000000b1	49cf836f-d742-4ab2-8246-b1b8f36d139e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0c3b569e-5877-4565-9445-ad84bb93d66f	5ec00000-0000-0000-0000-0000000000b1	556d8b0c-e252-4960-8d78-09dba0cee965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0c4ef906-878f-485e-8a65-03570973da84	5ec00000-0000-0000-0000-0000000000b1	06b920de-74e5-45bb-b16b-a62aab9d0568	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0d247964-3b0f-48c4-9c43-84eb19426195	5ec00000-0000-0000-0000-0000000000b2	9c3028dd-27da-498a-8e92-6acc3e7fdcba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0d4049c0-480e-428e-a8ae-7602bc970880	5ec00000-0000-0000-0000-0000000000b3	66646112-bc72-4765-8bd9-02f8e8b26c24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0d4bb416-62a6-4438-8f25-0e84ea3c651e	5ec00000-0000-0000-0000-0000000000b3	1fe6303e-a663-4f0d-b9d7-e994f5b4b243	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0d9c555f-d081-45c3-a6b4-a8788ba8d7ab	5ec00000-0000-0000-0000-0000000000b6	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0eea7039-2ef6-4a28-b75f-5feaabd3cff9	5ec00000-0000-0000-0000-0000000000b1	57cdad4c-5a37-4916-a417-34e8637c6c5c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
0f0edb37-0f4d-4ab5-b8de-bfbbe554c06a	5ec00000-0000-0000-0000-0000000000b1	945f4baf-cc5c-4c7e-894c-145995c87b19	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
103ca5bf-4532-4e5b-9a46-1057646957f4	5ec00000-0000-0000-0000-0000000000b3	5974aaf5-7647-4cd3-bc8c-9bbedc6e1a03	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
10dd44d7-dabd-4292-97e0-ff19b5d5d957	5ec00000-0000-0000-0000-0000000000b1	c7fa5ae5-a113-41b6-9aaf-452a81bd804e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
11782e22-69ad-405f-b681-d4af8a65e8af	5ec00000-0000-0000-0000-0000000000b1	62f53b42-2933-48ae-9830-92eb018e3e02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
11d7ab6d-2054-49fa-96c2-11d7077f29b4	5ec00000-0000-0000-0000-0000000000b1	17ea5f30-3a3f-47a6-8e36-f1b5f27cb6df	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
12692b17-cf5d-4809-b3a9-6544f8301b7f	5ec00000-0000-0000-0000-0000000000b3	0c3c03bb-93c0-49e1-9b27-9b08b82545d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
12d89e26-3d45-44f2-bc5c-60e0bb32c427	5ec00000-0000-0000-0000-0000000000b1	5b5a81c4-bfb5-48b4-802a-cdad3c5bfb30	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
13142b01-45e1-4948-9cab-e185ffcfa5c2	5ec00000-0000-0000-0000-0000000000b6	391b2821-58b5-493e-9b1f-c8e4c6077ef0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1349f2c5-178a-4ae9-8f5a-47ed27f69983	5ec00000-0000-0000-0000-0000000000b1	64be26fa-e0b2-4195-b5e8-b72245252986	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
146941be-3134-4ba5-b447-d4315929278c	5ec00000-0000-0000-0000-0000000000b2	ca0227ae-f8ac-4b7d-ac5d-5c4a27ed25f9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
154eb3cb-d712-4505-9577-d4436f222772	5ec00000-0000-0000-0000-0000000000b5	30409657-7d57-4ba8-92c6-9101c6db673e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
15bc6afe-ca85-4fa2-b6dc-0dc5e0b609e0	5ec00000-0000-0000-0000-0000000000b2	94cf6b77-5a81-4f08-93e7-65b8fa80c5a7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1685e5ed-a9c8-47e8-a7c8-b7959a973426	5ec00000-0000-0000-0000-0000000000b3	53c15e8b-dede-433a-983e-222a8b49ca24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1695230b-9509-4e0f-b710-71197405e5d4	5ec00000-0000-0000-0000-0000000000b1	cae8bea9-d6ea-43f7-ab63-95965cf84fc0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
16ab44a4-ae1d-4c5d-b05a-f0edfc37513a	5ec00000-0000-0000-0000-0000000000b1	f893dcfc-bb2c-4b47-be6f-01cfc2ed90e1	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1723cf7b-9155-4110-a334-ef7b6f4ed6c4	5ec00000-0000-0000-0000-0000000000b3	7afeab50-dff4-42ec-8770-169ec08fd4aa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
19a5c3e8-fd1d-49fb-ac9c-df88cfc510d5	5ec00000-0000-0000-0000-0000000000b1	24a9cce7-f9d8-459a-b6e5-513a8d899edc	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1a217013-57f3-42af-af02-4916e51d862f	5ec00000-0000-0000-0000-0000000000b2	8474e635-aa0d-4553-ba30-cb7f660b5df4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1a625a49-0072-4d95-8330-9a6e5fb3fa5b	5ec00000-0000-0000-0000-0000000000b1	1fe6303e-a663-4f0d-b9d7-e994f5b4b243	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1b6969ea-1d66-4283-ad91-601d5a2ae627	5ec00000-0000-0000-0000-0000000000b4	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1b7277fa-8864-4c13-bc7c-f3b19f5fa44d	5ec00000-0000-0000-0000-0000000000b1	fa0116a7-8eea-417e-8a3b-2f980979b012	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1c2a13e2-95f0-4643-8c6f-3fd091a42f32	5ec00000-0000-0000-0000-0000000000b1	641bc5e8-62ae-4429-a66e-a8f5d36772b7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1d025687-9ed2-4c37-96fb-ca2918eaf90d	5ec00000-0000-0000-0000-0000000000b2	9dd1d042-a6f4-4098-b3de-38a028a670ce	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1eb880f8-0bd6-44bd-9772-05f0c84aae8f	5ec00000-0000-0000-0000-0000000000b1	8693cc50-2029-4ad7-b194-07e5c8f0bf83	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1f431873-ee99-4200-8770-51b3c427c546	5ec00000-0000-0000-0000-0000000000b1	30409657-7d57-4ba8-92c6-9101c6db673e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
1f5ed74a-df3a-432e-8037-a3300269582a	5ec00000-0000-0000-0000-0000000000b1	8e0e58e6-a28f-4bd2-aa6e-674b77e4d626	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
203a47e3-a8ba-4e40-b66f-90b4beb6ec36	5ec00000-0000-0000-0000-0000000000b3	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2071336c-ae02-4ea7-979a-8825639683c4	5ec00000-0000-0000-0000-0000000000b2	d7d1f06b-ab90-4b60-9adb-4b36c612c07e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
20c79fcf-a8a5-4d62-88f1-2fbe06af9aed	5ec00000-0000-0000-0000-0000000000b1	d2cbc60c-5c26-4d4a-9795-eac279042f02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
21294f27-0de5-4ea4-8bd4-ddf6d45166fb	5ec00000-0000-0000-0000-0000000000b2	49cf836f-d742-4ab2-8246-b1b8f36d139e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2152bec3-76e4-4a47-9faf-708262ad117c	5ec00000-0000-0000-0000-0000000000b1	4f1e4e86-df39-4f95-98df-aec50ddda1d4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
21c43117-d354-446e-969c-7b838cb579f6	5ec00000-0000-0000-0000-0000000000b6	8e0e58e6-a28f-4bd2-aa6e-674b77e4d626	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
21d2f262-b8a0-44b5-8636-35cbab366996	5ec00000-0000-0000-0000-0000000000b1	569acce4-a21c-4f04-9f56-0dfd6ef79a26	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
220e76b0-a5fb-41cd-85ad-f62916495fc3	5ec00000-0000-0000-0000-0000000000b2	e11bacc7-5e2a-4cfa-9c7d-e76fe2494516	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
220e81a2-200b-489d-8009-cbb50502809d	5ec00000-0000-0000-0000-0000000000b3	5f7573f1-de2a-4f3f-82de-6abdaf9d4b42	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
22889d8f-7c14-4a4e-8d81-43f79938b91f	5ec00000-0000-0000-0000-0000000000b3	42c98b5c-6c10-40af-a820-51de40a1a1d3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
22a02e60-0d53-456d-89ad-2ec84dcbf483	5ec00000-0000-0000-0000-0000000000b1	99a41267-4872-41bc-b45d-6c5401e8a4fa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
232f4b05-c81b-4a6b-915c-8c2edd98a08a	5ec00000-0000-0000-0000-0000000000b1	391b2821-58b5-493e-9b1f-c8e4c6077ef0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
239c8ac4-6237-4305-a4d4-a1e41b2f92fb	5ec00000-0000-0000-0000-0000000000b1	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2452d57d-9539-4879-aee5-15a4e73fd777	5ec00000-0000-0000-0000-0000000000b2	53c15e8b-dede-433a-983e-222a8b49ca24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
24e7d6fb-8cfc-46c9-b158-27828bd0c322	5ec00000-0000-0000-0000-0000000000b5	0c3c03bb-93c0-49e1-9b27-9b08b82545d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
24f414a9-5c1d-433b-9f89-a54d98f670f0	5ec00000-0000-0000-0000-0000000000b1	2dd92f45-374a-4433-b8a3-f642ff867c3e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
250a670f-2094-4f57-ac18-807550cb2bee	5ec00000-0000-0000-0000-0000000000b2	23e69ef9-d63b-4160-95d0-b2cb03a4028d	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
25d2763c-f293-4865-adf7-9aeaf69ad747	5ec00000-0000-0000-0000-0000000000b1	ba551bea-d661-4a65-94e8-9943084b1149	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2709cd58-6967-451b-a687-63dfbff4a844	5ec00000-0000-0000-0000-0000000000b2	038cd2c4-2f00-4ac8-9efd-2f3b6cd81568	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
275d18b8-d982-4611-a710-f9bd5aed1ce0	5ec00000-0000-0000-0000-0000000000b6	d7d1f06b-ab90-4b60-9adb-4b36c612c07e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2773eca9-1632-4e58-984b-fa481cd5aae9	5ec00000-0000-0000-0000-0000000000b1	240d1a90-b188-4f15-b51f-4cfb1dac3714	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
29233e95-8c71-4779-a57b-ce075f275d41	5ec00000-0000-0000-0000-0000000000b2	788aabb3-4687-4af6-bb0a-2e84b42b8983	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2a54242d-4be8-434f-8e62-70cf4693ad9e	5ec00000-0000-0000-0000-0000000000b1	b8a4a589-9725-4739-9310-85d118fe8b21	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2a9435a8-b68b-49e5-806b-c55e3745d508	5ec00000-0000-0000-0000-0000000000b4	42c98b5c-6c10-40af-a820-51de40a1a1d3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2b0b7d48-4692-43ed-9ebb-13c180ea91d3	5ec00000-0000-0000-0000-0000000000b2	272073ec-87f8-4133-8d6e-41198c03e269	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2b341e52-8165-437f-8de9-01c94b22ccf1	5ec00000-0000-0000-0000-0000000000b2	033742ec-4105-4e2b-bc8b-3e138ec7563c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2bb4ce59-5495-445b-a574-95e2d62ddbd2	5ec00000-0000-0000-0000-0000000000b4	4c9a26ff-47c8-4813-81ce-d5a4a6e2ad36	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2bd2d5fe-cc88-4505-80f8-4718a1a0ed45	5ec00000-0000-0000-0000-0000000000b2	73be9ca0-df8b-4c1c-b552-eb84b1e88cda	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2c9e9d2e-e341-4c55-8b30-9f6583a3be58	5ec00000-0000-0000-0000-0000000000b1	4c8bdd44-c6bd-4a50-b72b-61cf2fbb7d60	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2d416439-2bd3-4c49-a8f1-ce46a6025abc	5ec00000-0000-0000-0000-0000000000b3	945f4baf-cc5c-4c7e-894c-145995c87b19	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2db26756-6c57-41ee-b8c1-a0cc5b9e4685	5ec00000-0000-0000-0000-0000000000b4	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2e073a99-e33c-4cfe-a87b-dc7245b63818	5ec00000-0000-0000-0000-0000000000b4	3f2ff6ad-d131-4eba-91c2-6a7c0f16cf98	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2ef6d420-4b48-40ee-8b0c-b119f3b8ddd4	5ec00000-0000-0000-0000-0000000000b3	e60f7cfd-02e6-45e0-8b15-7c82e59df2fb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2f5e31bd-8a2d-4411-8e39-ebb689a3b27a	5ec00000-0000-0000-0000-0000000000b5	dee96473-57a3-48b4-8bce-6baf8f75cd99	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
2f8b8c92-5f02-4fc8-94fe-3e8d4a27ef21	5ec00000-0000-0000-0000-0000000000b2	8645587f-82d9-4caf-9865-06dce9e32c15	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
31455da3-bf9d-421d-a6c8-15735ee6d98f	5ec00000-0000-0000-0000-0000000000b6	473425b2-4dc0-42cd-a907-93f68e57e786	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3187317e-21a1-447b-a7b8-22afbf16ec41	5ec00000-0000-0000-0000-0000000000b3	8d080dfa-ba69-44e8-80bc-5951641e24e6	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
32168a04-2f5f-4ad0-9ba4-2bc30fdacc7f	5ec00000-0000-0000-0000-0000000000b2	945f4baf-cc5c-4c7e-894c-145995c87b19	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
32e10969-3e0a-4192-a4ec-f40ed1e3ef2c	5ec00000-0000-0000-0000-0000000000b2	138465c7-6db9-43a4-95b3-dba5806c8bf3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
332176d3-f30b-4081-904c-eae468ee9fe7	5ec00000-0000-0000-0000-0000000000b3	0b1db92e-58a1-451e-82e4-48d930395edc	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
33e63e40-0d4a-420e-b6ad-d0855c29d6ab	5ec00000-0000-0000-0000-0000000000b2	93cc4166-7d28-44da-a91a-59068aa8909f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
34d84a10-9112-4500-a5da-cd1e7e62b28e	5ec00000-0000-0000-0000-0000000000b1	0b1db92e-58a1-451e-82e4-48d930395edc	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
34fc305a-4ef6-4916-b0c0-86cba8644a82	5ec00000-0000-0000-0000-0000000000b3	4f1e4e86-df39-4f95-98df-aec50ddda1d4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
35e12885-c202-4205-80c3-e5c90a9cd385	5ec00000-0000-0000-0000-0000000000b1	8031fbef-5eb9-4fb4-a147-0c9fd8489920	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
35f7f118-b557-4f10-a197-fe17c255f79e	5ec00000-0000-0000-0000-0000000000b2	9d26e43e-15bb-4809-877a-7f5f21728965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
367306a5-755c-4a9e-82bd-a0ab00f25790	5ec00000-0000-0000-0000-0000000000b1	a640f004-fe6e-41c3-870a-f7cb45b33e6c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
374949b7-9ebd-435e-ac83-7d2f2979b160	5ec00000-0000-0000-0000-0000000000b1	6e854819-7ad4-429b-8ba1-182c86b404a9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3791dac6-da56-47e1-8fe9-c6461ac57f0e	5ec00000-0000-0000-0000-0000000000b3	242b9aa5-e492-4591-8ee0-480260f8da78	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
379ff456-f788-48d7-8cd2-6fd62f21a754	5ec00000-0000-0000-0000-0000000000b2	aef75e72-fa40-4082-8e50-5dc7c1056515	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3845aeb0-f23f-453d-825d-125db0538c3e	5ec00000-0000-0000-0000-0000000000b4	4d46697b-99b4-4a49-b748-1b5a736cc873	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3943f7a7-6cc6-4f6b-aece-c1162ac0f7fd	5ec00000-0000-0000-0000-0000000000b2	8d080dfa-ba69-44e8-80bc-5951641e24e6	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
39f61528-45db-466b-a88f-ebf4a22bdaeb	5ec00000-0000-0000-0000-0000000000b1	5e81644c-deb4-4c5e-a784-e788baba35d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3bf245a9-e8cd-4dc2-b6c6-b0d8fb7d6369	5ec00000-0000-0000-0000-0000000000b1	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3c049b3b-979a-4432-8c28-3c5975a45377	5ec00000-0000-0000-0000-0000000000b3	d07110bc-1eaf-47fe-beff-83a5bec32deb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3c0fca2f-dc5d-429a-924e-963fb4949c5a	5ec00000-0000-0000-0000-0000000000b2	ff4e107a-3b8b-45c8-ad23-bf593911c582	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3ccc9bae-a207-4a5a-a122-8d57f65a4676	5ec00000-0000-0000-0000-0000000000b6	240d1a90-b188-4f15-b51f-4cfb1dac3714	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3d4e71db-b5af-4dfd-a05f-4aa9ee99c58e	5ec00000-0000-0000-0000-0000000000b3	138465c7-6db9-43a4-95b3-dba5806c8bf3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3eea248e-f483-4f1f-b1c5-cb7de72449d7	5ec00000-0000-0000-0000-0000000000b3	949c0087-39fa-4953-b193-ed2cf93ddacb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3f2f3569-b808-4b37-b540-293b42260c80	5ec00000-0000-0000-0000-0000000000b4	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
3f34364f-6bf7-4ff0-a15e-adbfce21eabd	5ec00000-0000-0000-0000-0000000000b1	c046ddac-0b5e-44f3-bb26-7c632680e592	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4171bbbe-3d28-453c-843d-e8fa9e8eccc4	5ec00000-0000-0000-0000-0000000000b2	0c3c03bb-93c0-49e1-9b27-9b08b82545d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
418ca364-e944-46ce-809b-c540b2936b8d	5ec00000-0000-0000-0000-0000000000b3	c9cbcfda-7ede-466b-b5f5-91a9df56118c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
420db0be-74c7-4d28-b36e-f9a70239bf72	5ec00000-0000-0000-0000-0000000000b1	5c36269f-033a-4ce8-b9a5-3474b2d294c0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
43287647-17e6-425c-b204-62467e69d886	5ec00000-0000-0000-0000-0000000000b2	62f53b42-2933-48ae-9830-92eb018e3e02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
434b4f69-8f32-4270-883f-c3fee9ea3887	5ec00000-0000-0000-0000-0000000000b2	d2cbc60c-5c26-4d4a-9795-eac279042f02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
43ec3af3-ac23-4a6c-b8e7-652521a20c82	5ec00000-0000-0000-0000-0000000000b3	c3c08a31-bc32-4485-b406-4b02da66a689	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
44ffb348-09ed-41dc-b41b-7d1e7a9b2ee6	5ec00000-0000-0000-0000-0000000000b1	0c3c03bb-93c0-49e1-9b27-9b08b82545d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
44ffb98c-a9c0-45a3-8921-aa87b55967c9	5ec00000-0000-0000-0000-0000000000b5	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
45d71f21-6328-4608-85ee-c4adce94742f	5ec00000-0000-0000-0000-0000000000b1	1586687c-d061-426a-8256-76b191a4a15b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
45e0d7d7-22d5-468e-a2fe-a2a11ba20a9e	5ec00000-0000-0000-0000-0000000000b4	737c8fb7-1d64-4f00-b4df-170662ede199	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
468041aa-e867-4d1c-883f-d42372481eec	5ec00000-0000-0000-0000-0000000000b1	6ce02c50-59b4-428f-8e22-bb4f5af202ca	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
471806d2-e67e-4b36-97bb-42b1ad5c9021	5ec00000-0000-0000-0000-0000000000b1	d46c02c0-a6ca-4541-801f-82813316b670	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
47ed6cae-a6a1-45a3-8a5d-efd357b67525	5ec00000-0000-0000-0000-0000000000b2	cae8bea9-d6ea-43f7-ab63-95965cf84fc0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4823bf92-2050-43fa-bbf2-5b2a6911ba19	5ec00000-0000-0000-0000-0000000000b3	45413c76-0018-4ae8-9f8c-4cd34cebf09f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
49093fb5-2500-4da8-aec2-00bd5f235931	5ec00000-0000-0000-0000-0000000000b1	7b5168a4-5404-441d-b224-c1e4cd4bce09	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4b25351a-376f-4a00-a805-7556a44c37e2	5ec00000-0000-0000-0000-0000000000b3	0b94936b-4b43-4852-b02c-b027ab041cee	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4b5dac24-55d2-48e3-830f-f87128005052	5ec00000-0000-0000-0000-0000000000b4	1fe6303e-a663-4f0d-b9d7-e994f5b4b243	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4d9709bc-9eb6-4661-bab2-3e1d7821633f	5ec00000-0000-0000-0000-0000000000b5	5038c88a-e24e-497b-8083-8211f72807e9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4ddef12f-eeeb-4e4d-aa5f-acb15d152a37	5ec00000-0000-0000-0000-0000000000b1	dee96473-57a3-48b4-8bce-6baf8f75cd99	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4e965fb0-966b-4699-bdf5-4e61505376bf	5ec00000-0000-0000-0000-0000000000b4	93cc4166-7d28-44da-a91a-59068aa8909f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4ead9723-eac9-43b4-a58f-fb6235098115	5ec00000-0000-0000-0000-0000000000b4	0b1db92e-58a1-451e-82e4-48d930395edc	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4f1b364c-3328-41db-9bf2-f745ba2ec5ae	5ec00000-0000-0000-0000-0000000000b1	949c0087-39fa-4953-b193-ed2cf93ddacb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4f242dfc-bd94-451f-b0a0-a4c31892ddd4	5ec00000-0000-0000-0000-0000000000b2	7890da75-bce5-44e6-9c62-410eb60c4a93	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
4f943640-07a7-4477-b13b-82e1f8609450	5ec00000-0000-0000-0000-0000000000b1	a32f1d39-1f2b-4a2b-88af-c7d1a2a38163	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
52d77f66-e45e-45b2-a7f7-77d48304dbb1	5ec00000-0000-0000-0000-0000000000b1	94cf6b77-5a81-4f08-93e7-65b8fa80c5a7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
53e9bdcc-d708-45f8-b278-6d6b04184ef9	5ec00000-0000-0000-0000-0000000000b1	c7570d62-8e5b-49c2-8d1b-0c76b784bddd	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
54acc006-d2c7-4dd3-8f03-df9ea4319990	5ec00000-0000-0000-0000-0000000000b2	814f27cc-ba77-4405-855b-a6769bf3353f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5586287e-e8e7-4eec-bcac-812e6158282f	5ec00000-0000-0000-0000-0000000000b1	8e329248-62c8-4127-bcb6-c87122af44d7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
55964e9d-a618-4a44-b761-3f589e9e9754	5ec00000-0000-0000-0000-0000000000b1	d13a7025-0835-468f-8c09-51ac73dcdc39	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
564afd0f-4e16-43ed-8d49-fc93892f55ba	5ec00000-0000-0000-0000-0000000000b1	ff4e107a-3b8b-45c8-ad23-bf593911c582	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
569601ab-f3e9-4110-b2b6-165fd81625f0	5ec00000-0000-0000-0000-0000000000b1	8645587f-82d9-4caf-9865-06dce9e32c15	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
58546b1a-08db-4d2e-b92a-03c15fee928d	5ec00000-0000-0000-0000-0000000000b4	5d0aa2dd-6612-49d4-b435-5bf7745f479f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
596b90af-e652-46f2-968a-040a53e8e4d6	5ec00000-0000-0000-0000-0000000000b2	473425b2-4dc0-42cd-a907-93f68e57e786	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5a1e96a2-26bd-4c33-b589-e745034e3fb6	5ec00000-0000-0000-0000-0000000000b1	b227e6e4-9eb9-4ef0-affc-e3e6da02e7e0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5c647cde-c3e3-4b84-986a-3ed2b44e4004	5ec00000-0000-0000-0000-0000000000b1	bbe3ba6c-d4e8-433b-a5eb-652e8c0d8106	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ccf55ac-8dc9-4012-ba52-d934b8599f69	5ec00000-0000-0000-0000-0000000000b3	ba551bea-d661-4a65-94e8-9943084b1149	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5ce39a43-f5d5-4721-aa62-a10adeae45a5	5ec00000-0000-0000-0000-0000000000b3	d5b1452c-6194-4aee-979b-6e7514ca7d82	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5dc3ca9c-9203-410d-acbd-67ea5be7caf7	5ec00000-0000-0000-0000-0000000000b2	7afeab50-dff4-42ec-8770-169ec08fd4aa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5e3219d5-0214-4fc1-b2ea-2054bdfbcf67	5ec00000-0000-0000-0000-0000000000b3	efb9fde2-4262-417e-b9ec-91e3c56e317c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5e37d418-5502-4ee1-b537-ca3b190882a8	5ec00000-0000-0000-0000-0000000000b3	1b1eb079-2f0b-49d3-9efd-45560c3ed57c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5e786dda-df7c-4059-bb1a-20edb8d8a84f	5ec00000-0000-0000-0000-0000000000b3	03eab55c-1fdd-475b-9cfc-78efb2bf3e7b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5efb1424-f697-473d-86c1-ef38d3c3f928	5ec00000-0000-0000-0000-0000000000b1	3570c1b3-fb0e-478d-ab47-157e31e71831	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
5f2c779e-f9f0-4f0d-a044-3ea3440794b1	5ec00000-0000-0000-0000-0000000000b3	556d8b0c-e252-4960-8d78-09dba0cee965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
60796402-8595-447c-8199-0c9177ff02b7	5ec00000-0000-0000-0000-0000000000b1	2d000536-63c8-4d6e-aaaa-3e7857e74363	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
60dc3055-fd65-4da6-867c-6099c1ccaf7a	5ec00000-0000-0000-0000-0000000000b2	3570c1b3-fb0e-478d-ab47-157e31e71831	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
61ceb54e-f4f3-4649-8b04-9a3d9d9d8ec4	5ec00000-0000-0000-0000-0000000000b2	a640f004-fe6e-41c3-870a-f7cb45b33e6c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
61eac380-ae4b-4e0e-a509-4c708db917bc	5ec00000-0000-0000-0000-0000000000b2	8e329248-62c8-4127-bcb6-c87122af44d7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
62106c35-bf16-4327-b2f9-198cceeca00b	5ec00000-0000-0000-0000-0000000000b6	f893dcfc-bb2c-4b47-be6f-01cfc2ed90e1	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
62125932-2a05-418e-8a3c-fc244c7e33fe	5ec00000-0000-0000-0000-0000000000b1	4c9a26ff-47c8-4813-81ce-d5a4a6e2ad36	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
64fb678d-0c0c-4e7f-8585-7ec1051aab1f	5ec00000-0000-0000-0000-0000000000b3	dee96473-57a3-48b4-8bce-6baf8f75cd99	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
651e089d-8546-464a-8cb5-e07c3cb12820	5ec00000-0000-0000-0000-0000000000b1	7890da75-bce5-44e6-9c62-410eb60c4a93	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
662f7043-bd7e-4028-b1ac-93064e63caa8	5ec00000-0000-0000-0000-0000000000b2	363e4291-aff5-46da-abfb-40a648fa2cad	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
66677d72-c71a-48c0-b0cc-b20f623af81b	5ec00000-0000-0000-0000-0000000000b2	4c8bdd44-c6bd-4a50-b72b-61cf2fbb7d60	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
66b9acf6-3826-486a-a6ae-332030a56909	5ec00000-0000-0000-0000-0000000000b1	e7174897-b063-4044-a5c8-d0ead927e9c9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
66d7e1d0-58f3-41e0-84dc-03d8fc278770	5ec00000-0000-0000-0000-0000000000b1	9d26e43e-15bb-4809-877a-7f5f21728965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
67227e8c-f9cb-49ce-a9f0-d73e30fb617a	5ec00000-0000-0000-0000-0000000000b1	c9cbcfda-7ede-466b-b5f5-91a9df56118c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
67e64846-23d7-426e-b3b6-1d801126820e	5ec00000-0000-0000-0000-0000000000b2	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
694eddd9-7a28-4ba6-83e5-395f8fc90a34	5ec00000-0000-0000-0000-0000000000b2	e60f7cfd-02e6-45e0-8b15-7c82e59df2fb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
69f439a1-d0e2-4295-8dcf-e5b87346fd91	5ec00000-0000-0000-0000-0000000000b1	8474e635-aa0d-4553-ba30-cb7f660b5df4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6a23b9d2-e6ac-4032-8802-06e2cb2cc333	5ec00000-0000-0000-0000-0000000000b1	d3afd4a3-3de9-4997-953b-c17aa78208ea	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6a614018-53eb-46b8-ae96-9f6c30a6926a	5ec00000-0000-0000-0000-0000000000b6	9a6c328c-af97-42ce-b5ac-546e73b47b24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6a7c985a-1a52-448e-8c0f-1dba25f47f19	5ec00000-0000-0000-0000-0000000000b3	7890da75-bce5-44e6-9c62-410eb60c4a93	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6b359ae5-61ab-46ff-bd02-7481f6339329	5ec00000-0000-0000-0000-0000000000b3	cae8bea9-d6ea-43f7-ab63-95965cf84fc0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6bd3989c-669a-4f26-8963-2e7eb5d38839	5ec00000-0000-0000-0000-0000000000b6	737c8fb7-1d64-4f00-b4df-170662ede199	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6c89affe-5dcb-4b90-aa88-c4e82add6bbb	5ec00000-0000-0000-0000-0000000000b2	936b7b9f-d56f-45e1-8abe-cc86ca39c8ba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6cc3e5e0-0fd1-44b1-9838-d1c6026081ef	5ec00000-0000-0000-0000-0000000000b2	d07110bc-1eaf-47fe-beff-83a5bec32deb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6d038b25-937b-49c9-89ee-aadf337d4bfb	5ec00000-0000-0000-0000-0000000000b1	f6efb59e-bb3b-42c9-b998-9d4860d687ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6dbbabaa-0cd6-4339-bfcc-ba9a2106bf61	5ec00000-0000-0000-0000-0000000000b2	03eab55c-1fdd-475b-9cfc-78efb2bf3e7b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6f01b384-d74d-4719-9823-d3388a8f9b37	5ec00000-0000-0000-0000-0000000000b3	62f53b42-2933-48ae-9830-92eb018e3e02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
6f0c125d-a3e9-4097-b89a-1273096a11c1	5ec00000-0000-0000-0000-0000000000b1	9a6c328c-af97-42ce-b5ac-546e73b47b24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
703e7e51-619e-4a27-ab27-a06a46707573	5ec00000-0000-0000-0000-0000000000b2	a294d19c-5c42-4958-81ed-3cab314c6168	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
71acb25d-0f2c-4ecc-b3df-64d9257dc85c	5ec00000-0000-0000-0000-0000000000b2	06b920de-74e5-45bb-b16b-a62aab9d0568	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
71d2ec31-0e20-477b-b309-75cacc31e82f	5ec00000-0000-0000-0000-0000000000b5	03eab55c-1fdd-475b-9cfc-78efb2bf3e7b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
71ef1655-9346-4abf-93b4-4e7b926c8bab	5ec00000-0000-0000-0000-0000000000b3	b227e6e4-9eb9-4ef0-affc-e3e6da02e7e0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
71f4eab7-b940-45fa-b29b-9f4482854868	5ec00000-0000-0000-0000-0000000000b3	936b7b9f-d56f-45e1-8abe-cc86ca39c8ba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
72895148-2e3e-429b-b6e6-bdf91ae49e80	5ec00000-0000-0000-0000-0000000000b2	b8b6abb1-70b2-4b95-86b8-10c6d923e65f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
730a2866-1dee-4c16-8287-ab9b774ebd82	5ec00000-0000-0000-0000-0000000000b1	93cc4166-7d28-44da-a91a-59068aa8909f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
73475c80-0d06-4966-bc67-ff474be0046d	5ec00000-0000-0000-0000-0000000000b2	8693cc50-2029-4ad7-b194-07e5c8f0bf83	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
73c53dc8-1880-46ef-9131-3869210c467e	5ec00000-0000-0000-0000-0000000000b1	ba2745c0-90c4-4ec3-b146-f04b9f9b194a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
74dc85fa-0541-47d5-bc53-baffc98da9f7	5ec00000-0000-0000-0000-0000000000b1	0b94936b-4b43-4852-b02c-b027ab041cee	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
75f71414-ccef-4604-b57b-ed07856aea65	5ec00000-0000-0000-0000-0000000000b6	a294d19c-5c42-4958-81ed-3cab314c6168	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
76a7474b-494d-4f3f-aacf-c9543ff10240	5ec00000-0000-0000-0000-0000000000b1	9f42ab57-53f5-4099-9e7f-008e64042b37	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
77143aef-38ed-47b0-84b9-3a054e15fca8	5ec00000-0000-0000-0000-0000000000b6	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
779298db-5fad-4e60-9d86-073e758d3c4a	5ec00000-0000-0000-0000-0000000000b3	64be26fa-e0b2-4195-b5e8-b72245252986	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
786f3006-b45a-41d3-b3aa-aa7623f837e2	5ec00000-0000-0000-0000-0000000000b3	9c3028dd-27da-498a-8e92-6acc3e7fdcba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
78929ec5-f1c8-4849-b9b9-08f7e78b29db	5ec00000-0000-0000-0000-0000000000b1	0765d767-50e2-4ab6-bc84-b2fbeda20637	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7901266b-0639-446e-9e71-57c1e3675b7b	5ec00000-0000-0000-0000-0000000000b6	5d0aa2dd-6612-49d4-b435-5bf7745f479f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
79592681-ab33-4f1e-9a4b-8871aaf3d52f	5ec00000-0000-0000-0000-0000000000b2	3938ab1d-72da-4f28-9240-f94904f87d6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7a516212-3142-4aea-8b5c-5c21e683b46a	5ec00000-0000-0000-0000-0000000000b1	11feac05-77fd-4ac0-b494-01da28867c02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7a6e86cc-c20b-46b5-9453-0f7c67e82594	5ec00000-0000-0000-0000-0000000000b3	391b2821-58b5-493e-9b1f-c8e4c6077ef0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7ae615bc-a777-4497-a886-aaab07f936f7	5ec00000-0000-0000-0000-0000000000b1	5d0aa2dd-6612-49d4-b435-5bf7745f479f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7b5bff21-2c5d-49a9-955a-1d4a8bd75542	5ec00000-0000-0000-0000-0000000000b1	3f2ff6ad-d131-4eba-91c2-6a7c0f16cf98	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7b939b72-28a2-4308-a59b-65aef7053de8	5ec00000-0000-0000-0000-0000000000b6	d13a7025-0835-468f-8c09-51ac73dcdc39	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7e8c2bbf-237b-4825-b900-5eb2e519beb3	5ec00000-0000-0000-0000-0000000000b5	b8a4a589-9725-4739-9310-85d118fe8b21	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7ed51c34-b023-467c-95c9-5fcb33b39cf5	5ec00000-0000-0000-0000-0000000000b1	073f2cb0-5e9e-402e-8f5f-5ce6e4ddbef3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7f02c4f8-d1b8-41a6-aeac-87ab186817c8	5ec00000-0000-0000-0000-0000000000b2	42c98b5c-6c10-40af-a820-51de40a1a1d3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
7f62f68f-da0c-4d11-a299-ed4cdfaeb908	5ec00000-0000-0000-0000-0000000000b1	7d0f3624-7c4e-4abf-81a4-c3e26067e882	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8035714e-a544-4cd7-bb2d-3f9472776853	5ec00000-0000-0000-0000-0000000000b2	6ce02c50-59b4-428f-8e22-bb4f5af202ca	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
807bf231-1692-4589-a87e-fa52362a6516	5ec00000-0000-0000-0000-0000000000b6	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
80a69a6f-6049-47f5-a7ab-0787ca2ce174	5ec00000-0000-0000-0000-0000000000b1	1e772fe2-a8a0-480f-a012-064843dd672c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
81404994-c88f-4faf-a9e8-2375c6e3fe72	5ec00000-0000-0000-0000-0000000000b2	3f2ff6ad-d131-4eba-91c2-6a7c0f16cf98	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8150c470-5be1-4a9b-b8ea-cc25577eaa48	5ec00000-0000-0000-0000-0000000000b1	8d080dfa-ba69-44e8-80bc-5951641e24e6	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
81c1347a-35ed-4497-a7be-5f65b3037d19	5ec00000-0000-0000-0000-0000000000b1	424d95d8-c5bb-4451-a6c0-89097cbcdc79	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
82f40b26-149b-4cf7-9fa8-4b7182c84e0b	5ec00000-0000-0000-0000-0000000000b2	ba551bea-d661-4a65-94e8-9943084b1149	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
82ff8437-805d-4736-8854-a0b903a211f8	5ec00000-0000-0000-0000-0000000000b4	ca0227ae-f8ac-4b7d-ac5d-5c4a27ed25f9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
832141a1-adca-4c0e-9c8b-4551c0f37a1c	5ec00000-0000-0000-0000-0000000000b2	66646112-bc72-4765-8bd9-02f8e8b26c24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8420c259-d7ac-4559-826e-c9f2f27943d3	5ec00000-0000-0000-0000-0000000000b1	d7d1f06b-ab90-4b60-9adb-4b36c612c07e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
848d1dae-a510-45f0-80ca-83c6244f2106	5ec00000-0000-0000-0000-0000000000b2	efb9fde2-4262-417e-b9ec-91e3c56e317c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
84c60320-70ce-4788-8c54-1717378b0682	5ec00000-0000-0000-0000-0000000000b5	4d46697b-99b4-4a49-b748-1b5a736cc873	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8501d9ce-6dc4-4009-8d6c-45ea2e7b917c	5ec00000-0000-0000-0000-0000000000b2	5b5a81c4-bfb5-48b4-802a-cdad3c5bfb30	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8665864e-9d8d-4736-a639-9f79a6ce71a0	5ec00000-0000-0000-0000-0000000000b1	efb9fde2-4262-417e-b9ec-91e3c56e317c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
877de724-8a89-420b-9645-61d748c95535	5ec00000-0000-0000-0000-0000000000b3	d46c02c0-a6ca-4541-801f-82813316b670	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
87ec1975-3b96-42e1-8746-872b9cf4d7ae	5ec00000-0000-0000-0000-0000000000b2	a32f1d39-1f2b-4a2b-88af-c7d1a2a38163	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
886a2f77-2d5a-46bd-bde3-4ea7f4ae355f	5ec00000-0000-0000-0000-0000000000b2	c046ddac-0b5e-44f3-bb26-7c632680e592	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
88980fb3-64a8-4554-a455-f3c16eda7828	5ec00000-0000-0000-0000-0000000000b1	737c8fb7-1d64-4f00-b4df-170662ede199	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
88e24b3e-d1b0-406c-9b0c-b97bdfe9db55	5ec00000-0000-0000-0000-0000000000b2	240d1a90-b188-4f15-b51f-4cfb1dac3714	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
88f60bd4-984f-4462-a2a5-7ec378b44ad2	5ec00000-0000-0000-0000-0000000000b2	d2ea8320-cae2-4183-b46f-872cf98c795b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
891cd523-3e72-4a7a-b551-7f9bf2f7a7c0	5ec00000-0000-0000-0000-0000000000b3	c046ddac-0b5e-44f3-bb26-7c632680e592	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
89dfbf94-06dc-4291-a402-f84a83f9e7cf	5ec00000-0000-0000-0000-0000000000b3	d2cbc60c-5c26-4d4a-9795-eac279042f02	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8a1a471b-abc0-464b-8c5d-8154f0971b8a	5ec00000-0000-0000-0000-0000000000b4	90303088-a5a7-491a-9868-116cfe781d6f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8a418fc6-63f5-4d47-b137-485cc7e2dcef	5ec00000-0000-0000-0000-0000000000b1	b06eb3c6-9d31-454b-b752-207c223e57f3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8b11fd9b-2bc0-4cfa-b1de-51e66f6f0111	5ec00000-0000-0000-0000-0000000000b3	eaf16230-627d-412c-8260-ec62b2a7dd87	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8b36a140-19fb-48fd-b276-d9f399a54e97	5ec00000-0000-0000-0000-0000000000b1	038cd2c4-2f00-4ac8-9efd-2f3b6cd81568	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8be489e6-a273-440e-962e-5f15af0319c8	5ec00000-0000-0000-0000-0000000000b6	9d26e43e-15bb-4809-877a-7f5f21728965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8c6bdb64-9bc6-4ce4-bed1-545023c8e479	5ec00000-0000-0000-0000-0000000000b1	82cad8a4-c690-49e3-be6f-b81ba096377c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8cdcdb21-6c72-415b-9730-ffe670b82f09	5ec00000-0000-0000-0000-0000000000b2	ba2745c0-90c4-4ec3-b146-f04b9f9b194a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8d1bc70e-9cb1-4a12-bc05-01f640f5edd3	5ec00000-0000-0000-0000-0000000000b3	af1db18e-4787-45d7-a77f-3f674e2d361a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8d4f0529-407c-417f-9779-3aefdde6f299	5ec00000-0000-0000-0000-0000000000b5	d46c02c0-a6ca-4541-801f-82813316b670	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8da55665-0561-437d-83f3-97484c61e563	5ec00000-0000-0000-0000-0000000000b6	4c9a26ff-47c8-4813-81ce-d5a4a6e2ad36	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8db9bdb9-3e4c-4b6f-9ff7-e46c324220bb	5ec00000-0000-0000-0000-0000000000b3	e11bacc7-5e2a-4cfa-9c7d-e76fe2494516	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8e509677-8a71-4b52-8dcb-cb2f2d29727b	5ec00000-0000-0000-0000-0000000000b2	5e81644c-deb4-4c5e-a784-e788baba35d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
8e7b8964-0426-4e40-a09b-f9b59177932a	5ec00000-0000-0000-0000-0000000000b4	82cad8a4-c690-49e3-be6f-b81ba096377c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
902bb1b0-938f-465c-9f5d-07f0d7533907	5ec00000-0000-0000-0000-0000000000b1	9bb63f23-7ec1-4535-862c-ca156d041a35	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
911d82f2-1b81-4f0d-9ce0-e8b19c192ef0	5ec00000-0000-0000-0000-0000000000b1	66defff9-27f0-4204-93b0-596464fad852	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
918cefbe-a433-4bb9-b817-1d2387c3925f	5ec00000-0000-0000-0000-0000000000b1	ca0227ae-f8ac-4b7d-ac5d-5c4a27ed25f9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9281188a-c812-49d5-916f-6b2d5d3d5cb8	5ec00000-0000-0000-0000-0000000000b2	4a19076a-4258-4fb4-bd26-e88bdd99434d	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
92ccd465-3ad5-4d55-97a6-4f75571a1729	5ec00000-0000-0000-0000-0000000000b2	af1db18e-4787-45d7-a77f-3f674e2d361a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
92fd7c10-f0be-4160-bade-f8298d9f240c	5ec00000-0000-0000-0000-0000000000b2	242b9aa5-e492-4591-8ee0-480260f8da78	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9324becb-6ddb-4186-98d2-53cc5ebb4198	5ec00000-0000-0000-0000-0000000000b3	6f5eef87-d4e5-4e77-b2e8-f79f410d4ae7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
937fd109-71ec-41e5-8490-e7255d3ab289	5ec00000-0000-0000-0000-0000000000b1	3938ab1d-72da-4f28-9240-f94904f87d6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
941d445a-33ac-489e-bff8-ca42df6b31ba	5ec00000-0000-0000-0000-0000000000b1	90303088-a5a7-491a-9868-116cfe781d6f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
94e75bc7-02b1-4987-bbd9-4ad4d2d547c3	5ec00000-0000-0000-0000-0000000000b1	03578c22-9e58-4735-9e75-268e1a2ff7c5	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
955784f4-3950-4f26-bdb8-b6d810444567	5ec00000-0000-0000-0000-0000000000b3	93cc4166-7d28-44da-a91a-59068aa8909f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
95e08c45-6256-4809-962b-33e04cbe4564	5ec00000-0000-0000-0000-0000000000b2	4c9a26ff-47c8-4813-81ce-d5a4a6e2ad36	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
95fc1bff-16a7-4717-a247-b947b3b73a8f	5ec00000-0000-0000-0000-0000000000b4	30409657-7d57-4ba8-92c6-9101c6db673e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9621ebaf-524e-4967-888c-22307513db1f	5ec00000-0000-0000-0000-0000000000b3	7ef0d556-2e09-49c1-9727-7aa4534b4613	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
973ad98d-ba07-4333-9a1c-37b430dba2af	5ec00000-0000-0000-0000-0000000000b2	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
97c34417-754f-4358-bf9e-918e96bdb6b8	5ec00000-0000-0000-0000-0000000000b1	8770c19b-c0f8-4d5e-a084-324476d9dd25	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
98718633-8bf5-4e24-b0ac-8074832e22cc	5ec00000-0000-0000-0000-0000000000b3	3f2ff6ad-d131-4eba-91c2-6a7c0f16cf98	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
98ac6ba4-fef0-4f8a-8837-59c9eee019a3	5ec00000-0000-0000-0000-0000000000b4	ba2745c0-90c4-4ec3-b146-f04b9f9b194a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
99d54662-4931-42a1-9fc0-ba9300b3d261	5ec00000-0000-0000-0000-0000000000b2	83ccf1cc-9271-4aec-bd68-4c921f46b836	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9af8b2bb-dce6-4827-93f2-ecef10878808	5ec00000-0000-0000-0000-0000000000b2	64be26fa-e0b2-4195-b5e8-b72245252986	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9bbc03f5-bea8-4433-b10f-6cb0bf74ef9d	5ec00000-0000-0000-0000-0000000000b2	45413c76-0018-4ae8-9f8c-4cd34cebf09f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9d223397-b20e-43a7-8359-ca9d1051d836	5ec00000-0000-0000-0000-0000000000b1	45413c76-0018-4ae8-9f8c-4cd34cebf09f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9e509bbb-7ea1-45d6-92c1-3cc6af3a1913	5ec00000-0000-0000-0000-0000000000b1	e42c89d0-15fb-4e18-89cf-00707c374ac4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9ea1fe3c-a986-415d-b1b4-c1a70fb0ebaf	5ec00000-0000-0000-0000-0000000000b2	c7570d62-8e5b-49c2-8d1b-0c76b784bddd	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9f006660-9596-4632-83a8-a786afa2d9ce	5ec00000-0000-0000-0000-0000000000b1	a294d19c-5c42-4958-81ed-3cab314c6168	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
9f98fbb3-9218-463a-876c-6ecb7ba26a88	5ec00000-0000-0000-0000-0000000000b1	d5b1452c-6194-4aee-979b-6e7514ca7d82	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a01b266a-c77e-4aa9-938a-c32ed4c57cb0	5ec00000-0000-0000-0000-0000000000b1	2db83939-04ec-47c8-8c32-9394bed4d519	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a0cca4cb-de0b-4fc9-acde-ffe556352f77	5ec00000-0000-0000-0000-0000000000b3	a640f004-fe6e-41c3-870a-f7cb45b33e6c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a337c265-d73e-487f-86cf-00e90daf77ea	5ec00000-0000-0000-0000-0000000000b2	18356373-728e-47de-83ea-771a791a02fa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a491d757-3d6c-4433-92cd-9340aead5d78	5ec00000-0000-0000-0000-0000000000b2	737c8fb7-1d64-4f00-b4df-170662ede199	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a5e3ac90-9d1c-4178-bfb6-90fedd0c2de3	5ec00000-0000-0000-0000-0000000000b4	fa0116a7-8eea-417e-8a3b-2f980979b012	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a5f76315-bda6-4815-9320-a62f92114d85	5ec00000-0000-0000-0000-0000000000b6	6e854819-7ad4-429b-8ba1-182c86b404a9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a6a58fb0-3735-437d-8d9d-5588e8d60f24	5ec00000-0000-0000-0000-0000000000b6	24a9cce7-f9d8-459a-b6e5-513a8d899edc	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a6d4c22c-2129-4ecd-9b44-06933ec81912	5ec00000-0000-0000-0000-0000000000b1	473425b2-4dc0-42cd-a907-93f68e57e786	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a7c3c89c-d454-4934-9684-e461d9203fcc	5ec00000-0000-0000-0000-0000000000b6	93cc4166-7d28-44da-a91a-59068aa8909f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a8099beb-fc7f-44a3-89b4-09520b259a88	5ec00000-0000-0000-0000-0000000000b3	5109f564-c5f5-42a9-af4a-ed705b21a556	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a887ca3a-1e60-4ca3-ae50-07d5e23bf57a	5ec00000-0000-0000-0000-0000000000b4	d13a7025-0835-468f-8c09-51ac73dcdc39	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
a9694d6e-a3ab-46d0-a568-ffdb65b2c133	5ec00000-0000-0000-0000-0000000000b3	5d0aa2dd-6612-49d4-b435-5bf7745f479f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ab559552-d744-4d2c-ac84-780e7d54cc9c	5ec00000-0000-0000-0000-0000000000b2	99a41267-4872-41bc-b45d-6c5401e8a4fa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ac59cbd1-649e-418e-8ec0-caba2f08491c	5ec00000-0000-0000-0000-0000000000b3	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
acd2b918-fd4c-4dd7-b9d1-065ee6b9b1b0	5ec00000-0000-0000-0000-0000000000b3	e42c89d0-15fb-4e18-89cf-00707c374ac4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
af7f6fac-2771-4f31-9b14-b8bf057ad21a	5ec00000-0000-0000-0000-0000000000b1	5109f564-c5f5-42a9-af4a-ed705b21a556	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b00a1168-a0ef-4fe8-846b-4e181a15dfbd	5ec00000-0000-0000-0000-0000000000b2	8e0e58e6-a28f-4bd2-aa6e-674b77e4d626	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b110894e-b60f-4e53-be83-ce27238db1af	5ec00000-0000-0000-0000-0000000000b1	1b1eb079-2f0b-49d3-9efd-45560c3ed57c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b2010a2a-7cef-446a-802d-ad1611c9f258	5ec00000-0000-0000-0000-0000000000b3	9bb63f23-7ec1-4535-862c-ca156d041a35	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b3049a36-65fe-45dc-b6b8-43a31bed518d	5ec00000-0000-0000-0000-0000000000b1	74154d57-f8d8-4c2c-8af3-59911bcc09c3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b3eb394f-67cf-4cf2-b022-8ed7b2c532d2	5ec00000-0000-0000-0000-0000000000b3	aef75e72-fa40-4082-8e50-5dc7c1056515	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b42c24b0-3ea9-43b6-a55d-1e799da96856	5ec00000-0000-0000-0000-0000000000b2	d4c48d24-1b39-41da-ac7f-16868ba96817	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b4315767-47c7-4fba-b1a3-aa5ba0c40aa0	5ec00000-0000-0000-0000-0000000000b1	363e4291-aff5-46da-abfb-40a648fa2cad	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b483503f-4faa-4c6c-a51b-dbd87682dec5	5ec00000-0000-0000-0000-0000000000b2	b227e6e4-9eb9-4ef0-affc-e3e6da02e7e0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b4ec3ff0-d9ec-4e4c-a45e-d5b5820b59aa	5ec00000-0000-0000-0000-0000000000b6	b3a709b8-9408-4e81-a61c-e0d4418797d5	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b4f55f89-8d4b-4d8d-b6ff-bb444f5b0451	5ec00000-0000-0000-0000-0000000000b2	641bc5e8-62ae-4429-a66e-a8f5d36772b7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b528d817-53bd-4bb8-8353-72a3a48d6718	5ec00000-0000-0000-0000-0000000000b4	5038c88a-e24e-497b-8083-8211f72807e9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b5ef999e-f1b5-4c86-8d82-186fff1cac76	5ec00000-0000-0000-0000-0000000000b2	7d0f3624-7c4e-4abf-81a4-c3e26067e882	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b627cb23-e39e-4a40-94f9-1719c6d18a14	5ec00000-0000-0000-0000-0000000000b2	d5b1452c-6194-4aee-979b-6e7514ca7d82	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b638e908-3202-4c83-a02f-4ffc896ae623	5ec00000-0000-0000-0000-0000000000b2	1fe6303e-a663-4f0d-b9d7-e994f5b4b243	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b73a1633-e796-4a97-b165-cbb7da0768d7	5ec00000-0000-0000-0000-0000000000b2	0b94936b-4b43-4852-b02c-b027ab041cee	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b7c22b7a-7e7d-4a73-b742-bb6955e3c427	5ec00000-0000-0000-0000-0000000000b2	6e854819-7ad4-429b-8ba1-182c86b404a9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b8879dc8-4280-4a73-a192-691c47b591c4	5ec00000-0000-0000-0000-0000000000b3	49cf836f-d742-4ab2-8246-b1b8f36d139e	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b8be05ba-69ba-4ad7-9043-ab21d2217ba6	5ec00000-0000-0000-0000-0000000000b2	6f5eef87-d4e5-4e77-b2e8-f79f410d4ae7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b8ecbcf1-8786-4371-9a23-af0583971e85	5ec00000-0000-0000-0000-0000000000b5	66646112-bc72-4765-8bd9-02f8e8b26c24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
b987af36-39cf-4aff-87c4-3a153a840231	5ec00000-0000-0000-0000-0000000000b2	bbe3ba6c-d4e8-433b-a5eb-652e8c0d8106	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bb29f0e3-0e88-47c8-98ec-c5ceadc9e3fb	5ec00000-0000-0000-0000-0000000000b1	6f5eef87-d4e5-4e77-b2e8-f79f410d4ae7	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bbb4709f-4ed3-4fd9-a0a0-48a84393c4fb	5ec00000-0000-0000-0000-0000000000b1	da8bafc3-0886-4a1e-ba31-7a2d3ebc5a92	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bbc5c6a3-d68d-4633-bb11-43468cb4e180	5ec00000-0000-0000-0000-0000000000b1	b29c664b-bf00-4d24-b650-0f4e4ce5b693	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bc4f3cb4-5d76-4ff5-9ee1-2204e4b8fb9d	5ec00000-0000-0000-0000-0000000000b1	9dd1d042-a6f4-4098-b3de-38a028a670ce	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bc8ba061-80ba-4554-afc0-17531076bf65	5ec00000-0000-0000-0000-0000000000b4	a294d19c-5c42-4958-81ed-3cab314c6168	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bd78e31e-636b-4afd-9ad8-173f2acf9614	5ec00000-0000-0000-0000-0000000000b6	e7174897-b063-4044-a5c8-d0ead927e9c9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bda42a41-a3e0-4f6f-a1de-91eea2858e0b	5ec00000-0000-0000-0000-0000000000b1	18356373-728e-47de-83ea-771a791a02fa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bde46071-8fd5-4ff1-a4cd-5756aef47d54	5ec00000-0000-0000-0000-0000000000b1	4266b01f-5f3d-4987-aa14-ab072afa05ec	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
be3fff4e-74f6-4a73-816d-b33e668ec401	5ec00000-0000-0000-0000-0000000000b2	dee96473-57a3-48b4-8bce-6baf8f75cd99	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
bf111137-eb58-4a85-ae52-34683cfa1acf	5ec00000-0000-0000-0000-0000000000b2	5974aaf5-7647-4cd3-bc8c-9bbedc6e1a03	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c01bbadb-d821-4696-aa79-7eaeef3d75da	5ec00000-0000-0000-0000-0000000000b5	fa0116a7-8eea-417e-8a3b-2f980979b012	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c0a30da7-b78e-4551-b275-def692396ad5	5ec00000-0000-0000-0000-0000000000b3	99a41267-4872-41bc-b45d-6c5401e8a4fa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c16f925a-50cb-402d-a2bb-b5de10ad8680	5ec00000-0000-0000-0000-0000000000b3	4c8bdd44-c6bd-4a50-b72b-61cf2fbb7d60	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c34cbd4e-3f2b-4a13-b92d-b251098294e2	5ec00000-0000-0000-0000-0000000000b4	e42c89d0-15fb-4e18-89cf-00707c374ac4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c403cab6-4ec5-41fc-9425-153340ca80e8	5ec00000-0000-0000-0000-0000000000b2	4f1e4e86-df39-4f95-98df-aec50ddda1d4	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c4227d35-50ac-4d1e-95e8-096c5a38135f	5ec00000-0000-0000-0000-0000000000b1	b3a709b8-9408-4e81-a61c-e0d4418797d5	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c48dccf0-3949-4be0-a4bc-066ca207e0c2	5ec00000-0000-0000-0000-0000000000b6	ca0227ae-f8ac-4b7d-ac5d-5c4a27ed25f9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c5cdfc78-3d0d-4a7b-9720-df37a19a635b	5ec00000-0000-0000-0000-0000000000b2	949c0087-39fa-4953-b193-ed2cf93ddacb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
c8b61b5f-adf2-47c9-b23b-92d01a01d402	5ec00000-0000-0000-0000-0000000000b2	d269cd02-6338-4f2f-8e88-49fa38993d2b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
cab85062-032d-47bb-9086-0a5798fc8a76	5ec00000-0000-0000-0000-0000000000b1	d2ea8320-cae2-4183-b46f-872cf98c795b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
cc1aece7-a13e-4edc-965d-347de2d32e9b	5ec00000-0000-0000-0000-0000000000b1	242b9aa5-e492-4591-8ee0-480260f8da78	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
cd538f8b-d558-487f-852a-f8712537d224	5ec00000-0000-0000-0000-0000000000b1	272073ec-87f8-4133-8d6e-41198c03e269	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ce9a5fbd-8224-4cbb-8345-ea50c2a55f50	5ec00000-0000-0000-0000-0000000000b3	73be9ca0-df8b-4c1c-b552-eb84b1e88cda	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
cf65e263-369e-4086-a6e4-3773b6a79f64	5ec00000-0000-0000-0000-0000000000b4	2d000536-63c8-4d6e-aaaa-3e7857e74363	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
cff81cce-4b62-4602-ac4e-bd337221fad1	5ec00000-0000-0000-0000-0000000000b3	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d0185bff-f8dc-4c92-802d-09d2c7054171	5ec00000-0000-0000-0000-0000000000b2	1586687c-d061-426a-8256-76b191a4a15b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d0e8fe7c-4e01-452f-89fa-accad6799a43	5ec00000-0000-0000-0000-0000000000b1	7ef0d556-2e09-49c1-9727-7aa4534b4613	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d1b710ad-fd3f-4ab6-a299-3a04a5e265ac	5ec00000-0000-0000-0000-0000000000b6	82cad8a4-c690-49e3-be6f-b81ba096377c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d2361f50-8ff5-438c-ba54-bce5a547da08	5ec00000-0000-0000-0000-0000000000b5	5f7573f1-de2a-4f3f-82de-6abdaf9d4b42	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d2d114cd-d7d6-4e6b-bd79-634a60ea376f	5ec00000-0000-0000-0000-0000000000b4	8e0e58e6-a28f-4bd2-aa6e-674b77e4d626	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d349e16c-c571-44fa-ae4d-c39bb0278cf3	5ec00000-0000-0000-0000-0000000000b1	53c15e8b-dede-433a-983e-222a8b49ca24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d49ba3d7-f0e2-4c06-b3ea-2d915c7fd5dc	5ec00000-0000-0000-0000-0000000000b1	d4c48d24-1b39-41da-ac7f-16868ba96817	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d4d14ac9-9490-4283-ad11-2ca5f84fb5db	5ec00000-0000-0000-0000-0000000000b1	788aabb3-4687-4af6-bb0a-2e84b42b8983	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d4fc5250-f7f1-43fb-9efe-336151c4b3d2	5ec00000-0000-0000-0000-0000000000b1	5974aaf5-7647-4cd3-bc8c-9bbedc6e1a03	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d51a20bc-87ad-45b7-b485-b99cfd53d21c	5ec00000-0000-0000-0000-0000000000b1	5038c88a-e24e-497b-8083-8211f72807e9	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d5a9facf-24e1-41f1-8e53-4b954662001c	5ec00000-0000-0000-0000-0000000000b2	d13a7025-0835-468f-8c09-51ac73dcdc39	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d728fce4-393c-44ca-bea7-2d90c3314524	5ec00000-0000-0000-0000-0000000000b1	66646112-bc72-4765-8bd9-02f8e8b26c24	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d7cc5922-b5ba-455f-9883-3e97b165fb94	5ec00000-0000-0000-0000-0000000000b5	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d8209612-384a-463e-b4ba-745526783a4c	5ec00000-0000-0000-0000-0000000000b4	473425b2-4dc0-42cd-a907-93f68e57e786	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d9bb7de1-6273-42f6-bf64-ffcd641638cd	5ec00000-0000-0000-0000-0000000000b1	e11bacc7-5e2a-4cfa-9c7d-e76fe2494516	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
d9c1e4b3-cd82-48d0-9f3e-7c2f9c5af8f4	5ec00000-0000-0000-0000-0000000000b1	6ed84722-ae18-45fa-b772-fe8519fbb217	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
da55f663-ed03-46c7-bd9f-527fd2429d54	5ec00000-0000-0000-0000-0000000000b1	83ccf1cc-9271-4aec-bd68-4c921f46b836	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
da67ae50-b587-4789-ac48-00a6125c164a	5ec00000-0000-0000-0000-0000000000b2	aba8f6f5-f78f-44a5-bf77-6602644f54e3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
da9158dd-052f-4dd0-b10d-cb8408b6db12	5ec00000-0000-0000-0000-0000000000b6	b06eb3c6-9d31-454b-b752-207c223e57f3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
dad0dc1c-1ee5-4eb3-a26b-6ed42d93720a	5ec00000-0000-0000-0000-0000000000b1	03eab55c-1fdd-475b-9cfc-78efb2bf3e7b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
db4a6d32-20c4-4d65-95ee-a1a0478bb796	5ec00000-0000-0000-0000-0000000000b3	3570c1b3-fb0e-478d-ab47-157e31e71831	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
dc363dcf-7c8d-47cb-847a-8a051eb040da	5ec00000-0000-0000-0000-0000000000b1	e0a10e30-b6de-4af2-9845-f67e18b81c7b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
de09e9bc-595d-4475-a53e-e94fb4a8c250	5ec00000-0000-0000-0000-0000000000b6	7afeab50-dff4-42ec-8770-169ec08fd4aa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
de95052a-288c-4588-84b8-6f7b02b91c25	5ec00000-0000-0000-0000-0000000000b4	83eb6243-bc73-4ff2-a532-b70e254b865c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
df7d5a6c-0887-41ba-bddc-d6efe29eb895	5ec00000-0000-0000-0000-0000000000b1	e60f7cfd-02e6-45e0-8b15-7c82e59df2fb	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e01dc2ca-6d01-4654-ba4a-4996d6e4afef	5ec00000-0000-0000-0000-0000000000b2	5109f564-c5f5-42a9-af4a-ed705b21a556	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e066eb60-ae47-4f97-9df5-6ff9a8fdc6c0	5ec00000-0000-0000-0000-0000000000b1	83eb6243-bc73-4ff2-a532-b70e254b865c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e0d3c512-1b85-489c-80c6-eb60be38df0e	5ec00000-0000-0000-0000-0000000000b3	83ccf1cc-9271-4aec-bd68-4c921f46b836	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e1243bf8-9438-4446-b1b3-9a0981e2eb25	5ec00000-0000-0000-0000-0000000000b3	ba2745c0-90c4-4ec3-b146-f04b9f9b194a	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e3273001-032b-4dd3-bb7c-a130799a1e48	5ec00000-0000-0000-0000-0000000000b5	207345e6-e3b8-495a-9378-ab5ef04545ac	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e36f5e5b-804d-41eb-bd19-a1461f7d59c3	5ec00000-0000-0000-0000-0000000000b3	8645587f-82d9-4caf-9865-06dce9e32c15	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e45959fb-6559-4887-91e4-8c2dc35ffe3b	5ec00000-0000-0000-0000-0000000000b5	83eb6243-bc73-4ff2-a532-b70e254b865c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e736c539-1c65-4e5b-8d93-664d6b8deaec	5ec00000-0000-0000-0000-0000000000b1	814f27cc-ba77-4405-855b-a6769bf3353f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e8d8c696-15d9-4266-ab36-85190ad7fcc1	5ec00000-0000-0000-0000-0000000000b1	aef75e72-fa40-4082-8e50-5dc7c1056515	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e8e3f302-8384-44fd-bb17-5bad19dad723	5ec00000-0000-0000-0000-0000000000b2	66defff9-27f0-4204-93b0-596464fad852	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e8f68c08-dd18-47e8-9d33-2626d0928e40	5ec00000-0000-0000-0000-0000000000b1	4732d4c6-491d-44dc-9494-81035a4c5b6b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e91d615f-d9c1-40f3-82fe-1820b3a2ebbd	5ec00000-0000-0000-0000-0000000000b2	556d8b0c-e252-4960-8d78-09dba0cee965	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
e983d942-5489-4db3-b827-1d039f7df529	5ec00000-0000-0000-0000-0000000000b3	ec961700-c0a8-472b-8793-2676794c2cea	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
eaac9ba5-1b49-4a09-80d1-48abb8eba1c2	5ec00000-0000-0000-0000-0000000000b4	1b1eb079-2f0b-49d3-9efd-45560c3ed57c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
eb60e80d-bcb2-4634-869f-e75f578caf79	5ec00000-0000-0000-0000-0000000000b6	66defff9-27f0-4204-93b0-596464fad852	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ecbfa466-fdd7-4e30-a5c0-181b233a9456	5ec00000-0000-0000-0000-0000000000b1	ec961700-c0a8-472b-8793-2676794c2cea	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
eceb65e1-8f2b-4e46-95b7-de97ad92cbc9	5ec00000-0000-0000-0000-0000000000b2	7ef0d556-2e09-49c1-9727-7aa4534b4613	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ed0b8591-1a13-4ab2-b286-b9d5e9eba216	5ec00000-0000-0000-0000-0000000000b2	5f7573f1-de2a-4f3f-82de-6abdaf9d4b42	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ee1f2abb-d766-4b6d-8e0f-4db672038847	5ec00000-0000-0000-0000-0000000000b1	7afeab50-dff4-42ec-8770-169ec08fd4aa	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ef5dd551-21b7-4619-ac37-81f00bca18e6	5ec00000-0000-0000-0000-0000000000b1	138465c7-6db9-43a4-95b3-dba5806c8bf3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f1ab6efb-3d12-4946-bbeb-5c349ae19ee3	5ec00000-0000-0000-0000-0000000000b2	ec961700-c0a8-472b-8793-2676794c2cea	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f1b26079-0046-42a7-a79e-e09674d9d165	5ec00000-0000-0000-0000-0000000000b6	90303088-a5a7-491a-9868-116cfe781d6f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f1d5af05-757e-45f5-ae73-4432d06512e3	5ec00000-0000-0000-0000-0000000000b1	4a19076a-4258-4fb4-bd26-e88bdd99434d	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f2fa5ff6-acc3-4aee-8e13-7b0b8c0765d2	5ec00000-0000-0000-0000-0000000000b1	ff5d97ba-c9a0-41b0-af20-db6b6a19167f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f4175bb2-7031-4235-b7f8-b7a66870739b	5ec00000-0000-0000-0000-0000000000b1	42c98b5c-6c10-40af-a820-51de40a1a1d3	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f53d3c37-9856-45b5-a6fb-31d14a20a22b	5ec00000-0000-0000-0000-0000000000b3	5e81644c-deb4-4c5e-a784-e788baba35d0	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f79ea536-36cb-4bea-809a-81f9e94dc38c	5ec00000-0000-0000-0000-0000000000b2	c9cbcfda-7ede-466b-b5f5-91a9df56118c	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f8712278-36da-4f67-bc0c-24fd270d677a	5ec00000-0000-0000-0000-0000000000b1	9c3028dd-27da-498a-8e92-6acc3e7fdcba	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f8d7aa29-47cc-4605-aadd-f046de1b15a6	5ec00000-0000-0000-0000-0000000000b2	9bb63f23-7ec1-4535-862c-ca156d041a35	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f980e22c-ce37-41b1-ab08-df7806c1e0a0	5ec00000-0000-0000-0000-0000000000b2	c3c08a31-bc32-4485-b406-4b02da66a689	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f996aa96-d8e1-4f87-807a-5a4de6662507	5ec00000-0000-0000-0000-0000000000b1	d269cd02-6338-4f2f-8e88-49fa38993d2b	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
f9ee3a52-44b0-4175-9b9b-77423fdb31f4	5ec00000-0000-0000-0000-0000000000b3	5b5a81c4-bfb5-48b4-802a-cdad3c5bfb30	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
fb16ef3b-e3e3-4b20-a354-84b44d2f38ea	5ec00000-0000-0000-0000-0000000000b1	b0f10564-620c-411e-b4b3-c77794f15848	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
fda8f530-d86f-4a46-b4b0-83a48524f692	5ec00000-0000-0000-0000-0000000000b3	6ce02c50-59b4-428f-8e22-bb4f5af202ca	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
fdbadc33-a2e8-437f-994d-f5f9ea80e389	5ec00000-0000-0000-0000-0000000000b1	73be9ca0-df8b-4c1c-b552-eb84b1e88cda	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
fe0ccc86-dc01-48d2-aa1a-cc3f992a8df1	5ec00000-0000-0000-0000-0000000000b1	4d46697b-99b4-4a49-b748-1b5a736cc873	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
feb9aee1-a28f-41d4-86f9-3a3cea6829b4	5ec00000-0000-0000-0000-0000000000b1	23e69ef9-d63b-4160-95d0-b2cb03a4028d	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
ff762eff-1dba-4438-95e1-bc6561ca14cc	5ec00000-0000-0000-0000-0000000000b1	b8b6abb1-70b2-4b95-86b8-10c6d923e65f	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.68087
\.


--
-- Data for Name: sys_role_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_role_right (id, role_id, right_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
\.


--
-- Data for Name: sys_row_level_right; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_row_level_right (id, profile_id, main_entity_name, entity_name, access_type, record_state, modified_by, modified_on, created_by, created_on, caption) FROM stdin;
\.


--
-- Data for Name: sys_row_level_security_object; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_row_level_security_object (id, row_level_right_id, entity_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
\.


--
-- Data for Name: sys_user_default_value; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_user_default_value (id, entity_name, user_id, value_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
\.


--
-- Data for Name: sys_user_profile; Type: TABLE DATA; Schema: public; Owner: lab_migrator
--

COPY public.sys_user_profile (id, user_id, profile_id, record_state, modified_by, modified_on, created_by, created_on) FROM stdin;
5ec00000-0000-0000-0000-0000000000a1	0e000000-0000-0000-0000-000000000001	5ec00000-0000-0000-0000-000000000001	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-18 23:57:14.255423
5ec00000-0000-0000-0000-0000000000a2	0e000000-0000-0000-0000-000000000002	5ec00000-0000-0000-0000-000000000002	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.781558
5ec00000-0000-0000-0000-0000000000a3	0e000000-0000-0000-0000-000000000003	5ec00000-0000-0000-0000-000000000003	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.781558
5ec00000-0000-0000-0000-0000000000a4	0e000000-0000-0000-0000-000000000004	5ec00000-0000-0000-0000-000000000004	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.781558
5ec00000-0000-0000-0000-0000000000a5	0e000000-0000-0000-0000-000000000005	5ec00000-0000-0000-0000-000000000005	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.781558
5ec00000-0000-0000-0000-0000000000a6	0e000000-0000-0000-0000-000000000006	5ec00000-0000-0000-0000-000000000006	2	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2026-10-26 11:52:43.781558
\.


--
-- Data for Name: tn_division; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.tn_division (id, tenant_id, code, name, type, address, is_active, phone, department_type_id, created_on, created_by, modified_on, modified_by, record_state) FROM stdin;
d0000000-0000-0000-0000-000000000002	d0000000-0000-0000-0000-000000000001	MAIN	Основна лабораторія	Laboratory	\N	t	\N	e1434f29-c0a5-4d7c-9c00-e4c890b4040f	2026-10-27 19:30:42.309041	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0d000000-0000-0000-0000-000000000001	d0000000-0000-0000-0000-000000000001	LAB-MAIN	Центральна лабораторія	laboratory	м. Київ, вул. Тестова, 1	t	\N	e1434f29-c0a5-4d7c-9c00-e4c890b4040f	2026-10-27 19:30:42.309041	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
0d000000-0000-0000-0000-000000000002	d0000000-0000-0000-0000-000000000001	CP-1	Пункт забору №1	collection_point	м. Київ, вул. Тестова, 5	t	\N	e1434f29-c0a5-4d7c-9c00-e4c890b4040f	2026-10-27 19:30:42.309041	00000000-0000-0000-0000-000000000000	\N	00000000-0000-0000-0000-000000000000	2
\.


--
-- Data for Name: tn_requisites; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.tn_requisites (tenant_id, legal_name, edrpou, address, phone, email, license_number, logo_url) FROM stdin;
d0000000-0000-0000-0000-000000000001	Клініко-діагностична лабораторія MedLink (mock)	00000000	м. Київ, вул. Тестова, 1	+380441000000	lab@example.com	MOCK-LICENSE-001	\N
\.


--
-- Data for Name: tn_sequence; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.tn_sequence (tenant_id, key, scope_key, value) FROM stdin;
d0000000-0000-0000-0000-000000000001	lab_tube_barcode_ean8	ALL	4800
\.


--
-- Data for Name: tn_settings; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.tn_settings (tenant_id, date_format, decimal_separator, default_form_language, status_color_markers, criticality_color_markers) FROM stdin;
d0000000-0000-0000-0000-000000000001	\N	\N	uk	\N	\N
\.


--
-- Data for Name: tn_tenant; Type: TABLE DATA; Schema: public; Owner: lis
--

COPY public.tn_tenant (id, name, type, time_zone, created_at) FROM stdin;
d0000000-0000-0000-0000-000000000001	Demo Lab	Laboratory	Europe/Kyiv	2026-10-25 23:34:15.802814+00
\.


--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.aggregatedcounter_id_seq', 1, false);


--
-- Name: counter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.counter_id_seq', 1, false);


--
-- Name: hash_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.hash_id_seq', 1, false);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.job_id_seq', 1, false);


--
-- Name: jobparameter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.jobparameter_id_seq', 1, false);


--
-- Name: jobqueue_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.jobqueue_id_seq', 1, false);


--
-- Name: list_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.list_id_seq', 1, false);


--
-- Name: set_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.set_id_seq', 1, false);


--
-- Name: state_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: lis_app
--

SELECT pg_catalog.setval('hangfire.state_id_seq', 1, false);


--
-- Name: aggregatedcounter aggregatedcounter_key_key; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.aggregatedcounter
    ADD CONSTRAINT aggregatedcounter_key_key UNIQUE (key);


--
-- Name: aggregatedcounter aggregatedcounter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.aggregatedcounter
    ADD CONSTRAINT aggregatedcounter_pkey PRIMARY KEY (id);


--
-- Name: counter counter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (id);


--
-- Name: hash hash_key_field_key; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.hash
    ADD CONSTRAINT hash_key_field_key UNIQUE (key, field);


--
-- Name: hash hash_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.hash
    ADD CONSTRAINT hash_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: jobparameter jobparameter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.jobparameter
    ADD CONSTRAINT jobparameter_pkey PRIMARY KEY (id);


--
-- Name: jobqueue jobqueue_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.jobqueue
    ADD CONSTRAINT jobqueue_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: lock lock_resource_key; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.lock
    ADD CONSTRAINT lock_resource_key UNIQUE (resource);

ALTER TABLE ONLY hangfire.lock REPLICA IDENTITY USING INDEX lock_resource_key;


--
-- Name: schema schema_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.schema
    ADD CONSTRAINT schema_pkey PRIMARY KEY (version);


--
-- Name: server server_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.server
    ADD CONSTRAINT server_pkey PRIMARY KEY (id);


--
-- Name: set set_key_value_key; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.set
    ADD CONSTRAINT set_key_value_key UNIQUE (key, value);


--
-- Name: set set_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.set
    ADD CONSTRAINT set_pkey PRIMARY KEY (id);


--
-- Name: state state_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (id);


--
-- Name: sys_row_level_right ak_sys_row_level_right_profile_id_entity_name_main_entity_name; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_row_level_right
    ADD CONSTRAINT ak_sys_row_level_right_profile_id_entity_name_main_entity_name UNIQUE (profile_id, entity_name, main_entity_name);


--
-- Name: sys_user_default_value ak_sys_user_default_value_user_id_entity_name; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_user_default_value
    ADD CONSTRAINT ak_sys_user_default_value_user_id_entity_name UNIQUE (user_id, entity_name);


--
-- Name: aud_event pk_aud_event; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.aud_event
    ADD CONSTRAINT pk_aud_event PRIMARY KEY (id);


--
-- Name: cmn_enum_record pk_cmn_enum_record; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.cmn_enum_record
    ADD CONSTRAINT pk_cmn_enum_record PRIMARY KEY (id);


--
-- Name: cmn_person pk_cmn_person; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.cmn_person
    ADD CONSTRAINT pk_cmn_person PRIMARY KEY (id);


--
-- Name: ehd_dictionary pk_ehd_dictionary; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehd_dictionary
    ADD CONSTRAINT pk_ehd_dictionary PRIMARY KEY (id);


--
-- Name: ehe_incoming_medical_referral pk_ehe_incoming_medical_referral; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_incoming_medical_referral
    ADD CONSTRAINT pk_ehe_incoming_medical_referral PRIMARY KEY (id);


--
-- Name: ehe_medical_referral_category pk_ehe_medical_referral_category; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_medical_referral_category
    ADD CONSTRAINT pk_ehe_medical_referral_category PRIMARY KEY (id);


--
-- Name: ehe_medical_service_program pk_ehe_medical_service_program; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_medical_service_program
    ADD CONSTRAINT pk_ehe_medical_service_program PRIMARY KEY (id);


--
-- Name: ehe_paper_medical_referral pk_ehe_paper_medical_referral; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_paper_medical_referral
    ADD CONSTRAINT pk_ehe_paper_medical_referral PRIMARY KEY (id);


--
-- Name: ehe_service_catalog_service pk_ehe_service_catalog_service; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_service_catalog_service
    ADD CONSTRAINT pk_ehe_service_catalog_service PRIMARY KEY (id);


--
-- Name: id_device_token pk_id_device_token; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_device_token
    ADD CONSTRAINT pk_id_device_token PRIMARY KEY (id);


--
-- Name: id_invitation pk_id_invitation; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_invitation
    ADD CONSTRAINT pk_id_invitation PRIMARY KEY (id);


--
-- Name: id_membership pk_id_membership; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership
    ADD CONSTRAINT pk_id_membership PRIMARY KEY (id);


--
-- Name: id_membership_division pk_id_membership_division; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership_division
    ADD CONSTRAINT pk_id_membership_division PRIMARY KEY (membership_id, division_id);


--
-- Name: id_membership_role pk_id_membership_role; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership_role
    ADD CONSTRAINT pk_id_membership_role PRIMARY KEY (id);


--
-- Name: id_permission pk_id_permission; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_permission
    ADD CONSTRAINT pk_id_permission PRIMARY KEY (code);


--
-- Name: id_role pk_id_role; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_role
    ADD CONSTRAINT pk_id_role PRIMARY KEY (id);


--
-- Name: id_role_permission pk_id_role_permission; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_role_permission
    ADD CONSTRAINT pk_id_role_permission PRIMARY KEY (role_id, permission);


--
-- Name: id_user pk_id_user; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_user
    ADD CONSTRAINT pk_id_user PRIMARY KEY (id);


--
-- Name: ins_gateway pk_ins_gateway; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ins_gateway
    ADD CONSTRAINT pk_ins_gateway PRIMARY KEY (id);


--
-- Name: int_api_key pk_int_api_key; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.int_api_key
    ADD CONSTRAINT pk_int_api_key PRIMARY KEY (id);


--
-- Name: int_client pk_int_client; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.int_client
    ADD CONSTRAINT pk_int_client PRIMARY KEY (id);


--
-- Name: lab_analyzer pk_lab_analyzer; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer
    ADD CONSTRAINT pk_lab_analyzer PRIMARY KEY (id);


--
-- Name: lab_analyzer_lockout pk_lab_analyzer_lockout; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_lockout
    ADD CONSTRAINT pk_lab_analyzer_lockout PRIMARY KEY (id);


--
-- Name: lab_analyzer_message pk_lab_analyzer_message; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_message
    ADD CONSTRAINT pk_lab_analyzer_message PRIMARY KEY (id);


--
-- Name: lab_analyzer_parameter_map pk_lab_analyzer_parameter_map; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_parameter_map
    ADD CONSTRAINT pk_lab_analyzer_parameter_map PRIMARY KEY (id);


--
-- Name: lab_analyzer_type pk_lab_analyzer_type; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_type
    ADD CONSTRAINT pk_lab_analyzer_type PRIMARY KEY (id);


--
-- Name: lab_antibiotic pk_lab_antibiotic; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_antibiotic
    ADD CONSTRAINT pk_lab_antibiotic PRIMARY KEY (id);


--
-- Name: lab_archive_cell pk_lab_archive_cell; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_archive_cell
    ADD CONSTRAINT pk_lab_archive_cell PRIMARY KEY (id);


--
-- Name: lab_archive_rack pk_lab_archive_rack; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_archive_rack
    ADD CONSTRAINT pk_lab_archive_rack PRIMARY KEY (id);


--
-- Name: lab_audit_log pk_lab_audit_log; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_audit_log
    ADD CONSTRAINT pk_lab_audit_log PRIMARY KEY (id);


--
-- Name: lab_biomaterial_type pk_lab_biomaterial_type; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_biomaterial_type
    ADD CONSTRAINT pk_lab_biomaterial_type PRIMARY KEY (id);


--
-- Name: lab_connector_command pk_lab_connector_command; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_connector_command
    ADD CONSTRAINT pk_lab_connector_command PRIMARY KEY (id);


--
-- Name: lab_connector_installation pk_lab_connector_installation; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_connector_installation
    ADD CONSTRAINT pk_lab_connector_installation PRIMARY KEY (id);


--
-- Name: lab_connector_log pk_lab_connector_log; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_connector_log
    ADD CONSTRAINT pk_lab_connector_log PRIMARY KEY (id);


--
-- Name: lab_culture_order pk_lab_culture_order; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_culture_order
    ADD CONSTRAINT pk_lab_culture_order PRIMARY KEY (id);


--
-- Name: lab_ehealth_exchange_log pk_lab_ehealth_exchange_log; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_ehealth_exchange_log
    ADD CONSTRAINT pk_lab_ehealth_exchange_log PRIMARY KEY (id);


--
-- Name: lab_employee_settings pk_lab_employee_settings; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_employee_settings
    ADD CONSTRAINT pk_lab_employee_settings PRIMARY KEY (employee_id);


--
-- Name: lab_eucast_breakpoint pk_lab_eucast_breakpoint; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_eucast_breakpoint
    ADD CONSTRAINT pk_lab_eucast_breakpoint PRIMARY KEY (id);


--
-- Name: lab_invoice pk_lab_invoice; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_invoice
    ADD CONSTRAINT pk_lab_invoice PRIMARY KEY (id);


--
-- Name: lab_isolate pk_lab_isolate; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_isolate
    ADD CONSTRAINT pk_lab_isolate PRIMARY KEY (id);


--
-- Name: lab_method_type pk_lab_method_type; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_method_type
    ADD CONSTRAINT pk_lab_method_type PRIMARY KEY (id);


--
-- Name: lab_micro_organism pk_lab_micro_organism; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_micro_organism
    ADD CONSTRAINT pk_lab_micro_organism PRIMARY KEY (id);


--
-- Name: lab_numerator pk_lab_numerator; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_numerator
    ADD CONSTRAINT pk_lab_numerator PRIMARY KEY (tenant_id, code);


--
-- Name: lab_order pk_lab_order; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT pk_lab_order PRIMARY KEY (id);


--
-- Name: lab_order_attachment pk_lab_order_attachment; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_attachment
    ADD CONSTRAINT pk_lab_order_attachment PRIMARY KEY (id);


--
-- Name: lab_order_charge pk_lab_order_charge; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_charge
    ADD CONSTRAINT pk_lab_order_charge PRIMARY KEY (id);


--
-- Name: lab_order_favorite pk_lab_order_favorite; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_favorite
    ADD CONSTRAINT pk_lab_order_favorite PRIMARY KEY (id);


--
-- Name: lab_order_sample pk_lab_order_sample; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT pk_lab_order_sample PRIMARY KEY (id);


--
-- Name: lab_order_test pk_lab_order_test; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT pk_lab_order_test PRIMARY KEY (id);


--
-- Name: lab_panic_call pk_lab_panic_call; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_panic_call
    ADD CONSTRAINT pk_lab_panic_call PRIMARY KEY (id);


--
-- Name: lab_patient_notification pk_lab_patient_notification; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_patient_notification
    ADD CONSTRAINT pk_lab_patient_notification PRIMARY KEY (id);


--
-- Name: lab_payer pk_lab_payer; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_payer
    ADD CONSTRAINT pk_lab_payer PRIMARY KEY (id);


--
-- Name: lab_payment pk_lab_payment; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_payment
    ADD CONSTRAINT pk_lab_payment PRIMARY KEY (id);


--
-- Name: lab_performer pk_lab_performer; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_performer
    ADD CONSTRAINT pk_lab_performer PRIMARY KEY (id);


--
-- Name: lab_performer_test pk_lab_performer_test; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_performer_test
    ADD CONSTRAINT pk_lab_performer_test PRIMARY KEY (id);


--
-- Name: lab_price_list pk_lab_price_list; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_price_list
    ADD CONSTRAINT pk_lab_price_list PRIMARY KEY (id);


--
-- Name: lab_price_list_item pk_lab_price_list_item; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_price_list_item
    ADD CONSTRAINT pk_lab_price_list_item PRIMARY KEY (id);


--
-- Name: lab_price_package pk_lab_price_package; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_price_package
    ADD CONSTRAINT pk_lab_price_package PRIMARY KEY (id);


--
-- Name: lab_qc_material pk_lab_qc_material; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_material
    ADD CONSTRAINT pk_lab_qc_material PRIMARY KEY (id);


--
-- Name: lab_qc_result pk_lab_qc_result; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_result
    ADD CONSTRAINT pk_lab_qc_result PRIMARY KEY (id);


--
-- Name: lab_qc_target pk_lab_qc_target; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_target
    ADD CONSTRAINT pk_lab_qc_target PRIMARY KEY (id);


--
-- Name: lab_reagent_lot pk_lab_reagent_lot; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_reagent_lot
    ADD CONSTRAINT pk_lab_reagent_lot PRIMARY KEY (id);


--
-- Name: lab_reference_layer pk_lab_reference_layer; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_reference_layer
    ADD CONSTRAINT pk_lab_reference_layer PRIMARY KEY (id);


--
-- Name: lab_reflex_rule pk_lab_reflex_rule; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_reflex_rule
    ADD CONSTRAINT pk_lab_reflex_rule PRIMARY KEY (id);


--
-- Name: lab_result_history pk_lab_result_history; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_result_history
    ADD CONSTRAINT pk_lab_result_history PRIMARY KEY (id);


--
-- Name: lab_sample_logistics pk_lab_sample_logistics; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics
    ADD CONSTRAINT pk_lab_sample_logistics PRIMARY KEY (id);


--
-- Name: lab_sample_logistics_item pk_lab_sample_logistics_item; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics_item
    ADD CONSTRAINT pk_lab_sample_logistics_item PRIMARY KEY (id);


--
-- Name: lab_sample_stage_event pk_lab_sample_stage_event; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_stage_event
    ADD CONSTRAINT pk_lab_sample_stage_event PRIMARY KEY (id);


--
-- Name: lab_section pk_lab_section; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section
    ADD CONSTRAINT pk_lab_section PRIMARY KEY (id);


--
-- Name: lab_section_journal_entry pk_lab_section_journal_entry; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section_journal_entry
    ADD CONSTRAINT pk_lab_section_journal_entry PRIMARY KEY (id);


--
-- Name: lab_send_out pk_lab_send_out; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out
    ADD CONSTRAINT pk_lab_send_out PRIMARY KEY (id);


--
-- Name: lab_send_out_item pk_lab_send_out_item; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out_item
    ADD CONSTRAINT pk_lab_send_out_item PRIMARY KEY (id);


--
-- Name: lab_settings pk_lab_settings; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_settings
    ADD CONSTRAINT pk_lab_settings PRIMARY KEY (id);


--
-- Name: lab_susceptibility_result pk_lab_susceptibility_result; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_susceptibility_result
    ADD CONSTRAINT pk_lab_susceptibility_result PRIMARY KEY (id);


--
-- Name: lab_test_definition pk_lab_test_definition; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_definition
    ADD CONSTRAINT pk_lab_test_definition PRIMARY KEY (id);


--
-- Name: lab_test_profile pk_lab_test_profile; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile
    ADD CONSTRAINT pk_lab_test_profile PRIMARY KEY (id);


--
-- Name: lab_test_profile_item pk_lab_test_profile_item; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile_item
    ADD CONSTRAINT pk_lab_test_profile_item PRIMARY KEY (id);


--
-- Name: lab_test_result pk_lab_test_result; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_result
    ADD CONSTRAINT pk_lab_test_result PRIMARY KEY (id);


--
-- Name: lab_tube_type pk_lab_tube_type; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_tube_type
    ADD CONSTRAINT pk_lab_tube_type PRIMARY KEY (id);


--
-- Name: lab_unmatched_result pk_lab_unmatched_result; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_unmatched_result
    ADD CONSTRAINT pk_lab_unmatched_result PRIMARY KEY (id);


--
-- Name: lab_workflow_template pk_lab_workflow_template; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_workflow_template
    ADD CONSTRAINT pk_lab_workflow_template PRIMARY KEY (tenant_id, code);


--
-- Name: lab_worklist_batch pk_lab_worklist_batch; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_worklist_batch
    ADD CONSTRAINT pk_lab_worklist_batch PRIMARY KEY (id);


--
-- Name: mis_diagnostic_report pk_mis_diagnostic_report; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.mis_diagnostic_report
    ADD CONSTRAINT pk_mis_diagnostic_report PRIMARY KEY (id);


--
-- Name: mis_patient_insurance pk_mis_patient_insurance; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.mis_patient_insurance
    ADD CONSTRAINT pk_mis_patient_insurance PRIMARY KEY (id);


--
-- Name: ord_order_identifier pk_ord_order_identifier; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_order_identifier
    ADD CONSTRAINT pk_ord_order_identifier PRIMARY KEY (id);


--
-- Name: ord_patient pk_ord_patient; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ord_patient
    ADD CONSTRAINT pk_ord_patient PRIMARY KEY (id);


--
-- Name: ord_patient_identifier pk_ord_patient_identifier; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_identifier
    ADD CONSTRAINT pk_ord_patient_identifier PRIMARY KEY (id);


--
-- Name: ord_patient_insurance pk_ord_patient_insurance; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_insurance
    ADD CONSTRAINT pk_ord_patient_insurance PRIMARY KEY (id);


--
-- Name: ord_requester pk_ord_requester; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_requester
    ADD CONSTRAINT pk_ord_requester PRIMARY KEY (id);


--
-- Name: org_employee pk_org_employee; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_employee
    ADD CONSTRAINT pk_org_employee PRIMARY KEY (id);


--
-- Name: org_organization_service pk_org_organization_service; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_organization_service
    ADD CONSTRAINT pk_org_organization_service PRIMARY KEY (id);


--
-- Name: sys_application_row_level_right pk_sys_application_row_level_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_application_row_level_right
    ADD CONSTRAINT pk_sys_application_row_level_right PRIMARY KEY (id);


--
-- Name: sys_field_right pk_sys_field_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_field_right
    ADD CONSTRAINT pk_sys_field_right PRIMARY KEY (id);


--
-- Name: sys_operation_right pk_sys_operation_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_operation_right
    ADD CONSTRAINT pk_sys_operation_right PRIMARY KEY (id);


--
-- Name: sys_profile pk_sys_profile; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile
    ADD CONSTRAINT pk_sys_profile PRIMARY KEY (id);


--
-- Name: sys_profile_operation_right pk_sys_profile_operation_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_operation_right
    ADD CONSTRAINT pk_sys_profile_operation_right PRIMARY KEY (id);


--
-- Name: sys_profile_right pk_sys_profile_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_right
    ADD CONSTRAINT pk_sys_profile_right PRIMARY KEY (id);


--
-- Name: sys_profile_role pk_sys_profile_role; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_role
    ADD CONSTRAINT pk_sys_profile_role PRIMARY KEY (id);


--
-- Name: sys_right pk_sys_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_right
    ADD CONSTRAINT pk_sys_right PRIMARY KEY (id);


--
-- Name: sys_role pk_sys_role; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role
    ADD CONSTRAINT pk_sys_role PRIMARY KEY (id);


--
-- Name: sys_role_operation_right pk_sys_role_operation_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_operation_right
    ADD CONSTRAINT pk_sys_role_operation_right PRIMARY KEY (id);


--
-- Name: sys_role_right pk_sys_role_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_right
    ADD CONSTRAINT pk_sys_role_right PRIMARY KEY (id);


--
-- Name: sys_row_level_right pk_sys_row_level_right; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_row_level_right
    ADD CONSTRAINT pk_sys_row_level_right PRIMARY KEY (id);


--
-- Name: sys_row_level_security_object pk_sys_row_level_security_object; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_row_level_security_object
    ADD CONSTRAINT pk_sys_row_level_security_object PRIMARY KEY (id);


--
-- Name: sys_user_default_value pk_sys_user_default_value; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_user_default_value
    ADD CONSTRAINT pk_sys_user_default_value PRIMARY KEY (id);


--
-- Name: sys_user_profile pk_sys_user_profile; Type: CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_user_profile
    ADD CONSTRAINT pk_sys_user_profile PRIMARY KEY (id);


--
-- Name: tn_division pk_tn_division; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_division
    ADD CONSTRAINT pk_tn_division PRIMARY KEY (id);


--
-- Name: tn_requisites pk_tn_requisites; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_requisites
    ADD CONSTRAINT pk_tn_requisites PRIMARY KEY (tenant_id);


--
-- Name: tn_sequence pk_tn_sequence; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_sequence
    ADD CONSTRAINT pk_tn_sequence PRIMARY KEY (tenant_id, key, scope_key);


--
-- Name: tn_settings pk_tn_settings; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_settings
    ADD CONSTRAINT pk_tn_settings PRIMARY KEY (tenant_id);


--
-- Name: tn_tenant pk_tn_tenant; Type: CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_tenant
    ADD CONSTRAINT pk_tn_tenant PRIMARY KEY (id);


--
-- Name: ix_hangfire_counter_expireat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_counter_expireat ON hangfire.counter USING btree (expireat);


--
-- Name: ix_hangfire_counter_key; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_counter_key ON hangfire.counter USING btree (key);


--
-- Name: ix_hangfire_hash_expireat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_hash_expireat ON hangfire.hash USING btree (expireat);


--
-- Name: ix_hangfire_job_expireat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_job_expireat ON hangfire.job USING btree (expireat);


--
-- Name: ix_hangfire_job_statename; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_job_statename ON hangfire.job USING btree (statename);


--
-- Name: ix_hangfire_job_statename_is_not_null; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_job_statename_is_not_null ON hangfire.job USING btree (statename) INCLUDE (id) WHERE (statename IS NOT NULL);


--
-- Name: ix_hangfire_jobparameter_jobidandname; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_jobparameter_jobidandname ON hangfire.jobparameter USING btree (jobid, name);


--
-- Name: ix_hangfire_jobqueue_fetchedat_queue_jobid; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_jobqueue_fetchedat_queue_jobid ON hangfire.jobqueue USING btree (fetchedat NULLS FIRST, queue, jobid);


--
-- Name: ix_hangfire_jobqueue_jobidandqueue; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_jobqueue_jobidandqueue ON hangfire.jobqueue USING btree (jobid, queue);


--
-- Name: ix_hangfire_jobqueue_queueandfetchedat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_jobqueue_queueandfetchedat ON hangfire.jobqueue USING btree (queue, fetchedat);


--
-- Name: ix_hangfire_list_expireat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_list_expireat ON hangfire.list USING btree (expireat);


--
-- Name: ix_hangfire_set_expireat; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_set_expireat ON hangfire.set USING btree (expireat);


--
-- Name: ix_hangfire_set_key_score; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_set_key_score ON hangfire.set USING btree (key, score);


--
-- Name: ix_hangfire_state_jobid; Type: INDEX; Schema: hangfire; Owner: lis_app
--

CREATE INDEX ix_hangfire_state_jobid ON hangfire.state USING btree (jobid);


--
-- Name: ix_aud_event_tenant_id_occurred_at; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_aud_event_tenant_id_occurred_at ON public.aud_event USING btree (tenant_id, occurred_at DESC);


--
-- Name: ix_cmn_person_gender_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_cmn_person_gender_id ON public.cmn_person USING btree (gender_id);


--
-- Name: ix_cmn_person_last_name_name; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_cmn_person_last_name_name ON public.cmn_person USING btree (last_name, name);


--
-- Name: ix_cmn_person_user_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_cmn_person_user_id ON public.cmn_person USING btree (user_id);


--
-- Name: ix_ehe_incoming_medical_referral_patient_card_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_incoming_medical_referral_patient_card_id ON public.ehe_incoming_medical_referral USING btree (patient_card_id);


--
-- Name: ix_ehe_incoming_medical_referral_processing_status_in_ehealth_i; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_incoming_medical_referral_processing_status_in_ehealth_i ON public.ehe_incoming_medical_referral USING btree (processing_status_in_ehealth_id);


--
-- Name: ix_ehe_incoming_medical_referral_service_catalog_service_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_incoming_medical_referral_service_catalog_service_id ON public.ehe_incoming_medical_referral USING btree (service_catalog_service_id);


--
-- Name: ix_ehe_incoming_medical_referral_status_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_incoming_medical_referral_status_id ON public.ehe_incoming_medical_referral USING btree (status_id);


--
-- Name: ix_ehe_incoming_medical_referral_tenant_id_reg_number; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_incoming_medical_referral_tenant_id_reg_number ON public.ehe_incoming_medical_referral USING btree (tenant_id, reg_number);


--
-- Name: ix_ehe_paper_medical_referral_patient_card_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_paper_medical_referral_patient_card_id ON public.ehe_paper_medical_referral USING btree (patient_card_id);


--
-- Name: ix_ehe_paper_medical_referral_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ehe_paper_medical_referral_tenant_id ON public.ehe_paper_medical_referral USING btree (tenant_id);


--
-- Name: ix_id_device_token_prefix; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_id_device_token_prefix ON public.id_device_token USING btree (prefix);


--
-- Name: ix_id_device_token_tenant_id_gateway_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_id_device_token_tenant_id_gateway_id ON public.id_device_token USING btree (tenant_id, gateway_id);


--
-- Name: ix_id_invitation_tenant_id_email; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_id_invitation_tenant_id_email ON public.id_invitation USING btree (tenant_id, email);


--
-- Name: ix_id_invitation_token; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_id_invitation_token ON public.id_invitation USING btree (token);


--
-- Name: ix_id_membership_role_membership_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_id_membership_role_membership_id ON public.id_membership_role USING btree (membership_id);


--
-- Name: ix_id_membership_role_role_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_id_membership_role_role_id ON public.id_membership_role USING btree (role_id);


--
-- Name: ix_id_membership_role_tenant_id_membership_id_role_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_id_membership_role_tenant_id_membership_id_role_id ON public.id_membership_role USING btree (tenant_id, membership_id, role_id);


--
-- Name: ix_id_membership_tenant_id_user_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_id_membership_tenant_id_user_id ON public.id_membership USING btree (tenant_id, user_id);


--
-- Name: ix_id_user_sub; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_id_user_sub ON public.id_user USING btree (sub);


--
-- Name: ix_ins_gateway_enrollment_code; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_ins_gateway_enrollment_code ON public.ins_gateway USING btree (enrollment_code);


--
-- Name: ix_ins_gateway_tenant_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ins_gateway_tenant_id ON public.ins_gateway USING btree (tenant_id);


--
-- Name: ix_int_api_key_prefix; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_int_api_key_prefix ON public.int_api_key USING btree (prefix);


--
-- Name: ix_int_api_key_tenant_id_client_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_int_api_key_tenant_id_client_id ON public.int_api_key USING btree (tenant_id, client_id);


--
-- Name: ix_int_client_tenant_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_int_client_tenant_id ON public.int_client USING btree (tenant_id);


--
-- Name: ix_lab_analyzer_analyzer_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_analyzer_type_id ON public.lab_analyzer USING btree (analyzer_type_id);


--
-- Name: ix_lab_analyzer_connector_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_connector_id ON public.lab_analyzer USING btree (connector_id);


--
-- Name: ix_lab_analyzer_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_department_id ON public.lab_analyzer USING btree (department_id);


--
-- Name: ix_lab_analyzer_lockout_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_lockout_analyzer_id ON public.lab_analyzer_lockout USING btree (analyzer_id);


--
-- Name: ix_lab_analyzer_lockout_tenant_id_analyzer_id_resolved_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_lockout_tenant_id_analyzer_id_resolved_at ON public.lab_analyzer_lockout USING btree (tenant_id, analyzer_id, resolved_at);


--
-- Name: ix_lab_analyzer_message_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_message_analyzer_id ON public.lab_analyzer_message USING btree (analyzer_id);


--
-- Name: ix_lab_analyzer_message_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_message_tenant_id ON public.lab_analyzer_message USING btree (tenant_id);


--
-- Name: ix_lab_analyzer_parameter_map_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_parameter_map_analyzer_id ON public.lab_analyzer_parameter_map USING btree (analyzer_id);


--
-- Name: ix_lab_analyzer_parameter_map_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_parameter_map_tenant_id ON public.lab_analyzer_parameter_map USING btree (tenant_id);


--
-- Name: ix_lab_analyzer_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_analyzer_tenant_id_code ON public.lab_analyzer USING btree (tenant_id, code);


--
-- Name: ix_lab_analyzer_type_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_analyzer_type_tenant_id ON public.lab_analyzer_type USING btree (tenant_id);


--
-- Name: ix_lab_antibiotic_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_antibiotic_tenant_id ON public.lab_antibiotic USING btree (tenant_id);


--
-- Name: ix_lab_archive_cell_rack_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_archive_cell_rack_id ON public.lab_archive_cell USING btree (rack_id);


--
-- Name: ix_lab_archive_cell_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_archive_cell_sample_id ON public.lab_archive_cell USING btree (sample_id);


--
-- Name: ix_lab_archive_cell_tenant_id_rack_id_row_num_col_num; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_archive_cell_tenant_id_rack_id_row_num_col_num ON public.lab_archive_cell USING btree (tenant_id, rack_id, row_num, col_num);


--
-- Name: ix_lab_archive_rack_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_archive_rack_tenant_id ON public.lab_archive_rack USING btree (tenant_id);


--
-- Name: ix_lab_audit_log_tenant_id_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_audit_log_tenant_id_at ON public.lab_audit_log USING btree (tenant_id, at);


--
-- Name: ix_lab_audit_log_tenant_id_entity_entity_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_audit_log_tenant_id_entity_entity_id ON public.lab_audit_log USING btree (tenant_id, entity, entity_id);


--
-- Name: ix_lab_biomaterial_type_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_biomaterial_type_tenant_id ON public.lab_biomaterial_type USING btree (tenant_id);


--
-- Name: ix_lab_connector_command_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_connector_command_tenant_id ON public.lab_connector_command USING btree (tenant_id);


--
-- Name: ix_lab_connector_installation_api_key_hash; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_connector_installation_api_key_hash ON public.lab_connector_installation USING btree (api_key_hash);


--
-- Name: ix_lab_connector_installation_install_key; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_connector_installation_install_key ON public.lab_connector_installation USING btree (install_key);


--
-- Name: ix_lab_connector_installation_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_connector_installation_tenant_id ON public.lab_connector_installation USING btree (tenant_id);


--
-- Name: ix_lab_connector_log_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_connector_log_tenant_id ON public.lab_connector_log USING btree (tenant_id);


--
-- Name: ix_lab_culture_order_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_culture_order_order_id ON public.lab_culture_order USING btree (order_id);


--
-- Name: ix_lab_culture_order_order_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_culture_order_order_test_id ON public.lab_culture_order USING btree (order_test_id);


--
-- Name: ix_lab_culture_order_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_culture_order_tenant_id ON public.lab_culture_order USING btree (tenant_id);


--
-- Name: ix_lab_ehealth_exchange_log_tenant_id_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_ehealth_exchange_log_tenant_id_at ON public.lab_ehealth_exchange_log USING btree (tenant_id, at);


--
-- Name: ix_lab_employee_settings_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_employee_settings_tenant_id ON public.lab_employee_settings USING btree (tenant_id);


--
-- Name: ix_lab_eucast_breakpoint_antibiotic_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_eucast_breakpoint_antibiotic_id ON public.lab_eucast_breakpoint USING btree (antibiotic_id);


--
-- Name: ix_lab_eucast_breakpoint_organism_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_eucast_breakpoint_organism_id ON public.lab_eucast_breakpoint USING btree (organism_id);


--
-- Name: ix_lab_eucast_breakpoint_tenant_id_organism_id_antibiotic_id_eu; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_eucast_breakpoint_tenant_id_organism_id_antibiotic_id_eu ON public.lab_eucast_breakpoint USING btree (tenant_id, organism_id, antibiotic_id, eucast_version);


--
-- Name: ix_lab_invoice_payer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_invoice_payer_id ON public.lab_invoice USING btree (payer_id);


--
-- Name: ix_lab_invoice_tenant_id_number; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_invoice_tenant_id_number ON public.lab_invoice USING btree (tenant_id, number);


--
-- Name: ix_lab_isolate_culture_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_isolate_culture_order_id ON public.lab_isolate USING btree (culture_order_id);


--
-- Name: ix_lab_isolate_organism_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_isolate_organism_id ON public.lab_isolate USING btree (organism_id);


--
-- Name: ix_lab_isolate_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_isolate_tenant_id ON public.lab_isolate USING btree (tenant_id);


--
-- Name: ix_lab_method_type_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_method_type_tenant_id ON public.lab_method_type USING btree (tenant_id);


--
-- Name: ix_lab_micro_organism_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_micro_organism_tenant_id ON public.lab_micro_organism USING btree (tenant_id);


--
-- Name: ix_lab_numerator_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_numerator_tenant_id ON public.lab_numerator USING btree (tenant_id);


--
-- Name: ix_lab_order_attachment_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_attachment_order_id ON public.lab_order_attachment USING btree (order_id);


--
-- Name: ix_lab_order_attachment_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_attachment_tenant_id ON public.lab_order_attachment USING btree (tenant_id);


--
-- Name: ix_lab_order_charge_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_charge_order_id ON public.lab_order_charge USING btree (order_id);


--
-- Name: ix_lab_order_charge_payer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_charge_payer_id ON public.lab_order_charge USING btree (payer_id);


--
-- Name: ix_lab_order_charge_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_charge_tenant_id ON public.lab_order_charge USING btree (tenant_id);


--
-- Name: ix_lab_order_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_department_id ON public.lab_order USING btree (department_id);


--
-- Name: ix_lab_order_diagnostic_report_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_diagnostic_report_id ON public.lab_order USING btree (diagnostic_report_id);


--
-- Name: ix_lab_order_doctor_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_doctor_id ON public.lab_order USING btree (doctor_id);


--
-- Name: ix_lab_order_ehealth_referral_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_ehealth_referral_id ON public.lab_order USING btree (ehealth_referral_id);


--
-- Name: ix_lab_order_favorite_tenant_id_employee_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_favorite_tenant_id_employee_id ON public.lab_order_favorite USING btree (tenant_id, employee_id);


--
-- Name: ix_lab_order_paper_referral_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_paper_referral_id ON public.lab_order USING btree (paper_referral_id);


--
-- Name: ix_lab_order_patient_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_patient_id ON public.lab_order USING btree (patient_id);


--
-- Name: ix_lab_order_payer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_payer_id ON public.lab_order USING btree (payer_id);


--
-- Name: ix_lab_order_requester_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_requester_id ON public.lab_order USING btree (requester_id);


--
-- Name: ix_lab_order_sample_biomaterial_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_sample_biomaterial_type_id ON public.lab_order_sample USING btree (biomaterial_type_id);


--
-- Name: ix_lab_order_sample_lab_section_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_sample_lab_section_id ON public.lab_order_sample USING btree (lab_section_id);


--
-- Name: ix_lab_order_sample_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_sample_order_id ON public.lab_order_sample USING btree (order_id);


--
-- Name: ix_lab_order_sample_parent_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_sample_parent_sample_id ON public.lab_order_sample USING btree (parent_sample_id);


--
-- Name: ix_lab_order_sample_tenant_id_barcode; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_order_sample_tenant_id_barcode ON public.lab_order_sample USING btree (tenant_id, barcode);


--
-- Name: ix_lab_order_sample_tube_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_sample_tube_type_id ON public.lab_order_sample USING btree (tube_type_id);


--
-- Name: ix_lab_order_tenant_id_order_datetime; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_tenant_id_order_datetime ON public.lab_order USING btree (tenant_id, order_datetime);


--
-- Name: ix_lab_order_tenant_id_order_number; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_order_tenant_id_order_number ON public.lab_order USING btree (tenant_id, order_number);


--
-- Name: ix_lab_order_tenant_id_referral_type; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_tenant_id_referral_type ON public.lab_order USING btree (tenant_id, referral_type);


--
-- Name: ix_lab_order_tenant_id_status; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_tenant_id_status ON public.lab_order USING btree (tenant_id, status);


--
-- Name: ix_lab_order_test_assigned_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_assigned_analyzer_id ON public.lab_order_test USING btree (assigned_analyzer_id);


--
-- Name: ix_lab_order_test_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_order_id ON public.lab_order_test USING btree (order_id);


--
-- Name: ix_lab_order_test_performer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_performer_id ON public.lab_order_test USING btree (performer_id);


--
-- Name: ix_lab_order_test_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_profile_id ON public.lab_order_test USING btree (profile_id);


--
-- Name: ix_lab_order_test_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_sample_id ON public.lab_order_test USING btree (sample_id);


--
-- Name: ix_lab_order_test_tenant_id_released_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_tenant_id_released_at ON public.lab_order_test USING btree (tenant_id, released_at);


--
-- Name: ix_lab_order_test_tenant_id_status; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_tenant_id_status ON public.lab_order_test USING btree (tenant_id, status);


--
-- Name: ix_lab_order_test_tenant_id_test_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_tenant_id_test_code ON public.lab_order_test USING btree (tenant_id, test_code);


--
-- Name: ix_lab_order_test_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_test_test_id ON public.lab_order_test USING btree (test_id);


--
-- Name: ix_lab_order_verify_token; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_order_verify_token ON public.lab_order USING btree (verify_token);


--
-- Name: ix_lab_panic_call_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_panic_call_tenant_id ON public.lab_panic_call USING btree (tenant_id);


--
-- Name: ix_lab_patient_notification_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_patient_notification_tenant_id ON public.lab_patient_notification USING btree (tenant_id);


--
-- Name: ix_lab_payer_price_list_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_payer_price_list_id ON public.lab_payer USING btree (price_list_id);


--
-- Name: ix_lab_payer_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_payer_tenant_id_code ON public.lab_payer USING btree (tenant_id, code);


--
-- Name: ix_lab_payment_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_payment_order_id ON public.lab_payment USING btree (order_id);


--
-- Name: ix_lab_payment_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_payment_tenant_id ON public.lab_payment USING btree (tenant_id);


--
-- Name: ix_lab_performer_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_performer_department_id ON public.lab_performer USING btree (department_id);


--
-- Name: ix_lab_performer_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_performer_tenant_id_code ON public.lab_performer USING btree (tenant_id, code);


--
-- Name: ix_lab_performer_test_performer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_performer_test_performer_id ON public.lab_performer_test USING btree (performer_id);


--
-- Name: ix_lab_performer_test_tenant_id_performer_id_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_performer_test_tenant_id_performer_id_test_id ON public.lab_performer_test USING btree (tenant_id, performer_id, test_id);


--
-- Name: ix_lab_performer_test_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_performer_test_test_id ON public.lab_performer_test USING btree (test_id);


--
-- Name: ix_lab_price_list_item_price_list_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_price_list_item_price_list_id ON public.lab_price_list_item USING btree (price_list_id);


--
-- Name: ix_lab_price_list_item_tenant_id_price_list_id_profile_id_test_; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_price_list_item_tenant_id_price_list_id_profile_id_test_ ON public.lab_price_list_item USING btree (tenant_id, price_list_id, profile_id, test_id);


--
-- Name: ix_lab_price_list_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_price_list_tenant_id_code ON public.lab_price_list USING btree (tenant_id, code);


--
-- Name: ix_lab_price_package_price_list_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_price_package_price_list_id ON public.lab_price_package USING btree (price_list_id);


--
-- Name: ix_lab_price_package_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_price_package_tenant_id ON public.lab_price_package USING btree (tenant_id);


--
-- Name: ix_lab_qc_material_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_material_analyzer_id ON public.lab_qc_material USING btree (analyzer_id);


--
-- Name: ix_lab_qc_material_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_material_tenant_id ON public.lab_qc_material USING btree (tenant_id);


--
-- Name: ix_lab_qc_result_qc_material_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_result_qc_material_id ON public.lab_qc_result USING btree (qc_material_id);


--
-- Name: ix_lab_qc_result_tenant_id_qc_material_id_test_code_run_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_result_tenant_id_qc_material_id_test_code_run_at ON public.lab_qc_result USING btree (tenant_id, qc_material_id, test_code, run_at);


--
-- Name: ix_lab_qc_target_qc_material_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_target_qc_material_id ON public.lab_qc_target USING btree (qc_material_id);


--
-- Name: ix_lab_qc_target_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_qc_target_tenant_id ON public.lab_qc_target USING btree (tenant_id);


--
-- Name: ix_lab_reagent_lot_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_reagent_lot_analyzer_id ON public.lab_reagent_lot USING btree (analyzer_id);


--
-- Name: ix_lab_reagent_lot_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_reagent_lot_tenant_id ON public.lab_reagent_lot USING btree (tenant_id);


--
-- Name: ix_lab_reference_layer_tenant_id_test_code_method_code_priority; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_reference_layer_tenant_id_test_code_method_code_priority ON public.lab_reference_layer USING btree (tenant_id, test_code, method_code, priority_order);


--
-- Name: ix_lab_reflex_rule_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_reflex_rule_tenant_id ON public.lab_reflex_rule USING btree (tenant_id);


--
-- Name: ix_lab_result_history_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_result_history_tenant_id ON public.lab_result_history USING btree (tenant_id);


--
-- Name: ix_lab_sample_logistics_destination_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_destination_department_id ON public.lab_sample_logistics USING btree (destination_department_id);


--
-- Name: ix_lab_sample_logistics_item_logistics_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_item_logistics_id ON public.lab_sample_logistics_item USING btree (logistics_id);


--
-- Name: ix_lab_sample_logistics_item_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_item_sample_id ON public.lab_sample_logistics_item USING btree (sample_id);


--
-- Name: ix_lab_sample_logistics_item_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_item_tenant_id ON public.lab_sample_logistics_item USING btree (tenant_id);


--
-- Name: ix_lab_sample_logistics_origin_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_origin_department_id ON public.lab_sample_logistics USING btree (origin_department_id);


--
-- Name: ix_lab_sample_logistics_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_logistics_tenant_id ON public.lab_sample_logistics USING btree (tenant_id);


--
-- Name: ix_lab_sample_stage_event_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_stage_event_sample_id ON public.lab_sample_stage_event USING btree (sample_id);


--
-- Name: ix_lab_sample_stage_event_tenant_id_sample_id_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_sample_stage_event_tenant_id_sample_id_at ON public.lab_sample_stage_event USING btree (tenant_id, sample_id, at);


--
-- Name: ix_lab_section_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_section_department_id ON public.lab_section USING btree (department_id);


--
-- Name: ix_lab_section_journal_entry_lab_section_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_section_journal_entry_lab_section_id ON public.lab_section_journal_entry USING btree (lab_section_id);


--
-- Name: ix_lab_section_journal_entry_order_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_section_journal_entry_order_id ON public.lab_section_journal_entry USING btree (order_id);


--
-- Name: ix_lab_section_journal_entry_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_section_journal_entry_sample_id ON public.lab_section_journal_entry USING btree (sample_id);


--
-- Name: ix_lab_section_journal_entry_tenant_id_lab_section_id_registere; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_section_journal_entry_tenant_id_lab_section_id_registere ON public.lab_section_journal_entry USING btree (tenant_id, lab_section_id, registered_at);


--
-- Name: ix_lab_section_journal_entry_tenant_id_order_id_lab_section_id_; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_section_journal_entry_tenant_id_order_id_lab_section_id_ ON public.lab_section_journal_entry USING btree (tenant_id, order_id, lab_section_id, sample_id);


--
-- Name: ix_lab_section_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_section_tenant_id_code ON public.lab_section USING btree (tenant_id, code);


--
-- Name: ix_lab_send_out_item_order_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_send_out_item_order_test_id ON public.lab_send_out_item USING btree (order_test_id);


--
-- Name: ix_lab_send_out_item_sample_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_send_out_item_sample_id ON public.lab_send_out_item USING btree (sample_id);


--
-- Name: ix_lab_send_out_item_send_out_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_send_out_item_send_out_id ON public.lab_send_out_item USING btree (send_out_id);


--
-- Name: ix_lab_send_out_item_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_send_out_item_tenant_id ON public.lab_send_out_item USING btree (tenant_id);


--
-- Name: ix_lab_send_out_performer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_send_out_performer_id ON public.lab_send_out USING btree (performer_id);


--
-- Name: ix_lab_send_out_tenant_id_number; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_send_out_tenant_id_number ON public.lab_send_out USING btree (tenant_id, number);


--
-- Name: ix_lab_settings_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_settings_tenant_id ON public.lab_settings USING btree (tenant_id);


--
-- Name: ix_lab_susceptibility_result_antibiotic_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_susceptibility_result_antibiotic_id ON public.lab_susceptibility_result USING btree (antibiotic_id);


--
-- Name: ix_lab_susceptibility_result_isolate_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_susceptibility_result_isolate_id ON public.lab_susceptibility_result USING btree (isolate_id);


--
-- Name: ix_lab_susceptibility_result_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_susceptibility_result_tenant_id ON public.lab_susceptibility_result USING btree (tenant_id);


--
-- Name: ix_lab_test_definition_biomaterial_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_definition_biomaterial_type_id ON public.lab_test_definition USING btree (biomaterial_type_id);


--
-- Name: ix_lab_test_definition_lab_section_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_definition_lab_section_id ON public.lab_test_definition USING btree (lab_section_id);


--
-- Name: ix_lab_test_definition_method_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_definition_method_id ON public.lab_test_definition USING btree (method_id);


--
-- Name: ix_lab_test_definition_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_test_definition_tenant_id_code ON public.lab_test_definition USING btree (tenant_id, code);


--
-- Name: ix_lab_test_definition_tube_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_definition_tube_type_id ON public.lab_test_definition USING btree (tube_type_id);


--
-- Name: ix_lab_test_profile_ehealth_service_catalog_service_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_profile_ehealth_service_catalog_service_id ON public.lab_test_profile USING btree (ehealth_service_catalog_service_id);


--
-- Name: ix_lab_test_profile_item_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_profile_item_profile_id ON public.lab_test_profile_item USING btree (profile_id);


--
-- Name: ix_lab_test_profile_item_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_profile_item_tenant_id ON public.lab_test_profile_item USING btree (tenant_id);


--
-- Name: ix_lab_test_profile_item_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_profile_item_test_id ON public.lab_test_profile_item USING btree (test_id);


--
-- Name: ix_lab_test_profile_organization_service_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_profile_organization_service_id ON public.lab_test_profile USING btree (organization_service_id);


--
-- Name: ix_lab_test_profile_tenant_id_code; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_test_profile_tenant_id_code ON public.lab_test_profile USING btree (tenant_id, code);


--
-- Name: ix_lab_test_result_analyzer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_result_analyzer_id ON public.lab_test_result USING btree (analyzer_id);


--
-- Name: ix_lab_test_result_order_test_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_lab_test_result_order_test_id ON public.lab_test_result USING btree (order_test_id);


--
-- Name: ix_lab_test_result_tenant_id_entered_at; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_result_tenant_id_entered_at ON public.lab_test_result USING btree (tenant_id, entered_at);


--
-- Name: ix_lab_test_result_tenant_id_flag; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_test_result_tenant_id_flag ON public.lab_test_result USING btree (tenant_id, flag);


--
-- Name: ix_lab_tube_type_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_tube_type_tenant_id ON public.lab_tube_type USING btree (tenant_id);


--
-- Name: ix_lab_unmatched_result_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_unmatched_result_tenant_id ON public.lab_unmatched_result USING btree (tenant_id);


--
-- Name: ix_lab_workflow_template_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_workflow_template_tenant_id ON public.lab_workflow_template USING btree (tenant_id);


--
-- Name: ix_lab_worklist_batch_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_lab_worklist_batch_tenant_id ON public.lab_worklist_batch USING btree (tenant_id);


--
-- Name: ix_mis_diagnostic_report_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_mis_diagnostic_report_tenant_id ON public.mis_diagnostic_report USING btree (tenant_id);


--
-- Name: ix_mis_patient_insurance_patient_card_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_mis_patient_insurance_patient_card_id ON public.mis_patient_insurance USING btree (patient_card_id);


--
-- Name: ix_mis_patient_insurance_payer_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_mis_patient_insurance_payer_id ON public.mis_patient_insurance USING btree (payer_id);


--
-- Name: ix_mis_patient_insurance_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_mis_patient_insurance_tenant_id ON public.mis_patient_insurance USING btree (tenant_id);


--
-- Name: ix_ord_order_identifier_order_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_order_identifier_order_id ON public.ord_order_identifier USING btree (order_id);


--
-- Name: ix_ord_order_identifier_tenant_id_system_value; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_order_identifier_tenant_id_system_value ON public.ord_order_identifier USING btree (tenant_id, system, value);


--
-- Name: ix_ord_patient_identifier_patient_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_patient_identifier_patient_id ON public.ord_patient_identifier USING btree (patient_id);


--
-- Name: ix_ord_patient_identifier_tenant_id_system_value; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_ord_patient_identifier_tenant_id_system_value ON public.ord_patient_identifier USING btree (tenant_id, system, value);


--
-- Name: ix_ord_patient_insurance_patient_card_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_patient_insurance_patient_card_id ON public.ord_patient_insurance USING btree (patient_card_id);


--
-- Name: ix_ord_patient_insurance_payer_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_patient_insurance_payer_id ON public.ord_patient_insurance USING btree (payer_id);


--
-- Name: ix_ord_patient_insurance_tenant_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_patient_insurance_tenant_id ON public.ord_patient_insurance USING btree (tenant_id);


--
-- Name: ix_ord_patient_tenant_id_caption; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ord_patient_tenant_id_caption ON public.ord_patient USING btree (tenant_id, caption);


--
-- Name: ix_ord_patient_tenant_id_last_name_name; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_ord_patient_tenant_id_last_name_name ON public.ord_patient USING btree (tenant_id, last_name, name);


--
-- Name: ix_ord_requester_tenant_id; Type: INDEX; Schema: public; Owner: lis
--

CREATE INDEX ix_ord_requester_tenant_id ON public.ord_requester USING btree (tenant_id);


--
-- Name: ix_org_employee_department_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_org_employee_department_id ON public.org_employee USING btree (department_id);


--
-- Name: ix_org_employee_membership_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE UNIQUE INDEX ix_org_employee_membership_id ON public.org_employee USING btree (membership_id);


--
-- Name: ix_org_employee_person_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_org_employee_person_id ON public.org_employee USING btree (person_id);


--
-- Name: ix_org_employee_position_type_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_org_employee_position_type_id ON public.org_employee USING btree (position_type_id);


--
-- Name: ix_org_employee_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_org_employee_tenant_id ON public.org_employee USING btree (tenant_id);


--
-- Name: ix_org_organization_service_tenant_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_org_organization_service_tenant_id ON public.org_organization_service USING btree (tenant_id);


--
-- Name: ix_sys_field_right_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_field_right_right_id ON public.sys_field_right USING btree (right_id);


--
-- Name: ix_sys_profile_operation_right_operation_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_operation_right_operation_right_id ON public.sys_profile_operation_right USING btree (operation_right_id);


--
-- Name: ix_sys_profile_operation_right_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_operation_right_profile_id ON public.sys_profile_operation_right USING btree (profile_id);


--
-- Name: ix_sys_profile_right_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_right_profile_id ON public.sys_profile_right USING btree (profile_id);


--
-- Name: ix_sys_profile_right_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_right_right_id ON public.sys_profile_right USING btree (right_id);


--
-- Name: ix_sys_profile_role_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_role_profile_id ON public.sys_profile_role USING btree (profile_id);


--
-- Name: ix_sys_profile_role_role_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_profile_role_role_id ON public.sys_profile_role USING btree (role_id);


--
-- Name: ix_sys_role_operation_right_operation_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_role_operation_right_operation_right_id ON public.sys_role_operation_right USING btree (operation_right_id);


--
-- Name: ix_sys_role_operation_right_role_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_role_operation_right_role_id ON public.sys_role_operation_right USING btree (role_id);


--
-- Name: ix_sys_role_right_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_role_right_right_id ON public.sys_role_right USING btree (right_id);


--
-- Name: ix_sys_role_right_role_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_role_right_role_id ON public.sys_role_right USING btree (role_id);


--
-- Name: ix_sys_row_level_security_object_row_level_right_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_row_level_security_object_row_level_right_id ON public.sys_row_level_security_object USING btree (row_level_right_id);


--
-- Name: ix_sys_user_profile_profile_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_user_profile_profile_id ON public.sys_user_profile USING btree (profile_id);


--
-- Name: ix_sys_user_profile_user_id; Type: INDEX; Schema: public; Owner: lab_migrator
--

CREATE INDEX ix_sys_user_profile_user_id ON public.sys_user_profile USING btree (user_id);


--
-- Name: ix_tn_division_tenant_id_code; Type: INDEX; Schema: public; Owner: lis
--

CREATE UNIQUE INDEX ix_tn_division_tenant_id_code ON public.tn_division USING btree (tenant_id, code);


--
-- Name: aud_event aud_event_no_update_delete; Type: TRIGGER; Schema: public; Owner: lis
--

CREATE TRIGGER aud_event_no_update_delete BEFORE DELETE OR UPDATE ON public.aud_event FOR EACH ROW EXECUTE FUNCTION public.aud_event_append_only();


--
-- Name: jobparameter jobparameter_jobid_fkey; Type: FK CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.jobparameter
    ADD CONSTRAINT jobparameter_jobid_fkey FOREIGN KEY (jobid) REFERENCES hangfire.job(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: state state_jobid_fkey; Type: FK CONSTRAINT; Schema: hangfire; Owner: lis_app
--

ALTER TABLE ONLY hangfire.state
    ADD CONSTRAINT state_jobid_fkey FOREIGN KEY (jobid) REFERENCES hangfire.job(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cmn_person fk_cmn_person_gender_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.cmn_person
    ADD CONSTRAINT fk_cmn_person_gender_id FOREIGN KEY (gender_id) REFERENCES public.cmn_enum_record(id);


--
-- Name: ehe_incoming_medical_referral fk_ehe_incoming_medical_referral_patient_card_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_incoming_medical_referral
    ADD CONSTRAINT fk_ehe_incoming_medical_referral_patient_card_id FOREIGN KEY (patient_card_id) REFERENCES public.ord_patient(id);


--
-- Name: ehe_incoming_medical_referral fk_ehe_incoming_medical_referral_processing_status_in_ehealth_i; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_incoming_medical_referral
    ADD CONSTRAINT fk_ehe_incoming_medical_referral_processing_status_in_ehealth_i FOREIGN KEY (processing_status_in_ehealth_id) REFERENCES public.cmn_enum_record(id);


--
-- Name: ehe_incoming_medical_referral fk_ehe_incoming_medical_referral_service_catalog_service_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_incoming_medical_referral
    ADD CONSTRAINT fk_ehe_incoming_medical_referral_service_catalog_service_id FOREIGN KEY (service_catalog_service_id) REFERENCES public.ehe_service_catalog_service(id);


--
-- Name: ehe_incoming_medical_referral fk_ehe_incoming_medical_referral_status_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_incoming_medical_referral
    ADD CONSTRAINT fk_ehe_incoming_medical_referral_status_id FOREIGN KEY (status_id) REFERENCES public.cmn_enum_record(id) ON DELETE CASCADE;


--
-- Name: ehe_medical_service_program fk_ehe_medical_service_program_type; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_medical_service_program
    ADD CONSTRAINT fk_ehe_medical_service_program_type FOREIGN KEY (type_id) REFERENCES public.ehd_dictionary(id);


--
-- Name: ehe_paper_medical_referral fk_ehe_paper_medical_referral_patient_card_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ehe_paper_medical_referral
    ADD CONSTRAINT fk_ehe_paper_medical_referral_patient_card_id FOREIGN KEY (patient_card_id) REFERENCES public.ord_patient(id) ON DELETE CASCADE;


--
-- Name: id_membership_role fk_id_membership_role_membership_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership_role
    ADD CONSTRAINT fk_id_membership_role_membership_id FOREIGN KEY (membership_id) REFERENCES public.id_membership(id) ON DELETE CASCADE;


--
-- Name: id_membership_role fk_id_membership_role_role_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership_role
    ADD CONSTRAINT fk_id_membership_role_role_id FOREIGN KEY (role_id) REFERENCES public.id_role(id) ON DELETE CASCADE;


--
-- Name: id_membership_role fk_id_membership_role_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.id_membership_role
    ADD CONSTRAINT fk_id_membership_role_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: lab_analyzer fk_lab_analyzer_analyzer_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer
    ADD CONSTRAINT fk_lab_analyzer_analyzer_type_id FOREIGN KEY (analyzer_type_id) REFERENCES public.lab_analyzer_type(id) ON DELETE CASCADE;


--
-- Name: lab_analyzer fk_lab_analyzer_connector_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer
    ADD CONSTRAINT fk_lab_analyzer_connector_id FOREIGN KEY (connector_id) REFERENCES public.lab_connector_installation(id);


--
-- Name: lab_analyzer fk_lab_analyzer_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer
    ADD CONSTRAINT fk_lab_analyzer_department_id FOREIGN KEY (department_id) REFERENCES public.tn_division(id);


--
-- Name: lab_analyzer_lockout fk_lab_analyzer_lockout_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_lockout
    ADD CONSTRAINT fk_lab_analyzer_lockout_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id) ON DELETE CASCADE;


--
-- Name: lab_analyzer_message fk_lab_analyzer_message_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_message
    ADD CONSTRAINT fk_lab_analyzer_message_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id) ON DELETE CASCADE;


--
-- Name: lab_analyzer_parameter_map fk_lab_analyzer_parameter_map_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_analyzer_parameter_map
    ADD CONSTRAINT fk_lab_analyzer_parameter_map_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id) ON DELETE CASCADE;


--
-- Name: lab_archive_cell fk_lab_archive_cell_rack_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_archive_cell
    ADD CONSTRAINT fk_lab_archive_cell_rack_id FOREIGN KEY (rack_id) REFERENCES public.lab_archive_rack(id) ON DELETE CASCADE;


--
-- Name: lab_archive_cell fk_lab_archive_cell_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_archive_cell
    ADD CONSTRAINT fk_lab_archive_cell_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id);


--
-- Name: lab_culture_order fk_lab_culture_order_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_culture_order
    ADD CONSTRAINT fk_lab_culture_order_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_culture_order fk_lab_culture_order_order_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_culture_order
    ADD CONSTRAINT fk_lab_culture_order_order_test_id FOREIGN KEY (order_test_id) REFERENCES public.lab_order_test(id) ON DELETE CASCADE;


--
-- Name: lab_employee_settings fk_lab_employee_settings_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_employee_settings
    ADD CONSTRAINT fk_lab_employee_settings_employee_id FOREIGN KEY (employee_id) REFERENCES public.org_employee(id) ON DELETE CASCADE;


--
-- Name: lab_eucast_breakpoint fk_lab_eucast_breakpoint_antibiotic_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_eucast_breakpoint
    ADD CONSTRAINT fk_lab_eucast_breakpoint_antibiotic_id FOREIGN KEY (antibiotic_id) REFERENCES public.lab_antibiotic(id) ON DELETE CASCADE;


--
-- Name: lab_eucast_breakpoint fk_lab_eucast_breakpoint_organism_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_eucast_breakpoint
    ADD CONSTRAINT fk_lab_eucast_breakpoint_organism_id FOREIGN KEY (organism_id) REFERENCES public.lab_micro_organism(id) ON DELETE CASCADE;


--
-- Name: lab_invoice fk_lab_invoice_payer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_invoice
    ADD CONSTRAINT fk_lab_invoice_payer_id FOREIGN KEY (payer_id) REFERENCES public.lab_payer(id) ON DELETE CASCADE;


--
-- Name: lab_isolate fk_lab_isolate_culture_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_isolate
    ADD CONSTRAINT fk_lab_isolate_culture_order_id FOREIGN KEY (culture_order_id) REFERENCES public.lab_culture_order(id) ON DELETE CASCADE;


--
-- Name: lab_isolate fk_lab_isolate_organism_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_isolate
    ADD CONSTRAINT fk_lab_isolate_organism_id FOREIGN KEY (organism_id) REFERENCES public.lab_micro_organism(id) ON DELETE CASCADE;


--
-- Name: lab_order_attachment fk_lab_order_attachment_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_attachment
    ADD CONSTRAINT fk_lab_order_attachment_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_order_charge fk_lab_order_charge_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_charge
    ADD CONSTRAINT fk_lab_order_charge_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_order_charge fk_lab_order_charge_payer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_charge
    ADD CONSTRAINT fk_lab_order_charge_payer_id FOREIGN KEY (payer_id) REFERENCES public.lab_payer(id) ON DELETE CASCADE;


--
-- Name: lab_order fk_lab_order_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_department_id FOREIGN KEY (department_id) REFERENCES public.tn_division(id);


--
-- Name: lab_order fk_lab_order_diagnostic_report_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_diagnostic_report_id FOREIGN KEY (diagnostic_report_id) REFERENCES public.mis_diagnostic_report(id);


--
-- Name: lab_order fk_lab_order_doctor_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_doctor_id FOREIGN KEY (doctor_id) REFERENCES public.org_employee(id);


--
-- Name: lab_order fk_lab_order_ehealth_referral_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_ehealth_referral_id FOREIGN KEY (ehealth_referral_id) REFERENCES public.ehe_incoming_medical_referral(id);


--
-- Name: lab_order fk_lab_order_paper_referral_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_paper_referral_id FOREIGN KEY (paper_referral_id) REFERENCES public.ehe_paper_medical_referral(id);


--
-- Name: lab_order fk_lab_order_patient_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_patient_id FOREIGN KEY (patient_id) REFERENCES public.ord_patient(id) ON DELETE CASCADE;


--
-- Name: lab_order fk_lab_order_payer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_payer_id FOREIGN KEY (payer_id) REFERENCES public.lab_payer(id);


--
-- Name: lab_order fk_lab_order_requester_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order
    ADD CONSTRAINT fk_lab_order_requester_id FOREIGN KEY (requester_id) REFERENCES public.ord_requester(id);


--
-- Name: lab_order_sample fk_lab_order_sample_biomaterial_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT fk_lab_order_sample_biomaterial_type_id FOREIGN KEY (biomaterial_type_id) REFERENCES public.lab_biomaterial_type(id) ON DELETE CASCADE;


--
-- Name: lab_order_sample fk_lab_order_sample_lab_section_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT fk_lab_order_sample_lab_section_id FOREIGN KEY (lab_section_id) REFERENCES public.lab_section(id);


--
-- Name: lab_order_sample fk_lab_order_sample_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT fk_lab_order_sample_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_order_sample fk_lab_order_sample_parent_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT fk_lab_order_sample_parent_sample_id FOREIGN KEY (parent_sample_id) REFERENCES public.lab_order_sample(id) ON DELETE RESTRICT;


--
-- Name: lab_order_sample fk_lab_order_sample_tube_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_sample
    ADD CONSTRAINT fk_lab_order_sample_tube_type_id FOREIGN KEY (tube_type_id) REFERENCES public.lab_tube_type(id) ON DELETE CASCADE;


--
-- Name: lab_order_test fk_lab_order_test_assigned_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_assigned_analyzer_id FOREIGN KEY (assigned_analyzer_id) REFERENCES public.lab_analyzer(id);


--
-- Name: lab_order_test fk_lab_order_test_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_order_test fk_lab_order_test_performer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_performer_id FOREIGN KEY (performer_id) REFERENCES public.lab_performer(id);


--
-- Name: lab_order_test fk_lab_order_test_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_profile_id FOREIGN KEY (profile_id) REFERENCES public.lab_test_profile(id);


--
-- Name: lab_order_test fk_lab_order_test_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id);


--
-- Name: lab_order_test fk_lab_order_test_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_order_test
    ADD CONSTRAINT fk_lab_order_test_test_id FOREIGN KEY (test_id) REFERENCES public.lab_test_definition(id) ON DELETE CASCADE;


--
-- Name: lab_payer fk_lab_payer_price_list_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_payer
    ADD CONSTRAINT fk_lab_payer_price_list_id FOREIGN KEY (price_list_id) REFERENCES public.lab_price_list(id);


--
-- Name: lab_payment fk_lab_payment_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_payment
    ADD CONSTRAINT fk_lab_payment_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_performer fk_lab_performer_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_performer
    ADD CONSTRAINT fk_lab_performer_department_id FOREIGN KEY (department_id) REFERENCES public.tn_division(id) ON DELETE SET NULL;


--
-- Name: lab_performer_test fk_lab_performer_test_performer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_performer_test
    ADD CONSTRAINT fk_lab_performer_test_performer_id FOREIGN KEY (performer_id) REFERENCES public.lab_performer(id) ON DELETE CASCADE;


--
-- Name: lab_performer_test fk_lab_performer_test_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_performer_test
    ADD CONSTRAINT fk_lab_performer_test_test_id FOREIGN KEY (test_id) REFERENCES public.lab_test_definition(id) ON DELETE CASCADE;


--
-- Name: lab_price_list_item fk_lab_price_list_item_price_list_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_price_list_item
    ADD CONSTRAINT fk_lab_price_list_item_price_list_id FOREIGN KEY (price_list_id) REFERENCES public.lab_price_list(id) ON DELETE CASCADE;


--
-- Name: lab_price_package fk_lab_price_package_price_list_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_price_package
    ADD CONSTRAINT fk_lab_price_package_price_list_id FOREIGN KEY (price_list_id) REFERENCES public.lab_price_list(id) ON DELETE CASCADE;


--
-- Name: lab_qc_material fk_lab_qc_material_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_material
    ADD CONSTRAINT fk_lab_qc_material_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id) ON DELETE CASCADE;


--
-- Name: lab_qc_result fk_lab_qc_result_qc_material_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_result
    ADD CONSTRAINT fk_lab_qc_result_qc_material_id FOREIGN KEY (qc_material_id) REFERENCES public.lab_qc_material(id) ON DELETE CASCADE;


--
-- Name: lab_qc_target fk_lab_qc_target_qc_material_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_qc_target
    ADD CONSTRAINT fk_lab_qc_target_qc_material_id FOREIGN KEY (qc_material_id) REFERENCES public.lab_qc_material(id) ON DELETE CASCADE;


--
-- Name: lab_reagent_lot fk_lab_reagent_lot_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_reagent_lot
    ADD CONSTRAINT fk_lab_reagent_lot_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id);


--
-- Name: lab_sample_logistics fk_lab_sample_logistics_destination_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics
    ADD CONSTRAINT fk_lab_sample_logistics_destination_department_id FOREIGN KEY (destination_department_id) REFERENCES public.tn_division(id) ON DELETE CASCADE;


--
-- Name: lab_sample_logistics_item fk_lab_sample_logistics_item_logistics_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics_item
    ADD CONSTRAINT fk_lab_sample_logistics_item_logistics_id FOREIGN KEY (logistics_id) REFERENCES public.lab_sample_logistics(id) ON DELETE CASCADE;


--
-- Name: lab_sample_logistics_item fk_lab_sample_logistics_item_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics_item
    ADD CONSTRAINT fk_lab_sample_logistics_item_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id) ON DELETE CASCADE;


--
-- Name: lab_sample_logistics fk_lab_sample_logistics_origin_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_logistics
    ADD CONSTRAINT fk_lab_sample_logistics_origin_department_id FOREIGN KEY (origin_department_id) REFERENCES public.tn_division(id) ON DELETE CASCADE;


--
-- Name: lab_sample_stage_event fk_lab_sample_stage_event_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_sample_stage_event
    ADD CONSTRAINT fk_lab_sample_stage_event_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id) ON DELETE CASCADE;


--
-- Name: lab_section fk_lab_section_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section
    ADD CONSTRAINT fk_lab_section_department_id FOREIGN KEY (department_id) REFERENCES public.tn_division(id);


--
-- Name: lab_section_journal_entry fk_lab_section_journal_entry_lab_section_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section_journal_entry
    ADD CONSTRAINT fk_lab_section_journal_entry_lab_section_id FOREIGN KEY (lab_section_id) REFERENCES public.lab_section(id) ON DELETE CASCADE;


--
-- Name: lab_section_journal_entry fk_lab_section_journal_entry_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section_journal_entry
    ADD CONSTRAINT fk_lab_section_journal_entry_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: lab_section_journal_entry fk_lab_section_journal_entry_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_section_journal_entry
    ADD CONSTRAINT fk_lab_section_journal_entry_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id);


--
-- Name: lab_send_out_item fk_lab_send_out_item_order_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out_item
    ADD CONSTRAINT fk_lab_send_out_item_order_test_id FOREIGN KEY (order_test_id) REFERENCES public.lab_order_test(id) ON DELETE CASCADE;


--
-- Name: lab_send_out_item fk_lab_send_out_item_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out_item
    ADD CONSTRAINT fk_lab_send_out_item_sample_id FOREIGN KEY (sample_id) REFERENCES public.lab_order_sample(id);


--
-- Name: lab_send_out_item fk_lab_send_out_item_send_out_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out_item
    ADD CONSTRAINT fk_lab_send_out_item_send_out_id FOREIGN KEY (send_out_id) REFERENCES public.lab_send_out(id) ON DELETE CASCADE;


--
-- Name: lab_send_out fk_lab_send_out_performer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_send_out
    ADD CONSTRAINT fk_lab_send_out_performer_id FOREIGN KEY (performer_id) REFERENCES public.lab_performer(id) ON DELETE CASCADE;


--
-- Name: lab_susceptibility_result fk_lab_susceptibility_result_antibiotic_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_susceptibility_result
    ADD CONSTRAINT fk_lab_susceptibility_result_antibiotic_id FOREIGN KEY (antibiotic_id) REFERENCES public.lab_antibiotic(id) ON DELETE CASCADE;


--
-- Name: lab_susceptibility_result fk_lab_susceptibility_result_isolate_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_susceptibility_result
    ADD CONSTRAINT fk_lab_susceptibility_result_isolate_id FOREIGN KEY (isolate_id) REFERENCES public.lab_isolate(id) ON DELETE CASCADE;


--
-- Name: lab_test_definition fk_lab_test_definition_biomaterial_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_definition
    ADD CONSTRAINT fk_lab_test_definition_biomaterial_type_id FOREIGN KEY (biomaterial_type_id) REFERENCES public.lab_biomaterial_type(id) ON DELETE CASCADE;


--
-- Name: lab_test_definition fk_lab_test_definition_lab_section_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_definition
    ADD CONSTRAINT fk_lab_test_definition_lab_section_id FOREIGN KEY (lab_section_id) REFERENCES public.lab_section(id);


--
-- Name: lab_test_definition fk_lab_test_definition_method_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_definition
    ADD CONSTRAINT fk_lab_test_definition_method_id FOREIGN KEY (method_id) REFERENCES public.lab_method_type(id);


--
-- Name: lab_test_definition fk_lab_test_definition_tube_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_definition
    ADD CONSTRAINT fk_lab_test_definition_tube_type_id FOREIGN KEY (tube_type_id) REFERENCES public.lab_tube_type(id);


--
-- Name: lab_test_profile fk_lab_test_profile_ehealth_service_catalog_service_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile
    ADD CONSTRAINT fk_lab_test_profile_ehealth_service_catalog_service_id FOREIGN KEY (ehealth_service_catalog_service_id) REFERENCES public.ehe_service_catalog_service(id);


--
-- Name: lab_test_profile_item fk_lab_test_profile_item_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile_item
    ADD CONSTRAINT fk_lab_test_profile_item_profile_id FOREIGN KEY (profile_id) REFERENCES public.lab_test_profile(id) ON DELETE CASCADE;


--
-- Name: lab_test_profile_item fk_lab_test_profile_item_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile_item
    ADD CONSTRAINT fk_lab_test_profile_item_test_id FOREIGN KEY (test_id) REFERENCES public.lab_test_definition(id) ON DELETE CASCADE;


--
-- Name: lab_test_profile fk_lab_test_profile_organization_service_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_profile
    ADD CONSTRAINT fk_lab_test_profile_organization_service_id FOREIGN KEY (organization_service_id) REFERENCES public.org_organization_service(id);


--
-- Name: lab_test_result fk_lab_test_result_analyzer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_result
    ADD CONSTRAINT fk_lab_test_result_analyzer_id FOREIGN KEY (analyzer_id) REFERENCES public.lab_analyzer(id);


--
-- Name: lab_test_result fk_lab_test_result_order_test_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.lab_test_result
    ADD CONSTRAINT fk_lab_test_result_order_test_id FOREIGN KEY (order_test_id) REFERENCES public.lab_order_test(id) ON DELETE CASCADE;


--
-- Name: mis_patient_insurance fk_mis_patient_insurance_patient_card_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.mis_patient_insurance
    ADD CONSTRAINT fk_mis_patient_insurance_patient_card_id FOREIGN KEY (patient_card_id) REFERENCES public.ord_patient(id) ON DELETE CASCADE;


--
-- Name: mis_patient_insurance fk_mis_patient_insurance_payer_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.mis_patient_insurance
    ADD CONSTRAINT fk_mis_patient_insurance_payer_id FOREIGN KEY (payer_id) REFERENCES public.lab_payer(id) ON DELETE CASCADE;


--
-- Name: ord_order_identifier fk_ord_order_identifier_order_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_order_identifier
    ADD CONSTRAINT fk_ord_order_identifier_order_id FOREIGN KEY (order_id) REFERENCES public.lab_order(id) ON DELETE CASCADE;


--
-- Name: ord_order_identifier fk_ord_order_identifier_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_order_identifier
    ADD CONSTRAINT fk_ord_order_identifier_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: ord_patient_identifier fk_ord_patient_identifier_patient_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_identifier
    ADD CONSTRAINT fk_ord_patient_identifier_patient_id FOREIGN KEY (patient_id) REFERENCES public.ord_patient(id) ON DELETE CASCADE;


--
-- Name: ord_patient_identifier fk_ord_patient_identifier_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_identifier
    ADD CONSTRAINT fk_ord_patient_identifier_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: ord_patient_insurance fk_ord_patient_insurance_patient_card_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_insurance
    ADD CONSTRAINT fk_ord_patient_insurance_patient_card_id FOREIGN KEY (patient_card_id) REFERENCES public.ord_patient(id) ON DELETE CASCADE;


--
-- Name: ord_patient_insurance fk_ord_patient_insurance_payer_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_insurance
    ADD CONSTRAINT fk_ord_patient_insurance_payer_id FOREIGN KEY (payer_id) REFERENCES public.lab_payer(id) ON DELETE CASCADE;


--
-- Name: ord_patient_insurance fk_ord_patient_insurance_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_patient_insurance
    ADD CONSTRAINT fk_ord_patient_insurance_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: ord_patient fk_ord_patient_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.ord_patient
    ADD CONSTRAINT fk_ord_patient_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: ord_requester fk_ord_requester_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.ord_requester
    ADD CONSTRAINT fk_ord_requester_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tn_tenant(id) ON DELETE RESTRICT;


--
-- Name: org_employee fk_org_employee_department_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_employee
    ADD CONSTRAINT fk_org_employee_department_id FOREIGN KEY (department_id) REFERENCES public.tn_division(id);


--
-- Name: org_employee fk_org_employee_membership_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_employee
    ADD CONSTRAINT fk_org_employee_membership_id FOREIGN KEY (membership_id) REFERENCES public.id_membership(id) ON DELETE RESTRICT;


--
-- Name: org_employee fk_org_employee_person_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_employee
    ADD CONSTRAINT fk_org_employee_person_id FOREIGN KEY (person_id) REFERENCES public.cmn_person(id) ON DELETE CASCADE;


--
-- Name: org_employee fk_org_employee_position_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.org_employee
    ADD CONSTRAINT fk_org_employee_position_type_id FOREIGN KEY (position_type_id) REFERENCES public.cmn_enum_record(id) ON DELETE CASCADE;


--
-- Name: sys_field_right fk_sys_field_right_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_field_right
    ADD CONSTRAINT fk_sys_field_right_right_id FOREIGN KEY (right_id) REFERENCES public.sys_right(id) ON DELETE CASCADE;


--
-- Name: sys_profile_operation_right fk_sys_profile_operation_right_operation_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_operation_right
    ADD CONSTRAINT fk_sys_profile_operation_right_operation_right_id FOREIGN KEY (operation_right_id) REFERENCES public.sys_operation_right(id) ON DELETE CASCADE;


--
-- Name: sys_profile_operation_right fk_sys_profile_operation_right_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_operation_right
    ADD CONSTRAINT fk_sys_profile_operation_right_profile_id FOREIGN KEY (profile_id) REFERENCES public.sys_profile(id) ON DELETE CASCADE;


--
-- Name: sys_profile_right fk_sys_profile_right_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_right
    ADD CONSTRAINT fk_sys_profile_right_profile_id FOREIGN KEY (profile_id) REFERENCES public.sys_profile(id) ON DELETE CASCADE;


--
-- Name: sys_profile_right fk_sys_profile_right_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_right
    ADD CONSTRAINT fk_sys_profile_right_right_id FOREIGN KEY (right_id) REFERENCES public.sys_right(id) ON DELETE CASCADE;


--
-- Name: sys_profile_role fk_sys_profile_role_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_role
    ADD CONSTRAINT fk_sys_profile_role_profile_id FOREIGN KEY (profile_id) REFERENCES public.sys_profile(id) ON DELETE CASCADE;


--
-- Name: sys_profile_role fk_sys_profile_role_role_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_profile_role
    ADD CONSTRAINT fk_sys_profile_role_role_id FOREIGN KEY (role_id) REFERENCES public.sys_role(id) ON DELETE CASCADE;


--
-- Name: sys_role_operation_right fk_sys_role_operation_right_operation_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_operation_right
    ADD CONSTRAINT fk_sys_role_operation_right_operation_right_id FOREIGN KEY (operation_right_id) REFERENCES public.sys_operation_right(id) ON DELETE CASCADE;


--
-- Name: sys_role_operation_right fk_sys_role_operation_right_role_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_operation_right
    ADD CONSTRAINT fk_sys_role_operation_right_role_id FOREIGN KEY (role_id) REFERENCES public.sys_role(id) ON DELETE CASCADE;


--
-- Name: sys_role_right fk_sys_role_right_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_right
    ADD CONSTRAINT fk_sys_role_right_right_id FOREIGN KEY (right_id) REFERENCES public.sys_right(id) ON DELETE CASCADE;


--
-- Name: sys_role_right fk_sys_role_right_role_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_role_right
    ADD CONSTRAINT fk_sys_role_right_role_id FOREIGN KEY (role_id) REFERENCES public.sys_role(id) ON DELETE CASCADE;


--
-- Name: sys_row_level_right fk_sys_row_level_right_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_row_level_right
    ADD CONSTRAINT fk_sys_row_level_right_profile_id FOREIGN KEY (profile_id) REFERENCES public.sys_profile(id) ON DELETE CASCADE;


--
-- Name: sys_row_level_security_object fk_sys_row_level_security_object_row_level_right_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_row_level_security_object
    ADD CONSTRAINT fk_sys_row_level_security_object_row_level_right_id FOREIGN KEY (row_level_right_id) REFERENCES public.sys_row_level_right(id) ON DELETE CASCADE;


--
-- Name: sys_user_profile fk_sys_user_profile_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: lab_migrator
--

ALTER TABLE ONLY public.sys_user_profile
    ADD CONSTRAINT fk_sys_user_profile_profile_id FOREIGN KEY (profile_id) REFERENCES public.sys_profile(id) ON DELETE CASCADE;


--
-- Name: tn_division fk_tn_division_department_type_id; Type: FK CONSTRAINT; Schema: public; Owner: lis
--

ALTER TABLE ONLY public.tn_division
    ADD CONSTRAINT fk_tn_division_department_type_id FOREIGN KEY (department_type_id) REFERENCES public.cmn_enum_record(id) ON DELETE SET NULL;


--
-- Name: aud_event; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.aud_event ENABLE ROW LEVEL SECURITY;

--
-- Name: ehe_incoming_medical_referral; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.ehe_incoming_medical_referral ENABLE ROW LEVEL SECURITY;

--
-- Name: ehe_paper_medical_referral; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.ehe_paper_medical_referral ENABLE ROW LEVEL SECURITY;

--
-- Name: id_device_token; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.id_device_token ENABLE ROW LEVEL SECURITY;

--
-- Name: id_invitation; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.id_invitation ENABLE ROW LEVEL SECURITY;

--
-- Name: id_membership; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.id_membership ENABLE ROW LEVEL SECURITY;

--
-- Name: id_membership_division; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.id_membership_division ENABLE ROW LEVEL SECURITY;

--
-- Name: id_membership_role; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.id_membership_role ENABLE ROW LEVEL SECURITY;

--
-- Name: ins_gateway; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.ins_gateway ENABLE ROW LEVEL SECURITY;

--
-- Name: int_api_key; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.int_api_key ENABLE ROW LEVEL SECURITY;

--
-- Name: int_client; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.int_client ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_analyzer; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_analyzer ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_analyzer_lockout; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_analyzer_lockout ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_analyzer_message; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_analyzer_message ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_analyzer_parameter_map; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_analyzer_parameter_map ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_analyzer_type; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_analyzer_type ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_antibiotic; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_antibiotic ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_archive_cell; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_archive_cell ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_archive_rack; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_archive_rack ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_audit_log; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_biomaterial_type; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_biomaterial_type ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_connector_command; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_connector_command ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_connector_installation; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_connector_installation ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_connector_log; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_connector_log ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_culture_order; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_culture_order ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_ehealth_exchange_log; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_ehealth_exchange_log ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_employee_settings; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_employee_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_eucast_breakpoint; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_eucast_breakpoint ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_invoice; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_invoice ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_isolate; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_isolate ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_method_type; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_method_type ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_micro_organism; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_micro_organism ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_numerator; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_numerator ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order_attachment; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order_attachment ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order_charge; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order_charge ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order_favorite; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order_favorite ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order_sample; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order_sample ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_order_test; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_order_test ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_panic_call; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_panic_call ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_patient_notification; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_patient_notification ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_payer; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_payer ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_payment; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_payment ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_performer; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_performer ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_performer_test; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_performer_test ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_price_list; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_price_list ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_price_list_item; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_price_list_item ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_price_package; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_price_package ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_qc_material; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_qc_material ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_qc_result; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_qc_result ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_qc_target; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_qc_target ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_reagent_lot; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_reagent_lot ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_reference_layer; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_reference_layer ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_reflex_rule; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_reflex_rule ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_result_history; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_result_history ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_sample_logistics; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_sample_logistics ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_sample_logistics_item; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_sample_logistics_item ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_sample_stage_event; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_sample_stage_event ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_section; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_section ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_section_journal_entry; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_section_journal_entry ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_send_out; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_send_out ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_send_out_item; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_send_out_item ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_settings; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_susceptibility_result; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_susceptibility_result ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_test_definition; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_test_definition ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_test_profile; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_test_profile ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_test_profile_item; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_test_profile_item ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_test_result; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_test_result ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_tube_type; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_tube_type ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_unmatched_result; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_unmatched_result ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_workflow_template; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_workflow_template ENABLE ROW LEVEL SECURITY;

--
-- Name: lab_worklist_batch; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.lab_worklist_batch ENABLE ROW LEVEL SECURITY;

--
-- Name: mis_diagnostic_report; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.mis_diagnostic_report ENABLE ROW LEVEL SECURITY;

--
-- Name: mis_patient_insurance; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.mis_patient_insurance ENABLE ROW LEVEL SECURITY;

--
-- Name: ord_order_identifier; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.ord_order_identifier ENABLE ROW LEVEL SECURITY;

--
-- Name: ord_patient; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.ord_patient ENABLE ROW LEVEL SECURITY;

--
-- Name: ord_patient_identifier; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.ord_patient_identifier ENABLE ROW LEVEL SECURITY;

--
-- Name: ord_patient_insurance; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.ord_patient_insurance ENABLE ROW LEVEL SECURITY;

--
-- Name: ord_requester; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.ord_requester ENABLE ROW LEVEL SECURITY;

--
-- Name: org_employee; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.org_employee ENABLE ROW LEVEL SECURITY;

--
-- Name: org_organization_service; Type: ROW SECURITY; Schema: public; Owner: lab_migrator
--

ALTER TABLE public.org_organization_service ENABLE ROW LEVEL SECURITY;

--
-- Name: aud_event tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.aud_event USING (((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid) OR ((tenant_id IS NULL) AND (current_setting('app.is_platform_admin'::text, false) = 'true'::text))));


--
-- Name: ehe_incoming_medical_referral tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.ehe_incoming_medical_referral USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: ehe_paper_medical_referral tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.ehe_paper_medical_referral USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: id_device_token tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.id_device_token USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: id_invitation tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.id_invitation USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: id_membership tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.id_membership USING (((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid) OR (user_id = (NULLIF(current_setting('app.user_id'::text, false), ''::text))::uuid)));


--
-- Name: id_membership_division tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.id_membership_division USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: id_membership_role tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.id_membership_role USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: ins_gateway tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.ins_gateway USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: int_api_key tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.int_api_key USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: int_client tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.int_client USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: lab_analyzer tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_analyzer USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_analyzer_lockout tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_analyzer_lockout USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_analyzer_message tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_analyzer_message USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_analyzer_parameter_map tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_analyzer_parameter_map USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_analyzer_type tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_analyzer_type USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_antibiotic tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_antibiotic USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_archive_cell tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_archive_cell USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_archive_rack tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_archive_rack USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_audit_log tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_audit_log USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_biomaterial_type tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_biomaterial_type USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_connector_command tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_connector_command USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_connector_installation tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_connector_installation USING ((public.lis_tenant_guard() AND ((tenant_id = public.lis_current_tenant()) OR (((api_key_hash)::text = NULLIF(current_setting('app.connector_api_key_hash'::text, true), ''::text)) OR ((install_key)::text = NULLIF(current_setting('app.connector_install_key'::text, true), ''::text)))))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_connector_log tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_connector_log USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_culture_order tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_culture_order USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_ehealth_exchange_log tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_ehealth_exchange_log USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_employee_settings tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_employee_settings USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_eucast_breakpoint tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_eucast_breakpoint USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_invoice tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_invoice USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_isolate tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_isolate USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_method_type tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_method_type USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_micro_organism tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_micro_organism USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_numerator tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_numerator USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order USING ((public.lis_tenant_guard() AND ((tenant_id = public.lis_current_tenant()) OR ((verify_token)::text = NULLIF(current_setting('app.verify_token'::text, true), ''::text))))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order_attachment tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order_attachment USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order_charge tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order_charge USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order_favorite tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order_favorite USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order_sample tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order_sample USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_order_test tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_order_test USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_panic_call tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_panic_call USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_patient_notification tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_patient_notification USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_payer tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_payer USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_payment tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_payment USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_performer tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_performer USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_performer_test tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_performer_test USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_price_list tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_price_list USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_price_list_item tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_price_list_item USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_price_package tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_price_package USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_qc_material tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_qc_material USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_qc_result tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_qc_result USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_qc_target tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_qc_target USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_reagent_lot tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_reagent_lot USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_reference_layer tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_reference_layer USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_reflex_rule tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_reflex_rule USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_result_history tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_result_history USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_sample_logistics tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_sample_logistics USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_sample_logistics_item tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_sample_logistics_item USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_sample_stage_event tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_sample_stage_event USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_section tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_section USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_section_journal_entry tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_section_journal_entry USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_send_out tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_send_out USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_send_out_item tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_send_out_item USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_settings tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_settings USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_susceptibility_result tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_susceptibility_result USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_test_definition tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_test_definition USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_test_profile tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_test_profile USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_test_profile_item tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_test_profile_item USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_test_result tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_test_result USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_tube_type tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_tube_type USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_unmatched_result tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_unmatched_result USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_workflow_template tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_workflow_template USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: lab_worklist_batch tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.lab_worklist_batch USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: mis_diagnostic_report tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.mis_diagnostic_report USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: mis_patient_insurance tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.mis_patient_insurance USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: ord_order_identifier tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.ord_order_identifier USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: ord_patient tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.ord_patient USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: ord_patient_identifier tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.ord_patient_identifier USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: ord_patient_insurance tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.ord_patient_insurance USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: ord_requester tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.ord_requester USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: org_employee tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.org_employee USING ((public.lis_tenant_guard() AND ((tenant_id = public.lis_current_tenant()) OR ((person_id)::text IN ( SELECT p.id
   FROM public.cmn_person p
  WHERE (p.user_id = NULLIF(current_setting('app.user_id'::text, true), ''::text))))))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: org_organization_service tenant_isolation; Type: POLICY; Schema: public; Owner: lab_migrator
--

CREATE POLICY tenant_isolation ON public.org_organization_service USING ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant()))) WITH CHECK ((public.lis_tenant_guard() AND (tenant_id = public.lis_current_tenant())));


--
-- Name: tn_division tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.tn_division USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: tn_requisites tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.tn_requisites USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: tn_sequence tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.tn_sequence USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: tn_settings tenant_isolation; Type: POLICY; Schema: public; Owner: lis
--

CREATE POLICY tenant_isolation ON public.tn_settings USING ((tenant_id = (NULLIF(current_setting('app.tenant_id'::text, false), ''::text))::uuid));


--
-- Name: tn_division; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.tn_division ENABLE ROW LEVEL SECURITY;

--
-- Name: tn_requisites; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.tn_requisites ENABLE ROW LEVEL SECURITY;

--
-- Name: tn_sequence; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.tn_sequence ENABLE ROW LEVEL SECURITY;

--
-- Name: tn_settings; Type: ROW SECURITY; Schema: public; Owner: lis
--

ALTER TABLE public.tn_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO lis_app;
GRANT USAGE ON SCHEMA public TO lab_app;


--
-- Name: FUNCTION aud_event_append_only(); Type: ACL; Schema: public; Owner: lis
--

GRANT ALL ON FUNCTION public.aud_event_append_only() TO lab_app;


--
-- Name: FUNCTION lis_current_tenant(); Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT ALL ON FUNCTION public.lis_current_tenant() TO lab_app;


--
-- Name: FUNCTION lis_tenant_guard(); Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT ALL ON FUNCTION public.lis_tenant_guard() TO lab_app;


--
-- Name: TABLE aud_event; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT ON TABLE public.aud_event TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.aud_event TO lab_app;


--
-- Name: TABLE cmn_enum_record; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cmn_enum_record TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cmn_enum_record TO lis_app;


--
-- Name: TABLE cmn_person; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cmn_person TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cmn_person TO lis_app;


--
-- Name: TABLE ehd_dictionary; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehd_dictionary TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehd_dictionary TO lis_app;


--
-- Name: TABLE ehe_incoming_medical_referral; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_incoming_medical_referral TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_incoming_medical_referral TO lis_app;


--
-- Name: TABLE ehe_medical_referral_category; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_medical_referral_category TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_medical_referral_category TO lis_app;


--
-- Name: TABLE ehe_medical_service_program; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_medical_service_program TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_medical_service_program TO lis_app;


--
-- Name: TABLE ehe_paper_medical_referral; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_paper_medical_referral TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_paper_medical_referral TO lis_app;


--
-- Name: TABLE ehe_service_catalog_service; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_service_catalog_service TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ehe_service_catalog_service TO lis_app;


--
-- Name: TABLE id_device_token; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_device_token TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_device_token TO lab_app;


--
-- Name: TABLE id_invitation; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_invitation TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_invitation TO lab_app;


--
-- Name: TABLE id_membership; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership TO lab_app;


--
-- Name: TABLE id_membership_division; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership_division TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership_division TO lab_app;


--
-- Name: TABLE id_membership_role; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership_role TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_membership_role TO lab_app;


--
-- Name: TABLE id_permission; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_permission TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_permission TO lab_app;


--
-- Name: TABLE id_role; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_role TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_role TO lab_app;


--
-- Name: TABLE id_role_permission; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_role_permission TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_role_permission TO lab_app;


--
-- Name: TABLE id_user; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_user TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.id_user TO lab_app;


--
-- Name: TABLE ins_gateway; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ins_gateway TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ins_gateway TO lab_app;


--
-- Name: TABLE int_api_key; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.int_api_key TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.int_api_key TO lab_app;


--
-- Name: TABLE int_client; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.int_client TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.int_client TO lab_app;


--
-- Name: TABLE lab_analyzer; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer TO lis_app;


--
-- Name: TABLE lab_analyzer_lockout; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_lockout TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_lockout TO lis_app;


--
-- Name: TABLE lab_analyzer_message; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_message TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_message TO lis_app;


--
-- Name: TABLE lab_analyzer_parameter_map; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_parameter_map TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_parameter_map TO lis_app;


--
-- Name: TABLE lab_analyzer_type; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_type TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_analyzer_type TO lis_app;


--
-- Name: TABLE lab_antibiotic; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_antibiotic TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_antibiotic TO lis_app;


--
-- Name: TABLE lab_archive_cell; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_archive_cell TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_archive_cell TO lis_app;


--
-- Name: TABLE lab_archive_rack; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_archive_rack TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_archive_rack TO lis_app;


--
-- Name: TABLE lab_audit_log; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_audit_log TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_audit_log TO lis_app;


--
-- Name: TABLE lab_biomaterial_type; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_biomaterial_type TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_biomaterial_type TO lis_app;


--
-- Name: TABLE lab_connector_command; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_command TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_command TO lis_app;


--
-- Name: TABLE lab_connector_installation; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_installation TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_installation TO lis_app;


--
-- Name: TABLE lab_connector_log; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_log TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_connector_log TO lis_app;


--
-- Name: TABLE lab_culture_order; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_culture_order TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_culture_order TO lis_app;


--
-- Name: TABLE lab_ehealth_exchange_log; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_ehealth_exchange_log TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_ehealth_exchange_log TO lis_app;


--
-- Name: TABLE lab_employee_settings; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_employee_settings TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_employee_settings TO lis_app;


--
-- Name: TABLE lab_eucast_breakpoint; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_eucast_breakpoint TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_eucast_breakpoint TO lis_app;


--
-- Name: TABLE lab_invoice; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_invoice TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_invoice TO lis_app;


--
-- Name: TABLE lab_isolate; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_isolate TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_isolate TO lis_app;


--
-- Name: TABLE lab_method_type; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_method_type TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_method_type TO lis_app;


--
-- Name: TABLE lab_micro_organism; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_micro_organism TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_micro_organism TO lis_app;


--
-- Name: TABLE lab_numerator; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_numerator TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_numerator TO lis_app;


--
-- Name: TABLE lab_order; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order TO lis_app;


--
-- Name: TABLE lab_order_attachment; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_attachment TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_attachment TO lis_app;


--
-- Name: TABLE lab_order_charge; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_charge TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_charge TO lis_app;


--
-- Name: TABLE lab_order_favorite; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_favorite TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_favorite TO lis_app;


--
-- Name: TABLE lab_order_sample; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_sample TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_sample TO lis_app;


--
-- Name: TABLE lab_order_test; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_test TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_order_test TO lis_app;


--
-- Name: TABLE lab_panic_call; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_panic_call TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_panic_call TO lis_app;


--
-- Name: TABLE lab_patient_notification; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_patient_notification TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_patient_notification TO lis_app;


--
-- Name: TABLE lab_payer; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_payer TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_payer TO lis_app;


--
-- Name: TABLE lab_payment; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_payment TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_payment TO lis_app;


--
-- Name: TABLE lab_performer; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_performer TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_performer TO lis_app;


--
-- Name: TABLE lab_performer_test; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_performer_test TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_performer_test TO lis_app;


--
-- Name: TABLE lab_price_list; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_list TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_list TO lis_app;


--
-- Name: TABLE lab_price_list_item; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_list_item TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_list_item TO lis_app;


--
-- Name: TABLE lab_price_package; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_package TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_price_package TO lis_app;


--
-- Name: TABLE lab_qc_material; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_material TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_material TO lis_app;


--
-- Name: TABLE lab_qc_result; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_result TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_result TO lis_app;


--
-- Name: TABLE lab_qc_target; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_target TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_qc_target TO lis_app;


--
-- Name: TABLE lab_reagent_lot; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reagent_lot TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reagent_lot TO lis_app;


--
-- Name: TABLE lab_reference_layer; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reference_layer TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reference_layer TO lis_app;


--
-- Name: TABLE lab_reflex_rule; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reflex_rule TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_reflex_rule TO lis_app;


--
-- Name: TABLE lab_result_history; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_result_history TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_result_history TO lis_app;


--
-- Name: TABLE lab_sample_logistics; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_logistics TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_logistics TO lis_app;


--
-- Name: TABLE lab_sample_logistics_item; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_logistics_item TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_logistics_item TO lis_app;


--
-- Name: TABLE lab_sample_stage_event; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_stage_event TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_sample_stage_event TO lis_app;


--
-- Name: TABLE lab_section; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_section TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_section TO lis_app;


--
-- Name: TABLE lab_section_journal_entry; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_section_journal_entry TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_section_journal_entry TO lis_app;


--
-- Name: TABLE lab_send_out; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_send_out TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_send_out TO lis_app;


--
-- Name: TABLE lab_send_out_item; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_send_out_item TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_send_out_item TO lis_app;


--
-- Name: TABLE lab_settings; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_settings TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_settings TO lis_app;


--
-- Name: TABLE lab_susceptibility_result; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_susceptibility_result TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_susceptibility_result TO lis_app;


--
-- Name: TABLE lab_test_definition; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_definition TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_definition TO lis_app;


--
-- Name: TABLE lab_test_profile; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_profile TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_profile TO lis_app;


--
-- Name: TABLE lab_test_profile_item; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_profile_item TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_profile_item TO lis_app;


--
-- Name: TABLE lab_test_result; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_result TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_test_result TO lis_app;


--
-- Name: TABLE lab_tube_type; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_tube_type TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_tube_type TO lis_app;


--
-- Name: TABLE lab_unmatched_result; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_unmatched_result TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_unmatched_result TO lis_app;


--
-- Name: TABLE lab_workflow_template; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_workflow_template TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_workflow_template TO lis_app;


--
-- Name: TABLE lab_worklist_batch; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_worklist_batch TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lab_worklist_batch TO lis_app;


--
-- Name: TABLE mis_diagnostic_report; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mis_diagnostic_report TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mis_diagnostic_report TO lis_app;


--
-- Name: TABLE mis_patient_insurance; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mis_patient_insurance TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mis_patient_insurance TO lis_app;


--
-- Name: TABLE ord_order_identifier; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_order_identifier TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_order_identifier TO lab_app;


--
-- Name: TABLE ord_patient; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient TO lis_app;


--
-- Name: TABLE ord_patient_identifier; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient_identifier TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient_identifier TO lab_app;


--
-- Name: TABLE ord_patient_insurance; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient_insurance TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_patient_insurance TO lab_app;


--
-- Name: TABLE ord_requester; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_requester TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ord_requester TO lab_app;


--
-- Name: TABLE org_employee; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_employee TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_employee TO lis_app;


--
-- Name: TABLE org_organization_service; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_organization_service TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_organization_service TO lis_app;


--
-- Name: TABLE sys_application_row_level_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_application_row_level_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_application_row_level_right TO lis_app;


--
-- Name: TABLE sys_field_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_field_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_field_right TO lis_app;


--
-- Name: TABLE sys_operation_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_operation_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_operation_right TO lis_app;


--
-- Name: TABLE sys_profile; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile TO lis_app;


--
-- Name: TABLE sys_profile_operation_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_operation_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_operation_right TO lis_app;


--
-- Name: TABLE sys_profile_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_right TO lis_app;


--
-- Name: TABLE sys_profile_role; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_role TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_profile_role TO lis_app;


--
-- Name: TABLE sys_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_right TO lis_app;


--
-- Name: TABLE sys_role; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role TO lis_app;


--
-- Name: TABLE sys_role_operation_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role_operation_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role_operation_right TO lis_app;


--
-- Name: TABLE sys_role_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_role_right TO lis_app;


--
-- Name: TABLE sys_row_level_right; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_row_level_right TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_row_level_right TO lis_app;


--
-- Name: TABLE sys_row_level_security_object; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_row_level_security_object TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_row_level_security_object TO lis_app;


--
-- Name: TABLE sys_user_default_value; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_user_default_value TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_user_default_value TO lis_app;


--
-- Name: TABLE sys_user_profile; Type: ACL; Schema: public; Owner: lab_migrator
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_user_profile TO lab_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.sys_user_profile TO lis_app;


--
-- Name: TABLE tn_division; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_division TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_division TO lab_app;


--
-- Name: TABLE tn_requisites; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_requisites TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_requisites TO lab_app;


--
-- Name: TABLE tn_sequence; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_sequence TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_sequence TO lab_app;


--
-- Name: TABLE tn_settings; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_settings TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_settings TO lab_app;


--
-- Name: TABLE tn_tenant; Type: ACL; Schema: public; Owner: lis
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_tenant TO lis_app;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tn_tenant TO lab_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: lis
--

ALTER DEFAULT PRIVILEGES FOR ROLE lis IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO lis_app;


--
-- PostgreSQL database dump complete
--

\unrestrict YrTKNCfYvO4Zoku2XaA3S7chduxNVbqHez3OQQ60U50WiHG31JKGNnoZOLxcxy2


--
-- Record applied EF Core migrations so `dotnet-ef database update` on this
-- already-fully-provisioned database is a no-op (schema already matches HEAD).
--

CREATE TABLE IF NOT EXISTS public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL,
    CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId")
);

INSERT INTO public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") VALUES
    ('20261022205819_0001_init', '8.0.10'),
    ('20261022223345_0002_tenancy', '8.0.10'),
    ('20261023153440_0003_tenancy_foundation', '8.0.10'),
    ('20261025195202_0004_lab_data_independence', '8.0.10')
ON CONFLICT ("MigrationId") DO NOTHING;
