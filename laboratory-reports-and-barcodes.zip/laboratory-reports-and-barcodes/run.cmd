@echo off
chcp 65001 > nul
echo === MedLink LIS: запуск API та інтерфейсу на http://localhost:5055 ===
cd /d "%~dp0"
dotnet tool restore && dotnet tool run dotnet-ef database update --project "%~dp0src\MedLink.LIS.Api" || exit /b 1
dotnet run --project "%~dp0src\MedLink.LIS.Api" --urls http://0.0.0.0:5055
