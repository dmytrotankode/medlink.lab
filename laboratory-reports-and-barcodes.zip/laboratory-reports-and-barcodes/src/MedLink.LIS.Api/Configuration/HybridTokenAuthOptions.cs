namespace MedLink.LIS.Api.Configuration;

public class HybridTokenAuthOptions
{
    public string? JwtBearerAudience { get; set; }

    public string? Authority { get; set; }

    public string? IntrospectionClientId { get; set; }

    public string? IntrospectionClientSecret { get; set; }

    public string? IntrospectionAudiences { get; set; }

    public bool UseRefreshTokenFlow { get; set; }

    public bool ForceOnlineIntrospectionPerRequest { get; set; }

    public bool UseRedisActiveTokenValidation { get; set; } = true;

    public string RedisActiveTokenKeyPrefix { get; set; } = SessionControlOptions.DefaultActiveTokenKeyPrefix;

    public string RedisTokenByHashKeyPrefix { get; set; } = SessionControlOptions.DefaultTokenByHashKeyPrefix;

    public bool RedisActiveTokenFallbackToIntrospection { get; set; } = true;

    public bool AuthDiagnosticsEnabled { get; set; } = true;
}
