using Core.Base.Exceptions;
using Core.Security;
using MedLink.LIS.Api.Dto.Administration;
using MedLink.LIS.Api.Services.ApplicationServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static Core.Mvc.Helpers.ControllerHelper;

namespace MedLink.LIS.Api.Controllers.adm;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
[Authorize]
public sealed class AccountController : ControllerBase
{
    private readonly AccountService _service;
    private readonly ILogger<AccountController> _logger;

    public AccountController(AccountService service, ILogger<AccountController> logger)
    {
        _service = service;
        _logger = logger;
    }

    [HttpGet("logout/")]
    [ProducesResponseType(200)]
    [AllowAnonymous]
    public async Task<IActionResult> LogoutAsync()
    {
        try
        {
            await _service.ClearCurrentUserInfoCache();
            return Ok();
        }
        catch (Exception ex)
        {
            var badRequestDetails = CreateProblemDetails(ex, 400, "Помилковий запит", "Помилка при виході із системи", _logger,
                "Error occurred while logging off user in method {MethodName}", $"{nameof(AccountController)}.{nameof(LogoutAsync)}");
            return BadRequest(badRequestDetails);
        }
    }

    [HttpPost("try-authenticate/")]
    [ProducesResponseType(200)]
    [ProducesResponseType(300)]
    [ProducesResponseType(401)]
    [AllowAnonymous]
    public async Task<IActionResult> TryAuthenticate([FromQuery] Guid? organizationId, [FromQuery] string? roleName)
    {
        try
        {
            _logger.LogInformation("TryAuthenticate started. identity_user_id={IdentityUserId}; organizationId={OrganizationId}; roleName={RoleName}",
                _service.CurrentUser?.Id ?? "n/a", organizationId, roleName);

            var userData = string.IsNullOrEmpty(roleName)
                ? await _service.GetUserDataAsync()
                : await _service.GetUserDataAsync(organizationId, roleName);

            if (userData.Count == 1)
            {
                var currentUserData = userData[0];
                return await Authenticate(new LoginInfo
                {
                    ProfileId = currentUserData.ProfileId,
                    UserId = currentUserData.UserId,
                    EhealthEmployeeId = currentUserData.EhealthEmployeeId,
                    SpecialityEhealthId = currentUserData.SpecialityEhealthId,
                    Email = currentUserData.Email,
                    LegalEntityTypeCode = currentUserData.LegalEntityTypeCode
                });
            }

            if (userData.Count > 1)
            {
                return StatusCode(300, userData);
            }

            return Unauthorized(CreateProblemDetails(401, AccountService.UnauthorizedTitle, "Користувача не авторизовано", _logger,
                "Error occurred while trying authenticate user in method {MethodName}. Application profile is not found. User id on identity server: {UserId}",
                $"{nameof(AccountController)}.{nameof(TryAuthenticate)}", _service.CurrentUser?.Id ?? "n/a"));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "TryAuthenticate failed for identity_user_id={IdentityUserId}. message={Message}", _service.CurrentUser?.Id ?? "n/a", ex.Message);
            return Unauthorized(CreateProblemDetails(ex, 401));
        }
    }

    [HttpPost("authenticate/")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [AllowAnonymous]
    public async Task<IActionResult> Authenticate(LoginInfo loginInfo)
    {
        try
        {
            var userData = await _service.AuthenticateAsync(loginInfo.ProfileId, loginInfo.UserId, loginInfo.EhealthEmployeeId, loginInfo.SpecialityEhealthId,
                loginInfo.Email, loginInfo.LegalEntityTypeCode);
            return Ok(userData);
        }
        catch (Exception ex)
        {
            var methodName = $"{nameof(AccountController)}.{nameof(Authenticate)}";
            var badRequestDetails = loginInfo == null
                ? CreateProblemDetails(ex, _logger, "Error occurred while trying authenticating user in method {MethodName}. Login data is null", methodName)
                : CreateProblemDetails(ex, _logger, "Error occurred while trying authenticating user in method {MethodName} with employee id {EmployeeId} and profile id {ProfileId}",
                    methodName, loginInfo.UserId.ToString(), loginInfo.ProfileId.ToString());
            return BadRequest(badRequestDetails);
        }
    }

    [HttpGet("info")]
    [AllowAnonymous]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> GetUserFullProfileDto()
    {
        try
        {
            return Ok(await _service.GetUserFullProfileDtoAsync());
        }
        catch (Exception ex)
        {
            return BadRequest(CreateProblemDetails(ex, _logger, $"{nameof(AccountController)}.{nameof(GetUserFullProfileDto)}"));
        }
    }

    [HttpGet("users")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> GetUsers([FromQuery] IDictionary<string, string> paramList)
    {
        IEnumerable<UsersListDto> list;
        try
        {
            list = await _service.GetUsersAsync(paramList);
        }
        catch (Exception ex)
        {
            return BadRequest(ListDetailsProblem(ex));
        }
        return Ok(list);
    }

    [HttpGet("users/ext/{id}")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    [ProducesResponseType(404)]
    public async Task<IActionResult> GetUserDetails(Guid id)
    {
        UsersListDto? item = null;
        try
        {
            if (id != Guid.Empty)
            {
                item = await _service.GetUserDetailsAsync(id);
            }
        }
        catch (Exception ex)
        {
            return BadRequest(ListDetailsProblem(ex));
        }

        if (item == null)
        {
            _logger.LogError(new EventId(404), "Error occured in controller. See exception details. Error message: {Message}", NotFoundDetailsMessage);
            return BadRequest(new ProblemDetails { Status = 404, Title = string.Empty, Detail = NotFoundDetailsMessage });
        }

        return Ok(item);
    }

    public const string NotFoundDetailsMessage = "Пацієнта було видалено із системи!";

    private ProblemDetails ListDetailsProblem(Exception ex)
    {
        switch (ex)
        {
            case NoRightsException nrex:
                _logger.LogError(new EventId(403), nrex, "Access error occured. Error message: {Message}", nrex.Message);
                return new ProblemDetails { Status = 403, Title = nrex.Title ?? "Access denied", Detail = nrex.Message };
            case AppException aex:
                _logger.LogError(new EventId(400), aex, "Error occured in controller. See exception details. Error message: {Message}", aex.Message);
                return new ProblemDetails { Status = 400, Title = aex.Title ?? "Bad request", Detail = aex.Message };
            default:
                _logger.LogError(new EventId(400), ex, "Error occured in controller. See exception details.");
                return new ProblemDetails { Status = 400, Title = "Bad request", Detail = "Error occurred (details hidden)" };
        }
    }

    [HttpGet("userProfiles")]
    [ProducesResponseType(200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> GetUserProfiles()
    {
        try
        {
            return Ok(await _service.GetUserDataAsync());
        }
        catch (Exception ex)
        {
            return BadRequest(CreateProblemDetails(ex, _logger, $"{nameof(AccountController)}.{nameof(GetUserProfiles)}"));
        }
    }

    public sealed class LoginInfo
    {
        public Guid ProfileId { get; set; }
        public Guid UserId { get; set; }
        public Guid? EhealthEmployeeId { get; set; }
        public Guid? SpecialityEhealthId { get; set; }
        public string? LegalEntityTypeCode { get; set; }
        public string? Email { get; set; }
    }
}
