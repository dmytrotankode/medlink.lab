using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Tenancy;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Data;

public static class DbContextExtensions
{
    public const string UserSetting = "app.user_id";
    public const string ConnectorApiKeyHashSetting = "app.connector_api_key_hash";
    public const string ConnectorInstallKeySetting = "app.connector_install_key";
    public const string VerifyTokenSetting = "app.verify_token";
    public const string TenantEnumerationSetting = "app.tenant_enumeration";
    private const string LookupSavepoint = "lis_lookup";
    private const string TenantSavepoint = "lis_tenant";

    public static Task<TResult> RunAsUserAsync<TResult>(this LisDbContext db, string identityUserId, Func<Task<TResult>> query, CancellationToken ct = default)
        => RunAsLookupAsync(db, UserSetting, identityUserId, query, ct);

    public static Task<TResult> RunAsConnectorApiKeyHashAsync<TResult>(this LisDbContext db, string apiKeyHash, Func<Task<TResult>> query, CancellationToken ct = default)
        => RunAsLookupAsync(db, ConnectorApiKeyHashSetting, apiKeyHash, query, ct);

    public static Task<TResult> RunAsConnectorInstallKeyAsync<TResult>(this LisDbContext db, string installKey, Func<Task<TResult>> query, CancellationToken ct = default)
        => RunAsLookupAsync(db, ConnectorInstallKeySetting, installKey, query, ct);

    public static Task<TResult> RunAsVerifyTokenAsync<TResult>(this LisDbContext db, string verifyToken, Func<Task<TResult>> query, CancellationToken ct = default)
        => RunAsLookupAsync(db, VerifyTokenSetting, verifyToken, query, ct);

    public static Task<TResult> RunAsTenantEnumerationAsync<TResult>(this LisDbContext db, Func<Task<TResult>> query, CancellationToken ct = default)
        => RunAsLookupAsync(db, TenantEnumerationSetting, "on", query, ct);

    private static async Task<TResult> RunAsLookupAsync<TResult>(LisDbContext db, string setting, string value, Func<Task<TResult>> query, CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is { } current)
        {
            await current.CreateSavepointAsync(LookupSavepoint, ct);
            try
            {
                await SetLocalAsync(db, TenantSession.TenantSetting, "", ct);
                await SetLocalAsync(db, setting, value, ct);
                return await query();
            }
            finally
            {
                await current.RollbackToSavepointAsync(LookupSavepoint, CancellationToken.None);
            }
        }
        await using var transaction = await db.Database.BeginTransactionAsync(ct);
        await SetLocalAsync(db, TenantSession.TenantSetting, "", ct);
        await SetLocalAsync(db, setting, value, ct);
        var result = await query();
        await transaction.CommitAsync(CancellationToken.None);
        return result;
    }

    public static async Task RunInTenantAsync(this LisDbContext db, Func<Task> action, CancellationToken ct = default)
    {
        var tenantId = TenantIds.Require(db.Tenant.TenantId);
        if (db.Database.CurrentTransaction is { } current)
        {
            var previous = await CurrentSettingAsync(db, TenantSession.TenantSetting, ct);
            if (previous == tenantId)
            {
                await action();
                return;
            }
            await current.CreateSavepointAsync(TenantSavepoint, ct);
            try
            {
                await SetLocalAsync(db, TenantSession.TenantSetting, tenantId, ct);
                await action();
            }
            catch
            {
                await current.RollbackToSavepointAsync(TenantSavepoint, CancellationToken.None);
                throw;
            }
            await current.ReleaseSavepointAsync(TenantSavepoint, ct);
            await SetLocalAsync(db, TenantSession.TenantSetting, previous, ct);
            return;
        }
        await using var transaction = await db.Database.BeginTransactionAsync(ct);
        await action();
        await transaction.CommitAsync(CancellationToken.None);
    }

    public static async Task<TResult> RunInTenantAsync<TResult>(this LisDbContext db, Func<Task<TResult>> action, CancellationToken ct = default)
    {
        TResult result = default!;
        await db.RunInTenantAsync(async () => { result = await action(); }, ct);
        return result;
    }

    public static async Task RunAsTenantAsync(this LisDbContext db, string tenantId, Func<Task> action, CancellationToken ct = default)
    {
        using var tenant = db.Tenant.RunAs(tenantId);
        using var division = db.Division.RunAs(null);
        await db.RunInTenantAsync(action, ct);
    }

    public static async Task<TResult> RunAsTenantAsync<TResult>(this LisDbContext db, string tenantId, Func<Task<TResult>> action, CancellationToken ct = default)
    {
        using var tenant = db.Tenant.RunAs(tenantId);
        using var division = db.Division.RunAs(null);
        return await db.RunInTenantAsync(action, ct);
    }

    public static async Task<LabSettings?> LabSettingsAsync(this LisDbContext db)
    {
        var settings = await db.Settings.AsNoTracking().FirstOrDefaultAsync();
        if (settings == null) return null;
        var requisites = await db.Requisites.AsNoTracking().FirstOrDefaultAsync();
        if (requisites != null)
        {
            settings.Name = requisites.LegalName; settings.Edrpou = requisites.Edrpou; settings.Address = requisites.Address; settings.Phone = requisites.Phone;
            settings.Email = requisites.Email; settings.LicenseNumber = requisites.LicenseNumber; settings.LogoBase64 = requisites.LogoUrl;
        }
        return settings;
    }

    public static async Task<string> EnumRecordIdAsync(this LisDbContext db, string enumType, string code) =>
        await db.EnumRecords.AsNoTracking().Where(r => r.EnumType == enumType && r.Code == code).Select(r => r.Id).SingleOrDefaultAsync()
        ?? throw new InvalidOperationException($"cmn_enum_record {enumType}/{code} не знайдено");

    public static async Task<string> ReferralCategoryIdAsync(this LisDbContext db, string code) =>
        await db.ReferralCategories.AsNoTracking().Where(c => c.Code == code).Select(c => c.Id).SingleOrDefaultAsync()
        ?? throw new InvalidOperationException($"ehe_medical_referral_category {code} не знайдено");

    private static Task SetLocalAsync(LisDbContext db, string setting, string value, CancellationToken ct) =>
        db.Database.ExecuteSqlRawAsync("SELECT set_config({0}, {1}, true)", new object[] { setting, value }, ct);

    private static Task<string> CurrentSettingAsync(LisDbContext db, string setting, CancellationToken ct) =>
        db.Database.SqlQueryRaw<string>("SELECT coalesce(current_setting({0}, true), '') AS \"Value\"", setting).SingleAsync(ct);
}
