using Core.Base.Data;
using Core.Security.Models;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Data;

public partial class LisDbContext
{
    public DbSet<FieldRight>? FieldRights { get; set; }
    public DbSet<ProfileRole>? ProfileRoles { get; set; }
    public DbSet<ProfileRight>? ProfileRights { get; set; }
    public DbSet<Profile>? SecurityProfiles { get; set; }
    DbSet<Profile>? ISecurityDbContext.Profiles { get => SecurityProfiles; set => SecurityProfiles = value; }
    public DbSet<Right>? Rights { get; set; }
    public DbSet<RoleRight>? RoleRights { get; set; }
    public DbSet<Role>? Roles { get; set; }
    public DbSet<ApplicationRowLevelRight>? ApplicationRowLevelRights { get; set; }
    public DbSet<RowLevelRight>? RowLevelRights { get; set; }
    public DbSet<RowLevelSecurityObject>? RowLevelSecurityObjects { get; set; }
    public DbSet<UserProfile>? UserProfiles { get; set; }
    public DbSet<UserDefaultValue>? UserDefaultValues { get; set; }
    public DbSet<OperationRight>? OperationRights { get; set; }
    public DbSet<ProfileOperationRight>? ProfileOperationRights { get; set; }
    public DbSet<RoleOperationRight>? RoleOperationRights { get; set; }
    public DbSet<SimpleDataDto>? SimpleDataDtos { get; set; }
}
