// [ЛІС] Лабораторні атрибути сутностей MedLink, що не мають відповідника в evomis:
// роль співробітника в ЛІС.
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedLink.LIS.Api.Data.Entities;

/// <summary>[ЛІС] lab_employee_settings — роль співробітника в ЛІС (1:1 з org_employee). В evomis роль може надаватися через sys_role/sys_user_profile.</summary>
[Table("lab_employee_settings")]
public class LabEmployeeSettings : AuditableEntity, ITenantScoped
{
    [Key, MaxLength(64)] public string EmployeeId { get; set; } = "";
    public string TenantId { get; set; } = "";
    /// <summary>LAB_ADMIN | LAB_DOCTOR | LAB_TECHNICIAN | PHLEBOTOMIST | LOGISTICS_COURIER | REGISTRAR</summary>
    [MaxLength(32)] public string LabRole { get; set; } = "LAB_TECHNICIAN";
    /// <summary>Назва посади для бланків (в evomis посада — тип position_type_id).</summary>
    [MaxLength(256)] public string? PositionName { get; set; }
    [MaxLength(128)] public string? DigitalSignatureCertId { get; set; }
    public bool IsActive { get; set; } = true;

    [ForeignKey(nameof(EmployeeId))] public OrgEmployee? Employee { get; set; }
}
