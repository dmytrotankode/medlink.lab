// =============================================================================
// [MedLink] — дзеркальні таблиці МІС MedLink (evomis) у тій самій структурі, що й в evomis
// (джерело: evomis/src/App.Data/Migrations/ApiDbContextModelSnapshot.cs). Відтворено підмножину
// колонок, потрібну ЛІС; назви таблиць/колонок і семантика збігаються. Ключі — uuid (у БД ЛІС
// зберігаються як рядок GUID). Під час перенесення ці класи замінюються моделями evomis, а
// ЛІС-таблиці посилаються на реальні таблиці.
// [MedLink+] — колонки, які ЛІС додає до таблиці evomis (позначено в коментарі до властивості).
// =============================================================================
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedLink.LIS.Api.Data.Entities;

/// <summary>[MedLink] cmn_enum_record — універсальний довідник переліків evomis (Gender, DepartmentType, OrgPositionType, PatientCardType…).</summary>
[Table("cmn_enum_record")]
public class CmnEnumRecord : GuidEntity
{
    public string? Caption { get; set; }
    public string? Code { get; set; }
    public string? EnumType { get; set; }
    [MaxLength(64)] public string? ParentId { get; set; }
    public int ValueType { get; set; }
}

/// <summary>[MedLink] cmn_person — фізична особа (ПІБ, дата народження, стать, ІПН, контакти).</summary>
[Table("cmn_person")]
public class CmnPerson : GuidEntity
{
    [MaxLength(100)] public string? LastName { get; set; }
    /// <summary>Ім'я.</summary>
    [MaxLength(100)] public string? Name { get; set; }
    /// <summary>По батькові.</summary>
    [MaxLength(100)] public string? MiddleName { get; set; }
    public DateTime? Birthday { get; set; }
    [MaxLength(64)] public string? GenderId { get; set; }
    /// <summary>РНОКПП (ІПН).</summary>
    [MaxLength(10)] public string? Ipn { get; set; }
    public bool NoIpn { get; set; }
    [MaxLength(50)] public string? Phone { get; set; }
    [MaxLength(129)] public string? Email { get; set; }
    /// <summary>Адреса.</summary>
    [MaxLength(250)] public string? Location { get; set; }
    [MaxLength(300)] public string? Caption { get; set; }
    [MaxLength(1000)] public string? Description { get; set; }
    public bool SubscribedToNotifications { get; set; }
    public string? UserId { get; set; }

    [ForeignKey(nameof(GenderId))] public CmnEnumRecord? Gender { get; set; }

    public static string BuildCaption(string? last, string? name, string? middle) =>
        string.Join(" ", new[] { last, name, middle }.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s!.Trim()));
}

/// <summary>[MedLink] org_employee — співробітник (ПІБ у caption та cmn_person). Лабораторна роль — у [ЛІС] lab_employee_settings.</summary>
[Table("org_employee")]
public class OrgEmployee : GuidEntity, ITenantScoped
{
    public OrgEmployee() => Id = UuidV7.New();

    /// <summary>ПІБ співробітника (як в evomis).</summary>
    public string? Caption { get; set; }
    [MaxLength(64)] public string PersonId { get; set; } = "";
    public string TenantId { get; set; } = "";
    public string MembershipId { get; set; } = "";
    public string? DepartmentId { get; set; }
    [MaxLength(64)] public string? DepartmentSectionId { get; set; }
    /// <summary>cmn_enum_record (OrgPositionType): 0001 Інші, 0002 Лікарі, 0003 Лаборанти, 0005 Середній мед.персонал…</summary>
    [MaxLength(64)] public string PositionTypeId { get; set; } = "";
    public DateTime? WorkingStartDate { get; set; }
    public bool HasScheduleWithPartner { get; set; }

    [ForeignKey(nameof(PersonId))] public CmnPerson? Person { get; set; }
    [ForeignKey(nameof(MembershipId))] public IdMembership? Membership { get; set; }
    [ForeignKey(nameof(DepartmentId))] public TnDivision? Department { get; set; }
    [ForeignKey(nameof(PositionTypeId))] public CmnEnumRecord? PositionType { get; set; }
    public LabEmployeeSettings? LabSettings { get; set; }

    [NotMapped] public string? LabRole => LabSettings?.LabRole;
    [NotMapped] public bool IsLabActive => LabSettings?.IsActive ?? true;
}

/// <summary>[MedLink] ehe_service_catalog_service — національний каталог послуг eHealth (код послуги для е-направлення та DiagnosticReport).</summary>
[Table("ehe_service_catalog_service")]
public class EheServiceCatalogService : GuidEntity
{
    public string? Caption { get; set; }
    public string? Code { get; set; }
    public string? Name { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsComposition { get; set; }
    public bool RequestAllowed { get; set; } = true;
    [MaxLength(64)] public string MedicalReferralCategoryId { get; set; } = "";
    [MaxLength(64)] public string? EhealthId { get; set; }
    public DateTime InsertedAtInEhealth { get; set; } = DateTime.UtcNow;
}

/// <summary>[MedLink] org_organization_service — послуга прайсу закладу (назва, ціна, тривалість). В evomis таблиця без службових колонок.</summary>
[Table("org_organization_service")]
public class OrgOrganizationService : ITenantScoped
{
    [Key, MaxLength(64)] public string Id { get; set; } = Guid.NewGuid().ToString();
    public string? Caption { get; set; }
    public string TenantId { get; set; } = "";
    public decimal? Price { get; set; }
    /// <summary>Тривалість, хв (smallint).</summary>
    public short Duration { get; set; }
    [MaxLength(64)] public string ProfileId { get; set; } = "";
}

[Table("ehe_medical_referral_category")]
public class EheMedicalReferralCategory : GuidEntity, ITenantScoped
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? EhealthCode { get; set; }
    public bool IsUsedInEhealth { get; set; }
    public string TenantId { get; set; } = "";
}

/// <summary>[MedLink] ehe_incoming_medical_referral — вхідне е-направлення.</summary>
[Table("ehe_incoming_medical_referral")]
public class EheIncomingMedicalReferral : GuidEntity, ITenantScoped
{
    /// <summary>Номер е-направлення.</summary>
    public string? RegNumber { get; set; }
    public DateTime RegDate { get; set; } = DateTime.UtcNow;
    public string? Caption { get; set; }
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string? PatientCardId { get; set; }
    public string? PatientShortName { get; set; }
    [MaxLength(64)] public string? ServiceCatalogServiceId { get; set; }
    /// <summary>ehe_medical_referral_category (laboratory_procedure…).</summary>
    [MaxLength(64)] public string MedicalReferralCategoryId { get; set; } = "";
    /// <summary>Заклад-направник (ehe_external_organization).</summary>
    [MaxLength(64)] public string? RequesterId { get; set; }
    /// <summary>cmn_enum_record — статус направлення.</summary>
    [MaxLength(64)] public string StatusId { get; set; } = "";
    /// <summary>ehd_dictionary — пріоритет.</summary>
    [MaxLength(64)] public string PriorityId { get; set; } = "";
    public DateTime? ExpirationDate { get; set; }
    [MaxLength(64)] public string? EhealthId { get; set; }
    [MaxLength(2000)] public string? PatientInstruction { get; set; }
    /// <summary>Програма медичних гарантій (ehe_medical_service_program) — для автоматичного вибору платника НСЗУ.</summary>
    [MaxLength(64)] public string? MedicalServiceProgramId { get; set; }
    // --- обробка направлення виконавцем (як в evomis EhealthIncomingMedicalReferralService) ---
    /// <summary>cmn_enum_record MedicalReferralProcessingStatusInEhealth: new | in_progress | completed …</summary>
    [MaxLength(64)] public string? ProcessingStatusInEhealthId { get; set; }
    /// <summary>Взято в роботу (UseMedicalReferralInEhealth).</summary>
    public DateTime? TakeInWorkDate { get; set; }
    /// <summary>Погашено (CompleteMedicalReferralInEhealth).</summary>
    public DateTime? CompleteDateInEhealth { get; set; }
    /// <summary>Документ, яким погашено направлення (mis_diagnostic_report.id).</summary>
    [MaxLength(64)] public string? CompletedWithItemEntityId { get; set; }
    /// <summary>Тип документа погашення: DiagnosticReport | Encounter | Procedure.</summary>
    public string? CompletedWithItemEntityName { get; set; }

    [ForeignKey(nameof(PatientCardId))] public OrdPatient? PatientCard { get; set; }
    [ForeignKey(nameof(StatusId))] public CmnEnumRecord? Status { get; set; }
    [ForeignKey(nameof(ProcessingStatusInEhealthId))] public CmnEnumRecord? ProcessingStatus { get; set; }
    [ForeignKey(nameof(ServiceCatalogServiceId))] public EheServiceCatalogService? ServiceCatalogService { get; set; }
}

/// <summary>[MedLink] ehe_paper_medical_referral — паперове направлення (ЛІС створює його при реєстрації замовлення за паперовим направленням).</summary>
[Table("ehe_paper_medical_referral")]
public class EhePaperMedicalReferral : GuidEntity, ITenantScoped
{
    /// <summary>Номер паперового направлення.</summary>
    public string? RegNumber { get; set; }
    public DateTime RegDate { get; set; } = DateTime.UtcNow;
    public string? Caption { get; set; }
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string PatientCardId { get; set; } = "";
    /// <summary>ПІБ лікаря-направника.</summary>
    public string? RequesterEmployeeName { get; set; }
    public string? RequesterLegalEntityName { get; set; }
    [MaxLength(50)] public string? RequesterLegalEntityEdrpou { get; set; }
    /// <summary>EhealthPaperMedicalReferralStatus: 0 PROJECT, 1 ACTIVE, 2 COMPLETED, 3 INACTIVE.</summary>
    public int Status { get; set; } = PaperReferralStatuses.Active;
    public DateTime? ProcessedDate { get; set; }
    [MaxLength(3000)] public string? Description { get; set; }

    [ForeignKey(nameof(PatientCardId))] public OrdPatient? PatientCard { get; set; }
}

public static class PaperReferralStatuses
{
    public const int Project = 0, Active = 1, Completed = 2, Inactive = 3;
}

/// <summary>[MedLink] mis_diagnostic_report — медичний висновок (DiagnosticReport). ЛІС створює його при видачі замовлення; зв'язок — lab_order.diagnostic_report_id.</summary>
[Table("mis_diagnostic_report")]
public class MisDiagnosticReport : GuidEntity, ITenantScoped
{
    public string? RegNumber { get; set; }
    public DateTime RegDate { get; set; } = DateTime.UtcNow;
    public string? Caption { get; set; }
    /// <summary>Статус документа evomis (int).</summary>
    public int Status { get; set; }
    [MaxLength(64)] public string? PatientCardId { get; set; }
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string LegalEntityId { get; set; } = "";
    /// <summary>Місце надання послуг eHealth (ehe_division).</summary>
    [MaxLength(64)] public string DivisionId { get; set; } = "";
    [MaxLength(64)] public string DocumentTypeId { get; set; } = "";
    [MaxLength(64)] public string EhealthServiceCatalogServiceId { get; set; } = "";
    [MaxLength(64)] public string? EhealthIncomingMedicalReferralId { get; set; }
    [MaxLength(64)] public string? DiagnosticReportCategoryId { get; set; }
    [MaxLength(3000)] public string? Description { get; set; }
    public string? Comment { get; set; }
    public DateTime? EffectiveDateTimeStart { get; set; }
    public DateTime? EffectiveDateTimeEnd { get; set; }
    public DateTime? IssuedAt { get; set; }
    /// <summary>Виконавець (ehe_employee); у ЛІС до перенесення — також текстом у performer_string.</summary>
    [MaxLength(64)] public string? PerformerId { get; set; }
    public string? PerformerString { get; set; }
    public bool IsPerformerString { get; set; }
    [MaxLength(64)] public string? RecordedById { get; set; }
    [MaxLength(64)] public string? EhealthId { get; set; }
    public bool IsPrimarySource { get; set; } = true;
}

/// <summary>Ідентифікатори та коди переліків evomis (cmn_enum_record), засіяні з тими самими GUID, що й у evomis DbInitializer.</summary>
public static class MedLinkEnums
{
    public const string EmptyGuid = "00000000-0000-0000-0000-000000000000";
}
