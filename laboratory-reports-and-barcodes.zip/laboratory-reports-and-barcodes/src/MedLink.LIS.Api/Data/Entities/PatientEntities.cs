using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedLink.LIS.Api.Data.Entities;

[Table("ord_patient")]
public class OrdPatient : TenantEntity
{
    [MaxLength(100)] public string? LastName { get; set; }
    [MaxLength(100)] public string? Name { get; set; }
    [MaxLength(100)] public string? MiddleName { get; set; }
    [MaxLength(300)] public string? Caption { get; set; }
    public DateTime? Birthday { get; set; }
    [MaxLength(8)] public string Sex { get; set; } = "unknown";
    [MaxLength(10)] public string? Ipn { get; set; }
    [MaxLength(50)] public string? Phone { get; set; }
    [MaxLength(129)] public string? Email { get; set; }
    [MaxLength(250)] public string? Location { get; set; }
    [MaxLength(100)] public string? LastNameLatin { get; set; }
    [MaxLength(100)] public string? FirstNameLatin { get; set; }

    [NotMapped] public string Gender => Sex switch { "male" => "M", "female" => "F", _ => "U" };

    public List<OrdPatientIdentifier> Identifiers { get; set; } = new();
}

[Table("ord_patient_identifier")]
public class OrdPatientIdentifier : AuditableEntity, ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string PatientId { get; set; } = "";
    [MaxLength(128)] public string System { get; set; } = "";
    [MaxLength(256)] public string Value { get; set; } = "";

    [ForeignKey(nameof(PatientId))] public OrdPatient? Patient { get; set; }
}
