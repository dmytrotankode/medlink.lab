// Системні таблиці: аудит, налаштування лабораторії, нумератори, лічильники
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedLink.LIS.Api.Data.Entities;

[Table("lab_audit_log")]
public class LabAuditLog : ITenantScoped
{
    [Key, MaxLength(64)] public string Id { get; set; } = Guid.NewGuid().ToString();
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string? UserId { get; set; }
    [MaxLength(256)] public string? UserName { get; set; }
    [MaxLength(64)] public string Action { get; set; } = "";
    [MaxLength(64)] public string Entity { get; set; } = "";
    [MaxLength(64)] public string? EntityId { get; set; }
    public string? BeforeJson { get; set; }
    public string? AfterJson { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
    [MaxLength(64)] public string? Ip { get; set; }
    [MaxLength(512)] public string? Comment { get; set; }
}

[Table("lab_settings")]
public class LabSettings : TenantEntity
{
    [NotMapped] public string Name { get; set; } = "Клініко-діагностична лабораторія MedLink";
    [NotMapped] public string? Edrpou { get; set; }
    [NotMapped] public string? Address { get; set; }
    [NotMapped] public string? Phone { get; set; }
    [NotMapped] public string? Email { get; set; }
    [NotMapped] public string? LicenseNumber { get; set; }
    [NotMapped] public string? LogoBase64 { get; set; }
    [MaxLength(256)] public string? DirectorName { get; set; }
    [MaxLength(128)] public string? WorkingHours { get; set; }
    [MaxLength(64)] public string OrderNumberMask { get; set; } = "{yyMM}-{000000}";
    [MaxLength(16)] public string? BarcodePrefix { get; set; }
    public string? ReportFooter { get; set; }
    [MaxLength(32)] public string? PanicPhone { get; set; }
    public double ColdChainMinC { get; set; } = 2.0;
    public double ColdChainMaxC { get; set; } = 8.0;
    // Принтер етикеток (друк виконує локальний print-агент коннектора; TCP/RAW 9100, без UDP)
    [MaxLength(128)] public string? LabelPrinterHost { get; set; }
    public int LabelPrinterPort { get; set; } = 9100;
    [MaxLength(128)] public string? LabelPrinterName { get; set; }
    /// <summary>Прапорці шаблонів бланка (JSON): {"final":true,"preliminary":true,"cito":true,"showPreviousValues":true,"showQr":true}</summary>
    public string ReportTemplatesJson { get; set; } = "{\"final\":true,\"preliminary\":true,\"cito\":true,\"showPreviousValues\":true,\"showQr\":true}";

    [NotMapped]
    public Dictionary<string, bool> ReportTemplates
    {
        get => System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, bool>>(ReportTemplatesJson) ?? new();
        set => ReportTemplatesJson = System.Text.Json.JsonSerializer.Serialize(value);
    }

    [NotMapped]
    public string DefaultLabelSize => ReportTemplates.TryGetValue("labelSize50x25", out var s) && s ? "50x25" : "30x20";

    [NotMapped]
    public string ReportPageSize => ReportTemplates.TryGetValue("pageSizeA5", out var a5) && a5 ? "A5" : "A4";

    [NotMapped]
    public string BarcodeSymbology => ReportTemplates.TryGetValue("symbologyEan13", out var e) && e ? "EAN13" : (ReportTemplates.TryGetValue("symbologyCode39", out var c) && c ? "CODE39" : "Code128");
}

[Table("lab_numerator")]
public class LabNumerator : ITenantScoped
{
    [Key, MaxLength(64)] public string Code { get; set; } = "";
    public string TenantId { get; set; } = "";
    [MaxLength(128)] public string Name { get; set; } = "";
    [MaxLength(64)] public string Mask { get; set; } = "{yyMM}-{000000}";
    [NotMapped] public long CurrentValue { get; set; }
    /// <summary>Ключ періоду (yyMM) — при зміні лічильник скидається.</summary>
    [NotMapped] public string? PeriodKey { get; set; }
    public bool ResetByPeriod { get; set; } = true;
    public DateTime? ModifiedOn { get; set; }
}