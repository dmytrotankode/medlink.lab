using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedLink.LIS.Api.Data.Entities;

public static class TenantTypes
{
    public const string Laboratory = "laboratory", Network = "network";
}

public static class DivisionTypes
{
    public const string Laboratory = "LABORATORY", CollectionPoint = "COLLECTION_POINT", Clinical = "CLINICAL", Branch = "BRANCH";
    public static readonly string[] All = { Laboratory, CollectionPoint, Clinical, Branch };
}

[Table("tn_tenant")]
public class TnTenant
{
    [Key] public string Id { get; set; } = UuidV7.New();
    [MaxLength(300)] public string Name { get; set; } = "";
    [MaxLength(16)] public string Type { get; set; } = TenantTypes.Laboratory;
    [MaxLength(64)] public string TimeZone { get; set; } = "Europe/Kyiv";
    [Column("created_at", TypeName = "timestamp with time zone")] public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

[Table("tn_division")]
public class TnDivision : AuditableEntity, ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    [MaxLength(10)] public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    [MaxLength(32)] public string Type { get; set; } = DivisionTypes.Clinical;
    public string? Address { get; set; }
    [MaxLength(32)] public string? Phone { get; set; }
    public bool IsActive { get; set; } = true;
    [MaxLength(64)] public string? DepartmentTypeId { get; set; }

    [ForeignKey(nameof(DepartmentTypeId))] public CmnEnumRecord? DepartmentType { get; set; }
}

[Table("tn_requisites")]
public class TnRequisites : ITenantScoped
{
    [Key] public string TenantId { get; set; } = "";
    [MaxLength(256)] public string LegalName { get; set; } = "";
    [MaxLength(16)] public string? Edrpou { get; set; }
    [MaxLength(512)] public string? Address { get; set; }
    [MaxLength(32)] public string? Phone { get; set; }
    [MaxLength(128)] public string? Email { get; set; }
    [MaxLength(128)] public string? LicenseNumber { get; set; }
    [Column("logo_url")] public string? LogoUrl { get; set; }
}

[Table("tn_settings")]
public class TnSettings : ITenantScoped
{
    [Key] public string TenantId { get; set; } = "";
    [MaxLength(32), Column("date_format")] public string? ReportDateFormat { get; set; }
    [MaxLength(1)] public string? DecimalSeparator { get; set; }
    [Column("status_color_markers")] public string? StatusColorsJson { get; set; }
    [Column("criticality_color_markers")] public string? CriticalityColorsJson { get; set; }
    [MaxLength(8), Column("default_form_language")] public string? ReportLanguage { get; set; } = "uk";
}

[Table("tn_sequence")]
public class TnSequence : ITenantScoped
{
    public string TenantId { get; set; } = "";
    [MaxLength(128)] public string Key { get; set; } = "";
    [MaxLength(32)] public string ScopeKey { get; set; } = "";
    public long Value { get; set; }
}

[Table("id_user")]
public class IdUser : AuditableEntity
{
    [Key] public string Id { get; set; } = UuidV7.New();
    [MaxLength(256)] public string? Sub { get; set; }
    [MaxLength(256)] public string? Email { get; set; }
    [MaxLength(300)] public string? DisplayName { get; set; }
    public string? DefaultTenantId { get; set; }

    [ForeignKey(nameof(DefaultTenantId))] public TnTenant? DefaultTenant { get; set; }
}

[Table("id_membership")]
public class IdMembership : ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string UserId { get; set; } = "";
    [MaxLength(64)] public string RoleId { get; set; } = "";
    public bool IsActive { get; set; } = true;
    [Column("created_at", TypeName = "timestamp with time zone")] public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

[Table("id_membership_division")]
public class IdMembershipDivision : ITenantScoped
{
    public string TenantId { get; set; } = "";
    public string MembershipId { get; set; } = "";
    public string DivisionId { get; set; } = "";

    [ForeignKey(nameof(MembershipId))] public IdMembership? Membership { get; set; }
    [ForeignKey(nameof(DivisionId))] public TnDivision? Division { get; set; }
}

[Table("id_permission")]
public class IdPermission
{
    [Key, MaxLength(64)] public string Code { get; set; } = "";
    [MaxLength(512)] public string Caption { get; set; } = "";
}

[Table("id_role")]
public class IdRole : AuditableEntity, ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    [MaxLength(64)] public string Code { get; set; } = "";
    [MaxLength(256)] public string Name { get; set; } = "";
    public bool IsSystem { get; set; }
}

[Table("id_role_permission")]
public class IdRolePermission : AuditableEntity, ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    public string RoleId { get; set; } = "";
    [MaxLength(64)] public string PermissionCode { get; set; } = "";

    [ForeignKey(nameof(RoleId))] public IdRole? Role { get; set; }
    [ForeignKey(nameof(PermissionCode))] public IdPermission? Permission { get; set; }
}

[Table("id_membership_role")]
public class IdMembershipRole : AuditableEntity, ITenantScoped
{
    [Key] public string Id { get; set; } = UuidV7.New();
    public string TenantId { get; set; } = "";
    public string MembershipId { get; set; } = "";
    public string RoleId { get; set; } = "";

    [ForeignKey(nameof(MembershipId))] public IdMembership? Membership { get; set; }
    [ForeignKey(nameof(RoleId))] public IdRole? Role { get; set; }
}
