using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace MedLink.LIS.Api.Data.Helpers;

public static class ApplicationOperations
{
    private static readonly List<ApplicationOperationData> _operations = new();

    [Display(Name = "Перегляд замовлень", Description = "Перегляд замовлень")]
    public static readonly string OrdersRead = "Перегляд замовлень";

    [Display(Name = "Перегляд результатів", Description = "Перегляд результатів")]
    public static readonly string ResultsRead = "Перегляд результатів";

    [Display(Name = "Замовлення: Редагувати замовлення", Description = "Замовлення: Редагувати замовлення")]
    public static readonly string OrderEdit = "Замовлення: Редагувати замовлення";

    [Display(Name = "Замовлення: Додати тест", Description = "Замовлення: Додати тест")]
    public static readonly string OrderAddTest = "Замовлення: Додати тест";

    [Display(Name = "Замовлення: Прибрати тест", Description = "Замовлення: Прибрати тест")]
    public static readonly string OrderRemoveTest = "Замовлення: Прибрати тест";

    [Display(Name = "Замовлення: Додати пробірку", Description = "Замовлення: Додати пробірку")]
    public static readonly string OrderAddSample = "Замовлення: Додати пробірку";

    [Display(Name = "Замовлення: Забір біоматеріалу", Description = "Замовлення: Забір біоматеріалу")]
    public static readonly string OrderCollect = "Замовлення: Забір біоматеріалу";

    [Display(Name = "Замовлення: Відправити в лабораторію", Description = "Замовлення: Відправити в лабораторію")]
    public static readonly string OrderDispatch = "Замовлення: Відправити в лабораторію";

    [Display(Name = "Замовлення: Прийняти в лабораторії", Description = "Замовлення: Прийняти в лабораторії")]
    public static readonly string OrderReceive = "Замовлення: Прийняти в лабораторії";

    [Display(Name = "Замовлення: Ввести результат", Description = "Замовлення: Ввести результат")]
    public static readonly string OrderEnterResult = "Замовлення: Ввести результат";

    [Display(Name = "Замовлення: Верифікувати результати", Description = "Замовлення: Верифікувати результати")]
    public static readonly string OrderVerify = "Замовлення: Верифікувати результати";

    [Display(Name = "Замовлення: Завершити (усі тести верифіковано)", Description = "Замовлення: Завершити (усі тести верифіковано)")]
    public static readonly string OrderComplete = "Замовлення: Завершити (усі тести верифіковано)";

    [Display(Name = "Замовлення: Видати результати пацієнту", Description = "Замовлення: Видати результати пацієнту")]
    public static readonly string OrderRelease = "Замовлення: Видати результати пацієнту";

    [Display(Name = "Замовлення: Повернути в роботу", Description = "Замовлення: Повернути в роботу")]
    public static readonly string OrderReopen = "Замовлення: Повернути в роботу";

    [Display(Name = "Замовлення: Скасувати замовлення", Description = "Замовлення: Скасувати замовлення")]
    public static readonly string OrderCancel = "Замовлення: Скасувати замовлення";

    [Display(Name = "Замовлення: Відхилити (брак біоматеріалу)", Description = "Замовлення: Відхилити (брак біоматеріалу)")]
    public static readonly string OrderReject = "Замовлення: Відхилити (брак біоматеріалу)";

    [Display(Name = "Замовлення: Видалити замовлення", Description = "Замовлення: Видалити замовлення")]
    public static readonly string OrderDelete = "Замовлення: Видалити замовлення";

    [Display(Name = "Замовлення: Друк етикеток", Description = "Замовлення: Друк етикеток")]
    public static readonly string OrderPrintLabels = "Замовлення: Друк етикеток";

    [Display(Name = "Замовлення: Друк бланка", Description = "Замовлення: Друк бланка")]
    public static readonly string OrderPrintReport = "Замовлення: Друк бланка";

    [Display(Name = "Пробірка: Забір пробірки", Description = "Пробірка: Забір пробірки")]
    public static readonly string SampleCollect = "Пробірка: Забір пробірки";

    [Display(Name = "Пробірка: Скасувати відмітку забору", Description = "Пробірка: Скасувати відмітку забору")]
    public static readonly string SampleUncollect = "Пробірка: Скасувати відмітку забору";

    [Display(Name = "Пробірка: Відправити", Description = "Пробірка: Відправити")]
    public static readonly string SampleDispatch = "Пробірка: Відправити";

    [Display(Name = "Пробірка: Прийняти", Description = "Пробірка: Прийняти")]
    public static readonly string SampleReceive = "Пробірка: Прийняти";

    [Display(Name = "Пробірка: В обробці (центрифугування/аналіз)", Description = "Пробірка: В обробці (центрифугування/аналіз)")]
    public static readonly string SampleProcess = "Пробірка: В обробці (центрифугування/аналіз)";

    [Display(Name = "Пробірка: Розмістити в біобанку", Description = "Пробірка: Розмістити в біобанку")]
    public static readonly string SampleStore = "Пробірка: Розмістити в біобанку";

    [Display(Name = "Пробірка: Утилізувати", Description = "Пробірка: Утилізувати")]
    public static readonly string SampleDispose = "Пробірка: Утилізувати";

    [Display(Name = "Пробірка: Відбракувати пробірку", Description = "Пробірка: Відбракувати пробірку")]
    public static readonly string SampleReject = "Пробірка: Відбракувати пробірку";

    [Display(Name = "Пробірка: Відмітки гемоліз/ліпемія/іктеричність", Description = "Пробірка: Відмітки гемоліз/ліпемія/іктеричність")]
    public static readonly string SampleEditFlags = "Пробірка: Відмітки гемоліз/ліпемія/іктеричність";

    [Display(Name = "Пробірка: Замінити пробірку (новий штрихкод)", Description = "Пробірка: Замінити пробірку (новий штрихкод)")]
    public static readonly string SampleReplace = "Пробірка: Замінити пробірку (новий штрихкод)";

    [Display(Name = "Пробірка: Видалити пробірку", Description = "Пробірка: Видалити пробірку")]
    public static readonly string SampleDelete = "Пробірка: Видалити пробірку";

    [Display(Name = "Тест: Передати на аналізатор", Description = "Тест: Передати на аналізатор")]
    public static readonly string OrderTestStartAnalysis = "Тест: Передати на аналізатор";

    [Display(Name = "Тест: Призначити аналізатор", Description = "Тест: Призначити аналізатор")]
    public static readonly string OrderTestAssignAnalyzer = "Тест: Призначити аналізатор";

    [Display(Name = "Тест: Ввести результат", Description = "Тест: Ввести результат")]
    public static readonly string OrderTestEnterResult = "Тест: Ввести результат";

    [Display(Name = "Тест: Відправити в зовнішню лабораторію", Description = "Тест: Відправити в зовнішню лабораторію")]
    public static readonly string OrderTestSendOut = "Тест: Відправити в зовнішню лабораторію";

    [Display(Name = "Тест: Відкликати з зовнішньої лабораторії", Description = "Тест: Відкликати з зовнішньої лабораторії")]
    public static readonly string OrderTestRecallSendOut = "Тест: Відкликати з зовнішньої лабораторії";

    [Display(Name = "Тест: Виправити результат (нова версія)", Description = "Тест: Виправити результат (нова версія)")]
    public static readonly string OrderTestEditResult = "Тест: Виправити результат (нова версія)";

    [Display(Name = "Тест: Видалити результат", Description = "Тест: Видалити результат")]
    public static readonly string OrderTestDeleteResult = "Тест: Видалити результат";

    [Display(Name = "Тест: Верифікувати", Description = "Тест: Верифікувати")]
    public static readonly string OrderTestVerify = "Тест: Верифікувати";

    [Display(Name = "Тест: Відхилити тест", Description = "Тест: Відхилити тест")]
    public static readonly string OrderTestReject = "Тест: Відхилити тест";

    [Display(Name = "Тест: Повторити дослідження", Description = "Тест: Повторити дослідження")]
    public static readonly string OrderTestRerun = "Тест: Повторити дослідження";

    [Display(Name = "Тест: Відкрити повторно", Description = "Тест: Відкрити повторно")]
    public static readonly string OrderTestReopen = "Тест: Відкрити повторно";

    [Display(Name = "Тест: Прибрати тест із замовлення", Description = "Тест: Прибрати тест із замовлення")]
    public static readonly string OrderTestRemove = "Тест: Прибрати тест із замовлення";

    [Display(Name = "Маніфест: Редагувати маніфест", Description = "Маніфест: Редагувати маніфест")]
    public static readonly string ManifestEdit = "Маніфест: Редагувати маніфест";

    [Display(Name = "Маніфест: Відправити", Description = "Маніфест: Відправити")]
    public static readonly string ManifestDispatch = "Маніфест: Відправити";

    [Display(Name = "Маніфест: Прийняти в лабораторії", Description = "Маніфест: Прийняти в лабораторії")]
    public static readonly string ManifestReceive = "Маніфест: Прийняти в лабораторії";

    [Display(Name = "Маніфест: Відхилити (порушення холодового ланцюга)", Description = "Маніфест: Відхилити (порушення холодового ланцюга)")]
    public static readonly string ManifestReject = "Маніфест: Відхилити (порушення холодового ланцюга)";

    [Display(Name = "Маніфест: Видалити маніфест", Description = "Маніфест: Видалити маніфест")]
    public static readonly string ManifestDelete = "Маніфест: Видалити маніфест";

    [Display(Name = "Посів: Редагувати посів", Description = "Посів: Редагувати посів")]
    public static readonly string CultureEdit = "Посів: Редагувати посів";

    [Display(Name = "Посів: Попередній результат", Description = "Посів: Попередній результат")]
    public static readonly string CulturePreliminary = "Посів: Попередній результат";

    [Display(Name = "Посів: Додати ізолят", Description = "Посів: Додати ізолят")]
    public static readonly string CultureAddIsolate = "Посів: Додати ізолят";

    [Display(Name = "Посів: Ізоляти виділено", Description = "Посів: Ізоляти виділено")]
    public static readonly string CultureIsolate = "Посів: Ізоляти виділено";

    [Display(Name = "Посів: Антибіотикограма", Description = "Посів: Антибіотикограма")]
    public static readonly string CultureAddSusceptibility = "Посів: Антибіотикограма";

    [Display(Name = "Посів: Завершити посів", Description = "Посів: Завершити посів")]
    public static readonly string CultureComplete = "Посів: Завершити посів";

    [Display(Name = "Посів: Видалити посів", Description = "Посів: Видалити посів")]
    public static readonly string CultureDelete = "Посів: Видалити посів";

    [Display(Name = "Коннектор: Реєстрація інсталяції", Description = "Коннектор: Реєстрація інсталяції")]
    public static readonly string ConnectorRegister = "Коннектор: Реєстрація інсталяції";

    [Display(Name = "Коннектор: Heartbeat", Description = "Коннектор: Heartbeat")]
    public static readonly string ConnectorHeartbeat = "Коннектор: Heartbeat";

    [Display(Name = "Коннектор: Позначити офлайн", Description = "Коннектор: Позначити офлайн")]
    public static readonly string ConnectorMarkOffline = "Коннектор: Позначити офлайн";

    [Display(Name = "Коннектор: Вимкнути", Description = "Коннектор: Вимкнути")]
    public static readonly string ConnectorDisable = "Коннектор: Вимкнути";

    [Display(Name = "Коннектор: Увімкнути (повторна реєстрація)", Description = "Коннектор: Увімкнути (повторна реєстрація)")]
    public static readonly string ConnectorEnable = "Коннектор: Увімкнути (повторна реєстрація)";

    [Display(Name = "Коннектор: Перевипустити ключ", Description = "Коннектор: Перевипустити ключ")]
    public static readonly string ConnectorRotateKey = "Коннектор: Перевипустити ключ";

    [Display(Name = "Коннектор: Редагувати", Description = "Коннектор: Редагувати")]
    public static readonly string ConnectorEdit = "Коннектор: Редагувати";

    [Display(Name = "Коннектор: Видалити", Description = "Коннектор: Видалити")]
    public static readonly string ConnectorDelete = "Коннектор: Видалити";

    [Display(Name = "Створення замовлення", Description = "Створення замовлення")]
    public static readonly string OrderCreate = "Створення замовлення";

    [Display(Name = "Створення замовлень", Description = "Створення замовлень (пакетно)")]
    public static readonly string OrderCreateBatch = "Створення замовлень";

    [Display(Name = "Створення маніфесту", Description = "Створення маніфесту")]
    public static readonly string ManifestCreate = "Створення маніфесту";

    [Display(Name = "Імпорт реєстру клініки", Description = "Імпорт реєстру клініки")]
    public static readonly string ClientRegistryImport = "Імпорт реєстру клініки";

    [Display(Name = "Рахунок/акт за період", Description = "Рахунок/акт за період")]
    public static readonly string PayerPeriodInvoice = "Рахунок/акт за період";

    [Display(Name = "Створення підрозділу лабораторії", Description = "Створення підрозділу лабораторії")]
    public static readonly string SectionCreate = "Створення підрозділу лабораторії";

    [Display(Name = "Редагування підрозділу лабораторії", Description = "Редагування підрозділу лабораторії")]
    public static readonly string SectionUpdate = "Редагування підрозділу лабораторії";

    [Display(Name = "Видалення підрозділу лабораторії", Description = "Видалення підрозділу лабораторії")]
    public static readonly string SectionDelete = "Видалення підрозділу лабораторії";

    [Display(Name = "Зміна статусу позиції журналу", Description = "Зміна статусу позиції журналу")]
    public static readonly string JournalEntryStatusChange = "Зміна статусу позиції журналу";

    [Display(Name = "Створення інсталяції коннектора", Description = "Створення інсталяції коннектора")]
    public static readonly string ConnectorCreate = "Створення інсталяції коннектора";

    [Display(Name = "Команда коннектору", Description = "Команда коннектору")]
    public static readonly string ConnectorCommand = "Команда коннектору";

    [Display(Name = "Зміна платника замовлення", Description = "Зміна платника замовлення")]
    public static readonly string OrderPayerChange = "Зміна платника замовлення";

    [Display(Name = "Зміна оплати позиції", Description = "Зміна оплати позиції")]
    public static readonly string ChargePatientChoiceChange = "Зміна оплати позиції";

    [Display(Name = "Прийом оплати", Description = "Прийом оплати")]
    public static readonly string PaymentAdd = "Прийом оплати";

    [Display(Name = "Виставлення рахунку платнику", Description = "Виставлення рахунку платнику")]
    public static readonly string InvoiceIssue = "Виставлення рахунку платнику";

    [Display(Name = "Анулювання рахунку", Description = "Анулювання рахунку")]
    public static readonly string InvoiceCancel = "Анулювання рахунку";

    [Display(Name = "Оплата рахунку платником", Description = "Оплата рахунку платником")]
    public static readonly string InvoiceMarkPaid = "Оплата рахунку платником";

    [Display(Name = "Довідник платників", Description = "Довідник платників")]
    public static readonly string PayersEdit = "Довідник платників";

    [Display(Name = "Прайс-листи", Description = "Прайс-листи")]
    public static readonly string PriceListsEdit = "Прайс-листи";

    [Display(Name = "Поліси пацієнта", Description = "Поліси пацієнта")]
    public static readonly string PatientInsurancesEdit = "Поліси пацієнта";

    [Display(Name = "Імпорт результатів", Description = "Імпорт результатів")]
    public static readonly string ResultsImport = "Імпорт результатів";

    [Display(Name = "Редагування обраних іншого співробітника", Description = "Редагування обраних іншого співробітника")]
    public static readonly string FavoritesEditOther = "Редагування обраних іншого співробітника";

    [Display(Name = "Збереження обраних наборів", Description = "Збереження обраних наборів")]
    public static readonly string FavoritesSave = "Збереження обраних наборів";

    [Display(Name = "Видалення обраних іншого співробітника", Description = "Видалення обраних іншого співробітника")]
    public static readonly string FavoritesDeleteOther = "Видалення обраних іншого співробітника";

    [Display(Name = "Створення аналізатора", Description = "Створення аналізатора")]
    public static readonly string AnalyzerCreate = "Створення аналізатора";

    [Display(Name = "Редагування аналізатора", Description = "Редагування аналізатора")]
    public static readonly string AnalyzerUpdate = "Редагування аналізатора";

    [Display(Name = "Видалення аналізатора", Description = "Видалення аналізатора")]
    public static readonly string AnalyzerDelete = "Видалення аналізатора";

    [Display(Name = "Видалення запису журналу", Description = "Видалення запису журналу обміну аналізатора")]
    public static readonly string AnalyzerMessageDelete = "Видалення запису журналу";

    [Display(Name = "Створення запису довідника", Description = "Створення запису довідника")]
    public static readonly string DictionaryEntryCreate = "Створення запису довідника";

    [Display(Name = "Редагування запису довідника", Description = "Редагування запису довідника")]
    public static readonly string DictionaryEntryUpdate = "Редагування запису довідника";

    [Display(Name = "Видалення запису довідника", Description = "Видалення запису довідника")]
    public static readonly string DictionaryEntryDelete = "Видалення запису довідника";

    [Display(Name = "Імпорт довідника", Description = "Імпорт довідника")]
    public static readonly string DictionaryImport = "Імпорт довідника";

    [Display(Name = "Збереження співробітника", Description = "Збереження співробітника")]
    public static readonly string EmployeeSave = "Збереження співробітника";

    [Display(Name = "Алікотування / розділення проби", Description = "Алікотування / розділення проби")]
    public static readonly string SampleSplit = "Алікотування / розділення проби";

    [Display(Name = "Фіксація етапу обробки проби", Description = "Фіксація етапу обробки проби")]
    public static readonly string SampleStageAdd = "Фіксація етапу обробки проби";

    [Display(Name = "Видалення події етапу", Description = "Видалення події етапу")]
    public static readonly string SampleStageEventDelete = "Видалення події етапу";

    [Display(Name = "Редагування шаблону робочого процесу", Description = "Редагування шаблону робочого процесу")]
    public static readonly string WorkflowTemplateEdit = "Редагування шаблону робочого процесу";

    [Display(Name = "Створення контрольного матеріалу", Description = "Створення контрольного матеріалу")]
    public static readonly string QcMaterialCreate = "Створення контрольного матеріалу";

    [Display(Name = "Редагування контрольного матеріалу", Description = "Редагування контрольного матеріалу")]
    public static readonly string QcMaterialUpdate = "Редагування контрольного матеріалу";

    [Display(Name = "Видалення контрольного матеріалу", Description = "Видалення контрольного матеріалу")]
    public static readonly string QcMaterialDelete = "Видалення контрольного матеріалу";

    [Display(Name = "Видалення цільового значення", Description = "Видалення цільового значення")]
    public static readonly string QcTargetDelete = "Видалення цільового значення";

    [Display(Name = "Внесення результату ВКЯ", Description = "Внесення результату ВКЯ")]
    public static readonly string QcResultAdd = "Внесення результату ВКЯ";

    [Display(Name = "Редагування результату ВКЯ", Description = "Редагування результату ВКЯ")]
    public static readonly string QcResultUpdate = "Редагування результату ВКЯ";

    [Display(Name = "Видалення результату ВКЯ", Description = "Видалення результату ВКЯ")]
    public static readonly string QcResultDelete = "Видалення результату ВКЯ";

    [Display(Name = "Ручне блокування аналізатора", Description = "Ручне блокування аналізатора")]
    public static readonly string LockoutCreate = "Ручне блокування аналізатора";

    [Display(Name = "Розблокування аналізатора", Description = "Розблокування аналізатора")]
    public static readonly string LockoutResolve = "Розблокування аналізатора";

    [Display(Name = "Видалення lockout", Description = "Видалення lockout")]
    public static readonly string LockoutDelete = "Видалення lockout";

    [Display(Name = "Автоверифікація", Description = "Автоверифікація")]
    public static readonly string ResultsAutoVerify = "Автоверифікація";

    [Display(Name = "Реєстрація панічного дзвінка", Description = "Реєстрація панічного дзвінка")]
    public static readonly string PanicCallCreate = "Реєстрація панічного дзвінка";

    [Display(Name = "Редагування панічного дзвінка", Description = "Редагування панічного дзвінка")]
    public static readonly string PanicCallUpdate = "Редагування панічного дзвінка";

    [Display(Name = "Видалення панічного дзвінка", Description = "Видалення панічного дзвінка")]
    public static readonly string PanicCallDelete = "Видалення панічного дзвінка";

    [Display(Name = "Створення робочого листа", Description = "Створення робочого листа")]
    public static readonly string WorklistBatchCreate = "Створення робочого листа";

    [Display(Name = "Редагування робочого листа", Description = "Редагування робочого листа")]
    public static readonly string WorklistBatchUpdate = "Редагування робочого листа";

    [Display(Name = "Видалення робочого листа", Description = "Видалення робочого листа")]
    public static readonly string WorklistBatchDelete = "Видалення робочого листа";

    [Display(Name = "Зв'язування результату", Description = "Зв'язування результату")]
    public static readonly string UnmatchedResultLink = "Зв'язування результату";

    [Display(Name = "Видалення незв'язаного результату", Description = "Видалення незв'язаного результату")]
    public static readonly string UnmatchedResultDelete = "Видалення незв'язаного результату";

    [Display(Name = "Довідник лабораторій-виконавців", Description = "Довідник лабораторій-виконавців")]
    public static readonly string PerformersEdit = "Довідник лабораторій-виконавців";

    [Display(Name = "Видалення лабораторії-виконавця", Description = "Видалення лабораторії-виконавця")]
    public static readonly string PerformerDelete = "Видалення лабораторії-виконавця";

    [Display(Name = "Прайс зовнішньої лабораторії", Description = "Прайс зовнішньої лабораторії")]
    public static readonly string PerformerTestsEdit = "Прайс зовнішньої лабораторії";

    [Display(Name = "Зміна виконавця дослідження", Description = "Зміна виконавця дослідження")]
    public static readonly string OrderTestPerformerChange = "Зміна виконавця дослідження";

    [Display(Name = "Формування реєстру відправки", Description = "Формування реєстру відправки")]
    public static readonly string SendOutCreate = "Формування реєстру відправки";

    [Display(Name = "Відправка проб у зовнішню лабораторію", Description = "Відправка проб у зовнішню лабораторію")]
    public static readonly string SendOutDispatch = "Відправка проб у зовнішню лабораторію";

    [Display(Name = "Підтвердження приймання зовнішньою лабораторією", Description = "Підтвердження приймання зовнішньою лабораторією")]
    public static readonly string SendOutAccept = "Підтвердження приймання зовнішньою лабораторією";

    [Display(Name = "Скасування реєстру відправки", Description = "Скасування реєстру відправки")]
    public static readonly string SendOutCancel = "Скасування реєстру відправки";

    [Display(Name = "Відмова/відкликання позиції реєстру", Description = "Відмова/відкликання позиції реєстру")]
    public static readonly string SendOutItemReject = "Відмова/відкликання позиції реєстру";

    [Display(Name = "Внесення результату зовнішньої лабораторії", Description = "Внесення результату зовнішньої лабораторії")]
    public static readonly string SendOutResultEnter = "Внесення результату зовнішньої лабораторії";

    [Display(Name = "Імпорт результатів зовнішньої лабораторії", Description = "Імпорт результатів зовнішньої лабораторії")]
    public static readonly string SendOutResultsImport = "Імпорт результатів зовнішньої лабораторії";

    [Display(Name = "Завантаження бланка результатів", Description = "Завантаження бланка результатів")]
    public static readonly string OrderAttachmentAdd = "Завантаження бланка результатів";

    [Display(Name = "Створення картки пацієнта", Description = "Створення картки пацієнта")]
    public static readonly string PatientCreate = "Створення картки пацієнта";

    [Display(Name = "Редагування картки пацієнта", Description = "Редагування картки пацієнта")]
    public static readonly string PatientUpdate = "Редагування картки пацієнта";

    [Display(Name = "Видалення картки пацієнта", Description = "Видалення картки пацієнта")]
    public static readonly string PatientDelete = "Видалення картки пацієнта";

    [Display(Name = "Зміна налаштувань лабораторії", Description = "Зміна налаштувань лабораторії")]
    public static readonly string LabSettingsUpdate = "Зміна налаштувань лабораторії";

    [Display(Name = "Зміна нумератора", Description = "Зміна нумератора")]
    public static readonly string NumeratorUpdate = "Зміна нумератора";

    [Display(Name = "Створення посіву", Description = "Створення посіву")]
    public static readonly string CultureCreate = "Створення посіву";

    [Display(Name = "Створення штатива", Description = "Створення штатива")]
    public static readonly string RackCreate = "Створення штатива";

    [Display(Name = "Редагування штатива", Description = "Редагування штатива")]
    public static readonly string RackUpdate = "Редагування штатива";

    [Display(Name = "Видалення штатива", Description = "Видалення штатива")]
    public static readonly string RackDelete = "Видалення штатива";

    [Display(Name = "Розміщення зразка в біобанку", Description = "Розміщення зразка в біобанку")]
    public static readonly string BiobankPlace = "Розміщення зразка в біобанку";

    [Display(Name = "Вилучення зразка з біобанку", Description = "Вилучення зразка з біобанку")]
    public static readonly string BiobankRemove = "Вилучення зразка з біобанку";

    [Display(Name = "Редагування комірки", Description = "Редагування комірки")]
    public static readonly string BiobankCellUpdate = "Редагування комірки";

    [Display(Name = "Видалення комірки", Description = "Видалення комірки")]
    public static readonly string BiobankCellDelete = "Видалення комірки";

    [Display(Name = "Створення лоту реагенту", Description = "Створення лоту реагенту")]
    public static readonly string ReagentLotCreate = "Створення лоту реагенту";

    [Display(Name = "Редагування лоту реагенту", Description = "Редагування лоту реагенту")]
    public static readonly string ReagentLotUpdate = "Редагування лоту реагенту";

    [Display(Name = "Видалення лоту реагенту", Description = "Видалення лоту реагенту")]
    public static readonly string ReagentLotDelete = "Видалення лоту реагенту";

    [Display(Name = "Списання реагенту", Description = "Списання реагенту")]
    public static readonly string ReagentConsume = "Списання реагенту";

    [Display(Name = "Очищення журналів", Description = "Очищення журналів")]
    public static readonly string LogsRetentionRun = "Очищення журналів";

    [Display(Name = "Редагування норм", Description = "Редагування норм")]
    public static readonly string NormsEdit = "Редагування норм";

    [Display(Name = "Видалення норм", Description = "Видалення норм")]
    public static readonly string NormsDelete = "Видалення норм";

    [Display(Name = "Перегляд звітів", Description = "Перегляд звітів")]
    public static readonly string ReportsRead = "Перегляд звітів";

    static ApplicationOperations()
    {
        var type = typeof(ApplicationOperations);
        var fields = type.GetFields(BindingFlags.Static | BindingFlags.Public);
        foreach (var fieldInfo in fields.Where(x => x.FieldType == typeof(string)))
        {
            var operationData = new ApplicationOperationData
            {
                OperationName = fieldInfo.Name
            };
            _operations.Add(operationData);

            if (fieldInfo.GetCustomAttributes(typeof(DisplayAttribute), false).FirstOrDefault() is not DisplayAttribute displayAttr)
            {
                operationData.OperationCaption = fieldInfo.GetValue(null)?.ToString();
            }
            else
            {
                operationData.OperationCaption = displayAttr.Name;
                operationData.OperationDescription = displayAttr.Description;
            }
        }
    }

    public static IEnumerable<ApplicationOperationData> GetDeclaredOperations() => _operations;

    public class ApplicationOperationData
    {
        public string OperationName { get; set; } = "";
        public string? OperationCaption { get; set; }
        public string? OperationDescription { get; set; }
    }
}
