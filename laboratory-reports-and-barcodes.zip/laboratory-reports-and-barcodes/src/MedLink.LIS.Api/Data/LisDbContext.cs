// =============================================================================
// MedLink LIS 4.0 — DbContext. Іменування як в evomis: snake_case таблиць/колонок,
// ключі — рядкові GUID, службові колонки created_on/created_by/modified_on/modified_by/is_deleted.
// Усі типи сумісні з PostgreSQL: перехід на evomis = UseNpgsql + вказати DbSet на реальні таблиці.
// =============================================================================
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using Core.Base.Data;
using Core.Models;
using Core.Security.Models;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Tenancy;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace MedLink.LIS.Api.Data;

public partial class LisDbContext : CoreDbContext, ISecurityDbContext
{
    static LisDbContext()
    {
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
    }

    private static readonly MethodInfo SetTenantFilterMethod =
        typeof(LisDbContext).GetMethod(nameof(SetTenantFilter), BindingFlags.NonPublic | BindingFlags.Instance)!;

    private static readonly HashSet<(Type Entity, string Property)> CrossTenantLookupIndexes = new()
    {
        (typeof(LabConnectorInstallation), nameof(LabConnectorInstallation.ApiKeyHash)),
        (typeof(LabConnectorInstallation), nameof(LabConnectorInstallation.InstallKey)),
        (typeof(LabOrder), nameof(LabOrder.VerifyToken))
    };

    public LisDbContext(DbContextOptions<LisDbContext> options) : this(options, new TenantContext(), new DivisionContext()) { }

    public LisDbContext(DbContextOptions<LisDbContext> options, ITenantContext tenant, IDivisionContext division) : base(options)
    {
        Tenant = tenant;
        Division = division;
    }

    public ITenantContext Tenant { get; }
    public IDivisionContext Division { get; }
    public string CurrentTenantId => TenantIds.Require(Tenant.TenantId);
    public IReadOnlyCollection<string>? AllowedDepartmentIds => Division.AllowedDepartmentIds;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.AddInterceptors(TenantTransactionInterceptor.Instance);
    }

    // --- [MedLink] дзеркало таблиць evomis (структура як в evomis) ---
    public DbSet<CmnEnumRecord> EnumRecords => Set<CmnEnumRecord>();
    public DbSet<CmnPerson> Persons => Set<CmnPerson>();
    public DbSet<TnTenant> Tenants => Set<TnTenant>();
    public DbSet<OrdPatient> Patients => Set<OrdPatient>();
    public DbSet<OrdPatientIdentifier> PatientIdentifiers => Set<OrdPatientIdentifier>();
    public DbSet<MisDiagnosticReport> DiagnosticReports => Set<MisDiagnosticReport>();
    public DbSet<OrgEmployee> Employees => Set<OrgEmployee>();
    public DbSet<TnDivision> Divisions => Set<TnDivision>();
    public DbSet<EheIncomingMedicalReferral> Referrals => Set<EheIncomingMedicalReferral>();
    public DbSet<EhePaperMedicalReferral> PaperReferrals => Set<EhePaperMedicalReferral>();
    public DbSet<EheServiceCatalogService> ServiceCatalog => Set<EheServiceCatalogService>();
    public DbSet<EheMedicalReferralCategory> ReferralCategories => Set<EheMedicalReferralCategory>();
    public DbSet<OrgOrganizationService> OrganizationServices => Set<OrgOrganizationService>();

    // --- [ЛІС] лабораторні атрибути сутностей MedLink ---
    public DbSet<LabEmployeeSettings> EmployeeSettings => Set<LabEmployeeSettings>();
    public DbSet<IdUser> LabUsers => Set<IdUser>();
    public DbSet<IdMembership> Memberships => Set<IdMembership>();
    public DbSet<IdMembershipDivision> MembershipDivisions => Set<IdMembershipDivision>();
    public DbSet<IdPermission> Permissions => Set<IdPermission>();
    public DbSet<IdRole> LabRoles => Set<IdRole>();
    public DbSet<IdRolePermission> RolePermissions => Set<IdRolePermission>();
    public DbSet<IdMembershipRole> MembershipRoles => Set<IdMembershipRole>();
    public DbSet<TnRequisites> Requisites => Set<TnRequisites>();
    public DbSet<TnSettings> TenantSettings => Set<TnSettings>();
    public DbSet<TnSequence> Sequences => Set<TnSequence>();

    // --- dictionaries ---
    public DbSet<LabBiomaterialType> BiomaterialTypes => Set<LabBiomaterialType>();
    public DbSet<LabTubeType> TubeTypes => Set<LabTubeType>();
    public DbSet<LabMethodType> MethodTypes => Set<LabMethodType>();
    public DbSet<LabAnalyzerType> AnalyzerTypes => Set<LabAnalyzerType>();
    public DbSet<LabTestDefinition> Tests => Set<LabTestDefinition>();
    public DbSet<LabTestProfile> Profiles => Set<LabTestProfile>();
    public DbSet<LabTestProfileItem> ProfileItems => Set<LabTestProfileItem>();
    public DbSet<LabReferenceLayer> ReferenceLayers => Set<LabReferenceLayer>();
    public DbSet<LabReflexRule> ReflexRules => Set<LabReflexRule>();
    public DbSet<LabMicroOrganism> Organisms => Set<LabMicroOrganism>();
    public DbSet<LabAntibiotic> Antibiotics => Set<LabAntibiotic>();
    public DbSet<LabEucastBreakpoint> EucastBreakpoints => Set<LabEucastBreakpoint>();

    // --- workflow ---
    public DbSet<LabOrder> Orders => Set<LabOrder>();
    public DbSet<OrdOrderIdentifier> OrderIdentifiers => Set<OrdOrderIdentifier>();
    public DbSet<OrdRequester> Requesters => Set<OrdRequester>();
    public DbSet<LabOrderSample> Samples => Set<LabOrderSample>();
    public DbSet<LabOrderTest> OrderTests => Set<LabOrderTest>();
    public DbSet<LabTestResult> Results => Set<LabTestResult>();
    public DbSet<LabResultHistory> ResultHistory => Set<LabResultHistory>();
    public DbSet<LabPanicCall> PanicCalls => Set<LabPanicCall>();
    public DbSet<LabWorklistBatch> Batches => Set<LabWorklistBatch>();
    public DbSet<LabUnmatchedResult> UnmatchedResults => Set<LabUnmatchedResult>();
    public DbSet<LabPatientNotification> Notifications => Set<LabPatientNotification>();

    // --- QC ---
    public DbSet<LabQcMaterial> QcMaterials => Set<LabQcMaterial>();
    public DbSet<LabQcTarget> QcTargets => Set<LabQcTarget>();
    public DbSet<LabQcResult> QcResults => Set<LabQcResult>();
    public DbSet<LabAnalyzerLockout> Lockouts => Set<LabAnalyzerLockout>();

    // --- logistics / biobank / reagents ---
    public DbSet<LabSampleLogistics> Logistics => Set<LabSampleLogistics>();
    public DbSet<LabSampleLogisticsItem> LogisticsItems => Set<LabSampleLogisticsItem>();
    public DbSet<LabArchiveRack> Racks => Set<LabArchiveRack>();
    public DbSet<LabArchiveCell> Cells => Set<LabArchiveCell>();
    public DbSet<LabReagentLot> ReagentLots => Set<LabReagentLot>();

    // --- microbiology ---
    public DbSet<LabCultureOrder> Cultures => Set<LabCultureOrder>();
    public DbSet<LabIsolate> Isolates => Set<LabIsolate>();
    public DbSet<LabSusceptibilityResult> Susceptibilities => Set<LabSusceptibilityResult>();

    // --- connector ---
    public DbSet<LabConnectorInstallation> Connectors => Set<LabConnectorInstallation>();
    public DbSet<LabAnalyzer> Analyzers => Set<LabAnalyzer>();
    public DbSet<LabAnalyzerParameterMap> AnalyzerParameters => Set<LabAnalyzerParameterMap>();
    public DbSet<LabAnalyzerMessage> AnalyzerMessages => Set<LabAnalyzerMessage>();
    public DbSet<LabConnectorLog> ConnectorLogs => Set<LabConnectorLog>();
    public DbSet<LabConnectorCommand> ConnectorCommands => Set<LabConnectorCommand>();

    // --- sections / journals / processing ---
    public DbSet<LabSection> Sections => Set<LabSection>();
    public DbSet<LabSectionJournalEntry> JournalEntries => Set<LabSectionJournalEntry>();
    public DbSet<LabWorkflowTemplate> WorkflowTemplates => Set<LabWorkflowTemplate>();
    public DbSet<LabSampleStageEvent> StageEvents => Set<LabSampleStageEvent>();
    public DbSet<LabOrderFavorite> OrderFavorites => Set<LabOrderFavorite>();

    // --- зовнішні лабораторії (send-out) ---
    public DbSet<LabPerformer> Performers => Set<LabPerformer>();
    public DbSet<LabPerformerTest> PerformerTests => Set<LabPerformerTest>();
    public DbSet<LabSendOut> SendOuts => Set<LabSendOut>();
    public DbSet<LabSendOutItem> SendOutItems => Set<LabSendOutItem>();
    public DbSet<LabOrderAttachment> Attachments => Set<LabOrderAttachment>();
    public DbSet<LabEhealthExchangeLog> EhealthExchangeLog => Set<LabEhealthExchangeLog>();

    // --- оплата (FR-GAP-060) ---
    public DbSet<LabPriceList> PriceLists => Set<LabPriceList>();
    public DbSet<LabPriceListItem> PriceListItems => Set<LabPriceListItem>();
    public DbSet<LabPricePackage> PricePackages => Set<LabPricePackage>();
    public DbSet<LabPayer> Payers => Set<LabPayer>();
    public DbSet<OrdPatientInsurance> PatientInsurances => Set<OrdPatientInsurance>();
    public DbSet<LabOrderCharge> OrderCharges => Set<LabOrderCharge>();
    public DbSet<LabPayment> Payments => Set<LabPayment>();
    public DbSet<LabInvoice> Invoices => Set<LabInvoice>();

    // --- system ---
    public DbSet<LabAuditLog> AuditLog => Set<LabAuditLog>();
    public DbSet<LabSettings> Settings => Set<LabSettings>();
    public DbSet<LabNumerator> Numerators => Set<LabNumerator>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        base.OnModelCreating(mb);

        // Унікальні індекси та індекси для швидких вибірок робочого листа
        mb.Entity<LabOrder>().HasIndex(o => o.OrderNumber).IsUnique();
        mb.Entity<LabOrder>().HasIndex(o => o.Status);
        mb.Entity<LabOrder>().HasIndex(o => o.PatientId);
        mb.Entity<LabOrder>().HasIndex(o => o.OrderDatetime);
        mb.Entity<LabOrder>().HasIndex(o => o.VerifyToken);
        mb.Entity<LabOrderSample>().HasIndex(s => s.Barcode).IsUnique();
        mb.Entity<LabOrderSample>().HasIndex(s => s.OrderId);
        mb.Entity<LabOrderTest>().HasIndex(t => t.OrderId);
        mb.Entity<LabOrderTest>().HasIndex(t => t.Status);
        mb.Entity<LabOrderTest>().HasIndex(t => t.TestCode);
        mb.Entity<LabTestResult>().HasIndex(r => r.OrderTestId).IsUnique();
        mb.Entity<LabTestResult>().HasIndex(r => r.Flag);
        mb.Entity<LabTestResult>().HasIndex(r => r.EnteredAt);
        mb.Entity<LabTestDefinition>().HasIndex(t => t.Code).IsUnique();
        mb.Entity<LabTestProfile>().HasIndex(p => p.Code).IsUnique();
        mb.Entity<LabReferenceLayer>().HasIndex(l => new { l.TestCode, l.MethodCode, l.PriorityOrder });
        mb.Entity<LabQcResult>().HasIndex(q => new { q.QcMaterialId, q.TestCode, q.RunAt });
        mb.Entity<LabAnalyzerLockout>().HasIndex(l => new { l.AnalyzerId, l.ResolvedAt });
        mb.Entity<LabAnalyzer>().HasIndex(a => a.Code).IsUnique();
        mb.Entity<LabConnectorInstallation>().HasIndex(c => c.ApiKeyHash);
        mb.Entity<LabConnectorInstallation>().HasIndex(c => c.InstallKey).IsUnique();
        mb.Entity<LabAuditLog>().HasIndex(a => new { a.Entity, a.EntityId });
        mb.Entity<LabAuditLog>().HasIndex(a => a.At);
        mb.Entity<LabArchiveCell>().HasIndex(c => new { c.RackId, c.RowNum, c.ColNum }).IsUnique();
        mb.Entity<LabEucastBreakpoint>().HasIndex(b => new { b.OrganismId, b.AntibioticId, b.EucastVersion }).IsUnique();
        mb.Entity<LabSection>().HasIndex(s => s.Code).IsUnique();
        mb.Entity<LabSectionJournalEntry>().HasIndex(j => new { j.LabSectionId, j.RegisteredAt });
        mb.Entity<LabSectionJournalEntry>().HasIndex(j => new { j.OrderId, j.LabSectionId, j.SampleId }).IsUnique();
        mb.Entity<LabSampleStageEvent>().HasIndex(e => new { e.SampleId, e.At });
        mb.Entity<LabOrderFavorite>().HasIndex(f => f.EmployeeId);
        mb.Entity<LabOrderSample>().HasOne(s => s.ParentSample).WithMany().HasForeignKey(s => s.ParentSampleId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<LabOrderTest>().HasIndex(t => t.ReleasedAt);

        // [MedLink] персона та лабораторні атрибути завантажуються разом із карткою/співробітником/підрозділом
        mb.Entity<LabEhealthExchangeLog>().HasIndex(l => l.At);
        mb.Entity<LabPriceList>().HasIndex(p => p.Code).IsUnique();
        mb.Entity<LabPriceListItem>().HasIndex(i => new { i.PriceListId, i.ProfileId, i.TestId });
        mb.Entity<LabPayer>().HasIndex(p => p.Code).IsUnique();
        mb.Entity<MisPatientInsurance>().HasIndex(p => p.PatientCardId);
        mb.Entity<OrdPatientInsurance>().HasIndex(p => p.PatientCardId);
        mb.Entity<LabOrderCharge>().HasIndex(c => c.OrderId);
        mb.Entity<LabPayment>().HasIndex(p => p.OrderId);
        mb.Entity<LabInvoice>().HasIndex(i => i.Number).IsUnique();
        mb.Entity<LabOrder>().HasMany(o => o.Charges).WithOne(c => c.Order).HasForeignKey(c => c.OrderId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<LabOrder>().HasIndex(o => o.EhealthReferralId);
        mb.Entity<LabOrder>().HasIndex(o => o.ReferralType);
        mb.Entity<EheIncomingMedicalReferral>().HasIndex(r => r.RegNumber);
        mb.Entity<LabPerformer>().HasIndex(p => p.Code).IsUnique();
        mb.Entity<LabPerformerTest>().HasIndex(p => new { p.PerformerId, p.TestId }).IsUnique();
        mb.Entity<LabSendOut>().HasIndex(s => s.Number).IsUnique();
        mb.Entity<LabSendOutItem>().HasIndex(i => i.OrderTestId);
        mb.Entity<LabOrderAttachment>().HasIndex(a => a.OrderId);
        mb.Entity<LabOrderTest>().HasIndex(t => t.PerformerId);

        mb.Entity<OrgEmployee>().HasOne(e => e.LabSettings).WithOne(s => s.Employee).HasForeignKey<LabEmployeeSettings>(s => s.EmployeeId);
        mb.Entity<OrgEmployee>().Navigation(e => e.Person).AutoInclude();
        mb.Entity<OrgEmployee>().Navigation(e => e.LabSettings).AutoInclude();
        mb.Entity<CmnPerson>().HasIndex(p => new { p.LastName, p.Name });
        mb.Entity<OrdPatient>().HasIndex(p => p.Caption);
        mb.Entity<OrdPatient>().HasIndex(p => new { p.LastName, p.Name });
        mb.Entity<OrdPatient>().Property<string?>("GenderId").HasMaxLength(64);
        mb.Entity<OrdPatient>().Property(p => p.Sex).HasDefaultValue("unknown");
        mb.Entity<OrdPatientIdentifier>().HasIndex(i => new { i.TenantId, i.System, i.Value }).IsUnique();
        mb.Entity<OrdOrderIdentifier>().HasIndex(i => new { i.TenantId, i.System, i.Value });
        mb.Entity<OrdRequester>().Property(r => r.Identifiers).HasDefaultValueSql("'[]'::jsonb");

        mb.Entity<LabOrderTest>().HasOne(t => t.Result).WithOne(r => r.OrderTest).HasForeignKey<LabTestResult>(r => r.OrderTestId);
        mb.Entity<LabOrder>().HasMany(o => o.Samples).WithOne(s => s.Order).HasForeignKey(s => s.OrderId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<LabOrder>().HasMany(o => o.Tests).WithOne(t => t.Order).HasForeignKey(t => t.OrderId).OnDelete(DeleteBehavior.Cascade);

        // Довідники з явними int-ключами (сід задає id)
        mb.Entity<LabBiomaterialType>().Property(e => e.Id).ValueGeneratedNever();
        mb.Entity<LabTubeType>().Property(e => e.Id).ValueGeneratedNever();
        mb.Entity<LabMethodType>().Property(e => e.Id).ValueGeneratedNever();
        mb.Entity<LabAnalyzerType>().Property(e => e.Id).ValueGeneratedNever();
        mb.Entity<LabMicroOrganism>().Property(e => e.Id).ValueGeneratedNever();
        mb.Entity<LabAntibiotic>().Property(e => e.Id).ValueGeneratedNever();

        mb.Entity<UserDefaultValue>().HasAlternateKey(ent => new { ent.UserId, ent.EntityName });
        mb.Entity<RowLevelRight>().HasAlternateKey(r => new { r.ProfileId, r.EntityName, r.MainEntityName });
        mb.Entity<UserProfile>().HasIndex(u => u.UserId);
        mb.Entity<CmnPerson>().HasIndex(p => p.UserId);
        mb.Entity<SimpleDataDto>().HasNoKey().ToTable((string?)null);

        mb.Entity<LabNumerator>().HasKey(n => new { n.TenantId, n.Code });
        mb.Entity<LabWorkflowTemplate>().HasKey(t => new { t.TenantId, t.Code });
        mb.Entity<TnSequence>().HasKey(s => new { s.TenantId, s.Key, s.ScopeKey });
        mb.Entity<TnDivision>().HasIndex(d => new { d.TenantId, d.Code }).IsUnique();
        mb.Entity<TnDivision>().Property(d => d.Type).HasConversion(v => v.ToLowerInvariant(), v => v.ToUpperInvariant());
        mb.Entity<IdUser>().HasIndex(u => u.Sub).IsUnique();
        mb.Entity<IdMembership>().HasIndex(m => new { m.TenantId, m.UserId }).IsUnique();
        mb.Entity<IdMembershipDivision>().HasKey(d => new { d.MembershipId, d.DivisionId });
        mb.Entity<IdMembershipDivision>().HasIndex(d => new { d.TenantId, d.MembershipId, d.DivisionId }).IsUnique();
        mb.Entity<IdMembershipDivision>().Property<Guid>("Id").HasColumnName("id").HasValueGenerator<Microsoft.EntityFrameworkCore.ValueGeneration.GuidValueGenerator>();
        mb.Entity<IdRole>().HasIndex(r => new { r.TenantId, r.Code }).IsUnique();
        mb.Entity<IdRolePermission>().HasIndex(r => new { r.TenantId, r.RoleId, r.PermissionCode }).IsUnique();
        mb.Entity<IdMembershipRole>().HasIndex(r => new { r.TenantId, r.MembershipId, r.RoleId }).IsUnique();
        mb.Entity<OrgEmployee>().Property(e => e.MembershipId).HasComputedColumnSql("id::uuid", stored: true);
        mb.Entity<OrgEmployee>().HasIndex(e => e.MembershipId).IsUnique();
        mb.Entity<OrgEmployee>().HasOne(e => e.Membership).WithMany().HasForeignKey(e => e.MembershipId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<LabPerformer>().HasOne<TnDivision>().WithMany().HasForeignKey(p => p.DepartmentId).OnDelete(DeleteBehavior.SetNull);
        mb.Entity<TnRequisites>().HasOne<TnTenant>().WithOne().HasForeignKey<TnRequisites>(r => r.TenantId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<TnSettings>().HasOne<TnTenant>().WithOne().HasForeignKey<TnSettings>(s => s.TenantId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<TnDivision>().HasOne<TnTenant>().WithMany().HasForeignKey(d => d.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<TnSequence>().HasOne<TnTenant>().WithMany().HasForeignKey(s => s.TenantId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<IdMembership>().HasOne<TnTenant>().WithMany().HasForeignKey(m => m.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<IdMembershipDivision>().HasOne<TnTenant>().WithMany().HasForeignKey(d => d.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<OrdPatient>().HasOne<TnTenant>().WithMany().HasForeignKey(p => p.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<OrdPatientIdentifier>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<OrdOrderIdentifier>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<OrdRequester>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<OrdPatientInsurance>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<IdRole>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<IdRolePermission>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<IdMembershipRole>().HasOne<TnTenant>().WithMany().HasForeignKey(e => e.TenantId).OnDelete(DeleteBehavior.Restrict);

        foreach (var entity in mb.Model.GetEntityTypes().Where(e => typeof(ITenantScoped).IsAssignableFrom(e.ClrType)).ToList())
        {
            PrefixIndexesWithTenant(entity);
            SetTenantFilterMethod.MakeGenericMethod(entity.ClrType).Invoke(this, new object[] { mb });
        }
        ApplyDivisionFilters(mb);
        ApplyUuidColumns(mb);

        var guidConverter = new ValueConverter<Guid, string>(v => v.ToString(), v => Guid.Parse(v));
        var guidNullableConverter = new ValueConverter<Guid?, string?>(v => v.HasValue ? v.Value.ToString() : null, v => v == null ? null : Guid.Parse(v));

        var utcConverter = new ValueConverter<DateTime, DateTime>(v => v, v => DateTime.SpecifyKind(v, DateTimeKind.Utc));
        var utcNullableConverter = new ValueConverter<DateTime?, DateTime?>(v => v, v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : v);

        foreach (var entity in mb.Model.GetEntityTypes())
        {
            // snake_case для таблиць без атрибуту [Table] та для всіх колонок
            var tableAttr = entity.ClrType.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.Schema.TableAttribute), false);
            var mappedTable = entity.GetTableName();
            if (mappedTable != null)
            {
                if (tableAttr.Length == 0) entity.SetTableName(ToSnakeCase(entity.ClrType.Name));
                else if (entity.ClrType.Namespace == typeof(Profile).Namespace) entity.SetTableName(ToSnakeCase(mappedTable));
            }

            foreach (var prop in entity.GetProperties())
            {
                var colAttr = prop.PropertyInfo?.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.Schema.ColumnAttribute), false);
                if (colAttr == null || colAttr.Length == 0) prop.SetColumnName(ToSnakeCase(prop.Name));
                if (prop.ClrType == typeof(DateTime)) prop.SetValueConverter(utcConverter);
                if (prop.ClrType == typeof(DateTime?)) prop.SetValueConverter(utcNullableConverter);
                if (prop.ClrType == typeof(decimal) || prop.ClrType == typeof(decimal?)) prop.SetColumnType("NUMERIC(18,2)");
                if (prop.ClrType == typeof(Guid)) { prop.SetValueConverter(guidConverter); prop.SetMaxLength(64); }
                if (prop.ClrType == typeof(Guid?)) { prop.SetValueConverter(guidNullableConverter); prop.SetMaxLength(64); }
            }
            foreach (var key in entity.GetKeys())
                key.SetName(key.IsPrimaryKey() ? ToSnakeCase($"pk_{entity.GetTableName()}") : ToSnakeCase($"ak_{entity.GetTableName()}_{string.Join("_", key.Properties.Select(p => p.Name))}"));
            foreach (var fk in entity.GetForeignKeys())
            {
                fk.SetConstraintName(ToSnakeCase($"fk_{entity.GetTableName()}_{string.Join("_", fk.Properties.Select(p => p.Name))}"));
                // Для довідкових зв'язків не каскадувати видалення
                if (fk.DeleteBehavior == DeleteBehavior.Cascade && !fk.IsRequired) fk.DeleteBehavior = DeleteBehavior.SetNull;
            }
            foreach (var ix in entity.GetIndexes())
                ix.SetDatabaseName(ToSnakeCase($"ix_{entity.GetTableName()}_{string.Join("_", ix.Properties.Select(p => p.Name))}"));
        }
        mb.Entity<IdMembershipDivision>().Property<Guid>("Id").HasConversion((ValueConverter?)null).HasColumnType("uuid").Metadata.SetMaxLength(null);
    }

    private void SetTenantFilter<TEntity>(ModelBuilder mb) where TEntity : class, ITenantScoped =>
        mb.Entity<TEntity>().HasQueryFilter(e => e.TenantId == CurrentTenantId);

    private void ApplyDivisionFilters(ModelBuilder mb)
    {
        mb.Entity<TnDivision>().HasQueryFilter(d => d.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || AllowedDepartmentIds.Contains(d.Id)));
        mb.Entity<LabOrder>().HasQueryFilter(o => o.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || (o.DepartmentId != null && AllowedDepartmentIds.Contains(o.DepartmentId!))));
        mb.Entity<OrdPatient>().HasQueryFilter(p => p.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.PatientId == p.Id)));
        mb.Entity<LabOrderSample>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabOrderTest>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabTestResult>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || OrderTests.Any(t => t.Id == e.OrderTestId)));
        mb.Entity<LabOrderCharge>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabPayment>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabCultureOrder>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabSectionJournalEntry>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabOrderAttachment>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabResultHistory>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || OrderTests.Any(t => t.Id == e.OrderTestId)));
        mb.Entity<LabPanicCall>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<LabPatientNotification>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || (e.OrderId != null ? Orders.Any(o => o.Id == e.OrderId) : Patients.Any(p => p.Id == e.PatientId))));
        mb.Entity<LabSampleStageEvent>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Samples.Any(s => s.Id == e.SampleId)));
        mb.Entity<LabSendOutItem>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || OrderTests.Any(t => t.Id == e.OrderTestId)));
        mb.Entity<LabSampleLogistics>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || AllowedDepartmentIds.Contains(e.OriginDepartmentId) || AllowedDepartmentIds.Contains(e.DestinationDepartmentId)));
        mb.Entity<LabSampleLogisticsItem>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Samples.Any(s => s.Id == e.SampleId)));
        mb.Entity<LabArchiveCell>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || e.SampleId == null || Samples.Any(s => s.Id == e.SampleId)));
        mb.Entity<LabIsolate>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Cultures.Any(c => c.Id == e.CultureOrderId)));
        mb.Entity<LabSusceptibilityResult>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Isolates.Any(i => i.Id == e.IsolateId)));
        mb.Entity<MisDiagnosticReport>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.DiagnosticReportId == e.Id)));
        mb.Entity<MisPatientInsurance>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Patients.Any(p => p.Id == e.PatientCardId)));
        mb.Entity<OrdPatientIdentifier>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Patients.Any(p => p.Id == e.PatientId)));
        mb.Entity<OrdPatientInsurance>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Patients.Any(p => p.Id == e.PatientCardId)));
        mb.Entity<OrdOrderIdentifier>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Orders.Any(o => o.Id == e.OrderId)));
        mb.Entity<EhePaperMedicalReferral>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || Patients.Any(p => p.Id == e.PatientCardId)));
        mb.Entity<LabInvoice>().HasQueryFilter(e => e.TenantId == CurrentTenantId
            && (AllowedDepartmentIds == null || (e.OrderId != null && Orders.Any(o => o.Id == e.OrderId))));
    }

    private static readonly HashSet<Type> UuidKeyedTypes = new() { typeof(TnTenant), typeof(TnDivision), typeof(IdUser), typeof(IdMembership), typeof(IdMembershipDivision), typeof(OrdPatientIdentifier), typeof(OrdOrderIdentifier), typeof(OrdRequester), typeof(OrdPatientInsurance), typeof(IdRole), typeof(IdRolePermission), typeof(IdMembershipRole) };

    public static Guid ToUuid(string? value) => Guid.TryParse(value, out var g) ? g : Guid.Empty;

    private static void ApplyUuidColumns(ModelBuilder mb)
    {
        var converter = new ValueConverter<string, Guid>(v => ToUuid(v), v => v.ToString());
        var properties = new HashSet<IMutableProperty>();
        foreach (var entity in mb.Model.GetEntityTypes())
        {
            if (typeof(ITenantScoped).IsAssignableFrom(entity.ClrType)) properties.Add(entity.FindProperty(nameof(ITenantScoped.TenantId))!);
            if (UuidKeyedTypes.Contains(entity.ClrType)) properties.UnionWith(entity.FindPrimaryKey()!.Properties);
            foreach (var fk in entity.GetForeignKeys().Where(fk => UuidKeyedTypes.Contains(fk.PrincipalEntityType.ClrType)))
                properties.UnionWith(fk.Properties);
        }
        foreach (var property in properties)
        {
            property.SetValueConverter(converter);
            property.SetColumnType("uuid");
            property.SetMaxLength(null);
        }
        var strictConverter = new ValueConverter<string, Guid>(v => Guid.Parse(v), v => v.ToString());
        foreach (var property in new[] { mb.Entity<IdMembership>().Property(m => m.RoleId).Metadata })
        {
            property.SetValueConverter(strictConverter);
            property.SetColumnType("uuid");
            property.SetMaxLength(null);
        }
    }

    private static void PrefixIndexesWithTenant(IMutableEntityType entity)
    {
        var tenant = entity.FindProperty(nameof(ITenantScoped.TenantId))!;
        foreach (var index in entity.GetIndexes().ToList())
        {
            if (index.Properties[0] == tenant) continue;
            if (((IConventionIndex)index).GetConfigurationSource() == ConfigurationSource.Convention) continue;
            if (index.Properties.Count == 1 && CrossTenantLookupIndexes.Contains((entity.ClrType, index.Properties[0].Name))) continue;
            if (entity.GetForeignKeys().Any(fk => fk.Properties.SequenceEqual(index.Properties))) continue;
            var properties = new List<IMutableProperty> { tenant };
            properties.AddRange(index.Properties);
            var isUnique = index.IsUnique;
            entity.RemoveIndex(index);
            entity.AddIndex(properties).IsUnique = isUnique;
        }
        if (!entity.GetIndexes().Any(i => i.Properties[0] == tenant)) entity.AddIndex(tenant);
    }

    public override int SaveChanges()
    {
        StampTenant();
        EnsureReferencesInTenantAsync(false, CancellationToken.None).GetAwaiter().GetResult();
        StampAudit();
        return base.SaveChanges();
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        StampTenant();
        await EnsureReferencesInTenantAsync(true, cancellationToken);
        StampAudit();
        return await base.SaveChangesAsync(cancellationToken);
    }

    private static readonly MethodInfo CountInTenantMethod =
        typeof(LisDbContext).GetMethod(nameof(CountInTenantAsync), BindingFlags.NonPublic | BindingFlags.Instance)!;

    private async Task EnsureReferencesInTenantAsync(bool async, CancellationToken ct)
    {
        var tracked = new HashSet<(IEntityType Type, object Key)>();
        var references = new Dictionary<(IEntityType Type, IProperty Key), HashSet<object>>();
        foreach (var entry in ChangeTracker.Entries())
        {
            var primaryKey = entry.Metadata.FindPrimaryKey();
            if (primaryKey is { Properties.Count: 1 } && entry.Property(primaryKey.Properties[0].Name).CurrentValue is { } key)
                tracked.Add((entry.Metadata.GetRootType(), key));
            if (entry.Entity is not ITenantScoped || entry.State is not (EntityState.Added or EntityState.Modified)) continue;
            foreach (var fk in entry.Metadata.GetForeignKeys())
            {
                if (fk.Properties.Count != 1 || fk.PrincipalKey.Properties.Count != 1 || !typeof(ITenantScoped).IsAssignableFrom(fk.PrincipalEntityType.ClrType)) continue;
                var property = entry.Property(fk.Properties[0].Name);
                if (property.CurrentValue is not { } value || (entry.State == EntityState.Modified && !property.IsModified)) continue;
                var target = (fk.PrincipalEntityType.GetRootType(), (IProperty)fk.PrincipalKey.Properties[0]);
                if (!references.TryGetValue(target, out var values)) references[target] = values = new HashSet<object>();
                values.Add(value);
            }
        }
        foreach (var ((type, keyProperty), values) in references)
        {
            var missing = values.Where(v => !tracked.Contains((type, v))).ToList();
            if (missing.Count == 0) continue;
            var count = await (Task<int>)CountInTenantMethod.MakeGenericMethod(type.ClrType, keyProperty.ClrType)
                .Invoke(this, new object[] { keyProperty.Name, missing, async, ct })!;
            if (count != missing.Count) throw new TenantMismatchException(type.GetTableName());
        }
    }

    private async Task<int> CountInTenantAsync<TEntity, TKey>(string keyName, List<object> keys, bool async, CancellationToken ct) where TEntity : class, ITenantScoped
    {
        var tenantId = CurrentTenantId;
        var typed = keys.Cast<TKey>().ToList();
        var query = Set<TEntity>().IgnoreQueryFilters().AsNoTracking().Where(e => e.TenantId == tenantId && typed.Contains(EF.Property<TKey>(e, keyName)));
        return async ? await query.CountAsync(ct) : query.Count();
    }

    private void StampTenant()
    {
        foreach (var entry in ChangeTracker.Entries<ITenantScoped>())
        {
            if (entry.State != EntityState.Added && entry.State != EntityState.Modified) continue;
            var tenantId = CurrentTenantId;
            if (entry.State == EntityState.Added && string.IsNullOrEmpty(entry.Entity.TenantId)) entry.Entity.TenantId = tenantId;
            else if (entry.Entity.TenantId != tenantId) throw new TenantMismatchException(entry.Metadata.GetTableName());
            if (entry.Entity is LabOrder order && AllowedDepartmentIds is { } allowed && (order.DepartmentId == null || !allowed.Contains(order.DepartmentId)))
                throw new DepartmentNotAllowedException(order.DepartmentId);
        }
    }

    /// <summary>Поточний користувач для службових колонок (виставляється middleware через CurrentEmployee).</summary>
    public string? CurrentUserId { get; set; }

    /// <summary>created_by/modified_by — uuid як в evomis: поточний співробітник або нульовий GUID для системних дій.</summary>
    private string AuditUserId => Guid.TryParse(CurrentUserId, out _) ? CurrentUserId! : MedLinkEnums.EmptyGuid;

    private void StampAudit()
    {
        var now = DateTime.UtcNow;
        foreach (var entry in ChangeTracker.Entries<AuditableEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                if (entry.Entity.CreatedOn == default) entry.Entity.CreatedOn = now;
                if (string.IsNullOrEmpty(entry.Entity.CreatedBy) || entry.Entity.CreatedBy == MedLinkEnums.EmptyGuid) entry.Entity.CreatedBy = AuditUserId;
                if (string.IsNullOrEmpty(entry.Entity.ModifiedBy) || entry.Entity.ModifiedBy == MedLinkEnums.EmptyGuid) entry.Entity.ModifiedBy = AuditUserId;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.ModifiedOn = now;
                entry.Entity.ModifiedBy = AuditUserId;
            }
        }
        var author = Guid.Parse(AuditUserId);
        foreach (var entry in ChangeTracker.Entries<CoreEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                if (entry.Entity.CreatedOn == default) entry.Entity.CreatedOn = now;
                if (entry.Entity.CreatedBy == Guid.Empty) entry.Entity.CreatedBy = author;
                if (entry.Entity.ModifiedBy == Guid.Empty) entry.Entity.ModifiedBy = author;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.ModifiedOn = now;
                entry.Entity.ModifiedBy = author;
            }
        }
    }

    public IEnumerable<string> GetIdentifiersRecursive(string entityName, string parentColumnName, IEnumerable<string> parentIds)
    {
        if (parentIds == null) throw new ArgumentNullException(nameof(parentIds), "Argument ids cannot be null");
        var entityType = Model.GetEntityTypes().FirstOrDefault(x => x.ClrType.Name == entityName)
                         ?? throw new ArgumentException($"Cannot find entity by name {entityName}");
        var property = entityType.FindProperty(parentColumnName) ?? throw new ArgumentException($"Cannot find property {parentColumnName} in entity {entityName}");
        var table = entityType.GetTableName()!;
        var parentColumn = property.GetColumnName();
        var emptyStringGuid = Guid.Empty.ToString();
        var filteredIds = parentIds.Where(x => !string.IsNullOrEmpty(x) && x != emptyStringGuid).Select(x => (object)x.ToLowerInvariant()).ToArray();
        if (filteredIds.Length == 0) return Array.Empty<string>();
        var placeHolders = string.Join(",", filteredIds.Select((_, i) => "{" + i + "}"));
        var scoped = typeof(ITenantScoped).IsAssignableFrom(entityType.ClrType);
        var tenant = "CAST({" + filteredIds.Length + "} AS uuid)";
        var arguments = scoped ? filteredIds.Append(CurrentTenantId).ToArray() : filteredIds;
        var queryText = $@"WITH RECURSIVE r AS (
   SELECT id, {parentColumn} FROM {table} WHERE {parentColumn} IN ({placeHolders}){(scoped ? $" AND tenant_id = {tenant}" : "")}
   UNION ALL
   SELECT tab.id, tab.{parentColumn} FROM {table} AS tab JOIN r ON tab.{parentColumn} = r.id AND tab.id <> r.id{(scoped ? $" AND tab.tenant_id = {tenant}" : "")}
)
SELECT r.id AS data FROM r";
        var query = Set<SimpleDataDto>().FromSqlInterpolated(FormattableStringFactory.Create(queryText, arguments));
        return query.ToArray().Select(x => x.Data).Distinct();
    }

    private static readonly Regex SnakeRegex = new("(?<=[a-z0-9])([A-Z])|(?<=[A-Z])([A-Z][a-z])", RegexOptions.Compiled);

    public static string ToSnakeCase(string name)
    {
        if (string.IsNullOrEmpty(name)) return name;
        var s = SnakeRegex.Replace(name, m => "_" + m.Value);
        return s.ToLowerInvariant().Replace("__", "_");
    }
}
