using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace MedLink.LIS.Api.Data;

public sealed class LisDbContextDesignTimeFactory : IDesignTimeDbContextFactory<LisDbContext>
{
    public const string MigratorConnectionName = "MigratorConnection";

    public LisDbContext CreateDbContext(string[] args)
    {
        var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development";
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddJsonFile($"appsettings.{environment}.json", optional: true)
            .AddEnvironmentVariables()
            .Build();
        var connectionString = configuration.GetConnectionString(MigratorConnectionName)
            ?? throw new InvalidOperationException($"ConnectionStrings:{MigratorConnectionName} is not configured.");
        return new LisDbContext(new DbContextOptionsBuilder<LisDbContext>().UseNpgsql(connectionString).Options);
    }
}
