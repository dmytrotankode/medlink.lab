using Microsoft.EntityFrameworkCore.Migrations;

namespace MedLink.LIS.Api.Data;

public static class MigrationHelpers
{
    public const string PolicyName = "tenant_isolation";
    public const string TenantCondition = "lis_tenant_guard() AND tenant_id = lis_current_tenant()";

    public static void CreateTenantFunctions(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            CREATE OR REPLACE FUNCTION lis_tenant_guard() RETURNS boolean
            LANGUAGE plpgsql STABLE COST 0.0001 AS $$
            BEGIN
                IF coalesce(current_setting('app.tenant_id', true), '') <> '' THEN
                    RETURN true;
                END IF;
                IF coalesce(current_setting('app.user_id', true), '') <> ''
                    OR coalesce(current_setting('app.connector_api_key_hash', true), '') <> ''
                    OR coalesce(current_setting('app.connector_install_key', true), '') <> ''
                    OR coalesce(current_setting('app.verify_token', true), '') <> ''
                    OR coalesce(current_setting('app.tenant_enumeration', true), '') <> '' THEN
                    RETURN true;
                END IF;
                RAISE EXCEPTION 'app.tenant_id is not set' USING ERRCODE = '42704';
            END
            $$;
            """);
        migrationBuilder.Sql("""
            CREATE OR REPLACE FUNCTION lis_current_tenant() RETURNS uuid
            LANGUAGE plpgsql STABLE AS $$
            BEGIN
                PERFORM lis_tenant_guard();
                RETURN NULLIF(current_setting('app.tenant_id', true), '')::uuid;
            END
            $$;
            """);
    }

    public static void DropTenantFunctions(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("DROP FUNCTION IF EXISTS lis_current_tenant();");
        migrationBuilder.Sql("DROP FUNCTION IF EXISTS lis_tenant_guard();");
    }

    public static void EnableRls(MigrationBuilder migrationBuilder, string table)
    {
        migrationBuilder.Sql($"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"""
            CREATE POLICY {PolicyName} ON {table}
            USING ({TenantCondition})
            WITH CHECK ({TenantCondition});
            """);
    }

    public static void EnableRlsWithLookup(MigrationBuilder migrationBuilder, string table, string lookupCondition)
    {
        migrationBuilder.Sql($"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"""
            CREATE POLICY {PolicyName} ON {table}
            USING (lis_tenant_guard() AND (tenant_id = lis_current_tenant() OR ({lookupCondition})))
            WITH CHECK ({TenantCondition});
            """);
    }

    public static void EnableTenantTableRls(MigrationBuilder migrationBuilder, string lookupCondition)
    {
        migrationBuilder.Sql("ALTER TABLE tn_tenant ENABLE ROW LEVEL SECURITY;");
        migrationBuilder.Sql("ALTER TABLE tn_tenant FORCE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"""
            CREATE POLICY {PolicyName} ON tn_tenant
            USING (lis_tenant_guard() AND (id = lis_current_tenant() OR ({lookupCondition})))
            WITH CHECK (lis_tenant_guard() AND id = lis_current_tenant());
            """);
    }

    public static void DisableRls(MigrationBuilder migrationBuilder, string table)
    {
        migrationBuilder.Sql($"DROP POLICY IF EXISTS {PolicyName} ON {table};");
        migrationBuilder.Sql($"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY;");
        migrationBuilder.Sql($"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;");
    }
}
