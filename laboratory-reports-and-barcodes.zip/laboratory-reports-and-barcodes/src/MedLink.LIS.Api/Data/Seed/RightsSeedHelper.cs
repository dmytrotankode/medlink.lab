using Core.Security;
using Core.Security.Models;
using MedLink.LIS.Api.Data.Helpers;
using Microsoft.EntityFrameworkCore;
using CoreRecordState = Core.Base.Data.RecordState;

namespace MedLink.LIS.Api.Data.Seed;

public sealed class SecuritySeed
{
    public List<LabRoleSeed> LabRoles { get; set; } = new();
    public Dictionary<string, string[]> OperationRoles { get; set; } = new();
    public List<UserProfileSeed> UserProfiles { get; set; } = new();
    public List<IdentityUserSeed> IdentityUsers { get; set; } = new();

    public LabRoleSeed? ForRole(string? code) => LabRoles.FirstOrDefault(r => r.Code == code);

    public LabRoleSeed? ForCaption(string? caption) => LabRoles.FirstOrDefault(r => r.Caption == caption);

    public bool Allows(string role, string operationName) => OperationRoles.TryGetValue(operationName, out var roles) && roles.Contains(role);

    public IEnumerable<string> OperationsOf(string role) => OperationRoles.Where(o => o.Value.Contains(role)).Select(o => o.Key);
}

public sealed class LabRoleSeed
{
    public string Code { get; set; } = "";
    public string Caption { get; set; } = "";
}

public sealed class UserProfileSeed
{
    public string EmployeeId { get; set; } = "";
}

public sealed class IdentityUserSeed
{
    public string UserId { get; set; } = "";
    public string? Email { get; set; }
    public string EmployeeId { get; set; } = "";
}

public static class RightsSeedHelper
{
    private static readonly Lazy<SecuritySeed> _security = new(() => SeedService.ReadResource<SecuritySeed>("security.json"));

    public static SecuritySeed Security => _security.Value;

    public static Profile CreateProfileIfAbsent(LisDbContext context, string caption, bool isActive = true)
    {
        var profile = context.SecurityProfiles!.SingleOrDefault(x => x.Caption == caption);
        if (profile == null)
        {
            profile = new Profile { Id = Guid.NewGuid(), IsActive = isActive, Caption = caption };
            context.SecurityProfiles!.Add(profile);
        }

        return profile;
    }

    public static Role CreateRoleIfAbsent(LisDbContext context, string caption, bool isActive = true)
    {
        var role = context.Roles!.SingleOrDefault(x => x.Caption == caption);
        if (role == null)
        {
            role = new Role { Id = Guid.NewGuid(), IsActive = isActive, Caption = caption };
            context.Roles!.Add(role);
        }

        return role;
    }

    public static ProfileRole CreateProfileRoleIfAbsent(LisDbContext context, Profile profile, Role role)
    {
        var profileRole = context.ProfileRoles!.SingleOrDefault(x => x.ProfileId == profile.Id && x.RoleId == role.Id);
        if (profileRole == null)
        {
            profileRole = new ProfileRole { Id = Guid.NewGuid(), ProfileId = profile.Id, RoleId = role.Id };
            context.ProfileRoles!.Add(profileRole);
        }

        return profileRole;
    }

    public static void CreateUpdateRoleOperationRightsIfDiffer(LisDbContext context, Guid roleId, IEnumerable<OperationRight> rights)
    {
        var existingRoleRights = context.RoleOperationRights!.Where(x => x.RoleId == roleId).Include(rr => rr.OperationRight).ToList();
        foreach (var right in rights)
        {
            var existingRR = existingRoleRights.FirstOrDefault(x => x.OperationRight != null && x.OperationRight.OperationName == right.OperationName);
            if (existingRR == null)
            {
                context.RoleOperationRights!.Add(new RoleOperationRight { Id = Guid.NewGuid(), RoleId = roleId, OperationRightId = right.Id });
            }
            else if (existingRR.OperationRight!.IsActive != right.IsActive || existingRR.OperationRight.AccessLevel != right.AccessLevel)
            {
                existingRR.OperationRightId = right.Id;
            }
        }
    }

    public static void RemoveRoleOperationRightsNotIn(LisDbContext context, Guid roleId, IEnumerable<string> operationNames)
    {
        var keep = operationNames.ToHashSet();
        var stale = context.RoleOperationRights!.Where(x => x.RoleId == roleId).Include(rr => rr.OperationRight).AsEnumerable()
            .Where(x => x.OperationRight == null || !keep.Contains(x.OperationRight.OperationName)).ToList();
        context.RoleOperationRights!.RemoveRange(stale);
    }

    public static List<OperationRight> CreateOperationRights()
    {
        var accessLevels = new[] { AccessLevel.No, AccessLevel.Read, AccessLevel.Write };
        var rights = new List<OperationRight>();
        foreach (var access in accessLevels)
        {
            foreach (var op in ApplicationOperations.GetDeclaredOperations())
            {
                rights.Add(CreateOperationRight(op, access));
            }
        }

        return rights;
    }

    public static OperationRight CreateOperationRight(ApplicationOperations.ApplicationOperationData operation, AccessLevel accessLevel)
    {
        var caption = operation.OperationCaption + accessLevel switch
        {
            AccessLevel.Read => ": Режим перегляду",
            AccessLevel.Write => ": Повний доступ",
            _ => ": Ні"
        };

        return new OperationRight { Id = Guid.NewGuid(), OperationName = operation.OperationName, Caption = caption, AccessLevel = accessLevel, IsActive = true };
    }

    public static async Task<bool> SetLabSecurityProfileAsync(LisDbContext context, string employeeId, string? labRole, Guid? id = null)
    {
        var target = Security.ForRole(labRole);
        if (target == null || !Guid.TryParse(employeeId, out var userId))
        {
            return false;
        }

        var captions = Security.LabRoles.Select(r => r.Caption).ToList();
        var labProfiles = await context.SecurityProfiles!.AsNoTracking().Where(p => captions.Contains(p.Caption)).Select(p => new { p.Id, p.Caption }).ToListAsync();
        var targetProfileId = labProfiles.Where(p => p.Caption == target.Caption).Select(p => (Guid?)p.Id).SingleOrDefault()
            ?? throw new InvalidOperationException($"Роль {labRole}: профіль «{target.Caption}» не знайдено");
        var labProfileIds = labProfiles.Select(p => p.Id).ToList();
        var links = await context.UserProfiles!.Where(u => u.UserId == userId && labProfileIds.Contains(u.ProfileId)).ToListAsync();
        var keep = links.FirstOrDefault(l => l.ProfileId == targetProfileId) ?? links.FirstOrDefault();
        var changed = false;
        if (keep == null)
        {
            context.UserProfiles!.Add(new UserProfile { Id = id ?? Guid.NewGuid(), UserId = userId, ProfileId = targetProfileId });
            changed = true;
        }
        else if (keep.ProfileId != targetProfileId || keep.RecordState != CoreRecordState.Active)
        {
            keep.ProfileId = targetProfileId;
            keep.RecordState = CoreRecordState.Active;
            changed = true;
        }

        foreach (var extra in links.Where(l => l != keep))
        {
            context.UserProfiles!.Remove(extra);
            changed = true;
        }

        return changed;
    }
}
