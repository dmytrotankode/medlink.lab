// =============================================================================
// Сідер довідників з вбудованих ресурсів db/seed/*.json (ідемпотентний: кожна таблиця
// заповнюється лише якщо порожня). Типи аналізаторів — із ресурсу MedLink.LIS.Core (analyzer_types.json).
// =============================================================================
using System.Reflection;
using System.Text.Json;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Models;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Core.Barcodes;
using Core.Security;
using CoreRecordState = Core.Base.Data.RecordState;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Data.Seed;

public sealed class SeedService
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true, ReadCommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true };
    private readonly LisDbContext _db;
    private readonly ILogger<SeedService> _logger;

    public SeedService(LisDbContext db, ILogger<SeedService> logger) { _db = db; _logger = logger; }

    public static T ReadResource<T>(string name)
    {
        var asm = typeof(SeedService).Assembly;
        var resName = asm.GetManifestResourceNames().FirstOrDefault(n => n.EndsWith("." + name, StringComparison.OrdinalIgnoreCase))
                      ?? throw new FileNotFoundException($"Вбудований ресурс сіду {name} не знайдено");
        using var s = asm.GetManifestResourceStream(resName)!;
        return JsonSerializer.Deserialize<T>(s, Json)!;
    }

    public static JsonElement ReadCoreAnalyzerTypes()
    {
        var asm = typeof(MedLink.LIS.Core.Contracts.ConnectorConfigDto).Assembly;
        var resName = asm.GetManifestResourceNames().FirstOrDefault(n => n.EndsWith("analyzer_types.json", StringComparison.OrdinalIgnoreCase))
                      ?? throw new FileNotFoundException("Ресурс analyzer_types.json у MedLink.LIS.Core не знайдено");
        using var s = asm.GetManifestResourceStream(resName)!;
        return JsonSerializer.Deserialize<JsonElement>(s, Json);
    }

    public async Task SeedAsync()
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        await SeedTenantAsync();
        await SeedSettingsAsync();
        await SeedOrgAsync();
        await SeedSecurityAsync();
        await SeedPermissionsAsync();
        await SeedDictionariesAsync();
        await SeedSectionsAsync();
        await SeedTestsAndProfilesAsync();
        await SeedReferenceLayersAsync();
        await SeedReflexRulesAsync();
        await SeedMicrobiologyAsync();
        await SeedAnalyzersAsync();
        await SeedPerformersAsync();
        await SeedBillingAsync();
        await SeedQcMaterialsAsync();
        await SeedCountersAsync();
        _logger.LogInformation("Сід довідників завершено за {Ms} мс", sw.ElapsedMilliseconds);
    }

    private async Task SeedTenantAsync()
    {
        if (!await _db.Tenants.AnyAsync())
            _db.Tenants.Add(new TnTenant { Id = _db.CurrentTenantId, Name = "ТОВ «МедЛінк» — Клініко-діагностична лабораторія", Type = TenantTypes.Laboratory });
        if (!await _db.TenantSettings.AnyAsync())
            _db.TenantSettings.Add(new TnSettings());
        await _db.SaveChangesAsync();
    }

    private async Task SeedSettingsAsync()
    {
        if (await _db.Settings.AnyAsync()) return;
        var s = ReadResource<JsonElement>("settings.json");
        var settings = JsonSerializer.Deserialize<LabSettings>(s.GetRawText(), Json) ?? new LabSettings();
        settings.Id = DeterministicGuid.For("lab-settings-default");
        if (s.TryGetProperty("reportTemplates", out var rt)) settings.ReportTemplates = JsonSerializer.Deserialize<Dictionary<string, bool>>(rt.GetRawText(), Json) ?? new();
        _db.Settings.Add(settings);
        if (!await _db.Requisites.AnyAsync())
            _db.Requisites.Add(new TnRequisites { LegalName = settings.Name, Edrpou = settings.Edrpou, Address = settings.Address, Phone = settings.Phone, Email = settings.Email, LicenseNumber = settings.LicenseNumber, LogoUrl = settings.LogoBase64 });
        await _db.SaveChangesAsync();
    }

    /// <summary>
    /// Організаційні дані у структурі MedLink: cmn_enum_record (ті самі GUID, що в evomis DbInitializer),
    /// tn_division, cmn_person + org_employee + id_membership + lab_employee_settings, ord_patient,
    /// ehe_service_catalog_service + org_organization_service, ehe_incoming_medical_referral. Вхідний org.json — плоский і читабельний.
    /// </summary>
    private async Task SeedOrgAsync()
    {
        var org = ReadResource<JsonElement>("org.json");
        if (!await _db.EnumRecords.AnyAsync())
        {
            void E(string type, string code, string caption) => _db.EnumRecords.Add(new CmnEnumRecord { EnumType = type, Code = code, Caption = caption });
            void G(string id, string code, string caption) => _db.EnumRecords.Add(new CmnEnumRecord { Id = id, EnumType = "Gender", Code = code, Caption = caption });
            G("01f0eff5-a698-4873-a45b-ad034a386d08", "F", "Жінка");
            G("24246b86-5324-4031-801a-4a3ce452baca", "O", "Інший");
            G("da5c673d-fe44-4ea6-93d6-f9c0a5695b08", "N", "Не застосовується");
            G("e7c650cc-db1b-4c9f-8b83-06d36e1139c9", "A", "Невизначений");
            G("4a27f64a-f484-4b8d-a0bd-17c242e2440e", "U", "Невідомий");
            G("07b60329-7282-4262-9409-b24ea4440428", "M", "Чоловік");
            E("DepartmentType", "02", "Діагностичне");
            E("DepartmentType", "03", "Лікувальне");
            E("DepartmentType", "05", "Філія");
            E("DepartmentType", "06", "Підрозділ");
            E("OrgPositionType", "0001", "Інші");
            E("OrgPositionType", "0002", "Лікарі");
            E("OrgPositionType", "0003", "Лаборанти");
            E("OrgPositionType", "0005", "Середній мед.персонал");
            E("PrivacyRequestType", "Uknown", "Не опитували");
            E("MedicalDocumentType", "AmbCard", "Амбулаторна карта");
            E("MedicalDocumentType", "DiagnosticReport", "DiagnosticReport");
            E("PatientCardType", "person", "Особа");
            E("MedicalReferralStatus", "active", "Активне");
            E("MedicalReferralStatus", "completed", "Погашене");
            E("MedicalReferralStatus", "recalled", "Відкликане");
            E("MedicalReferralProcessingStatusInEhealth", "new", "Нове");
            E("MedicalReferralProcessingStatusInEhealth", "in_progress", "Взято в роботу");
            E("MedicalReferralProcessingStatusInEhealth", "completed", "Виконано");
            await _db.SaveChangesAsync();
        }
        if (!await _db.Divisions.AnyAsync())
        {
            foreach (var el in org.GetProperty("departments").EnumerateArray())
            {
                var kind = el.GetProperty("departmentType").GetString()!;
                _db.Divisions.Add(new TnDivision
                {
                    Id = el.GetProperty("id").GetString()!, Code = Str(el, "code")!, Name = Str(el, "name")!, Address = Str(el, "address"),
                    Type = kind, Phone = Str(el, "phone"), DepartmentTypeId = await _db.EnumRecordIdAsync("DepartmentType", OrgDictionaryService.DepartmentTypeCodeFor(kind))
                });
            }
            await _db.SaveChangesAsync();
        }
        if (!await _db.Employees.AnyAsync())
            foreach (var el in org.GetProperty("employees").EnumerateArray())
            {
                var id = el.GetProperty("id").GetString()!;
                if (await _db.Employees.AnyAsync(x => x.Id == id)) continue;
                var personId = DeterministicGuid.For("person:employee:" + id);
                var person = await _db.Persons.FirstOrDefaultAsync(p => p.Id == personId);
                if (person == null)
                {
                    var parts = Str(el, "fullName")!.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    person = new CmnPerson
                    {
                        Id = personId, LastName = parts.ElementAtOrDefault(0), Name = parts.ElementAtOrDefault(1), MiddleName = parts.ElementAtOrDefault(2),
                        Phone = Str(el, "phone"), Email = Str(el, "email"), NoIpn = true
                    };
                    person.Caption = CmnPerson.BuildCaption(person.LastName, person.Name, person.MiddleName);
                }
                var role = el.GetProperty("labRole").GetString()!;
                var departmentCode = Str(el, "departmentCode") ?? throw new InvalidOperationException($"Співробітник {id}: departmentCode не задано");
                var departmentId = await _db.Divisions.Where(d => d.Code == departmentCode).Select(d => d.Id).SingleOrDefaultAsync()
                    ?? throw new InvalidOperationException($"Співробітник {id}: підрозділ з кодом {departmentCode} не знайдено");
                var roleId = await SeedEmployeeSecurityAsync(id, role);
                var e = new OrgEmployee
                {
                    Id = id, Person = person, PersonId = person.Id, Caption = person.Caption, TenantId = _db.CurrentTenantId,
                    Membership = new IdMembership { Id = id, TenantId = _db.CurrentTenantId, UserId = person.Id, RoleId = roleId },
                    DepartmentId = departmentId, PositionTypeId = await _db.EnumRecordIdAsync("OrgPositionType", OrgDictionaryService.PositionTypeCodeFor(role)), WorkingStartDate = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                };
                e.LabSettings = new LabEmployeeSettings { EmployeeId = id, LabRole = role, PositionName = Str(el, "positionName"), DigitalSignatureCertId = Str(el, "digitalSignatureCertId") };
                _db.Employees.Add(e);
            }
        if (!await _db.Patients.AnyAsync())
            foreach (var el in org.GetProperty("patients").EnumerateArray())
            {
                var req = JsonSerializer.Deserialize<NewPatientRequest>(el.GetRawText(), Json)!;
                if (req.BirthDate.HasValue) req.BirthDate = DateTime.SpecifyKind(req.BirthDate.Value, DateTimeKind.Utc);
                var card = MedLinkPeople.NewPatient(req, _db.CurrentTenantId);
                card.Id = el.GetProperty("id").GetString()!;
                _db.Patients.Add(card);
            }
        
        if (!await _db.ReferralCategories.AnyAsync(c => c.Code == MedLinkDefaults.ReferralCategoryLaboratoryCode))
        {
            _db.ReferralCategories.Add(new EheMedicalReferralCategory { Code = MedLinkDefaults.ReferralCategoryLaboratoryCode, Name = MedLinkDefaults.ReferralCategoryLaboratoryCode, EhealthCode = MedLinkDefaults.ReferralCategoryLaboratoryCode, IsUsedInEhealth = true });
            await _db.SaveChangesAsync();
        }
        var laboratoryCategoryId = await _db.ReferralCategoryIdAsync(MedLinkDefaults.ReferralCategoryLaboratoryCode);
        if (!await _db.ServiceCatalog.AnyAsync())
            foreach (var el in org.GetProperty("services").EnumerateArray())
            {
                var code = Str(el, "code")!;
                _db.ServiceCatalog.Add(new EheServiceCatalogService
                {
                    Id = DeterministicGuid.For("ehealth-service:" + code), Code = code, Name = Str(el, "name"), Caption = Str(el, "name"),
                    MedicalReferralCategoryId = laboratoryCategoryId
                });
                _db.OrganizationServices.Add(new OrgOrganizationService
                {
                    Id = el.GetProperty("id").GetString()!, Caption = Str(el, "name"), Price = el.GetProperty("price").GetDecimal(), TenantId = _db.CurrentTenantId, Duration = 15
                });
            }
        if (!await _db.ServiceCatalog.AnyAsync(s => s.Code == MedLinkDefaults.GenericLabServiceCode))
            _db.ServiceCatalog.Add(new EheServiceCatalogService
            {
                Code = MedLinkDefaults.GenericLabServiceCode, Name = "Лабораторне дослідження (загальна послуга)", Caption = "Лабораторне дослідження (загальна послуга)",
                MedicalReferralCategoryId = laboratoryCategoryId
            });
        await _db.SaveChangesAsync();
        if (!await _db.Referrals.AnyAsync())
        {
            var catalog = await _db.ServiceCatalog.AsNoTracking().Where(s => s.Code != null).ToDictionaryAsync(s => s.Code!, s => s.Id);
            var statusActiveId = await _db.EnumRecordIdAsync("MedicalReferralStatus", "active");
            var processingNewId = await _db.EnumRecordIdAsync("MedicalReferralProcessingStatusInEhealth", "new");
            foreach (var el in org.GetProperty("referrals").EnumerateArray())
            {
                var patientId = Str(el, "patientId");
                var patient = await _db.Patients.AsNoTracking().FirstOrDefaultAsync(p => p.Id == patientId);
                _db.Referrals.Add(new EheIncomingMedicalReferral
                {
                    Id = el.GetProperty("id").GetString()!, RegNumber = Str(el, "referralCode"), Caption = Str(el, "serviceName"), TenantId = _db.CurrentTenantId,
                    PatientCardId = patientId, PatientShortName = patient?.Caption, ServiceCatalogServiceId = catalog[Str(el, "serviceCode")!],
                    MedicalReferralCategoryId = laboratoryCategoryId, StatusId = statusActiveId, PriorityId = MedLinkEnums.EmptyGuid,
                    ProcessingStatusInEhealthId = processingNewId,
                    ExpirationDate = DateTime.UtcNow.Date.AddDays(30)
                });
            }
            await _db.SaveChangesAsync();
        }
    }

    /// <summary>Лабораторії-виконавці: власна, зовнішня партнерська (Сінево, обмін файлом) і TerraLab (довідково — обмін веде MedLink).</summary>
    private async Task SeedPerformersAsync()
    {
        if (await _db.Performers.AnyAsync()) return;
        var tests = await _db.Tests.AsNoTracking().ToDictionaryAsync(t => t.Code, t => t.Id);
        foreach (var el in ReadResource<List<JsonElement>>("performers.json"))
        {
            var p = JsonSerializer.Deserialize<LabPerformer>(el.GetRawText(), Json)!;
            p.Tests = new();
            foreach (var t in el.GetProperty("tests").EnumerateArray())
            {
                var code = t.GetProperty("testCode").GetString()!;
                if (!tests.TryGetValue(code, out var testId)) continue;
                var pt = JsonSerializer.Deserialize<LabPerformerTest>(t.GetRawText(), Json)!;
                pt.PerformerId = p.Id; pt.TestId = testId;
                p.Tests.Add(pt);
            }
            _db.Performers.Add(p);
        }
        await _db.SaveChangesAsync();
    }

    /// <summary>Прайс-листи, пакети, платники (каса, страхові програми, НСЗУ, клініка, внутрішнє), поліси демо-пацієнтів.</summary>
    private async Task SeedBillingAsync()
    {
        if (await _db.Payers.AnyAsync()) return;
        var b = ReadResource<JsonElement>("billing.json");
        var profiles = await _db.Profiles.AsNoTracking().ToDictionaryAsync(p => p.Code, p => p.Id);
        var tests = await _db.Tests.AsNoTracking().ToDictionaryAsync(t => t.Code, t => t.Id);
        (string? P, string? T) Ref(string code) => profiles.TryGetValue(code, out var p) ? (p, null) : tests.TryGetValue(code, out var t) ? (null, t) : throw new InvalidOperationException($"billing.json: невідомий код {code}");
        DateTime? D(JsonElement el, string n) => el.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? DateTime.SpecifyKind(DateTime.Parse(v.GetString()!), DateTimeKind.Utc) : null;
        var lists = new Dictionary<string, string>();
        foreach (var el in b.GetProperty("priceLists").EnumerateArray())
        {
            var code = el.GetProperty("code").GetString()!;
            var l = new LabPriceList { Id = DeterministicGuid.For("pricelist:" + code), Code = code, Name = el.GetProperty("name").GetString()!, ValidFrom = D(el, "validFrom"), ValidTo = D(el, "validTo"),
                IsDefault = el.TryGetProperty("isDefault", out var d) && d.GetBoolean() };
            foreach (var it in el.GetProperty("items").EnumerateObject()) { var (pid, tid) = Ref(it.Name); l.Items.Add(new LabPriceListItem { PriceListId = l.Id, ProfileId = pid, TestId = tid, Price = it.Value.GetDecimal() }); }
            if (el.TryGetProperty("packages", out var pk))
                foreach (var pe in pk.EnumerateArray())
                    l.Packages.Add(new LabPricePackage { PriceListId = l.Id, Code = pe.GetProperty("code").GetString()!, Name = pe.GetProperty("name").GetString()!, Price = pe.GetProperty("price").GetDecimal(),
                        MemberIds = pe.GetProperty("members").EnumerateArray().Select(m => { var (pid, tid) = Ref(m.GetString()!); return pid ?? tid!; }).ToList() });
            _db.PriceLists.Add(l);
            lists[code] = l.Id;
        }
        var payers = new Dictionary<string, string>();
        foreach (var el in b.GetProperty("payers").EnumerateArray())
        {
            var p = JsonSerializer.Deserialize<LabPayer>(el.GetRawText(), Json)!;
            p.Id = DeterministicGuid.For("payer:" + p.Code);
            p.ContractValidTo = D(el, "contractValidTo");
            if (el.TryGetProperty("priceListCode", out var pl)) p.PriceListId = lists[pl.GetString()!];
            _db.Payers.Add(p);
            payers[p.Code] = p.Id;
        }
        foreach (var el in b.GetProperty("policies").EnumerateArray())
            _db.PatientInsurances.Add(new OrdPatientInsurance
            {
                PatientCardId = el.GetProperty("patientId").GetString()!, PayerId = payers[el.GetProperty("payerCode").GetString()!],
                PolicyNumber = el.GetProperty("policyNumber").GetString()!, ValidFrom = D(el, "validFrom"), ValidTo = D(el, "validTo")
            });
        // Е-направлення №1 — за програмою медичних гарантій (платник НСЗУ підставляється автоматично)
        var program = b.GetProperty("nszuProgramId").GetString();
        var regNumber = Str(ReadResource<JsonElement>("org.json").GetProperty("referrals")[0], "referralCode") ?? throw new InvalidOperationException("org.json: у першого направлення немає referralCode");
        var r1 = await _db.Referrals.FirstOrDefaultAsync(r => r.RegNumber == regNumber) ?? throw new InvalidOperationException($"Е-направлення {regNumber} не знайдено");
        r1.MedicalServiceProgramId = program;
        await _db.SaveChangesAsync();
    }

    private async Task SeedPermissionsAsync()
    {
        var existing = await _db.Permissions.AsNoTracking().Select(p => p.Code).ToListAsync();
        foreach (var p in Helpers.PermissionCatalog.Permissions().Where(p => !existing.Contains(p.Code)))
            _db.Permissions.Add(new IdPermission { Code = p.Code, Caption = p.Caption });
        await _db.SaveChangesAsync();
    }

    private async Task SeedSecurityAsync()
    {
        var sec = RightsSeedHelper.Security;
        var existingOperationRights = await _db.OperationRights!.AsNoTracking().ToListAsync();
        foreach (var right in RightsSeedHelper.CreateOperationRights())
        {
            if (!existingOperationRights.Any(x => x.OperationName == right.OperationName && x.AccessLevel == right.AccessLevel))
                _db.OperationRights!.Add(right);
        }
        await _db.SaveChangesAsync();

        var operationRights = await _db.OperationRights!.AsNoTracking().ToListAsync();
        foreach (var labRole in sec.LabRoles)
        {
            var profile = RightsSeedHelper.CreateProfileIfAbsent(_db, labRole.Caption);
            var role = RightsSeedHelper.CreateRoleIfAbsent(_db, labRole.Caption);
            RightsSeedHelper.CreateProfileRoleIfAbsent(_db, profile, role);
            var roleRights = sec.OperationsOf(labRole.Code)
                .Select(op => operationRights.First(x => x.OperationName == op && x.AccessLevel == AccessLevel.Write)).ToList();
            RightsSeedHelper.RemoveRoleOperationRightsNotIn(_db, role.Id, sec.OperationsOf(labRole.Code));
            RightsSeedHelper.CreateUpdateRoleOperationRightsIfDiffer(_db, role.Id, roleRights);
        }
        await _db.SaveChangesAsync();

        foreach (var userProfile in sec.UserProfiles)
        {
            var employee = await _db.Employees.Include(e => e.LabSettings).FirstOrDefaultAsync(e => e.Id == userProfile.EmployeeId);
            if (employee?.LabSettings == null) continue;
            await RightsSeedHelper.SetLabSecurityProfileAsync(_db, employee.Id, employee.LabSettings.LabRole);
        }
        foreach (var identityUser in sec.IdentityUsers)
        {
            var employee = await _db.Employees.FirstOrDefaultAsync(e => e.Id == identityUser.EmployeeId);
            var person = employee == null ? null : await _db.Persons.FirstOrDefaultAsync(p => p.Id == employee.PersonId);
            if (person != null && string.IsNullOrEmpty(person.UserId)) person.UserId = identityUser.UserId;
        }
        await _db.SaveChangesAsync();
    }

    private static string? Str(JsonElement el, string name) => el.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private async Task<string> SeedEmployeeSecurityAsync(string employeeId, string labRole)
    {
        var sec = RightsSeedHelper.Security;
        var labRoleSeed = sec.ForRole(labRole);
        if (labRoleSeed != null)
        {
            var profile = RightsSeedHelper.CreateProfileIfAbsent(_db, labRoleSeed.Caption);
            var role = RightsSeedHelper.CreateRoleIfAbsent(_db, labRoleSeed.Caption);
            RightsSeedHelper.CreateProfileRoleIfAbsent(_db, profile, role);
            await _db.SaveChangesAsync();
            await RightsSeedHelper.SetLabSecurityProfileAsync(_db, employeeId, labRole);
            await _db.SaveChangesAsync();
        }
        var userId = Guid.Parse(employeeId);
        var roleIds = await _db.UserProfiles!.AsNoTracking().Where(u => u.UserId == userId && u.RecordState == CoreRecordState.Active)
            .Join(_db.ProfileRoles!.AsNoTracking().Where(pr => pr.RecordState == CoreRecordState.Active), u => u.ProfileId, pr => pr.ProfileId, (u, pr) => pr.RoleId).Distinct().ToListAsync();
        return roleIds.Count == 1 ? roleIds[0].ToString()
            : throw new InvalidOperationException($"Співробітник {employeeId}: sys_user_profile → sys_profile_role дає {roleIds.Count} ролей, очікувалась одна");
    }

    private async Task SeedDictionariesAsync()
    {
        if (!await _db.BiomaterialTypes.AnyAsync())
            _db.BiomaterialTypes.AddRange(ReadResource<List<LabBiomaterialType>>("biomaterials.json"));
        if (!await _db.TubeTypes.AnyAsync())
            _db.TubeTypes.AddRange(ReadResource<List<LabTubeType>>("tube_types.json"));
        if (!await _db.MethodTypes.AnyAsync())
            _db.MethodTypes.AddRange(ReadResource<List<LabMethodType>>("method_types.json"));
        if (!await _db.AnalyzerTypes.AnyAsync())
        {
            foreach (var el in ReadCoreAnalyzerTypes().EnumerateArray())
            {
                var t = JsonSerializer.Deserialize<LabAnalyzerType>(el.GetRawText(), Json)!;
                t.Manufacturer ??= GuessManufacturer(t.Name);
                _db.AnalyzerTypes.Add(t);
            }
        }
        await _db.SaveChangesAsync();
    }

    private static string? GuessManufacturer(string name)
    {
        var n = name.ToLowerInvariant();
        if (n.Contains("sysmex")) return "Sysmex";
        if (n.Contains("cobas") || n.Contains("сobas") || n.Contains("integra") || n.Contains("urisys") || n.Contains("reflotron")) return "Roche";
        if (n.Contains("mindray")) return "Mindray";
        if (n.Contains("vitros")) return "Ortho Clinical Diagnostics";
        if (n.Contains("radiometer") || n.Contains("abl") || n.Contains("aqt")) return "Radiometer";
        if (n.Contains("huma")) return "Human";
        if (n.Contains("beckman") || n.Contains("access")) return "Beckman Coulter";
        if (n.Contains("siemens") || n.Contains("rapid")) return "Siemens";
        if (n.Contains("maglumi")) return "Snibe";
        if (n.Contains("stago")) return "Stago";
        if (n.Contains("biosystem") || n.Contains("ba200")) return "BioSystems";
        if (n.Contains("pentra")) return "Horiba";
        if (n.Contains("nihon") || n.Contains("mek")) return "Nihon Kohden";
        if (n.Contains("iris")) return "Beckman Coulter";
        if (n.Contains("fuji")) return "Fujifilm";
        if (n.Contains("phadia")) return "Thermo Fisher";
        if (n.Contains("ichroma")) return "Boditech";
        if (n.Contains("erba")) return "Erba Mannheim";
        return null;
    }

    private async Task SeedSectionsAsync()
    {
        var doc = ReadResource<JsonElement>("sections.json");
        if (!await _db.WorkflowTemplates.AnyAsync())
        {
            foreach (var el in doc.GetProperty("workflowTemplates").EnumerateArray())
            {
                var stages = JsonSerializer.Deserialize<List<WorkflowStage>>(el.GetProperty("stages").GetRawText(), Json)!;
                _db.WorkflowTemplates.Add(new LabWorkflowTemplate { Code = el.GetProperty("code").GetString()!, Name = el.GetProperty("name").GetString()!, Stages = stages });
            }
        }
        if (!await _db.Sections.AnyAsync())
            _db.Sections.AddRange(JsonSerializer.Deserialize<List<LabSection>>(doc.GetProperty("sections").GetRawText(), Json)!);
        await _db.SaveChangesAsync();
    }

    private async Task SeedTestsAndProfilesAsync()
    {
        if (await _db.Tests.AnyAsync()) return;
        var bm = await _db.BiomaterialTypes.ToDictionaryAsync(b => b.Code, b => b.Id);
        var tubes = await _db.TubeTypes.ToDictionaryAsync(t => t.Code, t => t.Id);
        var sections = await _db.Sections.ToDictionaryAsync(s => s.Code, s => s.Id);
        var tests = new Dictionary<string, LabTestDefinition>();
        foreach (var el in ReadResource<List<JsonElement>>("tests.json"))
        {
            var t = JsonSerializer.Deserialize<LabTestDefinition>(el.GetRawText(), Json)!;
            t.Id = DeterministicGuid.For("test:" + t.Code);
            t.BiomaterialTypeId = bm[el.GetProperty("biomaterialCode").GetString()!];
            t.TubeTypeId = tubes[el.GetProperty("tubeCode").GetString()!];
            if (el.TryGetProperty("labSectionCode", out var sc) && sc.ValueKind == JsonValueKind.String && sections.TryGetValue(sc.GetString()!, out var sid)) t.LabSectionId = sid;
            if (el.TryGetProperty("dropdownOptions", out var opts) && opts.ValueKind == JsonValueKind.Array) t.DropdownOptions = opts.EnumerateArray().Select(o => o.GetString() ?? "").ToList();
            tests[t.Code] = t;
            _db.Tests.Add(t);
        }
        var org = ReadResource<JsonElement>("org.json");
        var services = org.GetProperty("services").EnumerateArray().ToList();
        var catalog = await _db.ServiceCatalog.AsNoTracking().Where(s => s.Code != null).ToDictionaryAsync(s => s.Code!, s => s.Id);
        foreach (var el in ReadResource<List<JsonElement>>("profiles.json"))
        {
            var p = JsonSerializer.Deserialize<LabTestProfile>(el.GetRawText(), Json)!;
            p.Id = DeterministicGuid.For("profile:" + p.Code);
            p.Items = new();
            p.DefaultBiomaterialTypeId = bm[el.GetProperty("biomaterialCode").GetString()!];
            p.DefaultTubeTypeId = tubes[el.GetProperty("tubeCode").GetString()!];
            foreach (var it in el.GetProperty("items").EnumerateArray())
            {
                var code = it.GetProperty("testCode").GetString()!;
                p.Items.Add(new LabTestProfileItem { ProfileId = p.Id, TestId = tests[code].Id, DisplayOrder = it.GetProperty("displayOrder").GetInt32(), IsRequired = it.GetProperty("isRequired").GetBoolean() });
            }
            // Послуга прайсу MedLink (org_organization_service) і послуга каталогу eHealth ↔ лабораторний профіль (рішення Q-01)
            var svc = services.FirstOrDefault(s => s.GetProperty("labProfileCode").GetString() == p.Code);
            if (svc.ValueKind == JsonValueKind.Object)
            {
                p.OrganizationServiceId = svc.GetProperty("id").GetString()!;
                p.EhealthServiceCatalogServiceId = catalog[svc.GetProperty("code").GetString()!];
                p.Price = svc.GetProperty("price").GetDecimal();
            }
            _db.Profiles.Add(p);
        }
        await _db.SaveChangesAsync();
    }

    private async Task SeedReferenceLayersAsync()
    {
        if (await _db.ReferenceLayers.AnyAsync()) return;
        var tests = await _db.Tests.ToDictionaryAsync(t => t.Code, t => t.Id);
        foreach (var l in ReadResource<List<LabReferenceLayer>>("reference_layers.json"))
        {
            l.TestId = tests.TryGetValue(l.TestCode, out var id) ? id : null;
            if (!Guid.TryParse(l.Id, out _)) l.Id = DeterministicGuid.For("layer:" + l.Id);
            _db.ReferenceLayers.Add(l);
        }
        await _db.SaveChangesAsync();
    }

    private async Task SeedReflexRulesAsync()
    {
        if (await _db.ReflexRules.AnyAsync()) return;
        _db.ReflexRules.AddRange(ReadResource<List<LabReflexRule>>("reflex_rules.json"));
        await _db.SaveChangesAsync();
    }

    private async Task SeedMicrobiologyAsync()
    {
        var m = ReadResource<JsonElement>("microbiology.json");
        if (!await _db.Organisms.AnyAsync()) _db.Organisms.AddRange(JsonSerializer.Deserialize<List<LabMicroOrganism>>(m.GetProperty("organisms").GetRawText(), Json)!);
        if (!await _db.Antibiotics.AnyAsync()) _db.Antibiotics.AddRange(JsonSerializer.Deserialize<List<LabAntibiotic>>(m.GetProperty("antibiotics").GetRawText(), Json)!);
        await _db.SaveChangesAsync();
        if (!await _db.EucastBreakpoints.AnyAsync())
        {
            var orgs = await _db.Organisms.ToDictionaryAsync(o => o.Code, o => o.Id);
            var abs = await _db.Antibiotics.ToDictionaryAsync(a => a.Code, a => a.Id);
            foreach (var el in m.GetProperty("breakpoints").EnumerateArray())
            {
                var bp = JsonSerializer.Deserialize<LabEucastBreakpoint>(el.GetRawText(), Json)!;
                bp.OrganismId = orgs[el.GetProperty("organismCode").GetString()!];
                bp.AntibioticId = abs[el.GetProperty("antibioticCode").GetString()!];
                bp.Id = DeterministicGuid.For($"bp:{bp.OrganismId}:{bp.AntibioticId}:{bp.EucastVersion}");
                _db.EucastBreakpoints.Add(bp);
            }
            await _db.SaveChangesAsync();
        }
    }

    private async Task SeedAnalyzersAsync()
    {
        var a = ReadResource<JsonElement>("analyzers.json");
        if (!await _db.Connectors.AnyAsync())
        {
            foreach (var el in a.GetProperty("connectors").EnumerateArray())
                _db.Connectors.Add(new LabConnectorInstallation { Id = el.GetProperty("id").GetString()!, Name = el.GetProperty("name").GetString()!, InstallKey = el.GetProperty("installKey").GetString()!, Status = el.GetProperty("status").GetString()! });
            await _db.SaveChangesAsync();
        }
        if (!await _db.Analyzers.AnyAsync())
        {
            var types = await _db.AnalyzerTypes.ToDictionaryAsync(t => t.Code, t => t.Id);
            foreach (var el in a.GetProperty("analyzers").EnumerateArray())
            {
                var an = JsonSerializer.Deserialize<LabAnalyzer>(el.GetRawText(), Json)!;
                an.AnalyzerTypeId = types[el.GetProperty("analyzerTypeCode").GetString()!];
                var installKey = Str(el, "connectorInstallKey");
                an.ConnectorId = installKey == null ? null : (await _db.Connectors.Where(c => c.InstallKey == installKey).Select(c => c.Id).SingleOrDefaultAsync()
                    ?? throw new InvalidOperationException($"Аналізатор {an.Code}: коннектор з ключем {installKey} не знайдено"));
                var departmentCode = Str(el, "departmentCode");
                an.DepartmentId = departmentCode == null ? null : (await _db.Divisions.Where(d => d.Code == departmentCode).Select(d => d.Id).SingleOrDefaultAsync()
                    ?? throw new InvalidOperationException($"Аналізатор {an.Code}: підрозділ з кодом {departmentCode} не знайдено"));
                an.ParameterMap = el.GetProperty("parameterMap").EnumerateArray().Select(m => new LabAnalyzerParameterMap
                {
                    AnalyzerId = an.Id, AnalyzerCode = m.GetProperty("analyzerCode").GetString()!, TestCode = m.GetProperty("testCode").GetString()!,
                    Factor = m.TryGetProperty("factor", out var f) ? f.GetDouble() : 1.0, Offset = m.TryGetProperty("offset", out var o) ? o.GetDouble() : 0.0,
                    UnitOverride = m.TryGetProperty("unitOverride", out var u) ? u.GetString() : null
                }).ToList();
                _db.Analyzers.Add(an);
            }
            await _db.SaveChangesAsync();
        }
    }

    private async Task SeedQcMaterialsAsync()
    {
        if (await _db.QcMaterials.AnyAsync()) return;
        foreach (var el in ReadResource<List<JsonElement>>("qc_materials.json"))
        {
            var m = JsonSerializer.Deserialize<LabQcMaterial>(el.GetRawText(), Json)!;
            var analyzerCode = Str(el, "analyzerCode") ?? throw new InvalidOperationException($"Контрольний матеріал {m.LotNumber}: analyzerCode не задано");
            m.AnalyzerId = await _db.Analyzers.Where(a => a.Code == analyzerCode).Select(a => a.Id).SingleOrDefaultAsync()
                ?? throw new InvalidOperationException($"Контрольний матеріал {m.LotNumber}: аналізатор з кодом {analyzerCode} не знайдено");
            m.ExpiryDate = DateTime.SpecifyKind(m.ExpiryDate, DateTimeKind.Utc);
            m.Targets = el.GetProperty("targets").EnumerateArray().Select(t => JsonSerializer.Deserialize<LabQcTarget>(t.GetRawText(), Json)!).ToList();
            foreach (var t in m.Targets) t.QcMaterialId = m.Id;
            _db.QcMaterials.Add(m);
        }
        await _db.SaveChangesAsync();
    }

    private async Task SeedCountersAsync()
    {
        if (!await _db.Sequences.AnyAsync(s => s.Key == TubeBarcodeGenerator.CounterCode))
            _db.Sequences.Add(new TnSequence { Key = TubeBarcodeGenerator.CounterCode, ScopeKey = NumeratorService.AllScope, Value = 4800 }); // продовження нумерації Simplex
        if (!await _db.Numerators.AnyAsync(n => n.Code == NumeratorService.OrderNumerator))
        {
            var mask = (await _db.Settings.AsNoTracking().FirstOrDefaultAsync())?.OrderNumberMask ?? "{yyMM}-{000000}";
            _db.Numerators.Add(new LabNumerator { Code = NumeratorService.OrderNumerator, Name = "Номер замовлення", Mask = mask, CurrentValue = 0, ResetByPeriod = true });
        }
        if (!await _db.Numerators.AnyAsync(n => n.Code == NumeratorService.ManifestNumerator))
            _db.Numerators.Add(new LabNumerator { Code = NumeratorService.ManifestNumerator, Name = "Номер маніфесту логістики", Mask = "MAN-{yyMMdd}-{0000}", ResetByPeriod = true });
        if (!await _db.Numerators.AnyAsync(n => n.Code == NumeratorService.BatchNumerator))
            _db.Numerators.Add(new LabNumerator { Code = NumeratorService.BatchNumerator, Name = "Код робочого листа", Mask = "WL-{yyMMdd}-{000}", ResetByPeriod = true });
        await _db.SaveChangesAsync();
    }
}
