using System.Data.Common;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace MedLink.LIS.Api.Data;

public static class TenantSession
{
    public const string TenantSetting = "app.tenant_id";

    internal static DbCommand SetLocalCommand(DbConnection connection, DbTransaction transaction, string tenantId)
    {
        var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = $"SELECT set_config('{TenantSetting}', @tenant_id, true)";
        var parameter = command.CreateParameter();
        parameter.ParameterName = "tenant_id";
        parameter.Value = tenantId;
        command.Parameters.Add(parameter);
        return command;
    }
}

public sealed class TenantTransactionInterceptor : DbTransactionInterceptor
{
    public static readonly TenantTransactionInterceptor Instance = new();

    public override DbTransaction TransactionStarted(DbConnection connection, TransactionEndEventData eventData, DbTransaction result)
    {
        if (eventData.Context is LisDbContext db && db.Tenant.TenantId is { } tenantId)
        {
            using var command = TenantSession.SetLocalCommand(connection, result, tenantId);
            command.ExecuteNonQuery();
        }
        return result;
    }

    public override async ValueTask<DbTransaction> TransactionStartedAsync(DbConnection connection, TransactionEndEventData eventData, DbTransaction result, CancellationToken cancellationToken = default)
    {
        if (eventData.Context is LisDbContext db && db.Tenant.TenantId is { } tenantId)
        {
            await using var command = TenantSession.SetLocalCommand(connection, result, tenantId);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        return result;
    }
}
