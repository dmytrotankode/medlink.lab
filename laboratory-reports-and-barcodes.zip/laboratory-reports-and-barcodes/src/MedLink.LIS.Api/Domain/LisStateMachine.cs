// =============================================================================
// MedLink LIS 4.0 — ЄДИНЕ МІСЦЕ ВИЗНАЧЕННЯ МАШИНИ СТАНІВ ТА ПРАВИЛ ДОСТУПУ ДО ДІЙ.
// Сутності: Order, Sample, OrderTest, Manifest (логістика), Culture (посів), Connector.
// Кожна дія (ActionRule) описує: з яких статусів дозволена, у який статус переводить,
// яке право на операцію (ApplicationOperations) потрібне в профілі безпеки поточного користувача.
// Невалідний перехід → 409 (ConflictException), немає права → 403 (OperationDeniedException).
// =============================================================================
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Helpers;
using MedLink.LIS.Api.Infrastructure;

namespace MedLink.LIS.Api.Domain;

public static class LabRoles
{
    public const string Admin = "LAB_ADMIN";
    public const string Doctor = "LAB_DOCTOR";
    public const string Technician = "LAB_TECHNICIAN";
    public const string Phlebotomist = "PHLEBOTOMIST";
    public const string Courier = "LOGISTICS_COURIER";
    public const string Registrar = "REGISTRAR";
    public static readonly string[] All = { Admin, Doctor, Technician, Phlebotomist, Courier, Registrar };
    private static readonly Dictionary<string, int> Ranks = new() { [Admin] = 3, [Doctor] = 2, [Technician] = 1, [Phlebotomist] = 1, [Courier] = 1, [Registrar] = 1 };
    public static int Rank(string? role) => role != null && Ranks.TryGetValue(role, out var rank) ? rank : 0;
    public static bool CanManage(string? ownRole, string? targetRole) => ownRole == Admin || Rank(targetRole) < Rank(ownRole);
    public static string[] AssignableBy(string? ownRole) => All.Where(r => CanManage(ownRole, r)).ToArray();
    /// <summary>Технічний актор (коннектор/система) — не підлягає рольовим обмеженням.</summary>
    public const string System = "SYSTEM";
}

public sealed record ActionRule(
    string Action,
    string[] FromStatuses,
    string? ToStatus,
    string Operation,
    string Label,
    /// <summary>Дія не змінює статус (редагування, друк).</summary>
    bool IsNonTransition = false);

public static class LisEntities
{
    public const string Order = "Order", Sample = "Sample", OrderTest = "OrderTest", Manifest = "Manifest",
        Culture = "Culture", Connector = "Connector";
}

public static class OrderActions
{
    public const string Edit = "EDIT", AddTest = "ADD_TEST", RemoveTest = "REMOVE_TEST", AddSample = "ADD_SAMPLE",
        Collect = "COLLECT", Dispatch = "DISPATCH", Receive = "RECEIVE", EnterResult = "ENTER_RESULT", Verify = "VERIFY",
        Complete = "COMPLETE", Release = "RELEASE", Reopen = "REOPEN", Cancel = "CANCEL", Reject = "REJECT", Delete = "DELETE",
        PrintLabels = "PRINT_LABELS", PrintReport = "PRINT_REPORT";
}

public static class SampleActions
{
    public const string Collect = "COLLECT", Dispatch = "DISPATCH", Receive = "RECEIVE", Process = "PROCESS", Store = "STORE",
        Dispose = "DISPOSE", Reject = "REJECT", EditFlags = "EDIT_FLAGS", Replace = "REPLACE", Delete = "DELETE", Uncollect = "UNCOLLECT";
}

public static class TestActions
{
    public const string EnterResult = "ENTER_RESULT", EditResult = "EDIT_RESULT", DeleteResult = "DELETE_RESULT", Verify = "VERIFY",
        Reject = "REJECT", Rerun = "RERUN", Reopen = "REOPEN", AssignAnalyzer = "ASSIGN_ANALYZER", Remove = "REMOVE", StartAnalysis = "START_ANALYSIS",
        SendOut = "SEND_OUT", RecallSendOut = "RECALL_SEND_OUT";
}

public static class ManifestActions
{
    public const string Edit = "EDIT", Dispatch = "DISPATCH", Receive = "RECEIVE", Reject = "REJECT", Delete = "DELETE";
}

public static class CultureActions
{
    public const string Edit = "EDIT", Preliminary = "PRELIMINARY", Isolate = "ISOLATE", Complete = "COMPLETE", Delete = "DELETE",
        AddIsolate = "ADD_ISOLATE", AddSusceptibility = "ADD_SUSCEPTIBILITY";
}

public static class ConnectorActions
{
    public const string Register = "REGISTER", Heartbeat = "HEARTBEAT", MarkOffline = "MARK_OFFLINE", Disable = "DISABLE",
        Enable = "ENABLE", RotateKey = "ROTATE_KEY", Edit = "EDIT", Delete = "DELETE";
}

public static class LisStateMachine
{
    // ------------------------------------------------------------------ ORDER
    public static readonly ActionRule[] OrderRules =
    {
        new(OrderActions.Edit, new[]{ OrderStatuses.New }, null, nameof(ApplicationOperations.OrderEdit), "Редагувати замовлення", true),
        new(OrderActions.AddTest, new[]{ OrderStatuses.New, OrderStatuses.Collected, OrderStatuses.Received, OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted }, null, nameof(ApplicationOperations.OrderAddTest), "Додати тест", true),
        new(OrderActions.RemoveTest, new[]{ OrderStatuses.New }, null, nameof(ApplicationOperations.OrderRemoveTest), "Прибрати тест", true),
        new(OrderActions.AddSample, new[]{ OrderStatuses.New, OrderStatuses.Collected }, null, nameof(ApplicationOperations.OrderAddSample), "Додати пробірку", true),
        new(OrderActions.Collect, new[]{ OrderStatuses.New }, OrderStatuses.Collected, nameof(ApplicationOperations.OrderCollect), "Забір біоматеріалу"),
        new(OrderActions.Dispatch, new[]{ OrderStatuses.Collected }, OrderStatuses.InTransit, nameof(ApplicationOperations.OrderDispatch), "Відправити в лабораторію"),
        new(OrderActions.Receive, new[]{ OrderStatuses.Collected, OrderStatuses.InTransit }, OrderStatuses.Received, nameof(ApplicationOperations.OrderReceive), "Прийняти в лабораторії"),
        new(OrderActions.EnterResult, new[]{ OrderStatuses.Received, OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted }, OrderStatuses.InProgress, nameof(ApplicationOperations.OrderEnterResult), "Ввести результат"),
        new(OrderActions.Verify, new[]{ OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted, OrderStatuses.Completed }, null, nameof(ApplicationOperations.OrderVerify), "Верифікувати результати", true),
        new(OrderActions.Complete, new[]{ OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted }, OrderStatuses.Completed, nameof(ApplicationOperations.OrderComplete), "Завершити (усі тести верифіковано)"),
        new(OrderActions.Release, new[]{ OrderStatuses.Completed }, OrderStatuses.Released, nameof(ApplicationOperations.OrderRelease), "Видати результати пацієнту"),
        new(OrderActions.Reopen, new[]{ OrderStatuses.Completed, OrderStatuses.Released }, OrderStatuses.InProgress, nameof(ApplicationOperations.OrderReopen), "Повернути в роботу"),
        new(OrderActions.Cancel, new[]{ OrderStatuses.New, OrderStatuses.Collected, OrderStatuses.InTransit, OrderStatuses.Received }, OrderStatuses.Cancelled, nameof(ApplicationOperations.OrderCancel), "Скасувати замовлення"),
        new(OrderActions.Reject, new[]{ OrderStatuses.Collected, OrderStatuses.InTransit, OrderStatuses.Received, OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted }, OrderStatuses.Rejected, nameof(ApplicationOperations.OrderReject), "Відхилити (брак біоматеріалу)"),
        new(OrderActions.Delete, new[]{ OrderStatuses.New, OrderStatuses.Cancelled }, null, nameof(ApplicationOperations.OrderDelete), "Видалити замовлення", true),
        new(OrderActions.PrintLabels, new[]{ OrderStatuses.New, OrderStatuses.Collected, OrderStatuses.InTransit, OrderStatuses.Received, OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted, OrderStatuses.Completed, OrderStatuses.Released }, null, nameof(ApplicationOperations.OrderPrintLabels), "Друк етикеток", true),
        new(OrderActions.PrintReport, new[]{ OrderStatuses.InProgress, OrderStatuses.PartiallyCompleted, OrderStatuses.Completed, OrderStatuses.Released }, null, nameof(ApplicationOperations.OrderPrintReport), "Друк бланка", true),
    };

    // ------------------------------------------------------------------ SAMPLE
    public static readonly ActionRule[] SampleRules =
    {
        new(SampleActions.Collect, new[]{ SampleStatuses.Pending }, SampleStatuses.Collected, nameof(ApplicationOperations.SampleCollect), "Забір пробірки"),
        new(SampleActions.Uncollect, new[]{ SampleStatuses.Collected }, SampleStatuses.Pending, nameof(ApplicationOperations.SampleUncollect), "Скасувати відмітку забору"),
        new(SampleActions.Dispatch, new[]{ SampleStatuses.Collected }, SampleStatuses.InTransit, nameof(ApplicationOperations.SampleDispatch), "Відправити"),
        new(SampleActions.Receive, new[]{ SampleStatuses.Collected, SampleStatuses.InTransit }, SampleStatuses.Received, nameof(ApplicationOperations.SampleReceive), "Прийняти"),
        new(SampleActions.Process, new[]{ SampleStatuses.Received }, SampleStatuses.Processing, nameof(ApplicationOperations.SampleProcess), "В обробці (центрифугування/аналіз)"),
        new(SampleActions.Store, new[]{ SampleStatuses.Received, SampleStatuses.Processing }, SampleStatuses.Stored, nameof(ApplicationOperations.SampleStore), "Розмістити в біобанку"),
        new(SampleActions.Dispose, new[]{ SampleStatuses.Stored, SampleStatuses.Received, SampleStatuses.Processing, SampleStatuses.Rejected }, SampleStatuses.Disposed, nameof(ApplicationOperations.SampleDispose), "Утилізувати"),
        new(SampleActions.Reject, new[]{ SampleStatuses.Collected, SampleStatuses.InTransit, SampleStatuses.Received, SampleStatuses.Processing }, SampleStatuses.Rejected, nameof(ApplicationOperations.SampleReject), "Відбракувати пробірку"),
        new(SampleActions.EditFlags, new[]{ SampleStatuses.Collected, SampleStatuses.InTransit, SampleStatuses.Received, SampleStatuses.Processing }, null, nameof(ApplicationOperations.SampleEditFlags), "Відмітки гемоліз/ліпемія/іктеричність", true),
        new(SampleActions.Replace, new[]{ SampleStatuses.Pending, SampleStatuses.Collected, SampleStatuses.Rejected }, null, nameof(ApplicationOperations.SampleReplace), "Замінити пробірку (новий штрихкод)", true),
        new(SampleActions.Delete, new[]{ SampleStatuses.Pending }, null, nameof(ApplicationOperations.SampleDelete), "Видалити пробірку", true),
    };

    // ------------------------------------------------------------------ ORDER TEST / RESULT
    public static readonly ActionRule[] TestRules =
    {
        new(TestActions.StartAnalysis, new[]{ OrderTestStatuses.Pending, OrderTestStatuses.Rerun }, OrderTestStatuses.InAnalysis, nameof(ApplicationOperations.OrderTestStartAnalysis), "Передати на аналізатор"),
        new(TestActions.AssignAnalyzer, new[]{ OrderTestStatuses.Pending, OrderTestStatuses.InAnalysis, OrderTestStatuses.Rerun }, null, nameof(ApplicationOperations.OrderTestAssignAnalyzer), "Призначити аналізатор", true),
        new(TestActions.EnterResult, new[]{ OrderTestStatuses.Pending, OrderTestStatuses.InAnalysis, OrderTestStatuses.Rerun, OrderTestStatuses.SentOut }, OrderTestStatuses.Resulted, nameof(ApplicationOperations.OrderTestEnterResult), "Ввести результат"),
        new(TestActions.SendOut, new[]{ OrderTestStatuses.Pending, OrderTestStatuses.Rerun }, OrderTestStatuses.SentOut, nameof(ApplicationOperations.OrderTestSendOut), "Відправити в зовнішню лабораторію"),
        new(TestActions.RecallSendOut, new[]{ OrderTestStatuses.SentOut }, OrderTestStatuses.Pending, nameof(ApplicationOperations.OrderTestRecallSendOut), "Відкликати з зовнішньої лабораторії"),
        new(TestActions.EditResult, new[]{ OrderTestStatuses.Resulted, OrderTestStatuses.NeedsReview }, OrderTestStatuses.Resulted, nameof(ApplicationOperations.OrderTestEditResult), "Виправити результат (нова версія)"),
        new(TestActions.DeleteResult, new[]{ OrderTestStatuses.Resulted, OrderTestStatuses.NeedsReview }, OrderTestStatuses.Pending, nameof(ApplicationOperations.OrderTestDeleteResult), "Видалити результат"),
        new(TestActions.Verify, new[]{ OrderTestStatuses.Resulted, OrderTestStatuses.NeedsReview, OrderTestStatuses.AutoVerified }, OrderTestStatuses.Verified, nameof(ApplicationOperations.OrderTestVerify), "Верифікувати"),
        new(TestActions.Reject, new[]{ OrderTestStatuses.Pending, OrderTestStatuses.InAnalysis, OrderTestStatuses.Resulted, OrderTestStatuses.NeedsReview, OrderTestStatuses.Rerun, OrderTestStatuses.SentOut }, OrderTestStatuses.Rejected, nameof(ApplicationOperations.OrderTestReject), "Відхилити тест"),
        new(TestActions.Rerun, new[]{ OrderTestStatuses.Resulted, OrderTestStatuses.NeedsReview, OrderTestStatuses.AutoVerified }, OrderTestStatuses.Rerun, nameof(ApplicationOperations.OrderTestRerun), "Повторити дослідження"),
        new(TestActions.Reopen, new[]{ OrderTestStatuses.Verified, OrderTestStatuses.AutoVerified, OrderTestStatuses.Rejected }, OrderTestStatuses.NeedsReview, nameof(ApplicationOperations.OrderTestReopen), "Відкрити повторно"),
        new(TestActions.Remove, new[]{ OrderTestStatuses.Pending }, null, nameof(ApplicationOperations.OrderTestRemove), "Прибрати тест із замовлення", true),
    };

    // ------------------------------------------------------------------ MANIFEST (логістика)
    public const string ManifestCreated = "CREATED", ManifestDispatched = "DISPATCHED", ManifestReceived = "RECEIVED", ManifestRejected = "REJECTED";
    public static readonly ActionRule[] ManifestRules =
    {
        new(ManifestActions.Edit, new[]{ ManifestCreated, ManifestDispatched }, null, nameof(ApplicationOperations.ManifestEdit), "Редагувати маніфест", true),
        new(ManifestActions.Dispatch, new[]{ ManifestCreated }, ManifestDispatched, nameof(ApplicationOperations.ManifestDispatch), "Відправити"),
        new(ManifestActions.Receive, new[]{ ManifestDispatched }, ManifestReceived, nameof(ApplicationOperations.ManifestReceive), "Прийняти в лабораторії"),
        new(ManifestActions.Reject, new[]{ ManifestDispatched }, ManifestRejected, nameof(ApplicationOperations.ManifestReject), "Відхилити (порушення холодового ланцюга)"),
        new(ManifestActions.Delete, new[]{ ManifestCreated, ManifestDispatched }, null, nameof(ApplicationOperations.ManifestDelete), "Видалити маніфест", true),
    };

    // ------------------------------------------------------------------ CULTURE (посів)
    public const string CultureIncubating = "INCUBATING", CulturePreliminary = "PRELIMINARY", CultureIsolated = "ISOLATED", CultureCompleted = "COMPLETED";
    public static readonly ActionRule[] CultureRules =
    {
        new(CultureActions.Edit, new[]{ CultureIncubating, CulturePreliminary, CultureIsolated }, null, nameof(ApplicationOperations.CultureEdit), "Редагувати посів", true),
        new(CultureActions.Preliminary, new[]{ CultureIncubating }, CulturePreliminary, nameof(ApplicationOperations.CulturePreliminary), "Попередній результат"),
        new(CultureActions.AddIsolate, new[]{ CultureIncubating, CulturePreliminary, CultureIsolated }, null, nameof(ApplicationOperations.CultureAddIsolate), "Додати ізолят", true),
        new(CultureActions.Isolate, new[]{ CultureIncubating, CulturePreliminary }, CultureIsolated, nameof(ApplicationOperations.CultureIsolate), "Ізоляти виділено"),
        new(CultureActions.AddSusceptibility, new[]{ CulturePreliminary, CultureIsolated }, null, nameof(ApplicationOperations.CultureAddSusceptibility), "Антибіотикограма", true),
        new(CultureActions.Complete, new[]{ CulturePreliminary, CultureIsolated }, CultureCompleted, nameof(ApplicationOperations.CultureComplete), "Завершити посів"),
        new(CultureActions.Delete, new[]{ CultureIncubating }, null, nameof(ApplicationOperations.CultureDelete), "Видалити посів", true),
    };

    // ------------------------------------------------------------------ CONNECTOR
    public const string ConnectorPending = "PENDING", ConnectorActive = "ACTIVE", ConnectorOffline = "OFFLINE", ConnectorDisabled = "DISABLED";
    public static readonly ActionRule[] ConnectorRules =
    {
        new(ConnectorActions.Register, new[]{ ConnectorPending }, ConnectorActive, nameof(ApplicationOperations.ConnectorRegister), "Реєстрація інсталяції"),
        new(ConnectorActions.Heartbeat, new[]{ ConnectorActive, ConnectorOffline }, ConnectorActive, nameof(ApplicationOperations.ConnectorHeartbeat), "Heartbeat"),
        new(ConnectorActions.MarkOffline, new[]{ ConnectorActive }, ConnectorOffline, nameof(ApplicationOperations.ConnectorMarkOffline), "Позначити офлайн"),
        new(ConnectorActions.Disable, new[]{ ConnectorPending, ConnectorActive, ConnectorOffline }, ConnectorDisabled, nameof(ApplicationOperations.ConnectorDisable), "Вимкнути"),
        new(ConnectorActions.Enable, new[]{ ConnectorDisabled }, ConnectorPending, nameof(ApplicationOperations.ConnectorEnable), "Увімкнути (повторна реєстрація)"),
        new(ConnectorActions.RotateKey, new[]{ ConnectorActive, ConnectorOffline, ConnectorDisabled }, null, nameof(ApplicationOperations.ConnectorRotateKey), "Перевипустити ключ", true),
        new(ConnectorActions.Edit, new[]{ ConnectorPending, ConnectorActive, ConnectorOffline, ConnectorDisabled }, null, nameof(ApplicationOperations.ConnectorEdit), "Редагувати", true),
        new(ConnectorActions.Delete, new[]{ ConnectorPending, ConnectorDisabled }, null, nameof(ApplicationOperations.ConnectorDelete), "Видалити", true),
    };

    public static ActionRule[] RulesFor(string entity) => entity switch
    {
        LisEntities.Order => OrderRules,
        LisEntities.Sample => SampleRules,
        LisEntities.OrderTest => TestRules,
        LisEntities.Manifest => ManifestRules,
        LisEntities.Culture => CultureRules,
        LisEntities.Connector => ConnectorRules,
        _ => throw new ArgumentException($"Невідома сутність машини станів: {entity}")
    };

    public static string EntityLabel(string entity) => entity switch
    {
        LisEntities.Order => "Замовлення",
        LisEntities.Sample => "Пробірка",
        LisEntities.OrderTest => "Тест",
        LisEntities.Manifest => "Маніфест",
        LisEntities.Culture => "Посів",
        LisEntities.Connector => "Коннектор",
        _ => entity
    };

    /// <summary>Дії, доступні для поточного статусу і прав користувача (для кнопок UI).</summary>
    public static List<AllowedActionDto> AllowedActions(string entity, string status, Func<string, bool> canExecute)
    {
        return RulesFor(entity)
            .Where(r => r.FromStatuses.Contains(status) && canExecute(r.Operation))
            .Select(r => new AllowedActionDto(r.Action, r.Label, r.ToStatus))
            .ToList();
    }

    /// <summary>Усі переходи сутності (документація машини станів для UI/розробників).</summary>
    public static List<TransitionDto> Describe(string entity) =>
        RulesFor(entity).Select(r => new TransitionDto(r.Action, r.Label, r.FromStatuses, r.ToStatus, r.Operation)).ToList();

    /// <summary>
    /// Перевіряє статус дії (409). Повертає правило (з цільовим статусом і правом на операцію).
    /// </summary>
    public static ActionRule EnsureStatus(string entity, string action, string currentStatus, string? objectLabel = null)
    {
        var rule = RulesFor(entity).FirstOrDefault(r => r.Action == action)
                   ?? throw new ArgumentException($"Невідома дія '{action}' для {entity}");
        var label = objectLabel ?? EntityLabel(entity);
        if (!rule.FromStatuses.Contains(currentStatus))
            throw new ConflictException($"{label}: дія «{rule.Label}» неможлива у статусі {currentStatus}. Дозволені статуси: {string.Join(", ", rule.FromStatuses)}");
        return rule;
    }

    /// <summary>Перевіряє, чи існує прямий перехід from→to хоча б за одним правилом.</summary>
    public static bool CanTransition(string entity, string from, string to) =>
        RulesFor(entity).Any(r => r.ToStatus == to && r.FromStatuses.Contains(from));
}

public sealed record AllowedActionDto(string Action, string Label, string? ToStatus);
public sealed record TransitionDto(string Action, string Label, string[] FromStatuses, string? ToStatus, string Operation);
