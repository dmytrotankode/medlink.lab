// Політика доступу: чи може поточний співробітник (з обраного профілю безпеки) виконати операцію за правами профілю.
// Повертає 403 ProblemDetails з українським текстом.
using Core.Data;
using Core.Security;
using Core.Services;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Filters;
using MedLink.LIS.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Domain;

public interface IRolePolicy
{
    bool Can(string operationName);
    /// <summary>Кидає OperationDeniedException, якщо профіль поточного користувача не має права на операцію.</summary>
    void Require(string operationName);
    /// <summary>Перевірка дії машини станів для сутності (409 статус / 403 право на операцію).</summary>
    ActionRule Ensure(string entity, string action, string currentStatus, string? objectLabel = null);
    List<AllowedActionDto> AllowedActions(string entity, string status);
}

public sealed class RolePolicy : IRolePolicy
{
    private readonly ICurrentEmployee _current;
    private readonly IUserInfoService _userService;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly LisDbContext _db;
    private readonly Dictionary<string, bool> _checked = new();

    public RolePolicy(ICurrentEmployee current, IUserInfoService userService, IHttpContextAccessor httpContextAccessor, LisDbContext db)
    {
        _current = current;
        _userService = userService;
        _httpContextAccessor = httpContextAccessor;
        _db = db;
    }

    public bool Can(string operationName)
    {
        if (!_current.IsResolved) return false;
        if (_checked.TryGetValue(operationName, out var allowed)) return allowed;
        allowed = TryAssert(CurrentUser(), operationName);
        _checked[operationName] = allowed;
        return allowed;
    }

    public void Require(string operationName)
    {
        if (!_current.IsResolved)
            throw new ForbiddenException(NotResolvedMessage(_current));
        if (Can(operationName)) return;
        var profileId = CurrentUser()?.ProfileId ?? Guid.Empty;
        var profileCaption = _db.SecurityProfiles!.AsNoTracking().Where(p => p.Id == profileId).Select(p => p.Caption).FirstOrDefault();
        throw new OperationDeniedException(ApiAuthorizationFilter.OperationDeniedDetail(operationName, profileCaption));
    }

    public ActionRule Ensure(string entity, string action, string currentStatus, string? objectLabel = null)
    {
        if (!_current.IsResolved)
            throw new ForbiddenException(NotResolvedMessage(_current));
        var rule = LisStateMachine.EnsureStatus(entity, action, currentStatus, objectLabel);
        Require(rule.Operation);
        return rule;
    }

    public List<AllowedActionDto> AllowedActions(string entity, string status) => LisStateMachine.AllowedActions(entity, status, Can);

    private BaseUserInfo? CurrentUser() => _httpContextAccessor.HttpContext == null ? _userService.SystemUser : _userService.GetCurrentUserInfo();

    private static bool TryAssert(BaseUserInfo? userInfo, string operationName)
    {
        if (userInfo == null || userInfo is UserInfo { Rights: null }) return false;
        try
        {
            userInfo.AssertCanExecuteOperation(operationName);
            return true;
        }
        catch (NoRightsException)
        {
            return false;
        }
    }

    private static string NotResolvedMessage(ICurrentEmployee current) => string.IsNullOrEmpty(current.EmployeeId)
        ? "Співробітника не визначено: увійдіть і оберіть профіль (api/account/authenticate/)"
        : $"Співробітника '{current.EmployeeId}' обраного профілю не знайдено";
}

/// <summary>Політика для технічного актора (коннектор) — усі дії дозволені.</summary>
public sealed class SystemRolePolicy : IRolePolicy
{
    private static readonly UserInfo SystemUser = new() { Rights = new UserApplicationRights(true) };

    public bool Can(string operationName)
    {
        SystemUser.AssertCanExecuteOperation(operationName);
        return true;
    }

    public void Require(string operationName) => SystemUser.AssertCanExecuteOperation(operationName);

    public ActionRule Ensure(string entity, string action, string currentStatus, string? objectLabel = null)
    {
        var rule = LisStateMachine.EnsureStatus(entity, action, currentStatus, objectLabel);
        Require(rule.Operation);
        return rule;
    }

    public List<AllowedActionDto> AllowedActions(string entity, string status) => LisStateMachine.AllowedActions(entity, status, Can);
}
