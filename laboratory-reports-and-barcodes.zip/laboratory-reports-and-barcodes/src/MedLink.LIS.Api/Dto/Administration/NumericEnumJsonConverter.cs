using System.Text.Json;
using System.Text.Json.Serialization;

namespace MedLink.LIS.Api.Dto.Administration;

public sealed class NumericEnumJsonConverter<T> : JsonConverter<T>
{
    private static readonly JsonSerializerOptions Numeric = new(JsonSerializerDefaults.Web)
    {
        ReferenceHandler = ReferenceHandler.IgnoreCycles
    };

    public override T? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        => JsonSerializer.Deserialize<T>(ref reader, Numeric);

    public override void Write(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
        => JsonSerializer.Serialize(writer, value, Numeric);
}
