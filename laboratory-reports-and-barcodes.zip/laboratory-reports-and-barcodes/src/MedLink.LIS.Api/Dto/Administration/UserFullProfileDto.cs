using System.Text.Json.Serialization;
using Core.Security;

namespace MedLink.LIS.Api.Dto.Administration;

public sealed class UserFullProfileDto
{
    public Guid EmployeeId { get; set; }
    public string? EmployeeCaption { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? DepartmentCaption { get; set; }
    public Guid? SpecialityId { get; set; }
    public string? SpecialityCaption { get; set; }
    public Guid? OrganizationId { get; set; }
    public string? OrganizationCaption { get; set; }
    public string? PersonName { get; set; }
    public string? PersonMiddleName { get; set; }
    public string? PersonLastName { get; set; }
    public Guid ProfileId { get; set; }
    public string ProfileCaption { get; set; } = "";
    public string UserId { get; set; } = "";
    [JsonConverter(typeof(NumericEnumJsonConverter<UserApplicationRights>))]
    public UserApplicationRights? Rights { get; set; }
    public bool SubscribedToNotifications { get; set; }
    public bool IsXlsxDownloadAccess { get; set; }
    public bool IsPaidServicesAccess { get; set; }
    public bool AllowsOperatingWithoutEhealth { get; set; }
    public Guid PersonId { get; set; }
    public bool IsQualityIndicatorsEnabledForOrganization { get; set; }
    public bool IsFinancialIndicatorsEnabledForOrganization { get; set; }
}
