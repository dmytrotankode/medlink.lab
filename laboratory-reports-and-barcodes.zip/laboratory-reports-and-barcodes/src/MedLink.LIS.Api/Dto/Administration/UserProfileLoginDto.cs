namespace MedLink.LIS.Api.Dto.Administration;

public sealed class UserProfileLoginDto
{
    public Guid ProfileId { get; set; }
    public Guid UserId { get; set; }
    public Guid PersonId { get; set; }
    public bool IsActive { get; set; }
    public string? UserOuterId { get; set; }
    public Guid? TypeId { get; set; }
    public Guid? EhealthSpecialityId { get; set; }
    public string? EhealthSpecialityCode { get; set; }
    public Guid? EhealthEmployeeId { get; set; }
    public string EhealthEmployeeCaption { get; set; } = "";
    public string? EhealthPositionCaption { get; set; }
    public string? EhealthPositionCode { get; set; }
    public Guid? EhealthDivisionId { get; set; }
    public string EhealthDivisionCaption { get; set; } = "";
    public int? EhealthEmployeeStatus { get; set; }
    public int? EhealthEmployeeRequestStatus { get; set; }
    public Guid? EhealthOrganizationId { get; set; }
    public Guid? EhealthOrganizationTypeId { get; set; }
    public string EhealthOrganizationTypeCode { get; set; } = "";
    public int? EhealthOrganizationStatus { get; set; }
    public string Email { get; set; } = "";
    public Guid? SpecialityId { get; set; }
    public string EhealthOrganizationCaption { get; set; } = "";
    public string EhealthOrganizationEdrpou { get; set; } = "";
    public Guid? OrganizationEhealthId { get; set; }
    public Guid? OrganizationId { get; set; }
    public bool CanUseTerraLab => !string.IsNullOrEmpty(TerraLabId);
    public string TerraLabId { get; set; } = "";
    public string RoleName { get; set; } = "";
}
