namespace MedLink.LIS.Api.Dto.Administration;

public sealed class UserProfileSelectLoginDto
{
    public Guid ProfileId { get; set; }
    public Guid UserId { get; set; }
    public Guid OrganizationId { get; set; }
    public string RoleName { get; set; } = "";
    public string ProfileCaption { get; set; } = "";
    public string UserCaption { get; set; } = "";
    public string OrganizationCaption { get; set; } = "";
    public bool IsActive { get; set; }
    public string? UserOuterId { get; set; }
    public Guid? EhealthSpecialityId { get; set; }
    public Guid? SpecialityEhealthId { get; set; }
    public string EhealthSpecialityCode { get; set; } = "";
    public string EhealthSpecialityName { get; set; } = "";
    public Guid? EhealthEmployeeId { get; set; }
    public string? EhealthPositionCaption { get; set; }
    public string DivisionCaption { get; set; } = "";
    public string Email { get; set; } = "";
    public string LegalEntityTypeCode { get; set; } = "";
}
