using System.ComponentModel.DataAnnotations.Schema;
using Core.Base.Data;
using Core.Common.Attributes;
using Core.Common.Enums;
using Core.Security;

namespace MedLink.LIS.Api.Dto.Administration;

[RlsRight("Organization", nameof(OrganizationId))]
[RlsRight("Employee", nameof(Id))]
[RlsRight("Department", nameof(DepartmentId))]
public sealed class UsersListDto : BaseDto, IPagingCounted
{
    [NotMapped]
    public int TotalRecordCount { get; set; }

    [CaseFilter(CaseFilterOperation.Equals)]
    public Guid? DepartmentId { get; set; }
    [CaseFilter(CaseFilterOperation.Contains)]
    public string DepartmentCaption { get; set; } = "";
    [CaseFilter(CaseFilterOperation.Equals)]
    public Guid OrganizationId { get; set; }
    [CaseFilter(CaseFilterOperation.Contains)]
    public string OrganizationCaption { get; set; } = "";
    [CaseFilter(CaseFilterOperation.Equals)]
    public Guid PositionTypeId { get; set; }
    [CaseFilter(CaseFilterOperation.Contains)]
    public string PositionTypeCaption { get; set; } = "";
}
