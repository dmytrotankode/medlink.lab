namespace MedLink.LIS.Api.Dto.Ehealth.ehd.NotMappedDto;

public sealed class EhealthInfoDto
{
    public Guid? EhealthOrganizationId { get; set; }
    public Guid? OrganizationEhealthId { get; set; }
    public Guid? OrganizationId { get; set; }
    public string? EhealthOrganizationCaption { get; set; }
    public Guid? EhealthEmployeeId { get; set; }
    public string? EhealthEmployeeCaption { get; set; }
    public Guid? TypeId { get; set; }
    public string? TypeCode { get; set; }
    public string? RoleName { get; set; }
    public Guid? EhealthSpecialityId { get; set; }
    public Guid? SpecialityId { get; set; }
    public string? SpecialityCode { get; set; }
    public string? EhealthPositionCaption { get; set; }
    public string? EhealthPositionCode { get; set; }
    public Guid? EhealthDivisionId { get; set; }
    public string? EhealthDivisionCaption { get; set; }
    public int? EmployeeStatus { get; set; }
    public int? EmployeeRequestStatus { get; set; }
    public int? EhealthOrganizationStatus { get; set; }
    public string? Email { get; set; }
    public string? EhealthOrganizationEdrpou { get; set; }
    public bool CanUseTerraLab { get; set; }
    public string? TerraLabId { get; set; }
    public bool IsReorganized => false;
    public string? CurrentUserId { get; set; }
    public int DeclarationVerificationUsageVersion { get; set; } = 1;
}
