using System.Collections.Concurrent;
using System.Security.Claims;
using Core.Base.Attributes;
using Core.Data;
using Core.Mvc.Filters;
using Core.Security;
using Core.Services;
using MedLink.LIS.Api.Configuration;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Filters;

public class ApiAuthorizationFilter : IAsyncAuthorizationFilter
{
    public const string NotAuthorizedTitle = ApiUnauthorizedResponseWriter.UnauthorizedTitle;
    public const string NotAuthorizedDetail = ApiUnauthorizedResponseWriter.UnauthorizedDetail;
    public const string NoProfileTitle = "Помилка авторизації";
    public const string NoProfileDetail = "Авторизований користувач не має профілю безпеки або строк дії сесії минув. Увійдіть повторно";
    public const string OperationDeniedTitle = "Операція відхилена";

    private static readonly ConcurrentDictionary<string, string?> _controllerOperations = new();
    private readonly ILogger<ApiAuthorizationFilter> _logger;

    public ApiAuthorizationFilter(ILogger<ApiAuthorizationFilter> logger)
    {
        _logger = logger;
    }

    public static string OperationDeniedDetail(string operationName, string? profileCaption)
    {
        var caption = ApplicationOperations.GetDeclaredOperations().FirstOrDefault(o => o.OperationName == operationName)?.OperationCaption ?? operationName;
        return $"Користувач з профілем \"{profileCaption}\" не має прав на здійснення функції «{caption}»";
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        var isAllowApiCall = context.ActionDescriptor.EndpointMetadata.Any(item => item is AllowApiCallAttribute);
        var isAllowAnonymous = context.ActionDescriptor.EndpointMetadata.Any(item => item is AllowAnonymousAttribute);

        if (!isAllowAnonymous && isAllowApiCall)
        {
            var isApiAuthenticated = context.HttpContext?.User?.Identity?.IsAuthenticated;
            if (!isApiAuthenticated.HasValue || !isApiAuthenticated.Value)
            {
                context.Result = new CustomAuthenticationRequiredResult(NotAuthorizedDetail, NotAuthorizedTitle);
                _logger.LogError("Caller not authenticated.");
                return;
            }
        }

        if (!isAllowAnonymous && !isAllowApiCall)
        {
            var path = context.HttpContext?.Request?.Path.Value ?? "n/a";
            var isAuthenticated = context.HttpContext?.User?.Identity?.IsAuthenticated ?? false;
            if (!isAuthenticated)
            {
                context.Result = new CustomAuthenticationRequiredResult(NotAuthorizedDetail, NotAuthorizedTitle);
                _logger.LogError("Authorization failed. Caller not authenticated. path={Path}", path);
                return;
            }

            var tokenSubject = context.HttpContext?.User?.FindFirst("sub")?.Value
                               ?? context.HttpContext?.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value
                               ?? "n/a";
            var userService = context.HttpContext!.RequestServices.GetRequiredService<IUserInfoService>();
            var userInfo = await userService.GetCurrentUserInfoAsync();
            if (userInfo == null || string.IsNullOrEmpty(userInfo.Id))
            {
                context.Result = new CustomUnauthorizedResult(NotAuthorizedDetail, NotAuthorizedTitle);
                _logger.LogError("Authorization failed. User id is empty. path={Path}; tokenSub={TokenSub}; userId={UserId}", path, tokenSubject, userInfo?.Id);
            }
            else if (userInfo.ProfileId == Guid.Empty)
            {
                context.Result = new CustomUnauthorizedResult(NoProfileDetail, NoProfileTitle);
                _logger.LogError("Authorization failed. Empty profile. path={Path}; tokenSub={TokenSub}; userId={UserId}", path, tokenSubject, userInfo.Id);
            }
            else
            {
                var operationValidationError = await GetOperationValidationFailedError(context, userInfo);
                if (!string.IsNullOrEmpty(operationValidationError))
                {
                    context.Result = new CustomUnauthorizedResult(operationValidationError, OperationDeniedTitle);
                }
            }
        }
    }

    private async Task<string> GetOperationValidationFailedError(AuthorizationFilterContext context, BaseUserInfo userInfo)
    {
        if (context.ActionDescriptor is ControllerActionDescriptor actDescriptor)
        {
            var controllerName = actDescriptor.ControllerName;
            var actionName = actDescriptor.ActionName;
            var operationKey = controllerName + "." + actionName;
            if (!_controllerOperations.TryGetValue(operationKey, out var operationName))
            {
                var operationAttribute = actDescriptor.MethodInfo.GetCustomAttributes(typeof(OperationRightAttribute), true).FirstOrDefault() as OperationRightAttribute;
                operationName = operationAttribute?.OperationName;
                _controllerOperations.TryAdd(operationKey, operationName);
            }

            if (!string.IsNullOrEmpty(operationName))
            {
                try
                {
                    userInfo.AssertCanExecuteOperation(operationName);
                }
                catch (NoRightsException ex)
                {
                    _logger.LogError(ex, "User with id={UserId}, profileId={ProfileId}) has no rights to perform controller action {ControllerAction}", userInfo?.Id, userInfo?.ProfileId, context.ActionDescriptor.DisplayName);
                    var db = context.HttpContext.RequestServices.GetRequiredService<LisDbContext>();
                    var profileCaption = await db.SecurityProfiles!.AsNoTracking().Where(p => p.Id == userInfo!.ProfileId).Select(p => p.Caption).FirstOrDefaultAsync();
                    return OperationDeniedDetail(operationName, profileCaption);
                }
            }
        }

        return string.Empty;
    }
}
