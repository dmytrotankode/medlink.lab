// Автентифікація коннектора заголовком X-MedLink-ApiKey (SHA-256 hash у lab_connector_installation).
// Це ідентифікація пристрою, а не користувацька авторизація.
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Core.Contracts;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Infrastructure;

[AttributeUsage(AttributeTargets.Method)]
public sealed class AllowWithoutApiKeyAttribute : Attribute { }

public sealed class ConnectorApiKeyFilter : IAsyncActionFilter
{
    public const string ItemKey = "MedLink.Connector";
    private readonly ConnectorService _connectors;
    private readonly LisDbContext _db;

    public ConnectorApiKeyFilter(ConnectorService connectors, LisDbContext db)
    {
        _connectors = connectors;
        _db = db;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var ct = context.HttpContext.RequestAborted;
        var allowAnonymous = context.ActionDescriptor.EndpointMetadata.OfType<AllowWithoutApiKeyAttribute>().Any();
        if (allowAnonymous)
        {
            var installKey = context.ActionArguments.Values.OfType<ConnectorRegisterRequest>().FirstOrDefault()?.InstallKey?.Trim();
            if (string.IsNullOrEmpty(installKey))
            {
                await next();
                return;
            }
            var registerTenantId = await _db.RunAsConnectorInstallKeyAsync(installKey, () => _db.Connectors.IgnoreQueryFilters().AsNoTracking()
                .Where(c => c.InstallKey == installKey && c.RecordState != RecordStates.Deleted)
                .Select(c => c.TenantId)
                .FirstOrDefaultAsync(ct), ct) ?? throw new ForbiddenConnectorException("Невідомий ключ інсталяції");
            await _db.RunAsTenantAsync(registerTenantId, async () => { await next(); }, ct);
            return;
        }

        var key = context.HttpContext.Request.Headers[ConnectorService.ApiKeyHeader].FirstOrDefault();
        var hash = string.IsNullOrWhiteSpace(key) ? null : ConnectorService.Hash(key);
        var tenantId = hash == null ? null : await _db.RunAsConnectorApiKeyHashAsync(hash, () => _db.Connectors.IgnoreQueryFilters().AsNoTracking()
            .Where(c => c.ApiKeyHash == hash && c.RecordState != RecordStates.Deleted)
            .Select(c => c.TenantId)
            .FirstOrDefaultAsync(ct), ct);
        if (tenantId == null) throw new ForbiddenConnectorException($"Відсутній або недійсний заголовок {ConnectorService.ApiKeyHeader}");
        await _db.RunAsTenantAsync(tenantId, async () =>
        {
            var connector = await _connectors.ResolveByApiKeyAsync(key)
                            ?? throw new ForbiddenConnectorException($"Відсутній або недійсний заголовок {ConnectorService.ApiKeyHeader}");
            context.HttpContext.Items[ItemKey] = connector;
            await next();
        }, ct);
    }
}

public static class ConnectorContextExtensions
{
    public static LabConnectorInstallation CurrentConnector(this HttpContext ctx) =>
        ctx.Items[ConnectorApiKeyFilter.ItemKey] as LabConnectorInstallation ?? throw new ForbiddenConnectorException("Коннектор не автентифіковано");
}
