// Поточний співробітник — із профілю, обраного після входу
// (IUserInfoService.GetCurrentUserInfoAsync().UserId → org_employee). Для анонімних викликів (коннектор, account/*) і
// фонових задач співробітник не визначений — системний контекст (created_by = нульовий GUID).
using Core.Services;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Tenancy;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Infrastructure;

public interface ICurrentEmployee
{
    string EmployeeId { get; }
    string? FullName { get; }
    string? LabRole { get; }
    Guid ProfileId { get; }
    string? DepartmentId { get; }
    string? Ip { get; }
    bool IsResolved { get; }
    void Set(OrgEmployee? employee, string requestedId, string? ip, Guid profileId = default);
}

public sealed class CurrentEmployee : ICurrentEmployee
{
    public string EmployeeId { get; private set; } = "";
    public string? FullName { get; private set; }
    public string? LabRole { get; private set; }
    public Guid ProfileId { get; private set; }
    public string? DepartmentId { get; private set; }
    public string? Ip { get; private set; }
    public bool IsResolved { get; private set; }

    public void Set(OrgEmployee? employee, string requestedId, string? ip, Guid profileId = default)
    {
        EmployeeId = employee?.Id ?? requestedId;
        FullName = employee?.Caption;
        LabRole = employee?.LabRole;
        ProfileId = profileId;
        DepartmentId = employee?.DepartmentId;
        Ip = ip;
        IsResolved = employee != null;
    }
}

public sealed class CurrentEmployeeMiddleware
{
    private readonly RequestDelegate _next;

    public CurrentEmployeeMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context, ICurrentEmployee current, LisDbContext db, ITenantContext tenant)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString();
        var employeeId = "";
        var profileId = Guid.Empty;
        OrgEmployee? employee = null;
        if (context.User?.Identity?.IsAuthenticated == true && context.Request.Path.StartsWithSegments("/api"))
        {
            var userInfo = await context.RequestServices.GetRequiredService<IUserInfoService>().GetCurrentUserInfoAsync();
            if (userInfo != null && userInfo.ProfileId != Guid.Empty && userInfo.UserId != Guid.Empty)
            {
                employeeId = userInfo.UserId.ToString();
                profileId = userInfo.ProfileId;
                employee = tenant.TenantId == null ? null : await db.Employees.AsNoTracking().FirstOrDefaultAsync(e => e.Id == employeeId && e.RecordState == RecordStates.Active);
            }
        }
        current.Set(employee, employeeId, ip, profileId);
        db.CurrentUserId = string.IsNullOrEmpty(employeeId) ? null : employeeId;
        await _next(context);
    }
}
