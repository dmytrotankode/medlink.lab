// Глобальна обробка винятків у форматі RFC 7807
using System.Text.Json;
using MedLink.LIS.Api.Tenancy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace MedLink.LIS.Api.Infrastructure;

public sealed class ProblemDetailsMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ProblemDetailsMiddleware> _logger;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web) { DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull };

    public ProblemDetailsMiddleware(RequestDelegate next, ILogger<ProblemDetailsMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (LisException ex)
        {
            await WriteAsync(context, ex.StatusCode, ex.Title, ex.Message, ex.Errors);
        }
        catch (Exception ex) when (Find<TenantNotSetException>(ex) != null || Find<PostgresException>(ex)?.SqlState == PostgresErrorCodes.UndefinedObject)
        {
            await WriteAsync(context, 400, TenantRequiredTitle, new TenantNotSetException().Message, null, TenantRequiredCode);
        }
        catch (Exception ex) when (Find<TenantMismatchException>(ex) != null || Find<DepartmentNotAllowedException>(ex) != null || IsRowLevelSecurityViolation(ex))
        {
            await WriteAsync(context, 404, NotFoundTitle, NotFoundDetail, null);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogWarning(ex, "Помилка збереження у БД");
            await WriteAsync(context, 409, "Помилка збереження", "Порушення цілісності даних: " + (ex.InnerException?.Message ?? ex.Message), null);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Необроблена помилка {Path}", context.Request.Path);
            await WriteAsync(context, 500, "Внутрішня помилка сервера", ex.Message, null);
        }
    }

    public const string TenantRequiredTitle = "Організацію не визначено";
    public const string TenantRequiredCode = "tenant_required";
    public const string NotFoundTitle = "Не знайдено";
    public const string NotFoundDetail = "Об'єкт не знайдено";

    private static T? Find<T>(Exception? ex) where T : Exception
    {
        for (; ex != null; ex = ex.InnerException)
            if (ex is T match) return match;
        return null;
    }

    private static bool IsRowLevelSecurityViolation(Exception ex) => Find<PostgresException>(ex)?.SqlState == PostgresErrorCodes.InsufficientPrivilege;

    private static async Task WriteAsync(HttpContext ctx, int status, string title, string detail, IDictionary<string, string[]>? errors, string? code = null)
    {
        if (ctx.Response.HasStarted) return;
        ctx.Response.Clear();
        ctx.Response.StatusCode = status;
        ctx.Response.ContentType = "application/problem+json; charset=utf-8";
        var pd = new ProblemDetails
        {
            Type = $"https://httpstatuses.com/{status}",
            Title = title,
            Status = status,
            Detail = detail,
            Instance = ctx.Request.Path
        };
        if (code != null) pd.Extensions["code"] = code;
        if (errors != null) pd.Extensions["errors"] = errors;
        pd.Extensions["traceId"] = ctx.TraceIdentifier;
        await ctx.Response.WriteAsync(JsonSerializer.Serialize(pd, JsonOptions));
    }
}
