// Swagger: заголовок X-MedLink-ApiKey для API коннектора (користувацькі запити — Authorization: Bearer <токен сервера ідентифікації>)
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace MedLink.LIS.Api.Infrastructure;

public sealed class SwaggerHeaderFilter : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        operation.Parameters ??= new List<OpenApiParameter>();
        var path = context.ApiDescription.RelativePath ?? "";
        if (path.Contains("/connector/", StringComparison.OrdinalIgnoreCase))
        {
            operation.Parameters.Add(new OpenApiParameter
            {
                Name = Services.ConnectorService.ApiKeyHeader, In = ParameterLocation.Header, Required = false,
                Description = "Технічний ключ інсталяції коннектора (видається при /connector/register)", Schema = new OpenApiSchema { Type = "string" }
            });
        }
    }
}
