﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MedLink.LIS.Api.Migrations
{
    /// <inheritdoc />
    public partial class _0001_init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "cmn_enum_record",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "text", nullable: true),
                    enum_type = table.Column<string>(type: "text", nullable: true),
                    parent_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    value_type = table.Column<int>(type: "integer", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_cmn_enum_record", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ehe_service_catalog_service",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "text", nullable: true),
                    name = table.Column<string>(type: "text", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    is_composition = table.Column<bool>(type: "boolean", nullable: false),
                    request_allowed = table.Column<bool>(type: "boolean", nullable: false),
                    medical_referral_category_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    ehealth_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    inserted_at_in_ehealth = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ehe_service_catalog_service", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_analyzer_type",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    manufacturer = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    category = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    exch_type = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    bop_base64 = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    eop_base64 = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    control_sum = table.Column<bool>(type: "boolean", nullable: false),
                    sleep_ms = table.Column<int>(type: "integer", nullable: false),
                    full_text = table.Column<bool>(type: "boolean", nullable: false),
                    order_template = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    parser_kind = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_analyzer_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_antibiotic",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    group_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    atc_code = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    eucast_code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    default_disk_content_mcg = table.Column<double>(type: "double precision", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_antibiotic", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_archive_rack",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    room_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    freezer_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    shelf_number = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    temperature_celsius = table.Column<double>(type: "double precision", nullable: false),
                    rows_count = table.Column<int>(type: "integer", nullable: false),
                    cols_count = table.Column<int>(type: "integer", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_archive_rack", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_audit_log",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    user_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    user_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    action = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    before_json = table.Column<string>(type: "text", nullable: true),
                    after_json = table.Column<string>(type: "text", nullable: true),
                    at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    ip = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    comment = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_audit_log", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_biomaterial_type",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    default_container = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    stability_hours = table.Column<int>(type: "integer", nullable: false),
                    temperature_regime = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_biomaterial_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_connector_command",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    connector_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    type = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    payload = table.Column<string>(type: "text", nullable: true),
                    is_delivered = table.Column<bool>(type: "boolean", nullable: false),
                    delivered_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_connector_command", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_connector_installation",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    host_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    os_description = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    version = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    install_key = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    install_key_used = table.Column<bool>(type: "boolean", nullable: false),
                    api_key_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    last_heartbeat_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    registered_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    buffered_count = table.Column<int>(type: "integer", nullable: false),
                    uptime_sec = table.Column<long>(type: "bigint", nullable: false),
                    config_version = table.Column<int>(type: "integer", nullable: false),
                    poll_interval_sec = table.Column<int>(type: "integer", nullable: false),
                    heartbeat_interval_sec = table.Column<int>(type: "integer", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_connector_installation", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_connector_log",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    connector_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    level = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    message = table.Column<string>(type: "text", nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_connector_log", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_counter",
                columns: table => new
                {
                    counter_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    counter_value = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_counter", x => x.counter_code);
                });

            migrationBuilder.CreateTable(
                name: "lab_ehealth_exchange_log",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    mode = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    method = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    request_json = table.Column<string>(type: "text", nullable: true),
                    status_code = table.Column<int>(type: "integer", nullable: true),
                    response_json = table.Column<string>(type: "text", nullable: true),
                    duration_ms = table.Column<int>(type: "integer", nullable: false),
                    at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_ehealth_exchange_log", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_method_type",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_method_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_micro_organism",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    latin_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    common_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    kingdom = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    gram_stain = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    morphology = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    is_pathogen = table.Column<bool>(type: "boolean", nullable: false),
                    is_opportunistic = table.Column<bool>(type: "boolean", nullable: false),
                    alert_critical_organism = table.Column<bool>(type: "boolean", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_micro_organism", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_numerator",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    mask = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    current_value = table.Column<long>(type: "bigint", nullable: false),
                    period_key = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    reset_by_period = table.Column<bool>(type: "boolean", nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_numerator", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "lab_order_favorite",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    employee_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    profile_ids_json = table.Column<string>(type: "text", nullable: false),
                    test_ids_json = table.Column<string>(type: "text", nullable: false),
                    display_order = table.Column<int>(type: "integer", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order_favorite", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_panic_call",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    result_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    value = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    doctor_notified_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    department = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    readback_confirmed = table.Column<bool>(type: "boolean", nullable: false),
                    notified_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    notified_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    comments = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_panic_call", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_patient_notification",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    channel = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    payload = table.Column<string>(type: "text", nullable: false),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    sent_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_patient_notification", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_performer",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    kind = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    exchange_mode = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    medlink_provider = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    edrpou = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    license_number = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    address = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    phone = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    email = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    contract_number = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    contract_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    default_tat_hours = table.Column<int>(type: "integer", nullable: false),
                    report_note = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_performer", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_price_list",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    valid_from = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    valid_to = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    is_default = table.Column<bool>(type: "boolean", nullable: false),
                    currency = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_price_list", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_reference_layer",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    method_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    method_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    layer_type = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    priority_order = table.Column<int>(type: "integer", nullable: false),
                    norm_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    gender = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    is_gender = table.Column<bool>(type: "boolean", nullable: false),
                    age_unit = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    age_from = table.Column<double>(type: "double precision", nullable: false),
                    age_to = table.Column<double>(type: "double precision", nullable: false),
                    is_age = table.Column<bool>(type: "boolean", nullable: false),
                    is_menstrual_phase = table.Column<bool>(type: "boolean", nullable: false),
                    menstrual_phase = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    is_pregnancy = table.Column<bool>(type: "boolean", nullable: false),
                    pregnancy_week_from = table.Column<int>(type: "integer", nullable: true),
                    pregnancy_week_to = table.Column<int>(type: "integer", nullable: true),
                    icd10_code = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    norm_low = table.Column<double>(type: "double precision", nullable: true),
                    norm_high = table.Column<double>(type: "double precision", nullable: true),
                    crit_low = table.Column<double>(type: "double precision", nullable: true),
                    crit_high = table.Column<double>(type: "double precision", nullable: true),
                    norm_text = table.Column<string>(type: "text", nullable: true),
                    unit = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    delta_check_max_pct = table.Column<double>(type: "double precision", nullable: true),
                    analyzer_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    dilution = table.Column<double>(type: "double precision", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_reference_layer", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_reflex_rule",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    trigger_test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    condition_operator = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    threshold_value = table.Column<double>(type: "double precision", nullable: true),
                    reflex_test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    auto_approve = table.Column<bool>(type: "boolean", nullable: false),
                    requires_same_sample = table.Column<bool>(type: "boolean", nullable: false),
                    description = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_reflex_rule", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_result_history",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    result_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    version = table.Column<int>(type: "integer", nullable: false),
                    action = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    numeric_value = table.Column<double>(type: "double precision", nullable: true),
                    string_value = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    flag = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    actor_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    comment = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    snapshot_json = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_result_history", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_settings",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    edrpou = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    address = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    email = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    license_number = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    logo_base64 = table.Column<string>(type: "text", nullable: true),
                    director_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    working_hours = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    order_number_mask = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    barcode_prefix = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    report_footer = table.Column<string>(type: "text", nullable: true),
                    panic_phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    cold_chain_min_c = table.Column<double>(type: "double precision", nullable: false),
                    cold_chain_max_c = table.Column<double>(type: "double precision", nullable: false),
                    label_printer_host = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    label_printer_port = table.Column<int>(type: "integer", nullable: false),
                    label_printer_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    report_templates_json = table.Column<string>(type: "text", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_settings", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_tube_type",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    color_code = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    anticoagulant = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    volume_ml = table.Column<double>(type: "double precision", nullable: false),
                    order_of_draw_index = table.Column<int>(type: "integer", nullable: false),
                    inversions_count = table.Column<int>(type: "integer", nullable: false),
                    usable_volume_ml = table.Column<double>(type: "double precision", nullable: true),
                    max_tests_per_tube = table.Column<int>(type: "integer", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_tube_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_unmatched_result",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    barcode = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    value = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    unit = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    flags = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    measured_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    raw_message_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    is_linked = table.Column<bool>(type: "boolean", nullable: false),
                    linked_order_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    received_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_unmatched_result", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "lab_workflow_template",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    stages_json = table.Column<string>(type: "text", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_workflow_template", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "lab_worklist_batch",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    batch_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    created_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    items_json = table.Column<string>(type: "text", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_worklist_batch", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "mis_diagnostic_report",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    reg_number = table.Column<string>(type: "text", nullable: true),
                    reg_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    status = table.Column<int>(type: "integer", nullable: false),
                    patient_card_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    legal_entity_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    division_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    document_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    ehealth_service_catalog_service_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    ehealth_incoming_medical_referral_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    diagnostic_report_category_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    description = table.Column<string>(type: "character varying(3000)", maxLength: 3000, nullable: true),
                    comment = table.Column<string>(type: "text", nullable: true),
                    effective_date_time_start = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    effective_date_time_end = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    issued_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    performer_string = table.Column<string>(type: "text", nullable: true),
                    is_performer_string = table.Column<bool>(type: "boolean", nullable: false),
                    recorded_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    ehealth_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_primary_source = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_mis_diagnostic_report", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "org_organization",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "character varying(400)", maxLength: 400, nullable: true),
                    full_name = table.Column<string>(type: "text", nullable: true),
                    description = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_organization", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "org_organization_service",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: true),
                    duration = table.Column<short>(type: "smallint", nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_organization_service", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_application_row_level_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity_name = table.Column<string>(type: "text", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    is_hierarchical = table.Column<bool>(type: "boolean", nullable: false),
                    hierarchy_field_name = table.Column<string>(type: "text", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_application_row_level_right", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_operation_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    operation_name = table.Column<string>(type: "text", nullable: false),
                    access_level = table.Column<int>(type: "integer", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_operation_right", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_profile",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_profile", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity_name = table.Column<string>(type: "text", nullable: false),
                    entity_access_level = table.Column<int>(type: "integer", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_right", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_role",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_role", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sys_user_default_value",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity_name = table.Column<string>(type: "text", nullable: false),
                    user_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    value_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_user_default_value", x => x.id);
                    table.UniqueConstraint("ak_sys_user_default_value_user_id_entity_name", x => new { x.user_id, x.entity_name });
                });

            migrationBuilder.CreateTable(
                name: "cmn_person",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    last_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    middle_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    birthday = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    gender_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    ipn = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true),
                    no_ipn = table.Column<bool>(type: "boolean", nullable: false),
                    phone = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    email = table.Column<string>(type: "character varying(129)", maxLength: 129, nullable: true),
                    location = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: true),
                    caption = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    description = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    subscribed_to_notifications = table.Column<bool>(type: "boolean", nullable: false),
                    user_id = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_cmn_person", x => x.id);
                    table.ForeignKey(
                        name: "fk_cmn_person_gender_id",
                        column: x => x.gender_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_eucast_breakpoint",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    organism_id = table.Column<int>(type: "integer", nullable: false),
                    antibiotic_id = table.Column<int>(type: "integer", nullable: false),
                    eucast_version = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    mic_susceptible_le = table.Column<double>(type: "double precision", nullable: true),
                    mic_resistant_gt = table.Column<double>(type: "double precision", nullable: true),
                    zone_susceptible_ge = table.Column<double>(type: "double precision", nullable: true),
                    zone_resistant_lt = table.Column<double>(type: "double precision", nullable: true),
                    intrinsic_resistance = table.Column<bool>(type: "boolean", nullable: false),
                    guidance_notes = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_eucast_breakpoint", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_eucast_breakpoint_antibiotic_id",
                        column: x => x.antibiotic_id,
                        principalTable: "lab_antibiotic",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_eucast_breakpoint_organism_id",
                        column: x => x.organism_id,
                        principalTable: "lab_micro_organism",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_send_out",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    number = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    external_batch_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    courier_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    temperature_dispatch = table.Column<double>(type: "double precision", nullable: true),
                    dispatched_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    dispatched_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    accepted_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    completed_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    notes = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_send_out", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_send_out_performer_id",
                        column: x => x.performer_id,
                        principalTable: "lab_performer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_payer",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    kind = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    organization_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    edrpou = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    contract_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    contract_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    contract_valid_to = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    price_list_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    coverage_pct = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    franchise_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    requires_policy = table.Column<bool>(type: "boolean", nullable: false),
                    requires_authorization = table.Column<bool>(type: "boolean", nullable: false),
                    medical_program_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    medlink_contract_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    contact_person = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    phone = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    email = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_payer", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_payer_price_list_id",
                        column: x => x.price_list_id,
                        principalTable: "lab_price_list",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_price_list_item",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    price_list_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_price_list_item", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_price_list_item_price_list_id",
                        column: x => x.price_list_id,
                        principalTable: "lab_price_list",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_price_package",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    price_list_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    member_ids_json = table.Column<string>(type: "text", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_price_package", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_price_package_price_list_id",
                        column: x => x.price_list_id,
                        principalTable: "lab_price_list",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "org_department",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "text", nullable: true),
                    full_name = table.Column<string>(type: "text", nullable: true),
                    category = table.Column<string>(type: "text", nullable: true),
                    description = table.Column<string>(type: "text", nullable: true),
                    location = table.Column<string>(type: "text", nullable: true),
                    zip_code = table.Column<string>(type: "text", nullable: true),
                    department_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    parent_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_department", x => x.id);
                    table.ForeignKey(
                        name: "fk_org_department_department_type_id",
                        column: x => x.department_type_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_org_department_organization_id",
                        column: x => x.organization_id,
                        principalTable: "org_organization",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_test_profile",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    category = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    turnaround_hours = table.Column<int>(type: "integer", nullable: false),
                    fasting_required = table.Column<bool>(type: "boolean", nullable: false),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    default_biomaterial_type_id = table.Column<int>(type: "integer", nullable: true),
                    default_tube_type_id = table.Column<int>(type: "integer", nullable: true),
                    organization_service_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    ehealth_service_catalog_service_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_test_profile", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_test_profile_ehealth_service_catalog_service_id",
                        column: x => x.ehealth_service_catalog_service_id,
                        principalTable: "ehe_service_catalog_service",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_test_profile_organization_service_id",
                        column: x => x.organization_service_id,
                        principalTable: "org_organization_service",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "sys_profile_operation_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    operation_right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_profile_operation_right", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_profile_operation_right_operation_right_id",
                        column: x => x.operation_right_id,
                        principalTable: "sys_operation_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sys_profile_operation_right_profile_id",
                        column: x => x.profile_id,
                        principalTable: "sys_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_row_level_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    main_entity_name = table.Column<string>(type: "text", nullable: false),
                    entity_name = table.Column<string>(type: "text", nullable: false),
                    access_type = table.Column<int>(type: "integer", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_row_level_right", x => x.id);
                    table.UniqueConstraint("ak_sys_row_level_right_profile_id_entity_name_main_entity_name", x => new { x.profile_id, x.entity_name, x.main_entity_name });
                    table.ForeignKey(
                        name: "fk_sys_row_level_right_profile_id",
                        column: x => x.profile_id,
                        principalTable: "sys_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_user_profile",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    user_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_user_profile", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_user_profile_profile_id",
                        column: x => x.profile_id,
                        principalTable: "sys_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_field_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    field_name = table.Column<string>(type: "text", nullable: false),
                    access_level = table.Column<int>(type: "integer", nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_field_right", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_field_right_right_id",
                        column: x => x.right_id,
                        principalTable: "sys_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_profile_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_profile_right", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_profile_right_profile_id",
                        column: x => x.profile_id,
                        principalTable: "sys_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sys_profile_right_right_id",
                        column: x => x.right_id,
                        principalTable: "sys_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_profile_role",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    role_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_profile_role", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_profile_role_profile_id",
                        column: x => x.profile_id,
                        principalTable: "sys_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sys_profile_role_role_id",
                        column: x => x.role_id,
                        principalTable: "sys_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_role_operation_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    role_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    operation_right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_role_operation_right", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_role_operation_right_operation_right_id",
                        column: x => x.operation_right_id,
                        principalTable: "sys_operation_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sys_role_operation_right_role_id",
                        column: x => x.role_id,
                        principalTable: "sys_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_role_right",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    role_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_role_right", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_role_right_right_id",
                        column: x => x.right_id,
                        principalTable: "sys_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sys_role_right_role_id",
                        column: x => x.role_id,
                        principalTable: "sys_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "mis_patient_card",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    person_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    reg_number = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    reg_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    birthday = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    gender_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    document_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_card_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    privacy_request_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    location = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: true),
                    description = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    last_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    first_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_mis_patient_card", x => x.id);
                    table.ForeignKey(
                        name: "fk_mis_patient_card_person_id",
                        column: x => x.person_id,
                        principalTable: "cmn_person",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_invoice",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    number = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    payer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    period_from = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    period_to = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    issued_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    paid_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    charge_ids_json = table.Column<string>(type: "text", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_invoice", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_invoice_payer_id",
                        column: x => x.payer_id,
                        principalTable: "lab_payer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_analyzer",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    analyzer_type_id = table.Column<int>(type: "integer", nullable: false),
                    connector_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    connection_mode = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    tcp_host = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    tcp_port = table.Column<int>(type: "integer", nullable: true),
                    is_tcp_server = table.Column<bool>(type: "boolean", nullable: false),
                    com_port = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    baud_rate = table.Column<int>(type: "integer", nullable: false),
                    parity = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    data_bits = table.Column<int>(type: "integer", nullable: false),
                    stop_bits = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    flow_control = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    file_path = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    file_poll_sec = table.Column<int>(type: "integer", nullable: false),
                    auto_query_orders = table.Column<bool>(type: "boolean", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    is_online = table.Column<bool>(type: "boolean", nullable: false),
                    last_message_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    last_error = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_analyzer", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_analyzer_analyzer_type_id",
                        column: x => x.analyzer_type_id,
                        principalTable: "lab_analyzer_type",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_analyzer_connector_id",
                        column: x => x.connector_id,
                        principalTable: "lab_connector_installation",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_analyzer_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_department_settings",
                columns: table => new
                {
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    lab_kind = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_department_settings", x => x.department_id);
                    table.ForeignKey(
                        name: "fk_lab_department_settings_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_sample_logistics",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    manifest_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    origin_department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    destination_department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    courier_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    courier_phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    dispatched_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    dispatched_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    temperature_dispatch = table.Column<double>(type: "double precision", nullable: true),
                    received_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    received_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    temperature_receipt = table.Column<double>(type: "double precision", nullable: true),
                    is_cold_chain_violated = table.Column<bool>(type: "boolean", nullable: false),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    notes = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_sample_logistics", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_sample_logistics_destination_department_id",
                        column: x => x.destination_department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_sample_logistics_origin_department_id",
                        column: x => x.origin_department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_section",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    section_type = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    journal_mask = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    journal_reset_period = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    secondary_mask = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    auto_release_verified = table.Column<bool>(type: "boolean", nullable: false),
                    workflow_template_code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_section", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_section_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "org_employee",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    person_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    department_section_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    position_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    working_start_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    has_schedule_with_partner = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_employee", x => x.id);
                    table.ForeignKey(
                        name: "fk_org_employee_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_org_employee_person_id",
                        column: x => x.person_id,
                        principalTable: "cmn_person",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_org_employee_position_type_id",
                        column: x => x.position_type_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sys_row_level_security_object",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    row_level_right_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    entity_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sys_row_level_security_object", x => x.id);
                    table.ForeignKey(
                        name: "fk_sys_row_level_security_object_row_level_right_id",
                        column: x => x.row_level_right_id,
                        principalTable: "sys_row_level_right",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ehe_incoming_medical_referral",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    reg_number = table.Column<string>(type: "text", nullable: true),
                    reg_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_card_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    patient_short_name = table.Column<string>(type: "text", nullable: true),
                    service_catalog_service_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    medical_referral_category_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    requester_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    status_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    priority_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    expiration_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    ehealth_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    patient_instruction = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: true),
                    medical_service_program_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    processing_status_in_ehealth_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    take_in_work_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    complete_date_in_ehealth = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    completed_with_item_entity_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    completed_with_item_entity_name = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ehe_incoming_medical_referral", x => x.id);
                    table.ForeignKey(
                        name: "fk_ehe_incoming_medical_referral_patient_card_id",
                        column: x => x.patient_card_id,
                        principalTable: "mis_patient_card",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_ehe_incoming_medical_referral_processing_status_in_ehealth_id",
                        column: x => x.processing_status_in_ehealth_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_ehe_incoming_medical_referral_service_catalog_service_id",
                        column: x => x.service_catalog_service_id,
                        principalTable: "ehe_service_catalog_service",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_ehe_incoming_medical_referral_status_id",
                        column: x => x.status_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ehe_paper_medical_referral",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    reg_number = table.Column<string>(type: "text", nullable: true),
                    reg_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_card_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    requester_employee_name = table.Column<string>(type: "text", nullable: true),
                    requester_legal_entity_name = table.Column<string>(type: "text", nullable: true),
                    requester_legal_entity_edrpou = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    status = table.Column<int>(type: "integer", nullable: false),
                    processed_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    description = table.Column<string>(type: "character varying(3000)", maxLength: 3000, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ehe_paper_medical_referral", x => x.id);
                    table.ForeignKey(
                        name: "fk_ehe_paper_medical_referral_patient_card_id",
                        column: x => x.patient_card_id,
                        principalTable: "mis_patient_card",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "mis_patient_insurance",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_card_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    payer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    policy_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    valid_from = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    valid_to = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    note = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_mis_patient_insurance", x => x.id);
                    table.ForeignKey(
                        name: "fk_mis_patient_insurance_patient_card_id",
                        column: x => x.patient_card_id,
                        principalTable: "mis_patient_card",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_mis_patient_insurance_payer_id",
                        column: x => x.payer_id,
                        principalTable: "lab_payer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_analyzer_lockout",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    qc_result_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    started_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    resolved_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    resolved_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    cause = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    action = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    comment = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    protocol_text = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_analyzer_lockout", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_analyzer_lockout_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_analyzer_message",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    direction = table.Column<string>(type: "character varying(4)", maxLength: 4, nullable: false),
                    protocol = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    raw_text = table.Column<string>(type: "text", nullable: false),
                    parsed_ok = table.Column<bool>(type: "boolean", nullable: false),
                    received_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    results_count = table.Column<int>(type: "integer", nullable: false),
                    error = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_analyzer_message", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_analyzer_message_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_analyzer_parameter_map",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    factor = table.Column<double>(type: "double precision", nullable: false),
                    offset = table.Column<double>(type: "double precision", nullable: false),
                    unit_override = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_analyzer_parameter_map", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_analyzer_parameter_map_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_qc_material",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    level = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    lot_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    manufacturer = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    expiry_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    opened_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    open_stability_days = table.Column<int>(type: "integer", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_qc_material", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_qc_material_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_reagent_lot",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    reagent_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    lot_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    manufacturer = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    tests_initial = table.Column<int>(type: "integer", nullable: false),
                    tests_remaining = table.Column<int>(type: "integer", nullable: false),
                    minimum_tests = table.Column<int>(type: "integer", nullable: false),
                    expiry_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    opened_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    onboard_stability_days = table.Column<int>(type: "integer", nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_reagent_lot", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_reagent_lot_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_test_definition",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    short_name = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    loinc_code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    unit = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    decimal_places = table.Column<int>(type: "integer", nullable: false),
                    result_type = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    dropdown_options_json = table.Column<string>(type: "text", nullable: true),
                    formula = table.Column<string>(type: "text", nullable: true),
                    category = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    biomaterial_type_id = table.Column<int>(type: "integer", nullable: false),
                    tube_type_id = table.Column<int>(type: "integer", nullable: true),
                    method_id = table.Column<int>(type: "integer", nullable: true),
                    method_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    lab_section_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    delta_check_max_pct = table.Column<double>(type: "double precision", nullable: true),
                    delta_check_hours = table.Column<int>(type: "integer", nullable: false),
                    requires_manual_verification = table.Column<bool>(type: "boolean", nullable: false),
                    is_qc_tracked = table.Column<bool>(type: "boolean", nullable: false),
                    requires_separate_tube = table.Column<bool>(type: "boolean", nullable: false),
                    max_tests_per_tube = table.Column<int>(type: "integer", nullable: true),
                    required_volume_ml = table.Column<double>(type: "double precision", nullable: true),
                    tube_compatibility_group = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_test_definition", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_test_definition_biomaterial_type_id",
                        column: x => x.biomaterial_type_id,
                        principalTable: "lab_biomaterial_type",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_test_definition_lab_section_id",
                        column: x => x.lab_section_id,
                        principalTable: "lab_section",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_test_definition_method_id",
                        column: x => x.method_id,
                        principalTable: "lab_method_type",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_test_definition_tube_type_id",
                        column: x => x.tube_type_id,
                        principalTable: "lab_tube_type",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_employee_settings",
                columns: table => new
                {
                    employee_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    lab_role = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    position_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    digital_signature_cert_id = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_employee_settings", x => x.employee_id);
                    table.ForeignKey(
                        name: "fk_lab_employee_settings_employee_id",
                        column: x => x.employee_id,
                        principalTable: "org_employee",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_order",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_number = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    patient_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    doctor_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    order_datetime = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    is_urgent_cito = table.Column<bool>(type: "boolean", nullable: false),
                    ehealth_referral_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    clinical_notes = table.Column<string>(type: "text", nullable: true),
                    is_pregnant = table.Column<bool>(type: "boolean", nullable: false),
                    pregnancy_week = table.Column<int>(type: "integer", nullable: true),
                    menstrual_phase = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    icd10_code = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    total_price = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    created_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    completed_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    released_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    released_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    verify_token = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    cancel_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    repeat_of_order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    referral_type = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    paper_referral_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    referrer_organization_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    referrer_organization_edrpou = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    referrer_doctor_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    referrer_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    payer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    patient_insurance_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    insurance_policy_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    authorization_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    payer_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    patient_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    paid_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    diagnostic_report_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_order_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_diagnostic_report_id",
                        column: x => x.diagnostic_report_id,
                        principalTable: "mis_diagnostic_report",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_doctor_id",
                        column: x => x.doctor_id,
                        principalTable: "org_employee",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_ehealth_referral_id",
                        column: x => x.ehealth_referral_id,
                        principalTable: "ehe_incoming_medical_referral",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_paper_referral_id",
                        column: x => x.paper_referral_id,
                        principalTable: "ehe_paper_medical_referral",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_patient_id",
                        column: x => x.patient_id,
                        principalTable: "mis_patient_card",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_order_payer_id",
                        column: x => x.payer_id,
                        principalTable: "lab_payer",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_qc_result",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    qc_material_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    measured_value = table.Column<double>(type: "double precision", nullable: false),
                    target_mean = table.Column<double>(type: "double precision", nullable: false),
                    target_sd = table.Column<double>(type: "double precision", nullable: false),
                    z_score = table.Column<double>(type: "double precision", nullable: false),
                    violated_rules_json = table.Column<string>(type: "text", nullable: false),
                    is_warning = table.Column<bool>(type: "boolean", nullable: false),
                    is_rejection = table.Column<bool>(type: "boolean", nullable: false),
                    lockout_enforced = table.Column<bool>(type: "boolean", nullable: false),
                    lockout_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    resolved_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    resolved_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    resolution_action = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    run_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    operator_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_qc_result", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_qc_result_qc_material_id",
                        column: x => x.qc_material_id,
                        principalTable: "lab_qc_material",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_qc_target",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    qc_material_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    target_mean = table.Column<double>(type: "double precision", nullable: false),
                    target_sd = table.Column<double>(type: "double precision", nullable: false),
                    unit = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    tea_pct = table.Column<double>(type: "double precision", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_qc_target", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_qc_target_qc_material_id",
                        column: x => x.qc_material_id,
                        principalTable: "lab_qc_material",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_performer_test",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    external_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    external_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    cost = table.Column<decimal>(type: "numeric(18,2)", nullable: true),
                    tat_hours = table.Column<int>(type: "integer", nullable: true),
                    is_default_route = table.Column<bool>(type: "boolean", nullable: false),
                    specimen_requirements = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_performer_test", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_performer_test_performer_id",
                        column: x => x.performer_id,
                        principalTable: "lab_performer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_performer_test_test_id",
                        column: x => x.test_id,
                        principalTable: "lab_test_definition",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_test_profile_item",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    display_order = table.Column<int>(type: "integer", nullable: false),
                    is_required = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_test_profile_item", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_test_profile_item_profile_id",
                        column: x => x.profile_id,
                        principalTable: "lab_test_profile",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_test_profile_item_test_id",
                        column: x => x.test_id,
                        principalTable: "lab_test_definition",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_order_attachment",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    send_out_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    kind = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    file_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    content_type = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    size_bytes = table.Column<long>(type: "bigint", nullable: false),
                    sha256 = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    content = table.Column<byte[]>(type: "bytea", nullable: false),
                    visible_to_patient = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order_attachment", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_order_attachment_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_order_charge",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    package_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false),
                    payer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    payer_kind = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    price_list_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    payer_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    patient_amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    is_not_covered = table.Column<bool>(type: "boolean", nullable: false),
                    is_patient_choice = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order_charge", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_order_charge_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_order_charge_payer_id",
                        column: x => x.payer_id,
                        principalTable: "lab_payer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_order_sample",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    barcode = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    tube_type_id = table.Column<int>(type: "integer", nullable: false),
                    biomaterial_type_id = table.Column<int>(type: "integer", nullable: false),
                    group_numb = table.Column<int>(type: "integer", nullable: false),
                    plan_reasons = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    parent_sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    derivation_type = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    derivation_index = table.Column<int>(type: "integer", nullable: false),
                    container_type = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    lab_section_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    current_stage = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    status = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    collected_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    collected_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    received_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    received_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    volume_ml = table.Column<double>(type: "double precision", nullable: true),
                    is_hemolyzed = table.Column<bool>(type: "boolean", nullable: false),
                    is_lipemic = table.Column<bool>(type: "boolean", nullable: false),
                    is_icteric = table.Column<bool>(type: "boolean", nullable: false),
                    is_clotted = table.Column<bool>(type: "boolean", nullable: false),
                    is_insufficient_volume = table.Column<bool>(type: "boolean", nullable: false),
                    reject_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    collect_checklist_json = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order_sample", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_order_sample_biomaterial_type_id",
                        column: x => x.biomaterial_type_id,
                        principalTable: "lab_biomaterial_type",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_order_sample_lab_section_id",
                        column: x => x.lab_section_id,
                        principalTable: "lab_section",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_sample_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_order_sample_parent_sample_id",
                        column: x => x.parent_sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_lab_order_sample_tube_type_id",
                        column: x => x.tube_type_id,
                        principalTable: "lab_tube_type",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_payment",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    amount = table.Column<decimal>(type: "numeric(18,2)", nullable: false),
                    method = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    receipt_number = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    paid_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    cashier_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    note = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_payment", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_payment_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_archive_cell",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    rack_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    row_num = table.Column<int>(type: "integer", nullable: false),
                    col_num = table.Column<int>(type: "integer", nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    barcode = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    stored_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    stored_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    expiry_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    is_disposed = table.Column<bool>(type: "boolean", nullable: false),
                    disposed_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    disposal_reason = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_archive_cell", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_archive_cell_rack_id",
                        column: x => x.rack_id,
                        principalTable: "lab_archive_rack",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_archive_cell_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_order_test",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    profile_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    test_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    status = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    assigned_analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_reflex = table.Column<bool>(type: "boolean", nullable: false),
                    reflex_from_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    reflex_needs_confirmation = table.Column<bool>(type: "boolean", nullable: false),
                    reject_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    display_order = table.Column<int>(type: "integer", nullable: false),
                    released_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_order_test", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_order_test_assigned_analyzer_id",
                        column: x => x.assigned_analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_test_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_order_test_performer_id",
                        column: x => x.performer_id,
                        principalTable: "lab_performer",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_test_profile_id",
                        column: x => x.profile_id,
                        principalTable: "lab_test_profile",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_test_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_order_test_test_id",
                        column: x => x.test_id,
                        principalTable: "lab_test_definition",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_sample_logistics_item",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    logistics_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    barcode = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_sample_logistics_item", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_sample_logistics_item_logistics_id",
                        column: x => x.logistics_id,
                        principalTable: "lab_sample_logistics",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_sample_logistics_item_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_sample_stage_event",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    stage_code = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    note = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    temperature = table.Column<double>(type: "double precision", nullable: true),
                    instrument_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    data_json = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_sample_stage_event", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_sample_stage_event_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_section_journal_entry",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    lab_section_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    order_test_ids_json = table.Column<string>(type: "text", nullable: false),
                    journal_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sequence_value = table.Column<long>(type: "bigint", nullable: false),
                    day_number = table.Column<int>(type: "integer", nullable: false),
                    secondary_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    period_key = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    registered_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    registered_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_section_journal_entry", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_section_journal_entry_lab_section_id",
                        column: x => x.lab_section_id,
                        principalTable: "lab_section",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_section_journal_entry_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_section_journal_entry_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "lab_culture_order",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    specimen_locus = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    incubation_start = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    incubation_hours_recommended = table.Column<int>(type: "integer", nullable: false),
                    culture_medium = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    growth_detected = table.Column<bool>(type: "boolean", nullable: true),
                    growth_intensity = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    cfu_per_ml = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    preliminary_report = table.Column<string>(type: "text", nullable: true),
                    final_microscopy_description = table.Column<string>(type: "text", nullable: true),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_culture_order", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_culture_order_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_culture_order_order_test_id",
                        column: x => x.order_test_id,
                        principalTable: "lab_order_test",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_send_out_item",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    send_out_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    sample_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    external_order_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    external_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    status = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    due_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    result_received_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    reject_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_send_out_item", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_send_out_item_order_test_id",
                        column: x => x.order_test_id,
                        principalTable: "lab_order_test",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_send_out_item_sample_id",
                        column: x => x.sample_id,
                        principalTable: "lab_order_sample",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_send_out_item_send_out_id",
                        column: x => x.send_out_id,
                        principalTable: "lab_send_out",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_test_result",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    order_test_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    numeric_value = table.Column<double>(type: "double precision", nullable: true),
                    string_value = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    unit = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    norm_low = table.Column<double>(type: "double precision", nullable: true),
                    norm_high = table.Column<double>(type: "double precision", nullable: true),
                    crit_low = table.Column<double>(type: "double precision", nullable: true),
                    crit_high = table.Column<double>(type: "double precision", nullable: true),
                    reference_display = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    flag = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    applied_layer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    applied_layer_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    delta_percent = table.Column<double>(type: "double precision", nullable: true),
                    delta_alert = table.Column<bool>(type: "boolean", nullable: false),
                    previous_value = table.Column<double>(type: "double precision", nullable: true),
                    previous_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    analyzer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    analyzer_flags = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    raw_message_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_auto_verified = table.Column<bool>(type: "boolean", nullable: false),
                    auto_verify_block_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    verified_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    verified_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    verification_comment = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    operator_comment = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                    report_text = table.Column<string>(type: "text", nullable: true),
                    entered_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    entered_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    measured_at = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    version = table.Column<int>(type: "integer", nullable: false),
                    performer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    external_reference = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_test_result", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_test_result_analyzer_id",
                        column: x => x.analyzer_id,
                        principalTable: "lab_analyzer",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "fk_lab_test_result_order_test_id",
                        column: x => x.order_test_id,
                        principalTable: "lab_order_test",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_isolate",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    culture_order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    isolate_number = table.Column<int>(type: "integer", nullable: false),
                    organism_id = table.Column<int>(type: "integer", nullable: false),
                    quantitative_count = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    is_clinically_significant = table.Column<bool>(type: "boolean", nullable: false),
                    colony_morphology = table.Column<string>(type: "text", nullable: true),
                    resistance_phenotypes = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_isolate", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_isolate_culture_order_id",
                        column: x => x.culture_order_id,
                        principalTable: "lab_culture_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_isolate_organism_id",
                        column: x => x.organism_id,
                        principalTable: "lab_micro_organism",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_susceptibility_result",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    isolate_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    antibiotic_id = table.Column<int>(type: "integer", nullable: false),
                    method = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    zone_diameter_mm = table.Column<double>(type: "double precision", nullable: true),
                    mic_value_mg_l = table.Column<double>(type: "double precision", nullable: true),
                    interpretation = table.Column<string>(type: "character varying(4)", maxLength: 4, nullable: false),
                    is_intrinsic_resistance = table.Column<bool>(type: "boolean", nullable: false),
                    breakpoint_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    override_reason = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    overridden_by_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_susceptibility_result", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_susceptibility_result_antibiotic_id",
                        column: x => x.antibiotic_id,
                        principalTable: "lab_antibiotic",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_susceptibility_result_isolate_id",
                        column: x => x.isolate_id,
                        principalTable: "lab_isolate",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_cmn_person_gender_id",
                table: "cmn_person",
                column: "gender_id");

            migrationBuilder.CreateIndex(
                name: "ix_cmn_person_last_name_name",
                table: "cmn_person",
                columns: new[] { "last_name", "name" });

            migrationBuilder.CreateIndex(
                name: "ix_cmn_person_user_id",
                table: "cmn_person",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_patient_card_id",
                table: "ehe_incoming_medical_referral",
                column: "patient_card_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_processing_status_in_ehealth_id",
                table: "ehe_incoming_medical_referral",
                column: "processing_status_in_ehealth_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_reg_number",
                table: "ehe_incoming_medical_referral",
                column: "reg_number");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_service_catalog_service_id",
                table: "ehe_incoming_medical_referral",
                column: "service_catalog_service_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_status_id",
                table: "ehe_incoming_medical_referral",
                column: "status_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_paper_medical_referral_patient_card_id",
                table: "ehe_paper_medical_referral",
                column: "patient_card_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_analyzer_type_id",
                table: "lab_analyzer",
                column: "analyzer_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_code",
                table: "lab_analyzer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_connector_id",
                table: "lab_analyzer",
                column: "connector_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_department_id",
                table: "lab_analyzer",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_lockout_analyzer_id_resolved_at",
                table: "lab_analyzer_lockout",
                columns: new[] { "analyzer_id", "resolved_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_message_analyzer_id",
                table: "lab_analyzer_message",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_parameter_map_analyzer_id",
                table: "lab_analyzer_parameter_map",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_cell_rack_id_row_num_col_num",
                table: "lab_archive_cell",
                columns: new[] { "rack_id", "row_num", "col_num" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_cell_sample_id",
                table: "lab_archive_cell",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_at",
                table: "lab_audit_log",
                column: "at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_entity_entity_id",
                table: "lab_audit_log",
                columns: new[] { "entity", "entity_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_connector_installation_api_key_hash",
                table: "lab_connector_installation",
                column: "api_key_hash");

            migrationBuilder.CreateIndex(
                name: "ix_lab_connector_installation_install_key",
                table: "lab_connector_installation",
                column: "install_key",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_culture_order_order_id",
                table: "lab_culture_order",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_culture_order_order_test_id",
                table: "lab_culture_order",
                column: "order_test_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_ehealth_exchange_log_at",
                table: "lab_ehealth_exchange_log",
                column: "at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_eucast_breakpoint_antibiotic_id",
                table: "lab_eucast_breakpoint",
                column: "antibiotic_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_eucast_breakpoint_organism_id_antibiotic_id_eucast_version",
                table: "lab_eucast_breakpoint",
                columns: new[] { "organism_id", "antibiotic_id", "eucast_version" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_invoice_number",
                table: "lab_invoice",
                column: "number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_invoice_payer_id",
                table: "lab_invoice",
                column: "payer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_isolate_culture_order_id",
                table: "lab_isolate",
                column: "culture_order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_isolate_organism_id",
                table: "lab_isolate",
                column: "organism_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_department_id",
                table: "lab_order",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_diagnostic_report_id",
                table: "lab_order",
                column: "diagnostic_report_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_doctor_id",
                table: "lab_order",
                column: "doctor_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_ehealth_referral_id",
                table: "lab_order",
                column: "ehealth_referral_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_order_datetime",
                table: "lab_order",
                column: "order_datetime");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_order_number",
                table: "lab_order",
                column: "order_number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_paper_referral_id",
                table: "lab_order",
                column: "paper_referral_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_patient_id",
                table: "lab_order",
                column: "patient_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_payer_id",
                table: "lab_order",
                column: "payer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_referral_type",
                table: "lab_order",
                column: "referral_type");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_status",
                table: "lab_order",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_verify_token",
                table: "lab_order",
                column: "verify_token");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_attachment_order_id",
                table: "lab_order_attachment",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_charge_order_id",
                table: "lab_order_charge",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_charge_payer_id",
                table: "lab_order_charge",
                column: "payer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_favorite_employee_id",
                table: "lab_order_favorite",
                column: "employee_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_barcode",
                table: "lab_order_sample",
                column: "barcode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_biomaterial_type_id",
                table: "lab_order_sample",
                column: "biomaterial_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_lab_section_id",
                table: "lab_order_sample",
                column: "lab_section_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_order_id",
                table: "lab_order_sample",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_parent_sample_id",
                table: "lab_order_sample",
                column: "parent_sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_tube_type_id",
                table: "lab_order_sample",
                column: "tube_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_assigned_analyzer_id",
                table: "lab_order_test",
                column: "assigned_analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_order_id",
                table: "lab_order_test",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_performer_id",
                table: "lab_order_test",
                column: "performer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_profile_id",
                table: "lab_order_test",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_released_at",
                table: "lab_order_test",
                column: "released_at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_sample_id",
                table: "lab_order_test",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_status",
                table: "lab_order_test",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_test_code",
                table: "lab_order_test",
                column: "test_code");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_test_id",
                table: "lab_order_test",
                column: "test_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_payer_code",
                table: "lab_payer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_payer_price_list_id",
                table: "lab_payer",
                column: "price_list_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_payment_order_id",
                table: "lab_payment",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_code",
                table: "lab_performer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_test_performer_id_test_id",
                table: "lab_performer_test",
                columns: new[] { "performer_id", "test_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_test_test_id",
                table: "lab_performer_test",
                column: "test_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_code",
                table: "lab_price_list",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_item_price_list_id_profile_id_test_id",
                table: "lab_price_list_item",
                columns: new[] { "price_list_id", "profile_id", "test_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_package_price_list_id",
                table: "lab_price_package",
                column: "price_list_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_material_analyzer_id",
                table: "lab_qc_material",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_result_qc_material_id_test_code_run_at",
                table: "lab_qc_result",
                columns: new[] { "qc_material_id", "test_code", "run_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_target_qc_material_id",
                table: "lab_qc_target",
                column: "qc_material_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_reagent_lot_analyzer_id",
                table: "lab_reagent_lot",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_reference_layer_test_code_method_code_priority_order",
                table: "lab_reference_layer",
                columns: new[] { "test_code", "method_code", "priority_order" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_destination_department_id",
                table: "lab_sample_logistics",
                column: "destination_department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_origin_department_id",
                table: "lab_sample_logistics",
                column: "origin_department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_item_logistics_id",
                table: "lab_sample_logistics_item",
                column: "logistics_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_item_sample_id",
                table: "lab_sample_logistics_item",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_stage_event_sample_id_at",
                table: "lab_sample_stage_event",
                columns: new[] { "sample_id", "at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_code",
                table: "lab_section",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_department_id",
                table: "lab_section",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_lab_section_id_registered_at",
                table: "lab_section_journal_entry",
                columns: new[] { "lab_section_id", "registered_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_order_id_lab_section_id_sample_id",
                table: "lab_section_journal_entry",
                columns: new[] { "order_id", "lab_section_id", "sample_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_sample_id",
                table: "lab_section_journal_entry",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_number",
                table: "lab_send_out",
                column: "number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_performer_id",
                table: "lab_send_out",
                column: "performer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_item_order_test_id",
                table: "lab_send_out_item",
                column: "order_test_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_item_sample_id",
                table: "lab_send_out_item",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_item_send_out_id",
                table: "lab_send_out_item",
                column: "send_out_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_susceptibility_result_antibiotic_id",
                table: "lab_susceptibility_result",
                column: "antibiotic_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_susceptibility_result_isolate_id",
                table: "lab_susceptibility_result",
                column: "isolate_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_biomaterial_type_id",
                table: "lab_test_definition",
                column: "biomaterial_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_code",
                table: "lab_test_definition",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_lab_section_id",
                table: "lab_test_definition",
                column: "lab_section_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_method_id",
                table: "lab_test_definition",
                column: "method_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_tube_type_id",
                table: "lab_test_definition",
                column: "tube_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_code",
                table: "lab_test_profile",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_ehealth_service_catalog_service_id",
                table: "lab_test_profile",
                column: "ehealth_service_catalog_service_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_organization_service_id",
                table: "lab_test_profile",
                column: "organization_service_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_item_profile_id",
                table: "lab_test_profile_item",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_item_test_id",
                table: "lab_test_profile_item",
                column: "test_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_analyzer_id",
                table: "lab_test_result",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_entered_at",
                table: "lab_test_result",
                column: "entered_at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_flag",
                table: "lab_test_result",
                column: "flag");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_order_test_id",
                table: "lab_test_result",
                column: "order_test_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_caption",
                table: "mis_patient_card",
                column: "caption");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_person_id",
                table: "mis_patient_card",
                column: "person_id");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_insurance_patient_card_id",
                table: "mis_patient_insurance",
                column: "patient_card_id");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_insurance_payer_id",
                table: "mis_patient_insurance",
                column: "payer_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_department_department_type_id",
                table: "org_department",
                column: "department_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_department_organization_id",
                table: "org_department",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_employee_department_id",
                table: "org_employee",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_employee_person_id",
                table: "org_employee",
                column: "person_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_employee_position_type_id",
                table: "org_employee",
                column: "position_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_field_right_right_id",
                table: "sys_field_right",
                column: "right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_operation_right_operation_right_id",
                table: "sys_profile_operation_right",
                column: "operation_right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_operation_right_profile_id",
                table: "sys_profile_operation_right",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_right_profile_id",
                table: "sys_profile_right",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_right_right_id",
                table: "sys_profile_right",
                column: "right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_role_profile_id",
                table: "sys_profile_role",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_profile_role_role_id",
                table: "sys_profile_role",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_role_operation_right_operation_right_id",
                table: "sys_role_operation_right",
                column: "operation_right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_role_operation_right_role_id",
                table: "sys_role_operation_right",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_role_right_right_id",
                table: "sys_role_right",
                column: "right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_role_right_role_id",
                table: "sys_role_right",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_row_level_security_object_row_level_right_id",
                table: "sys_row_level_security_object",
                column: "row_level_right_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_user_profile_profile_id",
                table: "sys_user_profile",
                column: "profile_id");

            migrationBuilder.CreateIndex(
                name: "ix_sys_user_profile_user_id",
                table: "sys_user_profile",
                column: "user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "lab_analyzer_lockout");

            migrationBuilder.DropTable(
                name: "lab_analyzer_message");

            migrationBuilder.DropTable(
                name: "lab_analyzer_parameter_map");

            migrationBuilder.DropTable(
                name: "lab_archive_cell");

            migrationBuilder.DropTable(
                name: "lab_audit_log");

            migrationBuilder.DropTable(
                name: "lab_connector_command");

            migrationBuilder.DropTable(
                name: "lab_connector_log");

            migrationBuilder.DropTable(
                name: "lab_counter");

            migrationBuilder.DropTable(
                name: "lab_department_settings");

            migrationBuilder.DropTable(
                name: "lab_ehealth_exchange_log");

            migrationBuilder.DropTable(
                name: "lab_employee_settings");

            migrationBuilder.DropTable(
                name: "lab_eucast_breakpoint");

            migrationBuilder.DropTable(
                name: "lab_invoice");

            migrationBuilder.DropTable(
                name: "lab_numerator");

            migrationBuilder.DropTable(
                name: "lab_order_attachment");

            migrationBuilder.DropTable(
                name: "lab_order_charge");

            migrationBuilder.DropTable(
                name: "lab_order_favorite");

            migrationBuilder.DropTable(
                name: "lab_panic_call");

            migrationBuilder.DropTable(
                name: "lab_patient_notification");

            migrationBuilder.DropTable(
                name: "lab_payment");

            migrationBuilder.DropTable(
                name: "lab_performer_test");

            migrationBuilder.DropTable(
                name: "lab_price_list_item");

            migrationBuilder.DropTable(
                name: "lab_price_package");

            migrationBuilder.DropTable(
                name: "lab_qc_result");

            migrationBuilder.DropTable(
                name: "lab_qc_target");

            migrationBuilder.DropTable(
                name: "lab_reagent_lot");

            migrationBuilder.DropTable(
                name: "lab_reference_layer");

            migrationBuilder.DropTable(
                name: "lab_reflex_rule");

            migrationBuilder.DropTable(
                name: "lab_result_history");

            migrationBuilder.DropTable(
                name: "lab_sample_logistics_item");

            migrationBuilder.DropTable(
                name: "lab_sample_stage_event");

            migrationBuilder.DropTable(
                name: "lab_section_journal_entry");

            migrationBuilder.DropTable(
                name: "lab_send_out_item");

            migrationBuilder.DropTable(
                name: "lab_settings");

            migrationBuilder.DropTable(
                name: "lab_susceptibility_result");

            migrationBuilder.DropTable(
                name: "lab_test_profile_item");

            migrationBuilder.DropTable(
                name: "lab_test_result");

            migrationBuilder.DropTable(
                name: "lab_unmatched_result");

            migrationBuilder.DropTable(
                name: "lab_workflow_template");

            migrationBuilder.DropTable(
                name: "lab_worklist_batch");

            migrationBuilder.DropTable(
                name: "mis_patient_insurance");

            migrationBuilder.DropTable(
                name: "sys_application_row_level_right");

            migrationBuilder.DropTable(
                name: "sys_field_right");

            migrationBuilder.DropTable(
                name: "sys_profile_operation_right");

            migrationBuilder.DropTable(
                name: "sys_profile_right");

            migrationBuilder.DropTable(
                name: "sys_profile_role");

            migrationBuilder.DropTable(
                name: "sys_role_operation_right");

            migrationBuilder.DropTable(
                name: "sys_role_right");

            migrationBuilder.DropTable(
                name: "sys_row_level_security_object");

            migrationBuilder.DropTable(
                name: "sys_user_default_value");

            migrationBuilder.DropTable(
                name: "sys_user_profile");

            migrationBuilder.DropTable(
                name: "lab_archive_rack");

            migrationBuilder.DropTable(
                name: "lab_qc_material");

            migrationBuilder.DropTable(
                name: "lab_sample_logistics");

            migrationBuilder.DropTable(
                name: "lab_send_out");

            migrationBuilder.DropTable(
                name: "lab_antibiotic");

            migrationBuilder.DropTable(
                name: "lab_isolate");

            migrationBuilder.DropTable(
                name: "sys_operation_right");

            migrationBuilder.DropTable(
                name: "sys_right");

            migrationBuilder.DropTable(
                name: "sys_role");

            migrationBuilder.DropTable(
                name: "sys_row_level_right");

            migrationBuilder.DropTable(
                name: "lab_culture_order");

            migrationBuilder.DropTable(
                name: "lab_micro_organism");

            migrationBuilder.DropTable(
                name: "sys_profile");

            migrationBuilder.DropTable(
                name: "lab_order_test");

            migrationBuilder.DropTable(
                name: "lab_analyzer");

            migrationBuilder.DropTable(
                name: "lab_performer");

            migrationBuilder.DropTable(
                name: "lab_test_profile");

            migrationBuilder.DropTable(
                name: "lab_order_sample");

            migrationBuilder.DropTable(
                name: "lab_test_definition");

            migrationBuilder.DropTable(
                name: "lab_analyzer_type");

            migrationBuilder.DropTable(
                name: "lab_connector_installation");

            migrationBuilder.DropTable(
                name: "org_organization_service");

            migrationBuilder.DropTable(
                name: "lab_order");

            migrationBuilder.DropTable(
                name: "lab_biomaterial_type");

            migrationBuilder.DropTable(
                name: "lab_section");

            migrationBuilder.DropTable(
                name: "lab_method_type");

            migrationBuilder.DropTable(
                name: "lab_tube_type");

            migrationBuilder.DropTable(
                name: "mis_diagnostic_report");

            migrationBuilder.DropTable(
                name: "org_employee");

            migrationBuilder.DropTable(
                name: "ehe_incoming_medical_referral");

            migrationBuilder.DropTable(
                name: "ehe_paper_medical_referral");

            migrationBuilder.DropTable(
                name: "lab_payer");

            migrationBuilder.DropTable(
                name: "org_department");

            migrationBuilder.DropTable(
                name: "ehe_service_catalog_service");

            migrationBuilder.DropTable(
                name: "mis_patient_card");

            migrationBuilder.DropTable(
                name: "lab_price_list");

            migrationBuilder.DropTable(
                name: "org_organization");

            migrationBuilder.DropTable(
                name: "cmn_person");

            migrationBuilder.DropTable(
                name: "cmn_enum_record");
        }
    }
}
