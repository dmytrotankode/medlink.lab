﻿using System;
using MedLink.LIS.Api.Data;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MedLink.LIS.Api.Migrations
{
    /// <inheritdoc />
    public partial class _0002_tenancy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_mis_patient_card_caption",
                table: "mis_patient_card");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_workflow_template",
                table: "lab_workflow_template");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_result_entered_at",
                table: "lab_test_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_result_flag",
                table: "lab_test_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_profile_code",
                table: "lab_test_profile");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_definition_code",
                table: "lab_test_definition");

            migrationBuilder.DropIndex(
                name: "ix_lab_send_out_number",
                table: "lab_send_out");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_lab_section_id_registered_at",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_order_id_lab_section_id_sample_id",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_code",
                table: "lab_section");

            migrationBuilder.DropIndex(
                name: "ix_lab_sample_stage_event_sample_id_at",
                table: "lab_sample_stage_event");

            migrationBuilder.DropIndex(
                name: "ix_lab_reference_layer_test_code_method_code_priority_order",
                table: "lab_reference_layer");

            migrationBuilder.DropIndex(
                name: "ix_lab_qc_result_qc_material_id_test_code_run_at",
                table: "lab_qc_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_list_item_price_list_id_profile_id_test_id",
                table: "lab_price_list_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_list_code",
                table: "lab_price_list");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_test_performer_id_test_id",
                table: "lab_performer_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_code",
                table: "lab_performer");

            migrationBuilder.DropIndex(
                name: "ix_lab_payer_code",
                table: "lab_payer");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_released_at",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_status",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_test_code",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_sample_barcode",
                table: "lab_order_sample");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_favorite_employee_id",
                table: "lab_order_favorite");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_order_datetime",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_order_number",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_referral_type",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_status",
                table: "lab_order");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_numerator",
                table: "lab_numerator");

            migrationBuilder.DropIndex(
                name: "ix_lab_invoice_number",
                table: "lab_invoice");

            migrationBuilder.DropIndex(
                name: "ix_lab_eucast_breakpoint_organism_id_antibiotic_id_eucast_version",
                table: "lab_eucast_breakpoint");

            migrationBuilder.DropIndex(
                name: "ix_lab_ehealth_exchange_log_at",
                table: "lab_ehealth_exchange_log");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_counter",
                table: "lab_counter");

            migrationBuilder.DropIndex(
                name: "ix_lab_audit_log_at",
                table: "lab_audit_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_audit_log_entity_entity_id",
                table: "lab_audit_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_archive_cell_rack_id_row_num_col_num",
                table: "lab_archive_cell");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_lockout_analyzer_id_resolved_at",
                table: "lab_analyzer_lockout");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_code",
                table: "lab_analyzer");

            migrationBuilder.DropIndex(
                name: "ix_ehe_incoming_medical_referral_reg_number",
                table: "ehe_incoming_medical_referral");

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "mis_patient_insurance",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_worklist_batch",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_workflow_template",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_unmatched_result",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_tube_type",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_test_result",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_test_profile_item",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_test_profile",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_test_definition",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_susceptibility_result",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_settings",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_send_out_item",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_send_out",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_section_journal_entry",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_section",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_sample_stage_event",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_sample_logistics_item",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_sample_logistics",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_result_history",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_reflex_rule",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_reference_layer",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_reagent_lot",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_qc_target",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_qc_result",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_qc_material",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_price_package",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_price_list_item",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_price_list",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_performer_test",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_performer",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_payment",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_payer",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_patient_notification",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_panic_call",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_order_test",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_order_sample",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_order_favorite",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_order_charge",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_order_attachment",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_numerator",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_micro_organism",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_method_type",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_isolate",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_invoice",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_eucast_breakpoint",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_employee_settings",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_ehealth_exchange_log",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_department_settings",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_culture_order",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_counter",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_connector_log",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_connector_installation",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_connector_command",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_biomaterial_type",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_audit_log",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_archive_rack",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_archive_cell",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_antibiotic",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_analyzer_type",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_analyzer_parameter_map",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_analyzer_message",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_analyzer_lockout",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "organization_id",
                table: "lab_analyzer",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true);

            Backfill(migrationBuilder);

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_workflow_template",
                table: "lab_workflow_template",
                columns: new[] { "organization_id", "code" });

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_numerator",
                table: "lab_numerator",
                columns: new[] { "organization_id", "code" });

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_counter",
                table: "lab_counter",
                columns: new[] { "organization_id", "counter_code" });

            migrationBuilder.CreateTable(
                name: "lab_employee_department",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    employee_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_employee_department", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_employee_department_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_employee_department_employee_id",
                        column: x => x.employee_id,
                        principalTable: "org_employee",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_org_organization_service_organization_id",
                table: "org_organization_service",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_employee_organization_id",
                table: "org_employee",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_insurance_organization_id",
                table: "mis_patient_insurance",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_organization_id_caption",
                table: "mis_patient_card",
                columns: new[] { "organization_id", "caption" });

            migrationBuilder.CreateIndex(
                name: "ix_mis_diagnostic_report_organization_id",
                table: "mis_diagnostic_report",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_worklist_batch_organization_id",
                table: "lab_worklist_batch",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_workflow_template_organization_id",
                table: "lab_workflow_template",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_unmatched_result_organization_id",
                table: "lab_unmatched_result",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_tube_type_organization_id",
                table: "lab_tube_type",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_organization_id_entered_at",
                table: "lab_test_result",
                columns: new[] { "organization_id", "entered_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_organization_id_flag",
                table: "lab_test_result",
                columns: new[] { "organization_id", "flag" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_item_organization_id",
                table: "lab_test_profile_item",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_organization_id_code",
                table: "lab_test_profile",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_organization_id_code",
                table: "lab_test_definition",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_susceptibility_result_organization_id",
                table: "lab_susceptibility_result",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_settings_organization_id",
                table: "lab_settings",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_item_organization_id",
                table: "lab_send_out_item",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_organization_id_number",
                table: "lab_send_out",
                columns: new[] { "organization_id", "number" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_lab_section_id",
                table: "lab_section_journal_entry",
                column: "lab_section_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_order_id",
                table: "lab_section_journal_entry",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_organization_id_lab_section_id_registered_at",
                table: "lab_section_journal_entry",
                columns: new[] { "organization_id", "lab_section_id", "registered_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_organization_id_order_id_lab_section_id_sample_id",
                table: "lab_section_journal_entry",
                columns: new[] { "organization_id", "order_id", "lab_section_id", "sample_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_organization_id_code",
                table: "lab_section",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_stage_event_organization_id_sample_id_at",
                table: "lab_sample_stage_event",
                columns: new[] { "organization_id", "sample_id", "at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_stage_event_sample_id",
                table: "lab_sample_stage_event",
                column: "sample_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_item_organization_id",
                table: "lab_sample_logistics_item",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_logistics_organization_id",
                table: "lab_sample_logistics",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_result_history_organization_id",
                table: "lab_result_history",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_reflex_rule_organization_id",
                table: "lab_reflex_rule",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_reference_layer_organization_id_test_code_method_code_priority_order",
                table: "lab_reference_layer",
                columns: new[] { "organization_id", "test_code", "method_code", "priority_order" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_reagent_lot_organization_id",
                table: "lab_reagent_lot",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_target_organization_id",
                table: "lab_qc_target",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_result_organization_id_qc_material_id_test_code_run_at",
                table: "lab_qc_result",
                columns: new[] { "organization_id", "qc_material_id", "test_code", "run_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_result_qc_material_id",
                table: "lab_qc_result",
                column: "qc_material_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_material_organization_id",
                table: "lab_qc_material",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_package_organization_id",
                table: "lab_price_package",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_item_organization_id_price_list_id_profile_id_test_id",
                table: "lab_price_list_item",
                columns: new[] { "organization_id", "price_list_id", "profile_id", "test_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_item_price_list_id",
                table: "lab_price_list_item",
                column: "price_list_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_organization_id_code",
                table: "lab_price_list",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_test_organization_id_performer_id_test_id",
                table: "lab_performer_test",
                columns: new[] { "organization_id", "performer_id", "test_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_test_performer_id",
                table: "lab_performer_test",
                column: "performer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_organization_id_code",
                table: "lab_performer",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_payment_organization_id",
                table: "lab_payment",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_payer_organization_id_code",
                table: "lab_payer",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_patient_notification_organization_id",
                table: "lab_patient_notification",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_panic_call_organization_id",
                table: "lab_panic_call",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_organization_id_released_at",
                table: "lab_order_test",
                columns: new[] { "organization_id", "released_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_organization_id_status",
                table: "lab_order_test",
                columns: new[] { "organization_id", "status" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_organization_id_test_code",
                table: "lab_order_test",
                columns: new[] { "organization_id", "test_code" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_organization_id_barcode",
                table: "lab_order_sample",
                columns: new[] { "organization_id", "barcode" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_favorite_organization_id_employee_id",
                table: "lab_order_favorite",
                columns: new[] { "organization_id", "employee_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_charge_organization_id",
                table: "lab_order_charge",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_attachment_organization_id",
                table: "lab_order_attachment",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_organization_id_order_datetime",
                table: "lab_order",
                columns: new[] { "organization_id", "order_datetime" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_organization_id_order_number",
                table: "lab_order",
                columns: new[] { "organization_id", "order_number" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_organization_id_referral_type",
                table: "lab_order",
                columns: new[] { "organization_id", "referral_type" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_organization_id_status",
                table: "lab_order",
                columns: new[] { "organization_id", "status" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_numerator_organization_id",
                table: "lab_numerator",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_micro_organism_organization_id",
                table: "lab_micro_organism",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_method_type_organization_id",
                table: "lab_method_type",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_isolate_organization_id",
                table: "lab_isolate",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_invoice_organization_id_number",
                table: "lab_invoice",
                columns: new[] { "organization_id", "number" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_eucast_breakpoint_organism_id",
                table: "lab_eucast_breakpoint",
                column: "organism_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_eucast_breakpoint_organization_id_organism_id_antibiotic_id_eucast_version",
                table: "lab_eucast_breakpoint",
                columns: new[] { "organization_id", "organism_id", "antibiotic_id", "eucast_version" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_settings_organization_id",
                table: "lab_employee_settings",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_ehealth_exchange_log_organization_id_at",
                table: "lab_ehealth_exchange_log",
                columns: new[] { "organization_id", "at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_department_settings_organization_id",
                table: "lab_department_settings",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_culture_order_organization_id",
                table: "lab_culture_order",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_counter_organization_id",
                table: "lab_counter",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_connector_log_organization_id",
                table: "lab_connector_log",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_connector_installation_organization_id",
                table: "lab_connector_installation",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_connector_command_organization_id",
                table: "lab_connector_command",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_biomaterial_type_organization_id",
                table: "lab_biomaterial_type",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_organization_id_at",
                table: "lab_audit_log",
                columns: new[] { "organization_id", "at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_organization_id_entity_entity_id",
                table: "lab_audit_log",
                columns: new[] { "organization_id", "entity", "entity_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_rack_organization_id",
                table: "lab_archive_rack",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_cell_organization_id_rack_id_row_num_col_num",
                table: "lab_archive_cell",
                columns: new[] { "organization_id", "rack_id", "row_num", "col_num" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_cell_rack_id",
                table: "lab_archive_cell",
                column: "rack_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_antibiotic_organization_id",
                table: "lab_antibiotic",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_type_organization_id",
                table: "lab_analyzer_type",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_parameter_map_organization_id",
                table: "lab_analyzer_parameter_map",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_message_organization_id",
                table: "lab_analyzer_message",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_lockout_analyzer_id",
                table: "lab_analyzer_lockout",
                column: "analyzer_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_lockout_organization_id_analyzer_id_resolved_at",
                table: "lab_analyzer_lockout",
                columns: new[] { "organization_id", "analyzer_id", "resolved_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_organization_id_code",
                table: "lab_analyzer",
                columns: new[] { "organization_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_ehe_paper_medical_referral_organization_id",
                table: "ehe_paper_medical_referral",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_organization_id_reg_number",
                table: "ehe_incoming_medical_referral",
                columns: new[] { "organization_id", "reg_number" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_department_id",
                table: "lab_employee_department",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_employee_id",
                table: "lab_employee_department",
                column: "employee_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_organization_id_employee_id_department_id",
                table: "lab_employee_department",
                columns: new[] { "organization_id", "employee_id", "department_id" },
                unique: true);

            CreateRoles(migrationBuilder);
            EnableRowLevelSecurity(migrationBuilder);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            DisableRowLevelSecurity(migrationBuilder);
            DropRoleGrants(migrationBuilder);

            migrationBuilder.DropTable(
                name: "lab_employee_department");

            migrationBuilder.DropIndex(
                name: "ix_org_organization_service_organization_id",
                table: "org_organization_service");

            migrationBuilder.DropIndex(
                name: "ix_org_employee_organization_id",
                table: "org_employee");

            migrationBuilder.DropIndex(
                name: "ix_mis_patient_insurance_organization_id",
                table: "mis_patient_insurance");

            migrationBuilder.DropIndex(
                name: "ix_mis_patient_card_organization_id_caption",
                table: "mis_patient_card");

            migrationBuilder.DropIndex(
                name: "ix_mis_diagnostic_report_organization_id",
                table: "mis_diagnostic_report");

            migrationBuilder.DropIndex(
                name: "ix_lab_worklist_batch_organization_id",
                table: "lab_worklist_batch");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_workflow_template",
                table: "lab_workflow_template");

            migrationBuilder.DropIndex(
                name: "ix_lab_workflow_template_organization_id",
                table: "lab_workflow_template");

            migrationBuilder.DropIndex(
                name: "ix_lab_unmatched_result_organization_id",
                table: "lab_unmatched_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_tube_type_organization_id",
                table: "lab_tube_type");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_result_organization_id_entered_at",
                table: "lab_test_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_result_organization_id_flag",
                table: "lab_test_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_profile_item_organization_id",
                table: "lab_test_profile_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_profile_organization_id_code",
                table: "lab_test_profile");

            migrationBuilder.DropIndex(
                name: "ix_lab_test_definition_organization_id_code",
                table: "lab_test_definition");

            migrationBuilder.DropIndex(
                name: "ix_lab_susceptibility_result_organization_id",
                table: "lab_susceptibility_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_settings_organization_id",
                table: "lab_settings");

            migrationBuilder.DropIndex(
                name: "ix_lab_send_out_item_organization_id",
                table: "lab_send_out_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_send_out_organization_id_number",
                table: "lab_send_out");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_lab_section_id",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_order_id",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_organization_id_lab_section_id_registered_at",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_journal_entry_organization_id_order_id_lab_section_id_sample_id",
                table: "lab_section_journal_entry");

            migrationBuilder.DropIndex(
                name: "ix_lab_section_organization_id_code",
                table: "lab_section");

            migrationBuilder.DropIndex(
                name: "ix_lab_sample_stage_event_organization_id_sample_id_at",
                table: "lab_sample_stage_event");

            migrationBuilder.DropIndex(
                name: "ix_lab_sample_stage_event_sample_id",
                table: "lab_sample_stage_event");

            migrationBuilder.DropIndex(
                name: "ix_lab_sample_logistics_item_organization_id",
                table: "lab_sample_logistics_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_sample_logistics_organization_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropIndex(
                name: "ix_lab_result_history_organization_id",
                table: "lab_result_history");

            migrationBuilder.DropIndex(
                name: "ix_lab_reflex_rule_organization_id",
                table: "lab_reflex_rule");

            migrationBuilder.DropIndex(
                name: "ix_lab_reference_layer_organization_id_test_code_method_code_priority_order",
                table: "lab_reference_layer");

            migrationBuilder.DropIndex(
                name: "ix_lab_reagent_lot_organization_id",
                table: "lab_reagent_lot");

            migrationBuilder.DropIndex(
                name: "ix_lab_qc_target_organization_id",
                table: "lab_qc_target");

            migrationBuilder.DropIndex(
                name: "ix_lab_qc_result_organization_id_qc_material_id_test_code_run_at",
                table: "lab_qc_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_qc_result_qc_material_id",
                table: "lab_qc_result");

            migrationBuilder.DropIndex(
                name: "ix_lab_qc_material_organization_id",
                table: "lab_qc_material");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_package_organization_id",
                table: "lab_price_package");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_list_item_organization_id_price_list_id_profile_id_test_id",
                table: "lab_price_list_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_list_item_price_list_id",
                table: "lab_price_list_item");

            migrationBuilder.DropIndex(
                name: "ix_lab_price_list_organization_id_code",
                table: "lab_price_list");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_test_organization_id_performer_id_test_id",
                table: "lab_performer_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_test_performer_id",
                table: "lab_performer_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_organization_id_code",
                table: "lab_performer");

            migrationBuilder.DropIndex(
                name: "ix_lab_payment_organization_id",
                table: "lab_payment");

            migrationBuilder.DropIndex(
                name: "ix_lab_payer_organization_id_code",
                table: "lab_payer");

            migrationBuilder.DropIndex(
                name: "ix_lab_patient_notification_organization_id",
                table: "lab_patient_notification");

            migrationBuilder.DropIndex(
                name: "ix_lab_panic_call_organization_id",
                table: "lab_panic_call");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_organization_id_released_at",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_organization_id_status",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_test_organization_id_test_code",
                table: "lab_order_test");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_sample_organization_id_barcode",
                table: "lab_order_sample");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_favorite_organization_id_employee_id",
                table: "lab_order_favorite");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_charge_organization_id",
                table: "lab_order_charge");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_attachment_organization_id",
                table: "lab_order_attachment");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_organization_id_order_datetime",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_organization_id_order_number",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_organization_id_referral_type",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_organization_id_status",
                table: "lab_order");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_numerator",
                table: "lab_numerator");

            migrationBuilder.DropIndex(
                name: "ix_lab_numerator_organization_id",
                table: "lab_numerator");

            migrationBuilder.DropIndex(
                name: "ix_lab_micro_organism_organization_id",
                table: "lab_micro_organism");

            migrationBuilder.DropIndex(
                name: "ix_lab_method_type_organization_id",
                table: "lab_method_type");

            migrationBuilder.DropIndex(
                name: "ix_lab_isolate_organization_id",
                table: "lab_isolate");

            migrationBuilder.DropIndex(
                name: "ix_lab_invoice_organization_id_number",
                table: "lab_invoice");

            migrationBuilder.DropIndex(
                name: "ix_lab_eucast_breakpoint_organism_id",
                table: "lab_eucast_breakpoint");

            migrationBuilder.DropIndex(
                name: "ix_lab_eucast_breakpoint_organization_id_organism_id_antibiotic_id_eucast_version",
                table: "lab_eucast_breakpoint");

            migrationBuilder.DropIndex(
                name: "ix_lab_employee_settings_organization_id",
                table: "lab_employee_settings");

            migrationBuilder.DropIndex(
                name: "ix_lab_ehealth_exchange_log_organization_id_at",
                table: "lab_ehealth_exchange_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_department_settings_organization_id",
                table: "lab_department_settings");

            migrationBuilder.DropIndex(
                name: "ix_lab_culture_order_organization_id",
                table: "lab_culture_order");

            migrationBuilder.DropPrimaryKey(
                name: "pk_lab_counter",
                table: "lab_counter");

            migrationBuilder.DropIndex(
                name: "ix_lab_counter_organization_id",
                table: "lab_counter");

            migrationBuilder.DropIndex(
                name: "ix_lab_connector_log_organization_id",
                table: "lab_connector_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_connector_installation_organization_id",
                table: "lab_connector_installation");

            migrationBuilder.DropIndex(
                name: "ix_lab_connector_command_organization_id",
                table: "lab_connector_command");

            migrationBuilder.DropIndex(
                name: "ix_lab_biomaterial_type_organization_id",
                table: "lab_biomaterial_type");

            migrationBuilder.DropIndex(
                name: "ix_lab_audit_log_organization_id_at",
                table: "lab_audit_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_audit_log_organization_id_entity_entity_id",
                table: "lab_audit_log");

            migrationBuilder.DropIndex(
                name: "ix_lab_archive_rack_organization_id",
                table: "lab_archive_rack");

            migrationBuilder.DropIndex(
                name: "ix_lab_archive_cell_organization_id_rack_id_row_num_col_num",
                table: "lab_archive_cell");

            migrationBuilder.DropIndex(
                name: "ix_lab_archive_cell_rack_id",
                table: "lab_archive_cell");

            migrationBuilder.DropIndex(
                name: "ix_lab_antibiotic_organization_id",
                table: "lab_antibiotic");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_type_organization_id",
                table: "lab_analyzer_type");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_parameter_map_organization_id",
                table: "lab_analyzer_parameter_map");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_message_organization_id",
                table: "lab_analyzer_message");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_lockout_analyzer_id",
                table: "lab_analyzer_lockout");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_lockout_organization_id_analyzer_id_resolved_at",
                table: "lab_analyzer_lockout");

            migrationBuilder.DropIndex(
                name: "ix_lab_analyzer_organization_id_code",
                table: "lab_analyzer");

            migrationBuilder.DropIndex(
                name: "ix_ehe_paper_medical_referral_organization_id",
                table: "ehe_paper_medical_referral");

            migrationBuilder.DropIndex(
                name: "ix_ehe_incoming_medical_referral_organization_id_reg_number",
                table: "ehe_incoming_medical_referral");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "mis_patient_insurance");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_worklist_batch");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_workflow_template");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_unmatched_result");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_tube_type");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_test_result");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_test_profile_item");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_test_profile");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_test_definition");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_susceptibility_result");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_send_out_item");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_send_out");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_section_journal_entry");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_section");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_sample_stage_event");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_sample_logistics_item");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_result_history");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_reflex_rule");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_reference_layer");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_reagent_lot");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_qc_target");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_qc_result");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_qc_material");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_price_package");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_price_list_item");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_price_list");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_performer_test");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_performer");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_payment");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_payer");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_patient_notification");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_panic_call");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_order_test");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_order_sample");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_order_favorite");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_order_charge");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_order_attachment");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_numerator");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_micro_organism");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_method_type");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_isolate");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_invoice");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_eucast_breakpoint");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_employee_settings");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_ehealth_exchange_log");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_department_settings");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_culture_order");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_counter");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_connector_log");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_connector_installation");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_connector_command");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_biomaterial_type");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_audit_log");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_archive_rack");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_archive_cell");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_antibiotic");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_analyzer_type");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_analyzer_parameter_map");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_analyzer_message");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_analyzer_lockout");

            migrationBuilder.DropColumn(
                name: "organization_id",
                table: "lab_analyzer");

            migrationBuilder.AlterColumn<string>(
                name: "organization_id",
                table: "lab_order",
                type: "character varying(64)",
                maxLength: 64,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(64)",
                oldMaxLength: 64);

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_workflow_template",
                table: "lab_workflow_template",
                column: "code");

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_numerator",
                table: "lab_numerator",
                column: "code");

            migrationBuilder.AddPrimaryKey(
                name: "pk_lab_counter",
                table: "lab_counter",
                column: "counter_code");

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_caption",
                table: "mis_patient_card",
                column: "caption");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_entered_at",
                table: "lab_test_result",
                column: "entered_at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_result_flag",
                table: "lab_test_result",
                column: "flag");

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_profile_code",
                table: "lab_test_profile",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_test_definition_code",
                table: "lab_test_definition",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_send_out_number",
                table: "lab_send_out",
                column: "number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_lab_section_id_registered_at",
                table: "lab_section_journal_entry",
                columns: new[] { "lab_section_id", "registered_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_journal_entry_order_id_lab_section_id_sample_id",
                table: "lab_section_journal_entry",
                columns: new[] { "order_id", "lab_section_id", "sample_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_section_code",
                table: "lab_section",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_sample_stage_event_sample_id_at",
                table: "lab_sample_stage_event",
                columns: new[] { "sample_id", "at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_reference_layer_test_code_method_code_priority_order",
                table: "lab_reference_layer",
                columns: new[] { "test_code", "method_code", "priority_order" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_qc_result_qc_material_id_test_code_run_at",
                table: "lab_qc_result",
                columns: new[] { "qc_material_id", "test_code", "run_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_item_price_list_id_profile_id_test_id",
                table: "lab_price_list_item",
                columns: new[] { "price_list_id", "profile_id", "test_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_price_list_code",
                table: "lab_price_list",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_test_performer_id_test_id",
                table: "lab_performer_test",
                columns: new[] { "performer_id", "test_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_code",
                table: "lab_performer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_payer_code",
                table: "lab_payer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_released_at",
                table: "lab_order_test",
                column: "released_at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_status",
                table: "lab_order_test",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_test_test_code",
                table: "lab_order_test",
                column: "test_code");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_sample_barcode",
                table: "lab_order_sample",
                column: "barcode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_favorite_employee_id",
                table: "lab_order_favorite",
                column: "employee_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_order_datetime",
                table: "lab_order",
                column: "order_datetime");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_order_number",
                table: "lab_order",
                column: "order_number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_referral_type",
                table: "lab_order",
                column: "referral_type");

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_status",
                table: "lab_order",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "ix_lab_invoice_number",
                table: "lab_invoice",
                column: "number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_eucast_breakpoint_organism_id_antibiotic_id_eucast_version",
                table: "lab_eucast_breakpoint",
                columns: new[] { "organism_id", "antibiotic_id", "eucast_version" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_ehealth_exchange_log_at",
                table: "lab_ehealth_exchange_log",
                column: "at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_at",
                table: "lab_audit_log",
                column: "at");

            migrationBuilder.CreateIndex(
                name: "ix_lab_audit_log_entity_entity_id",
                table: "lab_audit_log",
                columns: new[] { "entity", "entity_id" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_archive_cell_rack_id_row_num_col_num",
                table: "lab_archive_cell",
                columns: new[] { "rack_id", "row_num", "col_num" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_lockout_analyzer_id_resolved_at",
                table: "lab_analyzer_lockout",
                columns: new[] { "analyzer_id", "resolved_at" });

            migrationBuilder.CreateIndex(
                name: "ix_lab_analyzer_code",
                table: "lab_analyzer",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_ehe_incoming_medical_referral_reg_number",
                table: "ehe_incoming_medical_referral",
                column: "reg_number");
        }

        private static readonly string[] OrganizationTables =
        {
            "org_department", "org_employee", "org_organization_service", "mis_patient_card",
            "mis_diagnostic_report", "ehe_incoming_medical_referral", "ehe_paper_medical_referral", "lab_order",
            "mis_patient_insurance", "lab_employee_settings", "lab_department_settings", "lab_employee_department",
            "lab_settings", "lab_numerator", "lab_counter", "lab_workflow_template",
            "lab_audit_log", "lab_ehealth_exchange_log", "lab_biomaterial_type", "lab_tube_type",
            "lab_method_type", "lab_analyzer_type", "lab_micro_organism", "lab_antibiotic",
            "lab_section", "lab_test_definition", "lab_test_profile", "lab_test_profile_item",
            "lab_reference_layer", "lab_reflex_rule", "lab_eucast_breakpoint", "lab_connector_installation",
            "lab_analyzer", "lab_analyzer_parameter_map", "lab_analyzer_message", "lab_analyzer_lockout",
            "lab_connector_log", "lab_connector_command", "lab_qc_material", "lab_qc_target",
            "lab_qc_result", "lab_reagent_lot", "lab_price_list", "lab_price_list_item",
            "lab_price_package", "lab_payer", "lab_performer", "lab_performer_test",
            "lab_order_sample", "lab_order_test", "lab_test_result", "lab_result_history",
            "lab_panic_call", "lab_worklist_batch", "lab_unmatched_result", "lab_patient_notification",
            "lab_sample_logistics", "lab_sample_logistics_item", "lab_archive_rack", "lab_archive_cell",
            "lab_culture_order", "lab_isolate", "lab_susceptibility_result", "lab_section_journal_entry",
            "lab_sample_stage_event", "lab_order_favorite", "lab_send_out", "lab_send_out_item",
            "lab_order_attachment", "lab_order_charge", "lab_payment", "lab_invoice"
        };

        private static readonly (string Table, (string Parent, string Column)[] References)[] BackfillOrder =
        {
            ("org_department", System.Array.Empty<(string, string)>()),
            ("org_employee", System.Array.Empty<(string, string)>()),
            ("org_organization_service", System.Array.Empty<(string, string)>()),
            ("mis_patient_card", System.Array.Empty<(string, string)>()),
            ("mis_diagnostic_report", System.Array.Empty<(string, string)>()),
            ("ehe_incoming_medical_referral", System.Array.Empty<(string, string)>()),
            ("ehe_paper_medical_referral", System.Array.Empty<(string, string)>()),
            ("lab_order", System.Array.Empty<(string, string)>()),
            ("mis_patient_insurance", new[] { ("mis_patient_card", "patient_card_id") }),
            ("lab_employee_settings", new[] { ("org_employee", "employee_id") }),
            ("lab_department_settings", new[] { ("org_department", "department_id") }),
            ("lab_settings", System.Array.Empty<(string, string)>()),
            ("lab_numerator", System.Array.Empty<(string, string)>()),
            ("lab_counter", System.Array.Empty<(string, string)>()),
            ("lab_workflow_template", System.Array.Empty<(string, string)>()),
            ("lab_audit_log", System.Array.Empty<(string, string)>()),
            ("lab_ehealth_exchange_log", System.Array.Empty<(string, string)>()),
            ("lab_biomaterial_type", System.Array.Empty<(string, string)>()),
            ("lab_tube_type", System.Array.Empty<(string, string)>()),
            ("lab_method_type", System.Array.Empty<(string, string)>()),
            ("lab_analyzer_type", System.Array.Empty<(string, string)>()),
            ("lab_micro_organism", System.Array.Empty<(string, string)>()),
            ("lab_antibiotic", System.Array.Empty<(string, string)>()),
            ("lab_section", new[] { ("org_department", "department_id") }),
            ("lab_test_definition", new[] { ("lab_section", "lab_section_id") }),
            ("lab_test_profile", new[] { ("org_organization_service", "organization_service_id") }),
            ("lab_test_profile_item", new[] { ("lab_test_profile", "profile_id") }),
            ("lab_reference_layer", new[] { ("lab_test_definition", "test_id") }),
            ("lab_reflex_rule", System.Array.Empty<(string, string)>()),
            ("lab_eucast_breakpoint", new[] { ("lab_micro_organism", "organism_id") }),
            ("lab_connector_installation", System.Array.Empty<(string, string)>()),
            ("lab_analyzer", new[] { ("org_department", "department_id"), ("lab_connector_installation", "connector_id") }),
            ("lab_analyzer_parameter_map", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_analyzer_message", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_analyzer_lockout", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_connector_log", new[] { ("lab_connector_installation", "connector_id") }),
            ("lab_connector_command", new[] { ("lab_connector_installation", "connector_id") }),
            ("lab_qc_material", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_qc_target", new[] { ("lab_qc_material", "qc_material_id") }),
            ("lab_qc_result", new[] { ("lab_qc_material", "qc_material_id") }),
            ("lab_reagent_lot", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_price_list", System.Array.Empty<(string, string)>()),
            ("lab_price_list_item", new[] { ("lab_price_list", "price_list_id") }),
            ("lab_price_package", new[] { ("lab_price_list", "price_list_id") }),
            ("lab_payer", new[] { ("lab_price_list", "price_list_id") }),
            ("lab_performer", new[] { ("org_department", "department_id") }),
            ("lab_performer_test", new[] { ("lab_performer", "performer_id") }),
            ("lab_order_sample", new[] { ("lab_order", "order_id") }),
            ("lab_order_test", new[] { ("lab_order", "order_id") }),
            ("lab_test_result", new[] { ("lab_order_test", "order_test_id") }),
            ("lab_result_history", new[] { ("lab_order_test", "order_test_id") }),
            ("lab_panic_call", new[] { ("lab_order", "order_id") }),
            ("lab_worklist_batch", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_unmatched_result", new[] { ("lab_analyzer", "analyzer_id") }),
            ("lab_patient_notification", new[] { ("mis_patient_card", "patient_id") }),
            ("lab_sample_logistics", new[] { ("org_department", "origin_department_id") }),
            ("lab_sample_logistics_item", new[] { ("lab_sample_logistics", "logistics_id") }),
            ("lab_archive_rack", System.Array.Empty<(string, string)>()),
            ("lab_archive_cell", new[] { ("lab_archive_rack", "rack_id") }),
            ("lab_culture_order", new[] { ("lab_order", "order_id") }),
            ("lab_isolate", new[] { ("lab_culture_order", "culture_order_id") }),
            ("lab_susceptibility_result", new[] { ("lab_isolate", "isolate_id") }),
            ("lab_section_journal_entry", new[] { ("lab_order", "order_id") }),
            ("lab_sample_stage_event", new[] { ("lab_order_sample", "sample_id") }),
            ("lab_order_favorite", new[] { ("org_employee", "employee_id") }),
            ("lab_send_out", new[] { ("lab_performer", "performer_id") }),
            ("lab_send_out_item", new[] { ("lab_send_out", "send_out_id") }),
            ("lab_order_attachment", new[] { ("lab_order", "order_id") }),
            ("lab_order_charge", new[] { ("lab_order", "order_id") }),
            ("lab_payment", new[] { ("lab_order", "order_id") }),
            ("lab_invoice", new[] { ("lab_payer", "payer_id") })
        };

        private static void Backfill(MigrationBuilder migrationBuilder)
        {
            foreach (var (table, references) in BackfillOrder)
            {
                foreach (var (parent, column) in references)
                {
                    migrationBuilder.Sql($"UPDATE {table} c SET organization_id = p.organization_id FROM {parent} p WHERE p.id = c.{column} AND (c.organization_id IS NULL OR c.organization_id = '');");
                }
                migrationBuilder.Sql($"UPDATE {table} SET organization_id = (SELECT id FROM org_organization) WHERE organization_id IS NULL OR organization_id = '';");
            }
            foreach (var (table, _) in BackfillOrder)
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN organization_id SET NOT NULL;");
            }
        }

        private static void CreateRoles(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("""
                DO $$
                BEGIN
                    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'lab_migrator') THEN
                        CREATE ROLE lab_migrator LOGIN PASSWORD 'lab_migrator_dev';
                    END IF;
                EXCEPTION WHEN duplicate_object OR unique_violation THEN NULL;
                END
                $$;
                """);

            migrationBuilder.Sql("""
                DO $$
                BEGIN
                    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'lab_app') THEN
                        CREATE ROLE lab_app LOGIN PASSWORD 'lab_app_dev' NOBYPASSRLS;
                    END IF;
                EXCEPTION WHEN duplicate_object OR unique_violation THEN NULL;
                END
                $$;
                """);

            migrationBuilder.Sql("GRANT USAGE ON SCHEMA public TO lab_app;");
            migrationBuilder.Sql("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO lab_app;");
            migrationBuilder.Sql("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO lab_app;");

            migrationBuilder.Sql("GRANT USAGE, CREATE ON SCHEMA public TO lab_migrator;");
            migrationBuilder.Sql("ALTER DEFAULT PRIVILEGES FOR ROLE lab_migrator IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO lab_app;");
            migrationBuilder.Sql("""
                DO $$
                DECLARE t record;
                BEGIN
                    FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tableowner <> 'lab_migrator' LOOP
                        EXECUTE format('ALTER TABLE public.%I OWNER TO lab_migrator', t.tablename);
                    END LOOP;
                END
                $$;
                """);
        }

        private static void DropRoleGrants(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("REASSIGN OWNED BY lab_migrator TO CURRENT_USER;");
            migrationBuilder.Sql("ALTER DEFAULT PRIVILEGES FOR ROLE lab_migrator IN SCHEMA public REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM lab_app;");
            migrationBuilder.Sql("ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM lab_app;");
            migrationBuilder.Sql("REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM lab_app;");
            migrationBuilder.Sql("REVOKE USAGE ON SCHEMA public FROM lab_app;");
            migrationBuilder.Sql("REVOKE USAGE, CREATE ON SCHEMA public FROM lab_migrator;");
        }

        private static readonly (string Table, string Lookup)[] LookupPolicies =
        {
            ("org_employee", "person_id IN (SELECT p.id FROM cmn_person p WHERE p.user_id = NULLIF(current_setting('app.user_id', true), ''))"),
            ("lab_connector_installation", "api_key_hash = NULLIF(current_setting('app.connector_api_key_hash', true), '') OR install_key = NULLIF(current_setting('app.connector_install_key', true), '')"),
            ("lab_order", "verify_token = NULLIF(current_setting('app.verify_token', true), '')")
        };

        internal static void EnableRowLevelSecurity(MigrationBuilder migrationBuilder)
        {
            foreach (var table in OrganizationTables)
            {
                var lookup = System.Array.Find(LookupPolicies, p => p.Table == table).Lookup;
                if (lookup == null) EnableOrganizationRls(migrationBuilder, table);
                else EnableOrganizationRlsWithLookup(migrationBuilder, table, lookup);
            }
        }

        internal static void DisableRowLevelSecurity(MigrationBuilder migrationBuilder)
        {
            foreach (var table in OrganizationTables)
            {
                DisableOrganizationRls(migrationBuilder, table);
            }
        }

        private const string OrganizationCondition = "organization_id = NULLIF(current_setting('app.organization_id', false), '')";

        private static void EnableOrganizationRls(MigrationBuilder migrationBuilder, string table)
        {
            migrationBuilder.Sql($"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;");
            migrationBuilder.Sql($"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;");
            migrationBuilder.Sql($"""
                CREATE POLICY organization_isolation ON {table}
                USING ({OrganizationCondition});
                """);
        }

        private static void EnableOrganizationRlsWithLookup(MigrationBuilder migrationBuilder, string table, string lookupCondition)
        {
            migrationBuilder.Sql($"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;");
            migrationBuilder.Sql($"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;");
            migrationBuilder.Sql($"""
                CREATE POLICY organization_isolation ON {table}
                USING ({OrganizationCondition} OR ({lookupCondition}))
                WITH CHECK ({OrganizationCondition});
                """);
        }

        private static void DisableOrganizationRls(MigrationBuilder migrationBuilder, string table)
        {
            migrationBuilder.Sql($"DROP POLICY IF EXISTS organization_isolation ON {table};");
            migrationBuilder.Sql($"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY;");
            migrationBuilder.Sql($"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;");
        }
    }
}
