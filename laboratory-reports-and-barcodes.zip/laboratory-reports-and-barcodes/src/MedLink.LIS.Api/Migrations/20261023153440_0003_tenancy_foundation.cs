﻿using System;
using MedLink.LIS.Api.Data;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MedLink.LIS.Api.Migrations
{
    /// <inheritdoc />
    public partial class _0003_tenancy_foundation : Migration
    {
        private static readonly string[] TenantTables =
        {
            "org_employee", "org_organization_service", "mis_diagnostic_report", "ehe_incoming_medical_referral", "ehe_paper_medical_referral", "lab_order",
            "mis_patient_insurance", "lab_employee_settings",
            "lab_settings", "lab_numerator", "lab_workflow_template",
            "lab_audit_log", "lab_ehealth_exchange_log", "lab_biomaterial_type", "lab_tube_type",
            "lab_method_type", "lab_analyzer_type", "lab_micro_organism", "lab_antibiotic",
            "lab_section", "lab_test_definition", "lab_test_profile", "lab_test_profile_item",
            "lab_reference_layer", "lab_reflex_rule", "lab_eucast_breakpoint", "lab_connector_installation",
            "lab_analyzer", "lab_analyzer_parameter_map", "lab_analyzer_message", "lab_analyzer_lockout",
            "lab_connector_log", "lab_connector_command", "lab_qc_material", "lab_qc_target",
            "lab_qc_result", "lab_reagent_lot", "lab_price_list", "lab_price_list_item",
            "lab_price_package", "lab_payer", "lab_performer", "lab_performer_test",
            "lab_order_sample", "lab_order_test", "lab_test_result", "lab_result_history",
            "lab_panic_call", "lab_worklist_batch", "lab_unmatched_result", "lab_patient_notification",
            "lab_sample_logistics", "lab_sample_logistics_item", "lab_archive_rack", "lab_archive_cell",
            "lab_culture_order", "lab_isolate", "lab_susceptibility_result", "lab_section_journal_entry",
            "lab_sample_stage_event", "lab_order_favorite", "lab_send_out", "lab_send_out_item",
            "lab_order_attachment", "lab_order_charge", "lab_payment", "lab_invoice"
        };

        private static readonly string[] NewTenantTables = { "tn_division", "tn_requisites", "tn_settings", "tn_sequence", "id_membership_division", "ord_patient" };

        private static readonly string[] RenamedIndexes =
        {
            "ix_org_organization_service_organization_id",
            "ix_org_employee_organization_id",
            "ix_mis_patient_insurance_organization_id",
            "ix_mis_diagnostic_report_organization_id",
            "ix_lab_worklist_batch_organization_id",
            "ix_lab_workflow_template_organization_id",
            "ix_lab_unmatched_result_organization_id",
            "ix_lab_tube_type_organization_id",
            "ix_lab_test_result_organization_id_entered_at",
            "ix_lab_test_result_organization_id_flag",
            "ix_lab_test_profile_item_organization_id",
            "ix_lab_test_profile_organization_id_code",
            "ix_lab_test_definition_organization_id_code",
            "ix_lab_susceptibility_result_organization_id",
            "ix_lab_settings_organization_id",
            "ix_lab_send_out_item_organization_id",
            "ix_lab_send_out_organization_id_number",
            "ix_lab_section_journal_entry_organization_id_lab_section_id_registered_at",
            "ix_lab_section_journal_entry_organization_id_order_id_lab_section_id_sample_id",
            "ix_lab_section_organization_id_code",
            "ix_lab_sample_stage_event_organization_id_sample_id_at",
            "ix_lab_sample_logistics_item_organization_id",
            "ix_lab_sample_logistics_organization_id",
            "ix_lab_result_history_organization_id",
            "ix_lab_reflex_rule_organization_id",
            "ix_lab_reference_layer_organization_id_test_code_method_code_priority_order",
            "ix_lab_reagent_lot_organization_id",
            "ix_lab_qc_target_organization_id",
            "ix_lab_qc_result_organization_id_qc_material_id_test_code_run_at",
            "ix_lab_qc_material_organization_id",
            "ix_lab_price_package_organization_id",
            "ix_lab_price_list_item_organization_id_price_list_id_profile_id_test_id",
            "ix_lab_price_list_organization_id_code",
            "ix_lab_performer_test_organization_id_performer_id_test_id",
            "ix_lab_performer_organization_id_code",
            "ix_lab_payment_organization_id",
            "ix_lab_payer_organization_id_code",
            "ix_lab_patient_notification_organization_id",
            "ix_lab_panic_call_organization_id",
            "ix_lab_order_test_organization_id_released_at",
            "ix_lab_order_test_organization_id_status",
            "ix_lab_order_test_organization_id_test_code",
            "ix_lab_order_sample_organization_id_barcode",
            "ix_lab_order_favorite_organization_id_employee_id",
            "ix_lab_order_charge_organization_id",
            "ix_lab_order_attachment_organization_id",
            "ix_lab_order_organization_id_order_datetime",
            "ix_lab_order_organization_id_order_number",
            "ix_lab_order_organization_id_referral_type",
            "ix_lab_order_organization_id_status",
            "ix_lab_numerator_organization_id",
            "ix_lab_micro_organism_organization_id",
            "ix_lab_method_type_organization_id",
            "ix_lab_isolate_organization_id",
            "ix_lab_invoice_organization_id_number",
            "ix_lab_eucast_breakpoint_organization_id_organism_id_antibiotic_id_eucast_version",
            "ix_lab_employee_settings_organization_id",
            "ix_lab_ehealth_exchange_log_organization_id_at",
            "ix_lab_culture_order_organization_id",
            "ix_lab_connector_log_organization_id",
            "ix_lab_connector_installation_organization_id",
            "ix_lab_connector_command_organization_id",
            "ix_lab_biomaterial_type_organization_id",
            "ix_lab_audit_log_organization_id_at",
            "ix_lab_audit_log_organization_id_entity_entity_id",
            "ix_lab_archive_rack_organization_id",
            "ix_lab_archive_cell_organization_id_rack_id_row_num_col_num",
            "ix_lab_antibiotic_organization_id",
            "ix_lab_analyzer_type_organization_id",
            "ix_lab_analyzer_parameter_map_organization_id",
            "ix_lab_analyzer_message_organization_id",
            "ix_lab_analyzer_lockout_organization_id_analyzer_id_resolved_at",
            "ix_lab_analyzer_organization_id_code",
            "ix_ehe_paper_medical_referral_organization_id",
            "ix_ehe_incoming_medical_referral_organization_id_reg_number"
        };

        private static readonly (string Table, string Column)[] DivisionColumns =
        {
            ("lab_order", "department_id"), ("lab_section", "department_id"), ("lab_analyzer", "department_id"), ("lab_performer", "department_id"),
            ("org_employee", "department_id"), ("lab_sample_logistics", "origin_department_id"), ("lab_sample_logistics", "destination_department_id")
        };

        private const string UserLookup = "SELECT p.id FROM cmn_person p WHERE p.user_id = NULLIF(current_setting('app.user_id', true), '')";

        private static readonly (string Table, string Lookup)[] LookupPolicies =
        {
            ("org_employee", $"person_id IN ({UserLookup})"),
            ("id_membership", $"user_id IN ({UserLookup})"),
            ("lab_connector_installation", "api_key_hash = NULLIF(current_setting('app.connector_api_key_hash', true), '') OR install_key = NULLIF(current_setting('app.connector_install_key', true), '')"),
            ("lab_order", "verify_token = NULLIF(current_setting('app.verify_token', true), '')")
        };

        private const string TenantLookup = $"id IN (SELECT m.tenant_id FROM id_membership m WHERE m.user_id IN ({UserLookup})) OR current_setting('app.tenant_enumeration', true) = 'on'";

        private const string EmptyGuid = "00000000-0000-0000-0000-000000000000";

        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            _0002_tenancy.DisableRowLevelSecurity(migrationBuilder);

            migrationBuilder.DropForeignKey(
                name: "fk_ehe_incoming_medical_referral_patient_card_id",
                table: "ehe_incoming_medical_referral");

            migrationBuilder.DropForeignKey(
                name: "fk_ehe_paper_medical_referral_patient_card_id",
                table: "ehe_paper_medical_referral");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_analyzer_department_id",
                table: "lab_analyzer");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_order_department_id",
                table: "lab_order");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_order_patient_id",
                table: "lab_order");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_sample_logistics_destination_department_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_sample_logistics_origin_department_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_section_department_id",
                table: "lab_section");

            migrationBuilder.DropForeignKey(
                name: "fk_mis_patient_insurance_patient_card_id",
                table: "mis_patient_insurance");

            migrationBuilder.DropForeignKey(
                name: "fk_org_employee_department_id",
                table: "org_employee");

            migrationBuilder.CreateTable(
                name: "tn_tenant",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    name = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false),
                    type = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tn_tenant", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "id_membership",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    user_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_membership", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_membership_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_id_membership_user_id",
                        column: x => x.user_id,
                        principalTable: "cmn_person",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ord_patient",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    last_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    middle_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    caption = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    birthday = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    gender_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    ipn = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true),
                    phone = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    email = table.Column<string>(type: "character varying(129)", maxLength: 129, nullable: true),
                    location = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: true),
                    last_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    first_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ord_patient", x => x.id);
                    table.ForeignKey(
                        name: "fk_ord_patient_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tn_division",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    name = table.Column<string>(type: "text", nullable: false),
                    type = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    address = table.Column<string>(type: "text", nullable: true),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    department_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tn_division", x => x.id);
                    table.ForeignKey(
                        name: "fk_tn_division_department_type_id",
                        column: x => x.department_type_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_tn_division_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tn_requisites",
                columns: table => new
                {
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    legal_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    edrpou = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: true),
                    address = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    email = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    license_number = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    logo_base64 = table.Column<string>(type: "text", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tn_requisites", x => x.tenant_id);
                    table.ForeignKey(
                        name: "fk_tn_requisites_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tn_sequence",
                columns: table => new
                {
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    key = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    scope_key = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    value = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tn_sequence", x => new { x.tenant_id, x.key, x.scope_key });
                    table.ForeignKey(
                        name: "fk_tn_sequence_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tn_settings",
                columns: table => new
                {
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    time_zone = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    report_date_format = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    decimal_separator = table.Column<string>(type: "character varying(1)", maxLength: 1, nullable: true),
                    status_colors_json = table.Column<string>(type: "text", nullable: true),
                    criticality_colors_json = table.Column<string>(type: "text", nullable: true),
                    report_language = table.Column<string>(type: "character varying(8)", maxLength: 8, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tn_settings", x => x.tenant_id);
                    table.ForeignKey(
                        name: "fk_tn_settings_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "id_membership_division",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    membership_id = table.Column<Guid>(type: "uuid", nullable: false),
                    division_id = table.Column<Guid>(type: "uuid", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_membership_division", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_membership_division_division_id",
                        column: x => x.division_id,
                        principalTable: "tn_division",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_membership_division_membership_id",
                        column: x => x.membership_id,
                        principalTable: "id_membership",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_membership_division_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.Sql("INSERT INTO tn_tenant (id, name, type, created_on, created_by, modified_on, modified_by, record_state) SELECT o.id::uuid, left(coalesce(o.caption, ''), 300), CASE WHEN (SELECT count(*) FROM org_department d JOIN lab_department_settings s ON s.department_id = d.id WHERE d.organization_id = o.id AND s.lab_kind = 'LABORATORY') > 1 THEN 'network' ELSE 'laboratory' END, o.created_on, o.created_by, o.modified_on, o.modified_by, o.record_state FROM org_organization o;");
            migrationBuilder.Sql("INSERT INTO id_membership (id, tenant_id, user_id, is_active, created_on, created_by, modified_on, modified_by, record_state) SELECT e.id::uuid, e.organization_id::uuid, e.person_id, true, e.created_on, e.created_by, e.modified_on, e.modified_by, e.record_state FROM org_employee e;");
            migrationBuilder.Sql("INSERT INTO ord_patient (id, last_name, name, middle_name, caption, birthday, gender_id, ipn, phone, email, location, last_name_latin, first_name_latin, created_on, created_by, modified_on, modified_by, record_state, tenant_id) SELECT c.id, p.last_name, p.name, p.middle_name, coalesce(c.caption, p.caption), coalesce(c.birthday, p.birthday), coalesce(c.gender_id, p.gender_id), p.ipn, p.phone, p.email, coalesce(p.location, c.location), c.last_name_latin, c.first_name_latin, c.created_on, c.created_by, c.modified_on, c.modified_by, c.record_state, c.organization_id::uuid FROM mis_patient_card c JOIN cmn_person p ON p.id = c.person_id;");
            migrationBuilder.Sql("INSERT INTO tn_division (id, tenant_id, code, name, type, address, phone, is_active, department_type_id, created_on, created_by, modified_on, modified_by, record_state) SELECT d.id::uuid, d.organization_id::uuid, d.code, coalesce(d.caption, ''), lower(coalesce(s.lab_kind, 'CLINICAL')), d.location, s.phone, coalesce(s.is_active, true), d.department_type_id, d.created_on, d.created_by, d.modified_on, d.modified_by, d.record_state FROM org_department d LEFT JOIN lab_department_settings s ON s.department_id = d.id;");
            migrationBuilder.Sql("INSERT INTO tn_requisites (tenant_id, legal_name, edrpou, address, phone, email, license_number, logo_base64, created_on, created_by, modified_on, modified_by, record_state) SELECT organization_id::uuid, name, edrpou, address, phone, email, license_number, logo_base64, created_on, created_by, modified_on, modified_by, record_state FROM lab_settings;");
            migrationBuilder.Sql($"INSERT INTO tn_settings (tenant_id, time_zone, report_language, created_on, created_by, modified_by, record_state) SELECT id, 'Europe/Kyiv', 'uk', timezone('utc', now()), '{EmptyGuid}', '{EmptyGuid}', 2 FROM tn_tenant;");
            migrationBuilder.Sql("INSERT INTO tn_sequence (tenant_id, key, scope_key, value) SELECT organization_id::uuid, code, CASE WHEN reset_by_period THEN coalesce(period_key, 'ALL') ELSE 'ALL' END, current_value FROM lab_numerator UNION ALL SELECT organization_id::uuid, counter_code, 'ALL', counter_value FROM lab_counter;");
            migrationBuilder.Sql("INSERT INTO id_membership_division (id, tenant_id, membership_id, division_id, created_on, created_by, modified_on, modified_by, record_state) SELECT id::uuid, organization_id::uuid, employee_id::uuid, department_id::uuid, created_on, created_by, modified_on, modified_by, record_state FROM lab_employee_department;");
            migrationBuilder.Sql("DELETE FROM cmn_person p WHERE EXISTS (SELECT 1 FROM mis_patient_card c WHERE c.person_id = p.id) AND NOT EXISTS (SELECT 1 FROM org_employee e WHERE e.person_id = p.id);");

            migrationBuilder.DropTable(
                name: "lab_counter");

            migrationBuilder.DropTable(
                name: "lab_department_settings");

            migrationBuilder.DropTable(
                name: "lab_employee_department");

            migrationBuilder.DropTable(
                name: "mis_patient_card");

            migrationBuilder.DropTable(
                name: "org_department");

            migrationBuilder.DropTable(
                name: "org_organization");

            migrationBuilder.DropColumn(
                name: "address",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "edrpou",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "email",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "license_number",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "logo_base64",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "name",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "phone",
                table: "lab_settings");

            migrationBuilder.DropColumn(
                name: "current_value",
                table: "lab_numerator");

            migrationBuilder.DropColumn(
                name: "period_key",
                table: "lab_numerator");

            foreach (var table in TenantTables)
            {
                migrationBuilder.Sql($"ALTER TABLE {table} RENAME COLUMN organization_id TO tenant_id;");
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN tenant_id TYPE uuid USING tenant_id::uuid;");
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN tenant_id SET NOT NULL;");
            }

            foreach (var index in RenamedIndexes)
            {
                migrationBuilder.Sql($"ALTER INDEX {index} RENAME TO {index.Replace("organization_id", "tenant_id")};");
            }

            foreach (var (table, column) in DivisionColumns)
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN {column} TYPE uuid USING NULLIF({column}, '')::uuid;");
            }

            migrationBuilder.AddColumn<Guid>(
                name: "membership_id",
                table: "org_employee",
                type: "uuid",
                nullable: false,
                computedColumnSql: "id::uuid",
                stored: true);

            migrationBuilder.CreateIndex(
                name: "ix_org_employee_membership_id",
                table: "org_employee",
                column: "membership_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_lab_performer_department_id",
                table: "lab_performer",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_tenant_id_user_id",
                table: "id_membership",
                columns: new[] { "tenant_id", "user_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_user_id",
                table: "id_membership",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_division_division_id",
                table: "id_membership_division",
                column: "division_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_division_membership_id",
                table: "id_membership_division",
                column: "membership_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_division_tenant_id_membership_id_division_id",
                table: "id_membership_division",
                columns: new[] { "tenant_id", "membership_id", "division_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_tenant_id_caption",
                table: "ord_patient",
                columns: new[] { "tenant_id", "caption" });

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_tenant_id_last_name_name",
                table: "ord_patient",
                columns: new[] { "tenant_id", "last_name", "name" });

            migrationBuilder.CreateIndex(
                name: "ix_tn_division_department_type_id",
                table: "tn_division",
                column: "department_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_tn_division_tenant_id_code",
                table: "tn_division",
                columns: new[] { "tenant_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_tn_requisites_tenant_id",
                table: "tn_requisites",
                column: "tenant_id");

            migrationBuilder.CreateIndex(
                name: "ix_tn_sequence_tenant_id",
                table: "tn_sequence",
                column: "tenant_id");

            migrationBuilder.CreateIndex(
                name: "ix_tn_settings_tenant_id",
                table: "tn_settings",
                column: "tenant_id");

            migrationBuilder.AddForeignKey(
                name: "fk_ehe_incoming_medical_referral_patient_card_id",
                table: "ehe_incoming_medical_referral",
                column: "patient_card_id",
                principalTable: "ord_patient",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_ehe_paper_medical_referral_patient_card_id",
                table: "ehe_paper_medical_referral",
                column: "patient_card_id",
                principalTable: "ord_patient",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_analyzer_department_id",
                table: "lab_analyzer",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_lab_order_department_id",
                table: "lab_order",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_lab_order_patient_id",
                table: "lab_order",
                column: "patient_id",
                principalTable: "ord_patient",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_performer_department_id",
                table: "lab_performer",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_sample_logistics_destination_department_id",
                table: "lab_sample_logistics",
                column: "destination_department_id",
                principalTable: "tn_division",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_sample_logistics_origin_department_id",
                table: "lab_sample_logistics",
                column: "origin_department_id",
                principalTable: "tn_division",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_section_department_id",
                table: "lab_section",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_mis_patient_insurance_patient_card_id",
                table: "mis_patient_insurance",
                column: "patient_card_id",
                principalTable: "ord_patient",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_org_employee_department_id",
                table: "org_employee",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_org_employee_membership_id",
                table: "org_employee",
                column: "membership_id",
                principalTable: "id_membership",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            MigrationHelpers.CreateTenantFunctions(migrationBuilder);
            foreach (var table in TenantTables.Concat(NewTenantTables).Append("id_membership"))
            {
                var lookup = Array.Find(LookupPolicies, p => p.Table == table).Lookup;
                if (lookup == null) MigrationHelpers.EnableRls(migrationBuilder, table);
                else MigrationHelpers.EnableRlsWithLookup(migrationBuilder, table, lookup);
            }
            MigrationHelpers.EnableTenantTableRls(migrationBuilder, TenantLookup);

            migrationBuilder.Sql("GRANT SELECT, INSERT, UPDATE, DELETE ON tn_tenant, tn_division, tn_requisites, tn_settings, tn_sequence, id_membership, id_membership_division, ord_patient TO lab_app;");
            migrationBuilder.Sql("""
                DO $$
                DECLARE t record;
                BEGIN
                    FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tableowner <> 'lab_migrator' LOOP
                        EXECUTE format('ALTER TABLE public.%I OWNER TO lab_migrator', t.tablename);
                    END LOOP;
                END
                $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            foreach (var table in TenantTables.Concat(NewTenantTables).Append("id_membership").Append("tn_tenant"))
            {
                MigrationHelpers.DisableRls(migrationBuilder, table);
            }
            MigrationHelpers.DropTenantFunctions(migrationBuilder);

            migrationBuilder.DropForeignKey(
                name: "fk_ehe_incoming_medical_referral_patient_card_id",
                table: "ehe_incoming_medical_referral");

            migrationBuilder.DropForeignKey(
                name: "fk_ehe_paper_medical_referral_patient_card_id",
                table: "ehe_paper_medical_referral");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_analyzer_department_id",
                table: "lab_analyzer");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_order_department_id",
                table: "lab_order");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_order_patient_id",
                table: "lab_order");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_performer_department_id",
                table: "lab_performer");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_sample_logistics_destination_department_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_sample_logistics_origin_department_id",
                table: "lab_sample_logistics");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_section_department_id",
                table: "lab_section");

            migrationBuilder.DropForeignKey(
                name: "fk_mis_patient_insurance_patient_card_id",
                table: "mis_patient_insurance");

            migrationBuilder.DropForeignKey(
                name: "fk_org_employee_department_id",
                table: "org_employee");

            migrationBuilder.DropForeignKey(
                name: "fk_org_employee_membership_id",
                table: "org_employee");

            migrationBuilder.AddColumn<string>(
                name: "address",
                table: "lab_settings",
                type: "character varying(512)",
                maxLength: 512,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "edrpou",
                table: "lab_settings",
                type: "character varying(16)",
                maxLength: 16,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "email",
                table: "lab_settings",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "license_number",
                table: "lab_settings",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "logo_base64",
                table: "lab_settings",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "name",
                table: "lab_settings",
                type: "character varying(256)",
                maxLength: 256,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "phone",
                table: "lab_settings",
                type: "character varying(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "current_value",
                table: "lab_numerator",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "period_key",
                table: "lab_numerator",
                type: "character varying(16)",
                maxLength: 16,
                nullable: true);

            migrationBuilder.Sql("UPDATE lab_settings l SET name = r.legal_name, edrpou = r.edrpou, address = r.address, phone = r.phone, email = r.email, license_number = r.license_number, logo_base64 = r.logo_base64 FROM tn_requisites r WHERE r.tenant_id = l.tenant_id;");
            migrationBuilder.Sql("UPDATE lab_numerator n SET current_value = s.value, period_key = CASE WHEN s.scope_key = 'ALL' THEN NULL ELSE s.scope_key END FROM (SELECT DISTINCT ON (tenant_id, key) tenant_id, key, scope_key, value FROM tn_sequence ORDER BY tenant_id, key, scope_key DESC) s WHERE s.tenant_id = n.tenant_id AND s.key = n.code;");

            migrationBuilder.CreateTable(
                name: "org_organization",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "character varying(400)", maxLength: 400, nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    description = table.Column<string>(type: "text", nullable: true),
                    full_name = table.Column<string>(type: "text", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_organization", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "org_department",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    department_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "text", nullable: true),
                    category = table.Column<string>(type: "text", nullable: true),
                    code = table.Column<string>(type: "text", nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    description = table.Column<string>(type: "text", nullable: true),
                    full_name = table.Column<string>(type: "text", nullable: true),
                    location = table.Column<string>(type: "text", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    parent_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    zip_code = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_org_department", x => x.id);
                    table.ForeignKey(
                        name: "fk_org_department_department_type_id",
                        column: x => x.department_type_id,
                        principalTable: "cmn_enum_record",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_org_department_organization_id",
                        column: x => x.organization_id,
                        principalTable: "org_organization",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_department_settings",
                columns: table => new
                {
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    lab_kind = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    phone = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_department_settings", x => x.department_id);
                    table.ForeignKey(
                        name: "fk_lab_department_settings_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_employee_department",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    department_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    employee_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_employee_department", x => x.id);
                    table.ForeignKey(
                        name: "fk_lab_employee_department_department_id",
                        column: x => x.department_id,
                        principalTable: "org_department",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_lab_employee_department_employee_id",
                        column: x => x.employee_id,
                        principalTable: "org_employee",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "mis_patient_card",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    person_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    birthday = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    caption = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    description = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    document_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    first_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    gender_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    last_name_latin = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    location = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    patient_card_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    privacy_request_type_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    reg_date = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    reg_number = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_mis_patient_card", x => x.id);
                    table.ForeignKey(
                        name: "fk_mis_patient_card_person_id",
                        column: x => x.person_id,
                        principalTable: "cmn_person",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "lab_counter",
                columns: table => new
                {
                    organization_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    counter_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    counter_value = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_lab_counter", x => new { x.organization_id, x.counter_code });
                });

            migrationBuilder.Sql("INSERT INTO org_organization (id, caption, code, created_by, created_on, description, full_name, modified_by, modified_on, record_state) SELECT id::text, name, NULL, created_by, created_on, NULL, NULL, modified_by, modified_on, record_state FROM tn_tenant;");
            migrationBuilder.Sql("INSERT INTO org_department (id, department_type_id, organization_id, caption, category, code, created_by, created_on, description, full_name, location, modified_by, modified_on, parent_id, record_state, zip_code) SELECT id::text, department_type_id, tenant_id::text, name, NULL, code, created_by, created_on, NULL, name, address, modified_by, modified_on, NULL, record_state, NULL FROM tn_division;");
            migrationBuilder.Sql("INSERT INTO lab_department_settings (department_id, created_by, created_on, is_active, lab_kind, modified_by, modified_on, organization_id, phone, record_state) SELECT id::text, created_by, created_on, is_active, upper(type), modified_by, modified_on, tenant_id::text, phone, record_state FROM tn_division;");
            migrationBuilder.Sql("INSERT INTO lab_employee_department (id, department_id, employee_id, created_by, created_on, modified_by, modified_on, organization_id, record_state) SELECT id::text, division_id::text, membership_id::text, created_by, created_on, modified_by, modified_on, tenant_id::text, record_state FROM id_membership_division;");
            migrationBuilder.Sql("INSERT INTO cmn_person (id, last_name, name, middle_name, birthday, gender_id, ipn, no_ipn, phone, email, location, caption, description, subscribed_to_notifications, user_id, created_on, created_by, modified_on, modified_by, record_state) SELECT id, last_name, name, middle_name, birthday, gender_id, ipn, ipn IS NULL, phone, email, location, caption, NULL, false, NULL, created_on, created_by, modified_on, modified_by, record_state FROM ord_patient;");
            migrationBuilder.Sql("INSERT INTO mis_patient_card (id, person_id, birthday, caption, created_by, created_on, description, document_type_id, first_name_latin, gender_id, last_name_latin, location, modified_by, modified_on, organization_id, patient_card_type_id, privacy_request_type_id, record_state, reg_date, reg_number) SELECT id, id, birthday, caption, created_by, created_on, NULL, 'd95d3e30-15ea-421c-8785-8e80e60ffbbe', first_name_latin, gender_id, last_name_latin, location, modified_by, modified_on, tenant_id::text, '0c000000-0000-0000-0000-00000000e001', '64b66b71-581b-4c52-aff4-abf352fa6a6d', record_state, created_on, NULL FROM ord_patient;");
            migrationBuilder.Sql("INSERT INTO lab_counter (organization_id, counter_code, counter_value) SELECT s.tenant_id::text, s.key, s.value FROM tn_sequence s WHERE NOT EXISTS (SELECT 1 FROM lab_numerator n WHERE n.tenant_id = s.tenant_id AND n.code = s.key);");

            migrationBuilder.DropIndex(
                name: "ix_org_employee_membership_id",
                table: "org_employee");

            migrationBuilder.DropColumn(
                name: "membership_id",
                table: "org_employee");

            migrationBuilder.DropIndex(
                name: "ix_lab_performer_department_id",
                table: "lab_performer");

            migrationBuilder.DropTable(
                name: "id_membership_division");

            migrationBuilder.DropTable(
                name: "ord_patient");

            migrationBuilder.DropTable(
                name: "tn_requisites");

            migrationBuilder.DropTable(
                name: "tn_sequence");

            migrationBuilder.DropTable(
                name: "tn_settings");

            migrationBuilder.DropTable(
                name: "tn_division");

            migrationBuilder.DropTable(
                name: "id_membership");

            migrationBuilder.DropTable(
                name: "tn_tenant");

            foreach (var table in TenantTables)
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN tenant_id TYPE character varying(64) USING tenant_id::text;");
                migrationBuilder.Sql($"ALTER TABLE {table} RENAME COLUMN tenant_id TO organization_id;");
            }

            foreach (var (table, column) in DivisionColumns)
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN {column} TYPE character varying(64) USING {column}::text;");
            }

            foreach (var index in RenamedIndexes)
            {
                migrationBuilder.Sql($"ALTER INDEX {index.Replace("organization_id", "tenant_id")} RENAME TO {index};");
            }

            migrationBuilder.CreateIndex(
                name: "ix_lab_counter_organization_id",
                table: "lab_counter",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_department_settings_organization_id",
                table: "lab_department_settings",
                column: "organization_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_department_id",
                table: "lab_employee_department",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_employee_id",
                table: "lab_employee_department",
                column: "employee_id");

            migrationBuilder.CreateIndex(
                name: "ix_lab_employee_department_organization_id_employee_id_department_id",
                table: "lab_employee_department",
                columns: new[] { "organization_id", "employee_id", "department_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_organization_id_caption",
                table: "mis_patient_card",
                columns: new[] { "organization_id", "caption" });

            migrationBuilder.CreateIndex(
                name: "ix_mis_patient_card_person_id",
                table: "mis_patient_card",
                column: "person_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_department_department_type_id",
                table: "org_department",
                column: "department_type_id");

            migrationBuilder.CreateIndex(
                name: "ix_org_department_organization_id",
                table: "org_department",
                column: "organization_id");

            migrationBuilder.AddForeignKey(
                name: "fk_ehe_incoming_medical_referral_patient_card_id",
                table: "ehe_incoming_medical_referral",
                column: "patient_card_id",
                principalTable: "mis_patient_card",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_ehe_paper_medical_referral_patient_card_id",
                table: "ehe_paper_medical_referral",
                column: "patient_card_id",
                principalTable: "mis_patient_card",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_analyzer_department_id",
                table: "lab_analyzer",
                column: "department_id",
                principalTable: "org_department",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_lab_order_department_id",
                table: "lab_order",
                column: "department_id",
                principalTable: "org_department",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_lab_order_patient_id",
                table: "lab_order",
                column: "patient_id",
                principalTable: "mis_patient_card",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_sample_logistics_destination_department_id",
                table: "lab_sample_logistics",
                column: "destination_department_id",
                principalTable: "org_department",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_sample_logistics_origin_department_id",
                table: "lab_sample_logistics",
                column: "origin_department_id",
                principalTable: "org_department",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_lab_section_department_id",
                table: "lab_section",
                column: "department_id",
                principalTable: "org_department",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_mis_patient_insurance_patient_card_id",
                table: "mis_patient_insurance",
                column: "patient_card_id",
                principalTable: "mis_patient_card",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_org_employee_department_id",
                table: "org_employee",
                column: "department_id",
                principalTable: "org_department",
                principalColumn: "id");

            _0002_tenancy.EnableRowLevelSecurity(migrationBuilder);
        }
    }
}
