﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MedLink.LIS.Api.Migrations
{
    /// <inheritdoc />
    public partial class _0004_lab_data_independence : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "sex",
                table: "ord_patient",
                type: "character varying(8)",
                maxLength: 8,
                nullable: false,
                defaultValue: "unknown");

            migrationBuilder.AddColumn<Guid>(
                name: "requester_id",
                table: "lab_order",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "department_id",
                table: "id_membership",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "position_name",
                table: "id_membership",
                type: "character varying(256)",
                maxLength: 256,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "id_permission",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    caption = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_permission", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "id_role",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    is_system = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_role", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_role_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "id_user",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    sub = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    display_name = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    default_tenant_id = table.Column<Guid>(type: "uuid", nullable: true),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_user", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_user_default_tenant_id",
                        column: x => x.default_tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "ord_order_identifier",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    order_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    system = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    value = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ord_order_identifier", x => x.id);
                    table.ForeignKey(
                        name: "fk_ord_order_identifier_order_id",
                        column: x => x.order_id,
                        principalTable: "lab_order",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_ord_order_identifier_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ord_patient_identifier",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    patient_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    system = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    value = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ord_patient_identifier", x => x.id);
                    table.ForeignKey(
                        name: "fk_ord_patient_identifier_patient_id",
                        column: x => x.patient_id,
                        principalTable: "ord_patient",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_ord_patient_identifier_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ord_patient_insurance",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    patient_card_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    payer_id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    policy_number = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    valid_from = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    valid_to = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    note = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ord_patient_insurance", x => x.id);
                    table.ForeignKey(
                        name: "fk_ord_patient_insurance_patient_card_id",
                        column: x => x.patient_card_id,
                        principalTable: "ord_patient",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_ord_patient_insurance_payer_id",
                        column: x => x.payer_id,
                        principalTable: "lab_payer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_ord_patient_insurance_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ord_requester",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    organization = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    identifiers = table.Column<string>(type: "jsonb", nullable: false, defaultValueSql: "'[]'::jsonb"),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ord_requester", x => x.id);
                    table.ForeignKey(
                        name: "fk_ord_requester_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "id_membership_role",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    membership_id = table.Column<Guid>(type: "uuid", nullable: false),
                    role_id = table.Column<Guid>(type: "uuid", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_membership_role", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_membership_role_membership_id",
                        column: x => x.membership_id,
                        principalTable: "id_membership",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_membership_role_role_id",
                        column: x => x.role_id,
                        principalTable: "id_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_membership_role_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "id_role_permission",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    role_id = table.Column<Guid>(type: "uuid", nullable: false),
                    permission_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_id_role_permission", x => x.id);
                    table.ForeignKey(
                        name: "fk_id_role_permission_permission_code",
                        column: x => x.permission_code,
                        principalTable: "id_permission",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_role_permission_role_id",
                        column: x => x.role_id,
                        principalTable: "id_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_id_role_permission_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tn_tenant",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "ix_lab_order_requester_id",
                table: "lab_order",
                column: "requester_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_department_id",
                table: "id_membership",
                column: "department_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_role_membership_id",
                table: "id_membership_role",
                column: "membership_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_role_role_id",
                table: "id_membership_role",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_membership_role_tenant_id_membership_id_role_id",
                table: "id_membership_role",
                columns: new[] { "tenant_id", "membership_id", "role_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_id_role_tenant_id_code",
                table: "id_role",
                columns: new[] { "tenant_id", "code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_id_role_permission_permission_code",
                table: "id_role_permission",
                column: "permission_code");

            migrationBuilder.CreateIndex(
                name: "ix_id_role_permission_role_id",
                table: "id_role_permission",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_role_permission_tenant_id_role_id_permission_code",
                table: "id_role_permission",
                columns: new[] { "tenant_id", "role_id", "permission_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_id_user_default_tenant_id",
                table: "id_user",
                column: "default_tenant_id");

            migrationBuilder.CreateIndex(
                name: "ix_id_user_sub",
                table: "id_user",
                column: "sub",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_ord_order_identifier_order_id",
                table: "ord_order_identifier",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "ix_ord_order_identifier_tenant_id_system_value",
                table: "ord_order_identifier",
                columns: new[] { "tenant_id", "system", "value" });

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_identifier_patient_id",
                table: "ord_patient_identifier",
                column: "patient_id");

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_identifier_tenant_id_system_value",
                table: "ord_patient_identifier",
                columns: new[] { "tenant_id", "system", "value" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_insurance_patient_card_id",
                table: "ord_patient_insurance",
                column: "patient_card_id");

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_insurance_payer_id",
                table: "ord_patient_insurance",
                column: "payer_id");

            migrationBuilder.CreateIndex(
                name: "ix_ord_patient_insurance_tenant_id",
                table: "ord_patient_insurance",
                column: "tenant_id");

            migrationBuilder.CreateIndex(
                name: "ix_ord_requester_tenant_id",
                table: "ord_requester",
                column: "tenant_id");

            migrationBuilder.Sql("ALTER TABLE id_membership NO FORCE ROW LEVEL SECURITY; ALTER TABLE tn_division NO FORCE ROW LEVEL SECURITY; ALTER TABLE lab_order NO FORCE ROW LEVEL SECURITY;");

            migrationBuilder.AddForeignKey(
                name: "fk_id_membership_department_id",
                table: "id_membership",
                column: "department_id",
                principalTable: "tn_division",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_lab_order_requester_id",
                table: "lab_order",
                column: "requester_id",
                principalTable: "ord_requester",
                principalColumn: "id");

            migrationBuilder.Sql("ALTER TABLE id_membership FORCE ROW LEVEL SECURITY; ALTER TABLE tn_division FORCE ROW LEVEL SECURITY; ALTER TABLE lab_order FORCE ROW LEVEL SECURITY;");

            migrationBuilder.Sql("""
                DO $$
                DECLARE tenants uuid[];
                DECLARE t uuid;
                BEGIN
                    PERFORM set_config('app.tenant_enumeration', 'on', true);
                    SELECT coalesce(array_agg(id), '{}') INTO tenants FROM tn_tenant;
                    PERFORM set_config('app.tenant_enumeration', '', true);
                    FOREACH t IN ARRAY tenants LOOP
                        PERFORM set_config('app.tenant_id', t::text, true);
                        UPDATE ord_patient SET sex = CASE gender_id WHEN '01f0eff5-a698-4873-a45b-ad034a386d08' THEN 'female' WHEN '07b60329-7282-4262-9409-b24ea4440428' THEN 'male' ELSE 'unknown' END WHERE tenant_id = t;
                        UPDATE id_membership m SET position_name = s.position_name, department_id = e.department_id FROM org_employee e JOIN lab_employee_settings s ON s.employee_id = e.id WHERE e.id = m.id::text AND m.tenant_id = t AND e.tenant_id = t;
                        INSERT INTO ord_patient_insurance (id, patient_card_id, payer_id, policy_number, valid_from, valid_to, note, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id)
                        SELECT i.id::uuid, i.patient_card_id, i.payer_id, i.policy_number, i.valid_from, i.valid_to, i.note, i.is_active, i.created_on, i.created_by, i.modified_on, i.modified_by, i.record_state, i.tenant_id FROM mis_patient_insurance i WHERE i.tenant_id = t;
                    END LOOP;
                    PERFORM set_config('app.tenant_id', '', true);
                END
                $$;
                """);

            foreach (var table in new[] { "ord_patient_identifier", "ord_order_identifier", "ord_requester", "ord_patient_insurance", "id_role", "id_role_permission", "id_membership_role" })
                Data.MigrationHelpers.EnableRls(migrationBuilder, table);
            migrationBuilder.Sql("GRANT SELECT, INSERT, UPDATE, DELETE ON id_user, id_permission, id_role, id_role_permission, id_membership_role, ord_patient_identifier, ord_order_identifier, ord_requester, ord_patient_insurance TO lab_app;");
            migrationBuilder.Sql("""
                DO $$
                DECLARE t record;
                BEGIN
                    FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tableowner <> 'lab_migrator' LOOP
                        EXECUTE format('ALTER TABLE public.%I OWNER TO lab_migrator', t.tablename);
                    END LOOP;
                END
                $$;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("REVOKE ALL ON id_user, id_permission, id_role, id_role_permission, id_membership_role, ord_patient_identifier, ord_order_identifier, ord_requester, ord_patient_insurance FROM lab_app;");
            foreach (var table in new[] { "ord_patient_identifier", "ord_order_identifier", "ord_requester", "ord_patient_insurance", "id_role", "id_role_permission", "id_membership_role" })
                Data.MigrationHelpers.DisableRls(migrationBuilder, table);

            migrationBuilder.DropForeignKey(
                name: "fk_id_membership_department_id",
                table: "id_membership");

            migrationBuilder.DropForeignKey(
                name: "fk_lab_order_requester_id",
                table: "lab_order");

            migrationBuilder.DropTable(
                name: "id_membership_role");

            migrationBuilder.DropTable(
                name: "id_role_permission");

            migrationBuilder.DropTable(
                name: "id_user");

            migrationBuilder.DropTable(
                name: "ord_order_identifier");

            migrationBuilder.DropTable(
                name: "ord_patient_identifier");

            migrationBuilder.DropTable(
                name: "ord_patient_insurance");

            migrationBuilder.DropTable(
                name: "ord_requester");

            migrationBuilder.DropTable(
                name: "id_permission");

            migrationBuilder.DropTable(
                name: "id_role");

            migrationBuilder.DropIndex(
                name: "ix_lab_order_requester_id",
                table: "lab_order");

            migrationBuilder.DropIndex(
                name: "ix_id_membership_department_id",
                table: "id_membership");

            migrationBuilder.DropColumn(
                name: "sex",
                table: "ord_patient");

            migrationBuilder.DropColumn(
                name: "requester_id",
                table: "lab_order");

            migrationBuilder.DropColumn(
                name: "department_id",
                table: "id_membership");

            migrationBuilder.DropColumn(
                name: "position_name",
                table: "id_membership");
        }
    }
}
