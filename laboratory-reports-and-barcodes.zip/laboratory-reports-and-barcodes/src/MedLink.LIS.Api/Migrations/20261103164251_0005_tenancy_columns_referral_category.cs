﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MedLink.LIS.Api.Migrations
{
    /// <inheritdoc />
    public partial class _0005_tenancy_columns_referral_category : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "logo_url",
                table: "tn_requisites",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "date_format",
                table: "tn_settings",
                type: "character varying(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "status_color_markers",
                table: "tn_settings",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "criticality_color_markers",
                table: "tn_settings",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "default_form_language",
                table: "tn_settings",
                type: "character varying(8)",
                maxLength: 8,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "time_zone",
                table: "tn_tenant",
                type: "character varying(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "Europe/Kyiv");

            migrationBuilder.AddColumn<DateTime>(
                name: "created_at",
                table: "tn_tenant",
                type: "timestamp with time zone",
                nullable: false,
                defaultValueSql: "now()");

            migrationBuilder.AddColumn<DateTime>(
                name: "created_at",
                table: "id_membership",
                type: "timestamp with time zone",
                nullable: false,
                defaultValueSql: "now()");

            migrationBuilder.AddColumn<Guid>(
                name: "role_id",
                table: "id_membership",
                type: "uuid",
                nullable: true);

            var roleCaptions = string.Join(" ", System.Linq.Enumerable.Select(MedLink.LIS.Api.Data.Seed.RightsSeedHelper.Security.LabRoles, r => $"WHEN '{r.Code.Replace("'", "''")}' THEN '{r.Caption.Replace("'", "''")}'"));
            var activeState = (int)global::Core.Base.Data.RecordState.Active;
            migrationBuilder.Sql($$"""
                DO $$
                DECLARE tenants uuid[];
                DECLARE t uuid;
                BEGIN
                    PERFORM set_config('app.tenant_enumeration', 'on', true);
                    SELECT coalesce(array_agg(id), '{}') INTO tenants FROM tn_tenant;
                    PERFORM set_config('app.tenant_enumeration', '', true);
                    FOREACH t IN ARRAY tenants LOOP
                        PERFORM set_config('app.tenant_id', t::text, true);
                        UPDATE id_membership m SET role_id = x.role_id::uuid
                        FROM (
                            SELECT s.employee_id, min(pr.role_id) AS role_id
                            FROM lab_employee_settings s
                            JOIN sys_profile p ON p.caption = CASE s.lab_role {{roleCaptions}} END AND p.record_state = {{activeState}}
                            JOIN sys_profile_role pr ON pr.profile_id = p.id AND pr.record_state = {{activeState}}
                            WHERE s.tenant_id = t
                            GROUP BY s.employee_id
                            HAVING count(*) = 1
                        ) x
                        WHERE x.employee_id = m.id::text AND m.tenant_id = t;
                    END LOOP;
                    PERFORM set_config('app.tenant_id', '', true);
                END
                $$;
                """);

            migrationBuilder.Sql("ALTER TABLE id_membership ALTER COLUMN role_id SET NOT NULL;");

            foreach (var table in new[] { "tn_tenant", "tn_settings", "tn_requisites", "id_membership", "id_membership_division" })
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN created_on SET DEFAULT now();");
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN record_state SET DEFAULT {MedLink.LIS.Api.Data.Entities.RecordStates.Active};");
            }

            migrationBuilder.CreateTable(
                name: "ehe_medical_referral_category",
                columns: table => new
                {
                    id = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    code = table.Column<string>(type: "text", nullable: true),
                    name = table.Column<string>(type: "text", nullable: true),
                    ehealth_code = table.Column<string>(type: "text", nullable: true),
                    is_used_in_ehealth = table.Column<bool>(type: "boolean", nullable: false),
                    tenant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    created_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    created_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    modified_on = table.Column<DateTime>(type: "timestamp without time zone", nullable: true),
                    modified_by = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    record_state = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ehe_medical_referral_category", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "ix_ehe_medical_referral_category_tenant_id",
                table: "ehe_medical_referral_category",
                column: "tenant_id");

            Data.MigrationHelpers.EnableRls(migrationBuilder, "ehe_medical_referral_category");
            migrationBuilder.Sql("GRANT SELECT, INSERT, UPDATE, DELETE ON ehe_medical_referral_category TO lab_app;");
            migrationBuilder.Sql("ALTER TABLE ehe_medical_referral_category OWNER TO lab_migrator;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            Data.MigrationHelpers.DisableRls(migrationBuilder, "ehe_medical_referral_category");

            migrationBuilder.DropTable(
                name: "ehe_medical_referral_category");

            foreach (var table in new[] { "tn_tenant", "tn_settings", "tn_requisites", "id_membership", "id_membership_division" })
            {
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN created_on DROP DEFAULT;");
                migrationBuilder.Sql($"ALTER TABLE {table} ALTER COLUMN record_state DROP DEFAULT;");
            }

            migrationBuilder.DropColumn(
                name: "role_id",
                table: "id_membership");

            migrationBuilder.DropColumn(
                name: "created_at",
                table: "id_membership");

            migrationBuilder.DropColumn(
                name: "created_at",
                table: "tn_tenant");

            migrationBuilder.DropColumn(
                name: "time_zone",
                table: "tn_tenant");

            migrationBuilder.DropColumn(
                name: "default_form_language",
                table: "tn_settings");

            migrationBuilder.DropColumn(
                name: "criticality_color_markers",
                table: "tn_settings");

            migrationBuilder.DropColumn(
                name: "status_color_markers",
                table: "tn_settings");

            migrationBuilder.DropColumn(
                name: "date_format",
                table: "tn_settings");

            migrationBuilder.DropColumn(
                name: "logo_url",
                table: "tn_requisites");
        }
    }
}
