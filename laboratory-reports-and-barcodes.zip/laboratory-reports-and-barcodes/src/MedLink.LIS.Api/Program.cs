// =============================================================================
// MedLink LIS 4.0 — ASP.NET Core 8 Web API (PostgreSQL, EF Core 8). Автентифікація та профілі:
// гібридний JWT/introspection + Redis, ApiAuthorizationFilter на всіх контролерах.
// =============================================================================
using System.Text.Json.Serialization;
using Core.Security.Models;
using Core.Services;
using Core.Services.DistributedCacheService;
using Core.ThirdParty.Redis;
using MedLink.LIS.Api.Configuration;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Filters;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Services.ApplicationServices;
using MedLink.LIS.Api.Services.Parsing;
using MedLink.LIS.Api.Tenancy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

static string ConnectionString(IConfiguration cfg) => cfg.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("ConnectionStrings:DefaultConnection is not configured.");
builder.Services.AddSingleton<ITenantContext, TenantContext>();
builder.Services.AddSingleton<IDivisionContext, DivisionContext>();
builder.Services.AddDbContext<LisDbContext>((sp, o) => o.UseNpgsql(ConnectionString(sp.GetRequiredService<IConfiguration>())));

builder.Services.AddMemoryCache();
builder.Services.AddStackExchangeRedisCache(o => o.Configuration = builder.Configuration.GetConnectionString("Redis"));
builder.Services.AddHttpContextAccessor();
builder.Services.AddHybridJwtAndReferenceTokenAuthentication(builder.Configuration);
ConfigureCors(builder.Services, builder.Configuration);
builder.Services.AddAuthorization();
builder.Services.AddSingleton<IRedisDatabaseProvider, RedisDatabaseProvider>();
builder.Services.AddScoped<IDistributedCacheService, DistributedCacheService>();
builder.Services.AddScoped<ISecurityDbContext>(sp => sp.GetRequiredService<LisDbContext>());
builder.Services.AddScoped<IUserInfoService, UserInfoService>();
builder.Services.AddScoped<AccountService>();

// --- MVC / JSON / ProblemDetails ---
builder.Services.AddControllers(o => o.Filters.Add<ApiAuthorizationFilter>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
    })
    .ConfigureApiBehaviorOptions(o =>
    {
        o.InvalidModelStateResponseFactory = ctx =>
        {
            var errors = ctx.ModelState.Where(kv => kv.Value?.Errors.Count > 0)
                .ToDictionary(kv => kv.Key, kv => kv.Value!.Errors.Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? "Некоректне значення" : e.ErrorMessage).ToArray());
            var pd = new ProblemDetails { Type = "https://httpstatuses.com/400", Title = "Помилка валідації", Status = 400, Detail = "Перевірте поля запиту", Instance = ctx.HttpContext.Request.Path };
            pd.Extensions["errors"] = errors;
            return new BadRequestObjectResult(pd) { ContentTypes = { "application/problem+json" } };
        };
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "MedLink LIS 4.0 API",
        Version = "v1",
        Description = "Лабораторна інформаційна система для МІС MedLink (evomis): замовлення, проби, робочий лист, каскад норм Simplex, ВКЯ (Вестгард), коннектор аналізаторів, біобанк, мікробіологія (EUCAST), аналітика TAT. Вхід — через сервер ідентифікації (Authorization: Bearer), далі вибір профілю: /api/account/try-authenticate/ або /api/account/authenticate/. Коннектор — X-MedLink-ApiKey."
    });
    c.OperationFilter<SwaggerHeaderFilter>();
    var xml = Path.Combine(AppContext.BaseDirectory, "MedLink.LIS.Api.xml");
    if (File.Exists(xml)) c.IncludeXmlComments(xml, true);
    c.CustomSchemaIds(t => t.FullName!.Replace("+", "."));
});

// --- Сервіси домену ---
builder.Services.AddScoped<ICurrentEmployee, CurrentEmployee>();
builder.Services.AddScoped<IRolePolicy, RolePolicy>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<INumeratorService, NumeratorService>();
builder.Services.AddScoped<OrderStateService>();
builder.Services.AddScoped<TubePlanService>();
builder.Services.AddScoped<OrgDictionaryService>();
builder.Services.AddScoped<SendOutService>();
// --- ЕСОЗ (eHealth): реальні виклики API; у режимі Mock відповідає EhealthMockHandler (автономна робота й тести) ---
var ehealthOptions = builder.Configuration.GetSection("Ehealth").Get<MedLink.LIS.Api.Services.Ehealth.EhealthOptions>() ?? new();
builder.Services.AddSingleton(ehealthOptions);
builder.Services.AddSingleton<MedLink.LIS.Api.Services.Ehealth.EhealthMockState>();
builder.Services.AddTransient<MedLink.LIS.Api.Services.Ehealth.EhealthMockHandler>();
var ehealthHttp = builder.Services.AddHttpClient(MedLink.LIS.Api.Services.Ehealth.EhealthClient.HttpClientName, c =>
{
    c.BaseAddress = new Uri(ehealthOptions.BaseUrl.EndsWith('/') ? ehealthOptions.BaseUrl : ehealthOptions.BaseUrl + "/");
    c.Timeout = TimeSpan.FromSeconds(60);
});
if (ehealthOptions.IsMock) ehealthHttp.ConfigurePrimaryHttpMessageHandler<MedLink.LIS.Api.Services.Ehealth.EhealthMockHandler>();
builder.Services.AddScoped<MedLink.LIS.Api.Services.Ehealth.IEhealthClient, MedLink.LIS.Api.Services.Ehealth.EhealthClient>();
builder.Services.AddScoped<IEhealthReferralGateway, EhealthReferralGateway>();
builder.Services.AddScoped<ReferralService>();
builder.Services.AddScoped<BillingService>();
builder.Services.AddScoped<ClientService>();
builder.Services.AddScoped<OrderService>();
builder.Services.AddScoped<SampleService>();
builder.Services.AddScoped<ResultPipelineService>();
builder.Services.AddScoped<WorklistService>();
builder.Services.AddScoped<QcService>();
builder.Services.AddScoped<ConnectorService>();
builder.Services.AddScoped<ConnectorApiKeyFilter>();
builder.Services.AddScoped<AnalyzerService>();
builder.Services.AddScoped<LogisticsService>();
builder.Services.AddScoped<BiobankService>();
builder.Services.AddScoped<ReagentService>();
builder.Services.AddScoped<MicrobiologyService>();
builder.Services.AddScoped<AnalyticsService>();
builder.Services.AddScoped<ReportService>();
builder.Services.AddScoped<LabelPdfService>();
builder.Services.AddScoped<ImportService>();
builder.Services.AddScoped<PatientService>();
builder.Services.AddScoped<SettingsService>();
builder.Services.AddScoped<DictionaryService>();
builder.Services.AddScoped<SectionJournalService>();
builder.Services.AddScoped<ProgressiveReleaseService>();
builder.Services.AddScoped<SampleProcessingService>();
builder.Services.AddScoped<OrderMatrixService>();
builder.Services.AddScoped<SeedService>();
builder.Services.AddScoped<DemoDataSeeder>();
// Парсер повідомлень аналізаторів: локальна реалізація; замінюється на MedLink.LIS.Core.Protocols однією реєстрацією
builder.Services.AddSingleton<IAnalyzerMessageParser, AnalyzerMessageParserFallback>();
builder.Services.AddSingleton<RetentionCleanupService>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<RetentionCleanupService>());

var app = builder.Build();

// --- Експорт DDL PostgreSQL для перенесення в MedLink: --export-pg-ddl <файл> (без запуску сервера) ---
var ddlArg = Array.IndexOf(args, "--export-pg-ddl");
if (ddlArg >= 0)
{
    using var ddlScope = app.Services.CreateScope();
    var target = ddlArg + 1 < args.Length ? args[ddlArg + 1] : "medlink_lis_schema.sql";
    Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(target))!);
    File.WriteAllText(target, PostgresDdlGenerator.Generate(ddlScope.ServiceProvider.GetRequiredService<LisDbContext>()), new System.Text.UTF8Encoding(false));
    Console.WriteLine($"DDL PostgreSQL збережено: {Path.GetFullPath(target)}");
    return;
}

// --- Сід (ідемпотентно, лише порожні таблиці) ---
using (var scope = app.Services.CreateScope())
{
    var seedDb = scope.ServiceProvider.GetRequiredService<LisDbContext>();
    var tenantIds = await seedDb.Tenants.AsNoTracking().Select(t => t.Id).ToListAsync();
    var seedTenantId = tenantIds.Count switch
    {
        1 => tenantIds[0],
        0 => MedLink.LIS.Api.Data.Entities.UuidV7.New(),
        _ => throw new InvalidOperationException($"tn_tenant: очікувався один рядок, знайдено {tenantIds.Count}")
    };
    await seedDb.RunAsTenantAsync(seedTenantId, () => scope.ServiceProvider.GetRequiredService<SeedService>().SeedAsync());
    if (app.Configuration.GetValue<bool?>("Lab:SeedDemoData") ?? true)
    {
        try { await seedDb.RunAsTenantAsync(seedTenantId, () => scope.ServiceProvider.GetRequiredService<DemoDataSeeder>().SeedAsync()); }
        catch (Exception ex) { app.Logger.LogError(ex, "Помилка створення демо-даних"); }
    }
}

app.UseMiddleware<ProblemDetailsMiddleware>();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseSwagger();
app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "MedLink LIS 4.0 API v1"); c.RoutePrefix = "swagger"; c.DocumentTitle = "MedLink LIS 4.0 — API"; });
app.UseRouting();
app.UseCors(CorsPolicyName(app.Configuration));
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<TenantResolutionMiddleware>();
app.UseMiddleware<CurrentEmployeeMiddleware>();
app.MapControllers();

// Health
app.MapGet("/health", async (LisDbContext db) =>
{
    var ok = await db.Database.CanConnectAsync();
    return Results.Json(new { status = ok ? "Healthy" : "Unhealthy", db = ok ? "ok" : "error", version = "4.0.0", utc = DateTime.UtcNow }, statusCode: ok ? 200 : 503);
});

// Публічна сторінка верифікації бланка за QR (без ПІБ): /verify/{token}
app.MapGet("/verify/{token}", async (string token, OrderService orders) =>
{
    var result = await orders.VerifyByTokenAsync(token);
    var ok = result != null;
    var html = $"<!doctype html><html lang=\"uk\"><head><meta charset=\"utf-8\"><title>Перевірка бланка</title><style>body{{font-family:Arial,sans-serif;background:#f4f6f9;margin:0}}.c{{max-width:520px;margin:12vh auto;background:#fff;padding:28px 36px;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.08)}}h1{{color:{(ok ? "#15803d" : "#b91c1c")};font-size:20px}}</style></head><body><div class=\"c\"><h1>{(ok ? "Бланк автентичний ✔" : "Бланк не знайдено ✖")}</h1>" +
               (ok ? $"<p>Номер замовлення: <b>{System.Net.WebUtility.HtmlEncode(result!.GetType().GetProperty("orderNumber")!.GetValue(result)?.ToString())}</b><br>Видано: {result.GetType().GetProperty("releasedAt")!.GetValue(result)}<br>Лабораторія: {System.Net.WebUtility.HtmlEncode(result.GetType().GetProperty("lab")!.GetValue(result)?.ToString())}</p>" : "<p>Токен недійсний або результати ще не видано.</p>") +
               "</div></body></html>";
    return Results.Content(html, "text/html; charset=utf-8", statusCode: ok ? 200 : 404);
});

// SPA fallback: усе, що не /api, не /swagger і не файл → wwwroot/index.html; невідомі /api → 404 ProblemDetails
app.MapFallback(async ctx =>
{
    if (ctx.Request.Path.StartsWithSegments("/api"))
    {
        ctx.Response.StatusCode = 404;
        ctx.Response.ContentType = "application/problem+json; charset=utf-8";
        await ctx.Response.WriteAsJsonAsync(new ProblemDetails { Type = "https://httpstatuses.com/404", Title = "Не знайдено", Status = 404, Detail = $"Маршрут {ctx.Request.Path} не існує", Instance = ctx.Request.Path });
        return;
    }
    var index = Path.Combine(app.Environment.WebRootPath ?? Path.Combine(app.Environment.ContentRootPath, "wwwroot"), "index.html");
    if (File.Exists(index)) { ctx.Response.ContentType = "text/html; charset=utf-8"; await ctx.Response.SendFileAsync(index); }
    else { ctx.Response.StatusCode = 404; await ctx.Response.WriteAsync("Фронтенд не зібрано (wwwroot/index.html відсутній)"); }
});

var dbConnection = new Npgsql.NpgsqlConnectionStringBuilder(ConnectionString(app.Configuration));
app.Logger.LogInformation("MedLink LIS 4.0 API запущено. Swagger: /swagger · БД: {Db}", $"{dbConnection.Host}:{dbConnection.Port}/{dbConnection.Database}");
await app.RunAsync();

static string CorsPolicyName(IConfiguration cfg) => cfg.GetValue<string>("Cors:PolicyName") ?? "Default";

static void ConfigureCors(IServiceCollection services, IConfiguration cfg)
{
    services.AddCors();
    var cors = cfg.GetSection("Cors");
    var allowAnyOrigin = cors.GetValue<bool>("AllowAnyOrigin");
    var allowAnyMethod = cors.GetValue<bool>("AllowAnyMethod");
    var allowAnyHeader = cors.GetValue<bool>("AllowAnyHeader");
    var allowCredentials = cors.GetValue<bool>("AllowCredentials");
    var allowedOrigins = cfg.GetSection("Cors:AllowedOrigins").Get<string[]>()?.Where(o => !string.IsNullOrWhiteSpace(o)).ToArray();
    if (!allowAnyOrigin && (allowedOrigins == null || allowedOrigins.Length == 0)) return;
    services.AddCors(options => options.AddPolicy(CorsPolicyName(cfg), b =>
    {
        if (allowAnyOrigin) b.AllowAnyOrigin(); else b.WithOrigins(allowedOrigins!);
        if (allowAnyMethod) b.AllowAnyMethod();
        if (allowAnyHeader) b.AllowAnyHeader();
        if (allowCredentials) b.AllowCredentials();
        b.WithExposedHeaders(AuthenticationExtensions.IdentityChallengeHeader, "Content-Disposition", "X-MedLink-Pdf-Fallback");
    }));
}

/// <summary>Точка входу (для WebApplicationFactory в інтеграційних тестах).</summary>
public partial class Program { }
