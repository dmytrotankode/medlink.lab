# MedLink LIS 4.0 — Backend (ASP.NET Core 8, EF Core 8, PostgreSQL)

Лабораторна інформаційна система для МІС MedLink (evomis). Контракт: `docs/API_CONTRACT.md`.
Автентифікація: токен сервера ідентифікації (`Authorization: Bearer`, JWT або reference-токен через Redis/introspection),
далі вибір профілю безпеки (`/api/account/try-authenticate/` або `/api/account/authenticate/`). Поточний співробітник — співробітник
обраного профілю; без токена — 401, без профілю — 403. Роль (`lab_employee_settings.lab_role`) визначає дозволені дії (403 українською).
Коннектор — лише `X-MedLink-ApiKey`, без токена користувача.

## Запуск

```bash
dotnet run --project src/MedLink.LIS.Api            # http://0.0.0.0:5055 (Kestrel з appsettings.json)
dotnet run --project src/MedLink.LIS.Api --urls http://127.0.0.1:5055
```

- Swagger: `/swagger`, health: `/health`, SPA: `wwwroot/index.html` (fallback для не-`/api` шляхів), QR-верифікація бланка: `/verify/{token}`.
- Схема БД: міграції EF Core (`Migrations/`), окремий крок перед запуском: `dotnet tool restore && dotnet tool run dotnet-ef database update --project src/MedLink.LIS.Api` (так робить `run.sh`).
- При старті: ідемпотентний сід довідників (`db/seed/*.json`, вбудовані ресурси) + демо-дані (`Lab:SeedDemoData`).

## Конфігурація (`appsettings.json`)

| Ключ | Призначення |
|---|---|
| `ConnectionStrings:DefaultConnection` | PostgreSQL (локально `Host=localhost;Port=5434;Database=lis`) |
| `Identity:*` | сервер ідентифікації: `Authority` (локально `https://localhost:5001`), `JwtBearerAudience`, `UseRefreshTokenFlow`, `UseRedisActiveTokenValidation`, префікси ключів Redis, `RedisActiveTokenFallbackToIntrospection`, `IntrospectionClientId` (`MisApiScope`), `IntrospectionClientSecret` (у `appsettings.Development.json` або env `REFERENCE_TOKEN_API_SECRET`), `UserDataUri` |
| `ConnectionStrings:Redis`, `RedisConfiguration:*` | Redis (локально `localhost:6390`): активні токени `IDS:*` і кеш користувача/профілю |
| `Caching:UserInfo`, `Caching:Rights` | строк життя кешу користувача та прав, с (`null` — без обмеження) |
| `Cors:*` | CORS (`PolicyName` `AllowAll`, `AllowedOrigins`, серед них dev-сервер фронтенду http://localhost:8085) |
| `Lab:PublicBaseUrl` | база для QR-посилань та ZIP коннектора |
| `Lab:VerifySecret` | HMAC-секрет токена бланка |
| `Lab:SeedDemoData` | створювати демо-замовлення/ВКЯ/біобанк |
| `Lab:MessageRetentionDays`, `Lab:ConnectorLogRetentionDays`, `Lab:RetentionCleanupIntervalMinutes` | фонове очищення журналів (`RetentionCleanupService`) |

Ролі демо-співробітників: `0e000000-0000-0000-0000-00000000000{1..6}` = LAB_ADMIN, LAB_DOCTOR, LAB_TECHNICIAN, PHLEBOTOMIST, LOGISTICS_COURIER, REGISTRAR.
Локальний вхід: користувач identity-server `lab.admin@medlink.local` (`00000000-0000-4000-8000-00000000a001`) → профіль «Адміністратор лабораторії»
→ співробітник `…0001` (`db/seed/security.json`: `sys_profile`, `sys_user_profile`, `cmn_person.user_id`).
Коннектор демо: install key `DEMO-INSTALL-KEY-0001` → `POST /api/v1/lab/connector/register`.

## Де що лежить

- `Domain/LisStateMachine.cs` — **єдине визначення машини станів та рольових правил** (Order, Sample, OrderTest, Manifest, Culture, Connector); `Domain/RolePolicy.cs` — перевірка (409 статус / 403 роль), `allowedActions` у DTO, `GET /orders/{id}/transitions`.
- `Services/ResultPipelineService.cs` — єдиний конвеєр результатів (ручне введення, коннектор, імпорт): каскад норм → прапорець → delta-check → reflex → автоверифікація (lockout блокує) → історія/аудит → прогресивна видача (`ProgressiveReleaseService`).
- `Services/SectionJournalService.cs` — секції лабораторії, журнали відділень (нумерація за масками `{yyyy}-{seq6}`, `{yy}{MM}{dd}/{dayseq3}`, `S{yy}-{seq5}` через `lab_numerator`).
- `Services/SampleProcessingService.cs` — алікотування/касети/блоки/скельця (похідні штрихкоди), етапи обробки за шаблонами `lab_workflow_template`.
- `Services/Parsing/AnalyzerMessageParserFallback.cs` — локальний парсер ASTM/HL7 для `/analyzers/{id}/simulate`; замінюється реалізацією `MedLink.LIS.Core.Protocols` однією реєстрацією `IAnalyzerMessageParser` у `Program.cs`.
- `Data/LisDbContext.cs` — snake_case, GUID-рядки, службові колонки `created_on/created_by/modified_on/modified_by/record_state`; реалізує `ISecurityDbContext` (таблиці `sys_*` з app.core `Core.Security`; DbSet-и безпеки — `Data/DbContextSecurityPartial.cs`).
- Автентифікація: `Configuration/*` (`AddHybridJwtAndReferenceTokenAuthentication`, Redis active-token), `Filters/ApiAuthorizationFilter.cs`; `Services/ApplicationServices/AccountService.cs` + `Controllers/adm/AccountController.cs` — `api/account/*`; DTO — `Dto/Administration/*` (один клас на файл).
- Чисті правила: `src/MedLink.LIS.Core/Clinical/*` (NormsCascadeResolver, ResultFlagger, DeltaCheckEvaluator, AutoVerificationEngine, ReflexRuleEngine, WestgardEvaluator, QcStatistics, EucastInterpreter, TatCalculator), `Core/Barcodes/*` (TubeBarcodeGenerator — Simplex gen_lab_tube_barcode, Code128Svg, ZplLabelBuilder, QrSvg), `Core/Common/TransliterationKmu2010`.

## Перехід в evomis / PostgreSQL

1. Провайдер — `Npgsql.EntityFrameworkCore.PostgreSQL` (`UseNpgsql`); DDL для перенесення — `db/postgres`.
2. Mirror-сутності (`MisPatientCard`, `MisSpecimen`, `MisDiagnosticReport`, `OrgEmployee`, `OrgDepartment`, `EheIncomingMedicalReferral`, `DctService`) вказують на реальні таблиці evomis — лишити `[Table]`, прибрати їх із сідера (`Data/Seed/SeedService.SeedOrgAsync`).
3. `LabTestProfile.MisServiceId` → `dct_service.id`: код/назва/ціна беруться з МІС (`GET /norms/service-card/{id}`), ЛІС зберігає лише лабораторні атрибути.
4. Схема — міграції EF Core (`Migrations/`).
