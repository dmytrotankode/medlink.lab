// Аналітика: TAT (медіана/P90 за етапами, профілями, CITO, SLA), обсяги, експорт XLSX
using System.Text.Json;
using System.Text.Json.Nodes;
using ClosedXML.Excel;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Core.Clinical;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace MedLink.LIS.Api.Services;

public sealed class AnalyticsService
{
    private static readonly string[] ResultAuditEntities = { "lab_test_result", "lab_panic_call", "lab_unmatched_result", "lab_culture_order", "lab_isolate", "lab_susceptibility_result", "lab_order_attachment" };
    private const string TestAuditEntity = "lab_order_test";
    private static readonly string[] OrderAuditEntities = { "lab_order", "lab_order_sample", "lab_sample_stage_event", "lab_send_out", "lab_send_out_item", "ehe_incoming_medical_referral" };
    private static readonly string[] FreeTextKeys = { "reason", "comment", "note", "notes", "description" };
    private readonly LisDbContext _db;
    private readonly IRolePolicy _policy;
    public AnalyticsService(LisDbContext db, IRolePolicy policy) { _db = db; _policy = policy; }

    static AnalyticsService()
    {
        QuestPDF.Settings.License = LicenseType.Community;
    }

    private sealed record OrderTat(string OrderId, string OrderNumber, bool Cito, string? ProfileId, string? ProfileName, int SlaHours, TatBreakdown Tat);

    private async Task<List<OrderTat>> CollectAsync(DateTime from, DateTime to, string? profileId, bool? cito)
    {
        var orders = await _db.Orders.AsNoTracking()
            .Include(o => o.Samples).Include(o => o.Tests).ThenInclude(t => t.Result).Include(o => o.Tests).ThenInclude(t => t.Profile)
            .Where(o => o.OrderDatetime >= from && o.OrderDatetime <= to && o.Status != OrderStatuses.Cancelled && (cito == null || o.IsUrgentCito == cito))
            .ToListAsync();
        var list = new List<OrderTat>();
        foreach (var o in orders)
        {
            var profiles = o.Tests.Where(t => t.Profile != null).Select(t => t.Profile!).DistinctBy(p => p.Id).ToList();
            if (profileId != null && profiles.All(p => p.Id != profileId && p.Code != profileId)) continue;
            var main = profiles.OrderBy(p => p.TurnaroundHours).FirstOrDefault();
            var results = o.Tests.Where(t => t.Result != null).Select(t => t.Result!).ToList();
            var tat = TatCalculator.Compute(new TatTimestamps
            {
                OrderedAt = o.OrderDatetime,
                CollectedAt = o.Samples.Where(s => s.CollectedAt != null).Select(s => s.CollectedAt).Min(),
                ReceivedAt = o.Samples.Where(s => s.ReceivedAt != null).Select(s => s.ReceivedAt).Min(),
                ResultedAt = results.Count == 0 ? null : results.Max(r => r.EnteredAt),
                VerifiedAt = results.Any(r => r.VerifiedAt != null) ? results.Where(r => r.VerifiedAt != null).Max(r => r.VerifiedAt) : null,
                ReleasedAt = o.ReleasedAt
            });
            list.Add(new OrderTat(o.Id, o.OrderNumber, o.IsUrgentCito, main?.Id, main?.Name, o.IsUrgentCito ? Math.Min(main?.TurnaroundHours ?? 2, 2) : main?.TurnaroundHours ?? 24, tat));
        }
        return list;
    }

    public async Task<object> TatAsync(DateTime? from, DateTime? to, string? profileId, bool? cito)
    {
        var f = from ?? DateTime.UtcNow.AddDays(-30); var t = to ?? DateTime.UtcNow;
        var data = await CollectAsync(f, t, profileId, cito);
        var totals = data.Where(d => d.Tat.TotalMinutes.HasValue).Select(d => d.Tat.TotalMinutes!.Value).ToList();
        var stages = TatCalculator.StageNames.Select(name =>
        {
            var vals = data.Select(d => d.Tat.Stages.First(s => s.Name == name).Minutes).Where(m => m.HasValue).Select(m => m!.Value).ToList();
            return new { name, medianMin = Round(TatCalculator.Median(vals)), p90Min = Round(TatCalculator.P90(vals)), n = vals.Count };
        }).ToList();
        var byProfile = data.Where(d => d.ProfileName != null).GroupBy(d => new { d.ProfileId, d.ProfileName, d.SlaHours }).Select(g =>
        {
            var vals = g.Where(d => d.Tat.TotalMinutes.HasValue).Select(d => d.Tat.TotalMinutes!.Value).ToList();
            return new { profileId = g.Key.ProfileId, profileName = g.Key.ProfileName, slaHours = g.Key.SlaHours, n = g.Count(), completed = vals.Count, medianMin = Round(TatCalculator.Median(vals)), p90Min = Round(TatCalculator.P90(vals)), slaViolations = vals.Count(v => v > g.Key.SlaHours * 60) };
        }).OrderBy(x => x.profileName).ToList();
        var violations = data.Where(d => d.Tat.TotalMinutes.HasValue && d.Tat.TotalMinutes > d.SlaHours * 60)
            .Select(d => new { d.OrderId, d.OrderNumber, d.Cito, d.ProfileName, slaHours = d.SlaHours, totalMin = d.Tat.TotalMinutes, overMin = Math.Round(d.Tat.TotalMinutes!.Value - d.SlaHours * 60) }).ToList();
        var citoVals = data.Where(d => d.Cito && d.Tat.TotalMinutes.HasValue).Select(d => d.Tat.TotalMinutes!.Value).ToList();
        var routineVals = data.Where(d => !d.Cito && d.Tat.TotalMinutes.HasValue).Select(d => d.Tat.TotalMinutes!.Value).ToList();
        return new
        {
            from = f, to = t, orders = data.Count, completed = totals.Count, medianMin = Round(TatCalculator.Median(totals)), p90Min = Round(TatCalculator.P90(totals)),
            cito = new { n = citoVals.Count, medianMin = Round(TatCalculator.Median(citoVals)), p90Min = Round(TatCalculator.P90(citoVals)) },
            routine = new { n = routineVals.Count, medianMin = Round(TatCalculator.Median(routineVals)), p90Min = Round(TatCalculator.P90(routineVals)) },
            stages, byProfile, slaViolations = violations.Count, slaViolationOrders = violations,
            waterfall = TatCalculator.StageNames.Select(name => new { stage = name, medianMin = stages.First(s => s.name == name).medianMin })
        };
    }

    private static double? Round(double? v) => v.HasValue ? Math.Round(v.Value, 1) : null;

    public async Task<object> VolumeAsync(DateTime? from, DateTime? to, string groupBy)
    {
        var f = from ?? DateTime.UtcNow.AddDays(-30); var t = to ?? DateTime.UtcNow;
        var tests = await _db.OrderTests.AsNoTracking().Include(x => x.Order).Include(x => x.Profile).Include(x => x.Result).ThenInclude(r => r!.Analyzer)
            .Where(x => x.Order!.OrderDatetime >= f && x.Order.OrderDatetime <= t && x.Order.Status != OrderStatuses.Cancelled).ToListAsync();
        var employees = await _db.Employees.AsNoTracking().ToDictionaryAsync(e => e.Id, e => e.Caption ?? "");
        IEnumerable<IGrouping<string, LabOrderTest>> groups = groupBy.ToLowerInvariant() switch
        {
            "analyzer" => tests.GroupBy(x => x.Result?.Analyzer?.Name ?? "Ручне введення"),
            "employee" => tests.GroupBy(x => x.Result?.VerifiedById != null && employees.TryGetValue(x.Result.VerifiedById, out var n) ? n : x.Result?.IsAutoVerified == true ? "Автоверифікація" : "—"),
            "day" => tests.GroupBy(x => x.Order!.OrderDatetime.ToString("yyyy-MM-dd")),
            "test" => tests.GroupBy(x => x.TestCode),
            "department" => tests.GroupBy(x => x.Order!.DepartmentId ?? "—"),
            _ => tests.GroupBy(x => x.Profile?.Name ?? "Окремі тести")
        };
        var canReadResults = DtoMapper.CanReadResults(_policy);
        var rows = groups.OrderByDescending(g => g.Count()).Select(g =>
        {
            var row = new Dictionary<string, object>
            {
                ["key"] = g.Key, ["tests"] = g.Count(), ["orders"] = g.Select(x => x.OrderId).Distinct().Count(), ["resulted"] = g.Count(x => x.Result != null),
                ["verified"] = g.Count(x => OrderTestStatuses.VerifiedAny.Contains(x.Status)), ["autoVerified"] = g.Count(x => x.Result?.IsAutoVerified == true)
            };
            if (canReadResults)
            {
                row["critical"] = g.Count(x => x.Result != null && ResultFlags.IsCritical(x.Result.Flag));
                row["abnormal"] = g.Count(x => x.Result != null && ResultFlags.IsAbnormal(x.Result.Flag));
            }
            row["cito"] = g.Count(x => x.Order!.IsUrgentCito);
            row["revenue"] = g.Where(x => x.ProfileId == null).Sum(x => (decimal?)0) ?? 0;
            return row;
        }).ToList();
        var revenue = await _db.Orders.AsNoTracking().Where(o => o.OrderDatetime >= f && o.OrderDatetime <= t && o.Status != OrderStatuses.Cancelled).SumAsync(o => o.TotalPrice);
        return new { from = f, to = t, groupBy, totalTests = tests.Count, totalOrders = tests.Select(x => x.OrderId).Distinct().Count(), totalRevenue = revenue, rows };
    }

    public async Task<byte[]> ExportXlsxAsync(string report, DateTime? from, DateTime? to)
    {
        var f = from ?? DateTime.UtcNow.AddDays(-30); var t = to ?? DateTime.UtcNow;
        using var wb = new XLWorkbook();
        switch (report.ToLowerInvariant())
        {
            case "tat":
            {
                var data = await CollectAsync(f, t, null, null);
                var ws = wb.AddWorksheet("TAT");
                var headers = new[] { "Замовлення", "CITO", "Профіль", "SLA, год" }.Concat(TatCalculator.StageNames).Concat(new[] { "Всього, хв", "Порушення SLA" }).ToArray();
                for (var i = 0; i < headers.Length; i++) ws.Cell(1, i + 1).Value = headers[i];
                var row = 2;
                foreach (var d in data)
                {
                    var c = 1;
                    ws.Cell(row, c++).Value = d.OrderNumber; ws.Cell(row, c++).Value = d.Cito ? "Так" : ""; ws.Cell(row, c++).Value = d.ProfileName ?? ""; ws.Cell(row, c++).Value = d.SlaHours;
                    foreach (var s in d.Tat.Stages) { if (s.Minutes.HasValue) ws.Cell(row, c).Value = s.Minutes.Value; c++; }
                    if (d.Tat.TotalMinutes.HasValue) ws.Cell(row, c).Value = d.Tat.TotalMinutes.Value; c++;
                    ws.Cell(row, c).Value = d.Tat.TotalMinutes > d.SlaHours * 60 ? "Так" : "";
                    row++;
                }
                break;
            }
            case "volume":
            {
                var ws = wb.AddWorksheet("Обсяги");
                var tests = await _db.OrderTests.AsNoTracking().Include(x => x.Order).Include(x => x.Profile).Include(x => x.Result).ThenInclude(r => r!.Analyzer)
                    .Where(x => x.Order!.OrderDatetime >= f && x.Order.OrderDatetime <= t && x.Order.Status != OrderStatuses.Cancelled).ToListAsync();
                var canReadResults = DtoMapper.CanReadResults(_policy);
                var headers = canReadResults
                    ? new[] { "Профіль", "Тест", "Кількість", "З результатом", "Верифіковано", "Автоверифіковано", "Критичних", "CITO" }
                    : new[] { "Профіль", "Тест", "Кількість", "З результатом", "Верифіковано", "Автоверифіковано", "CITO" };
                for (var i = 0; i < headers.Length; i++) ws.Cell(1, i + 1).Value = headers[i];
                var row = 2;
                foreach (var g in tests.GroupBy(x => new { profile = x.Profile?.Name ?? "Окремі тести", x.TestCode }).OrderBy(g => g.Key.profile).ThenBy(g => g.Key.TestCode))
                {
                    var c = 1;
                    ws.Cell(row, c++).Value = g.Key.profile; ws.Cell(row, c++).Value = g.Key.TestCode; ws.Cell(row, c++).Value = g.Count(); ws.Cell(row, c++).Value = g.Count(x => x.Result != null);
                    ws.Cell(row, c++).Value = g.Count(x => OrderTestStatuses.VerifiedAny.Contains(x.Status)); ws.Cell(row, c++).Value = g.Count(x => x.Result?.IsAutoVerified == true);
                    if (canReadResults) ws.Cell(row, c++).Value = g.Count(x => x.Result != null && ResultFlags.IsCritical(x.Result.Flag));
                    ws.Cell(row, c).Value = g.Count(x => x.Order!.IsUrgentCito);
                    row++;
                }
                break;
            }
            case "qc":
            {
                var ws = wb.AddWorksheet("ВКЯ");
                var results = await _db.QcResults.AsNoTracking().Include(r => r.Material).ThenInclude(m => m!.Analyzer).Where(r => r.RunAt >= f && r.RunAt <= t).OrderBy(r => r.RunAt).ToListAsync();
                var headers = new[] { "Дата", "Аналізатор", "Матеріал", "Лот", "Тест", "Значення", "Ціль", "SD", "z", "Правила", "Lockout" };
                for (var i = 0; i < headers.Length; i++) ws.Cell(1, i + 1).Value = headers[i];
                var row = 2;
                foreach (var r in results)
                {
                    ws.Cell(row, 1).Value = r.RunAt; ws.Cell(row, 2).Value = r.Material?.Analyzer?.Name ?? ""; ws.Cell(row, 3).Value = r.Material?.Name ?? ""; ws.Cell(row, 4).Value = r.Material?.LotNumber ?? "";
                    ws.Cell(row, 5).Value = r.TestCode; ws.Cell(row, 6).Value = r.MeasuredValue; ws.Cell(row, 7).Value = r.TargetMean; ws.Cell(row, 8).Value = r.TargetSd; ws.Cell(row, 9).Value = r.ZScore;
                    ws.Cell(row, 10).Value = string.Join(",", r.ViolatedRules); ws.Cell(row, 11).Value = r.LockoutEnforced ? "Так" : "";
                    row++;
                }
                break;
            }
            default:
            {
                var ws = wb.AddWorksheet("Замовлення");
                var orders = await _db.Orders.AsNoTracking().Include(o => o.Patient).Include(o => o.Department).Include(o => o.Tests)
                    .Where(o => o.OrderDatetime >= f && o.OrderDatetime <= t).OrderBy(o => o.OrderDatetime).ToListAsync();
                var headers = new[] { "Номер", "Дата", "Пацієнт", "Стать", "Дата народження", "Підрозділ", "Статус", "CITO", "Тестів", "Сума" };
                for (var i = 0; i < headers.Length; i++) ws.Cell(1, i + 1).Value = headers[i];
                var row = 2;
                foreach (var o in orders)
                {
                    ws.Cell(row, 1).Value = o.OrderNumber; ws.Cell(row, 2).Value = o.OrderDatetime; ws.Cell(row, 3).Value = o.Patient?.Caption ?? ""; ws.Cell(row, 4).Value = o.Patient?.Gender ?? "";
                    if (o.Patient?.Birthday != null) ws.Cell(row, 5).Value = o.Patient.Birthday.Value;
                    ws.Cell(row, 6).Value = o.Department?.Name ?? ""; ws.Cell(row, 7).Value = o.Status; ws.Cell(row, 8).Value = o.IsUrgentCito ? "Так" : ""; ws.Cell(row, 9).Value = o.Tests.Count; ws.Cell(row, 10).Value = o.TotalPrice;
                    row++;
                }
                break;
            }
        }
        foreach (var ws in wb.Worksheets) { ws.Row(1).Style.Font.Bold = true; ws.SheetView.FreezeRows(1); }
        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    public async Task<byte[]> ExportCsvAsync(string report, DateTime? from, DateTime? to)
    {
        var rows = await ExportRowsAsync(report, from, to);
        var csv = string.Join("\r\n", rows.Select(row => string.Join(",", row.Select(EscapeCsv))));
        return new System.Text.UTF8Encoding(true).GetBytes(csv);
    }

    public async Task<byte[]> ExportPdfAsync(string report, DateTime? from, DateTime? to)
    {
        var rows = await ExportRowsAsync(report, from, to);
        var columnCount = Math.Max(1, rows.Max(row => row.Length));
        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4.Landscape());
                page.Margin(12);
                page.DefaultTextStyle(style => style.FontSize(8).FontFamily("Lato"));
                page.Header().PaddingBottom(8).Text($"Звіт лабораторії: {report.ToUpperInvariant()}").FontSize(14).Bold();
                page.Content().Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        for (var i = 0; i < columnCount; i++) columns.RelativeColumn();
                    });
                    table.Header(header =>
                    {
                        foreach (var value in rows[0])
                            header.Cell().Background("#eef3f9").Border(0.5f).BorderColor("#bbb").Padding(3).Text(value).Bold();
                    });
                    foreach (var row in rows.Skip(1))
                    {
                        for (var i = 0; i < columnCount; i++)
                            table.Cell().Border(0.5f).BorderColor("#bbb").Padding(3).Text(i < row.Length ? row[i] : "");
                    }
                });
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("Сторінка ");
                    text.CurrentPageNumber();
                    text.Span(" з ");
                    text.TotalPages();
                });
            });
        });
        return document.GeneratePdf();
    }

    private async Task<List<string[]>> ExportRowsAsync(string report, DateTime? from, DateTime? to)
    {
        using var stream = new MemoryStream(await ExportXlsxAsync(report, from, to));
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet(1);
        var lastColumn = worksheet.LastColumnUsed()?.ColumnNumber() ?? 1;
        return worksheet.RowsUsed().Select(row => Enumerable.Range(1, lastColumn)
            .Select(column => row.Cell(column).GetFormattedString()).ToArray()).ToList();
    }

    private static string EscapeCsv(string value) => $"\"{value.Replace("\"", "\"\"")}\"";

    public async Task<PagedResult<LabAuditLog>> AuditAsync(string? entity, string? entityId, string? userId, string? action, DateTime? from, DateTime? to, PagingQuery paging)
    {
        var q = _db.AuditLog.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(entity)) q = q.Where(a => a.Entity == entity);
        if (!string.IsNullOrWhiteSpace(entityId)) q = q.Where(a => a.EntityId == entityId);
        if (!string.IsNullOrWhiteSpace(userId)) q = q.Where(a => a.UserId == userId);
        if (!string.IsNullOrWhiteSpace(action)) q = q.Where(a => a.Action == action);
        if (from.HasValue) q = q.Where(a => a.At >= from.Value);
        if (to.HasValue) q = q.Where(a => a.At <= to.Value);
        var page = await q.OrderByDescending(a => a.At).ToPagedAsync(paging);
        if (!DtoMapper.CanReadResults(_policy))
            foreach (var a in page.Items) HideResultContent(a);
        return page;
    }

    private static void HideResultContent(LabAuditLog a)
    {
        if (ResultAuditEntities.Contains(a.Entity))
        {
            a.BeforeJson = null; a.AfterJson = null; a.Comment = null;
        }
        else if (a.Entity == TestAuditEntity)
        {
            a.BeforeJson = StatusOnly(a.BeforeJson); a.AfterJson = StatusOnly(a.AfterJson); a.Comment = null;
        }
        else if (OrderAuditEntities.Contains(a.Entity))
        {
            a.BeforeJson = WithoutFreeText(a.BeforeJson); a.AfterJson = WithoutFreeText(a.AfterJson); a.Comment = null;
        }
    }

    private static JsonNode? ParseOrNull(string json)
    {
        try { return JsonNode.Parse(json); }
        catch (JsonException) { return null; }
    }

    private static string? StatusOnly(string? json)
    {
        if (string.IsNullOrEmpty(json) || ParseOrNull(json) is not JsonObject source) return null;
        var kept = new JsonObject();
        foreach (var (key, value) in source.Where(p => string.Equals(p.Key, "status", StringComparison.OrdinalIgnoreCase)).ToList())
            kept[key] = value?.DeepClone();
        return kept.Count == 0 ? null : kept.ToJsonString();
    }

    private static string? WithoutFreeText(string? json)
    {
        if (string.IsNullOrEmpty(json)) return json;
        var node = ParseOrNull(json);
        if (node == null) return null;
        RemoveFreeText(node);
        return node.ToJsonString();
    }

    private static void RemoveFreeText(JsonNode? node)
    {
        if (node is JsonObject o)
        {
            foreach (var key in o.Select(p => p.Key).Where(k => FreeTextKeys.Contains(k, StringComparer.OrdinalIgnoreCase)).ToList()) o.Remove(key);
            foreach (var (_, value) in o) RemoveFreeText(value);
        }
        else if (node is JsonArray arr)
            foreach (var item in arr) RemoveFreeText(item);
    }
}
