using System.Globalization;
using Core.Base.Exceptions;
using Core.Common.Attributes;
using Core.Common.Enums;
using Core.Common.Extensions;
using Core.Data;
using Core.Mvc.Helpers;
using Core.Services;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Dto.Administration;
using MedLink.LIS.Api.Dto.Ehealth.ehd.NotMappedDto;
using Microsoft.EntityFrameworkCore;
using CoreRecordState = Core.Base.Data.RecordState;
using SecurityProfile = Core.Security.Models.Profile;
using SecurityUserProfile = Core.Security.Models.UserProfile;

namespace MedLink.LIS.Api.Services.ApplicationServices;

public sealed class AccountService
{
    public const string UnauthorizedTitle = "Не авторизовано";
    public const string NotAuthenticatedMessage = "Користувач не аутентифікований";
    public const string PersonNotFoundMessage = "Користувач аутентифікований на сервері ідентифікації але не існує в системі";
    public const string EmployeeNotFoundMessage = "Для користувача не створено працівника для роботи в системі";
    public const string NoProfileMessage = "Користувачу не призначено профіль для входу в систему";
    public const string NoRoleProfileMessage = "Користувачу з поточним профілем eHealth не призначено профіль для входу в систему";
    public const string OrganizationRestrictedMessage = "Доступ для Вашої організації тимчасово обмежено. \n Для відновлення доступу зверніться, будь ласка, до особи у Вашому закладі, відповідальної за роботу системи.";

    private readonly LisDbContext _db;
    private readonly IUserInfoService _userService;
    private readonly ILogger<AccountService> _logger;

    public AccountService(LisDbContext db, IUserInfoService userService, ILogger<AccountService> logger)
    {
        _db = db;
        _userService = userService;
        _logger = logger;
    }

    public BaseUserInfo? CurrentUser => _userService.GetCurrentUserInfo();

    public async Task<object> AuthenticateAsync(Guid profileId, Guid userId, Guid? ehealthEmployeeId, Guid? specialityEhealthId, string? email, string? ehealthOrganizationTypeCode)
    {
        var user = await _userService.GetCurrentUserInfoAsync();
        if (string.IsNullOrEmpty(user?.Id))
        {
            _logger.LogError("Authentication error. User is not authenticated on Identity server. Parameters: profileId = {ProfileId}, userId = {UserId}", profileId, userId);
            throw new AppException(NotAuthenticatedMessage, UnauthorizedTitle);
        }

        var userProfileData = (await GetUserProfileLoginDataAsync(user.Id)).FirstOrDefault(x =>
            x.EhealthEmployeeId == ehealthEmployeeId &&
            x.EhealthSpecialityId == specialityEhealthId &&
            x.ProfileId == profileId &&
            x.UserId == userId &&
            (string.IsNullOrEmpty(ehealthOrganizationTypeCode) || x.EhealthOrganizationTypeCode == ehealthOrganizationTypeCode) &&
            x.IsActive);

        if (userProfileData == null)
        {
            _logger.LogError("Profile {ProfileId} of employee {EmployeeId} is not available for identity user {IdentityUserId}", profileId, userId, user.Id);
            throw new AppException(NoProfileMessage, UnauthorizedTitle);
        }

        _userService.UpdateCurrentUserInfo(userProfileData.PersonId, userId, profileId);

        return new { userProfileData, ehealthInfo = new EhealthInfoDto(), isAuthInEhealth = false };
    }

    public async Task<List<UserProfileSelectLoginDto>> GetUserDataAsync()
    {
        var user = CurrentUser;
        if (string.IsNullOrEmpty(user?.Id))
        {
            throw new AppException(NotAuthenticatedMessage, UnauthorizedTitle);
        }

        var profileData = await GetUserProfileSelectDataAsync(user.Id);

        if (!profileData.Any(x => x.HasOrganization))
        {
            throw new AppException(OrganizationRestrictedMessage, UnauthorizedTitle);
        }

        if (profileData.Count == 0)
        {
            _logger.LogError("Person is not found for user logged in on Identity server. Identity user id: {UserId}", user.Id);
            throw new AppException(PersonNotFoundMessage, UnauthorizedTitle);
        }

        var personEmployees = profileData.Where(x => x.UserId != Guid.Empty).ToList();
        if (personEmployees.Count == 0)
        {
            _logger.LogError("Employee is not found for person logged in on Identity server. Identity user id: {UserId}", user.Id);
            throw new AppException(EmployeeNotFoundMessage, UnauthorizedTitle);
        }

        var employeeProfiles = personEmployees.Where(x => x.ProfileId != Guid.Empty && x.IsActive).ToList();
        if (employeeProfiles.Count == 0)
        {
            var employeesToLog = string.Join(", ", personEmployees.Select(x => $"{x.UserCaption} ({x.UserId})"));
            _logger.LogError("Security profile is not set for an employee. Identity user id: {UserId}. Employees: {Employees}", user.Id, employeesToLog);
            throw new AppException(NoProfileMessage, UnauthorizedTitle);
        }

        return employeeProfiles.Select(x => x.Dto).ToList();
    }

    public async Task<List<UserProfileSelectLoginDto>> GetUserDataAsync(Guid? organizationId, string roleName)
    {
        var employeeProfiles = await GetUserDataAsync();
        var roleProfiles = employeeProfiles.Where(x => x.OrganizationId == organizationId && x.RoleName == roleName).ToList();
        if (roleProfiles.Count == 0)
        {
            _logger.LogError("Security profile is not set for employee with role {Role}. Identity user id: {UserId}", roleName, CurrentUser?.Id);
            throw new AppException(NoRoleProfileMessage, UnauthorizedTitle);
        }
        return roleProfiles;
    }

    public Task ClearCurrentUserInfoCache()
    {
        _userService.DeleteCurrentUserInfo();
        return Task.CompletedTask;
    }

    public async Task<UserFullProfileDto?> GetUserFullProfileDtoAsync()
    {
        var user = await _userService.GetCurrentUserInfoAsync();
        if (string.IsNullOrEmpty(user?.Id))
        {
            _logger.LogWarning("Authentication error. User is not authenticated on Identity server. User id in not set");
            return null;
        }

        if (user.ProfileId == Guid.Empty || user.UserId == Guid.Empty)
        {
            _logger.LogWarning("Security profile is not set to current user, try relogin. User id at identity server: {IdentityUserId}", user.Id);
            return new UserFullProfileDto();
        }
        if (_db.Tenant.TenantId == null) return null;

        var employeeId = user.UserId.ToString();
        var employee = await _db.Employees.AsNoTracking().Include(e => e.Department)
            .FirstOrDefaultAsync(e => e.Id == employeeId && e.RecordState == RecordStates.Active);
        var hasProfile = await _db.UserProfiles!.AsNoTracking().AnyAsync(u => u.UserId == user.UserId && u.ProfileId == user.ProfileId);
        if (employee == null || !hasProfile) return null;

        var profile = await _db.SecurityProfiles!.AsNoTracking().FirstOrDefaultAsync(p => p.Id == user.ProfileId);
        var organization = await _db.Tenants.AsNoTracking().FirstOrDefaultAsync(o => o.Id == employee.TenantId);
        var person = employee.Person != null && employee.Person.RecordState == RecordStates.Active ? employee.Person : null;
        var department = employee.Department != null && employee.Department.RecordState == RecordStates.Active ? employee.Department : null;

        return new UserFullProfileDto
        {
            EmployeeId = user.UserId,
            EmployeeCaption = employee.Caption,
            DepartmentId = ParseGuid(employee.DepartmentId),
            DepartmentCaption = department?.Name,
            OrganizationId = ParseGuid(employee.TenantId),
            OrganizationCaption = organization?.Name,
            PersonName = person?.Name,
            PersonMiddleName = person?.MiddleName,
            PersonLastName = person?.LastName,
            ProfileId = profile?.Id ?? Guid.Empty,
            ProfileCaption = profile?.Caption ?? "",
            UserId = person?.UserId ?? "",
            SubscribedToNotifications = person?.SubscribedToNotifications ?? false,
            PersonId = ParseGuid(person?.Id) ?? Guid.Empty,
            Rights = (user as UserInfo)?.Rights
        };
    }

    public const string CalculateTotalRecordsCount = "calculateTotalRecords";

    public async Task<IEnumerable<UsersListDto>> GetUsersAsync(IDictionary<string, string>? paramList)
    {
        var (pageSize, pageNumber, orderBy, otherParameters) = HttpQueryStringHelper.GetQueryParametersFromQueryParamList(paramList);
        var query = ApplyCaseFilters(await GetUsersListDataAsync(), otherParameters).AsQueryable();

        if (otherParameters.Any(x => x.Key == CalculateTotalRecordsCount))
        {
            var count = query.Count();
            var result = query.Take(1).ToList();
            if (count != 0)
            {
                foreach (var item in result) item.TotalRecordCount = count;
            }
            return result;
        }

        query = query.AddOrderBy(orderBy);
        var skip = (pageNumber - 1) * pageSize;
        if (skip > 0) query = query.Skip(skip);
        if (pageSize != 0) query = query.Take(pageSize);
        return query.ToList();
    }

    public async Task<UsersListDto?> GetUserDetailsAsync(Guid id)
        => (await GetUsersListDataAsync()).Where(x => x.Id == id).SingleOrDefault();

    private async Task<List<UsersListDto>> GetUsersListDataAsync()
    {
        var employees = await _db.Employees.AsNoTracking().IgnoreAutoIncludes().Where(e => e.RecordState == RecordStates.Active).ToListAsync();
        var organizations = await _db.Tenants.AsNoTracking().ToDictionaryAsync(o => o.Id, o => o.Name);
        var departments = await _db.Divisions.AsNoTracking().ToDictionaryAsync(d => d.Id, d => d.Name);
        var positionTypeIds = employees.Select(e => e.PositionTypeId).Distinct().ToList();
        var positionTypes = await _db.EnumRecords.AsNoTracking().Where(r => positionTypeIds.Contains(r.Id)).ToDictionaryAsync(r => r.Id, r => r.Caption);

        return employees.Select(e => new UsersListDto
        {
            Id = ParseGuid(e.Id) ?? Guid.Empty,
            Caption = e.Caption!,
            DepartmentId = ParseGuid(e.DepartmentId),
            DepartmentCaption = (e.DepartmentId != null && departments.TryGetValue(e.DepartmentId, out var dep) ? dep : null) ?? "",
            OrganizationId = ParseGuid(e.TenantId) ?? Guid.Empty,
            OrganizationCaption = (organizations.TryGetValue(e.TenantId, out var org) ? org : null) ?? "",
            PositionTypeId = ParseGuid(e.PositionTypeId) ?? Guid.Empty,
            PositionTypeCaption = (positionTypes.TryGetValue(e.PositionTypeId, out var pos) ? pos : null) ?? ""
        }).ToList();
    }

    private static IEnumerable<TDto> ApplyCaseFilters<TDto>(IEnumerable<TDto> query, IDictionary<string, string> parameters)
    {
        var properties = typeof(TDto).GetProperties()
            .Where(p => p.IsDefined(typeof(CaseFilterAttribute), true))
            .ToDictionary(p => p, p => (CaseFilterAttribute)p.GetCustomAttributes(typeof(CaseFilterAttribute), true).First());

        foreach (var (key, value) in parameters)
        {
            if (string.IsNullOrEmpty(key) || key == "X-Requested-With") continue;
            var name = key.ToLower();
            if (name.EndsWith("_from")) name = name.Remove(name.LastIndexOf("_from", StringComparison.Ordinal));
            else if (name.EndsWith("_to")) name = name.Remove(name.LastIndexOf("_to", StringComparison.Ordinal));
            var property = properties.Keys.FirstOrDefault(p => p.Name.ToLower() == name);
            if (property == null) continue;

            switch (properties[property].Operation)
            {
                case CaseFilterOperation.Equals:
                    if (value != null && value.StartsWith("[") && value.EndsWith("]"))
                    {
                        var values = value[1..^1].Split(',').Where(v => !string.IsNullOrEmpty(v)).Select(v => ConvertFilterValue(property.PropertyType, v)).ToList();
                        if (values.Count == 0) throw new ArgumentException($"Empty list filter for {property.Name}");
                        query = query.Where(x => values.Contains(property.GetValue(x)));
                    }
                    else if (value == null)
                    {
                        query = query.Where(x => property.GetValue(x) == null);
                    }
                    else
                    {
                        var expected = ConvertFilterValue(property.PropertyType, value);
                        query = query.Where(x => Equals(property.GetValue(x), expected));
                    }
                    break;
                case CaseFilterOperation.Contains:
                    if (value == null) break;
                    var part = value.ToLowerInvariant();
                    query = query.Where(x => property.GetValue(x) is string s && s.ToLowerInvariant().Contains(part));
                    break;
                default:
                    throw new NotSupportedException($"CaseFilter {properties[property].Operation} is not supported");
            }
        }
        return query;
    }

    private static object? ConvertFilterValue(Type type, string value)
    {
        var target = Nullable.GetUnderlyingType(type) ?? type;
        if (target == typeof(Guid)) return Guid.Parse(value);
        if (target == typeof(string)) return value;
        return Convert.ChangeType(value, target, CultureInfo.InvariantCulture);
    }

    private sealed record SelectRow(UserProfileSelectLoginDto Dto, bool HasOrganization)
    {
        public Guid UserId => Dto.UserId;
        public Guid ProfileId => Dto.ProfileId;
        public Guid OrganizationId => Dto.OrganizationId;
        public string? OrganizationCaption => Dto.OrganizationCaption;
        public string UserCaption => Dto.UserCaption;
        public bool IsActive => Dto.IsActive;
    }

    private async Task<List<SelectRow>> GetUserProfileSelectDataAsync(string identityUserId)
    {
        var persons = await _db.Persons.AsNoTracking().Where(p => p.UserId == identityUserId && p.RecordState == RecordStates.Active).ToListAsync();
        var personIds = persons.Select(p => p.Id).ToList();
        var employees = await _db.RunAsUserAsync(identityUserId, () => _db.Employees.IgnoreQueryFilters().AsNoTracking().IgnoreAutoIncludes()
            .Where(e => personIds.Contains(e.PersonId) && e.RecordState == RecordStates.Active).ToListAsync());
        var organizationIds = employees.Select(e => e.TenantId).Distinct().ToList();
        var organizations = await _db.RunAsUserAsync(identityUserId, () => _db.Tenants.AsNoTracking().Where(o => organizationIds.Contains(o.Id)).ToDictionaryAsync(o => o.Id));
        var employeeGuids = employees.Select(e => ParseGuid(e.Id)).Where(g => g.HasValue).Select(g => g!.Value).ToList();
        var userProfiles = await _db.UserProfiles!.AsNoTracking()
            .Where(u => employeeGuids.Contains(u.UserId) && u.RecordState == CoreRecordState.Active).ToListAsync();
        var profileIds = userProfiles.Select(u => u.ProfileId).Distinct().ToList();
        var profiles = await _db.SecurityProfiles!.AsNoTracking()
            .Where(p => profileIds.Contains(p.Id) && p.RecordState == CoreRecordState.Active).ToDictionaryAsync(p => p.Id);
        var typeIds = profiles.Values.Where(p => p.TypeId.HasValue).Select(p => p.TypeId!.Value.ToString()).Distinct().ToList();
        var roleNames = await _db.EnumRecords.AsNoTracking().Where(r => typeIds.Contains(r.Id) && r.RecordState == RecordStates.Active).ToDictionaryAsync(r => r.Id, r => r.Code);

        var rows = new List<SelectRow>();
        foreach (var person in persons)
        {
            var personEmployees = employees.Where(e => e.PersonId == person.Id).ToList();
            if (personEmployees.Count == 0)
            {
                rows.Add(new SelectRow(NewSelectDto(person, null, null, null, null, null), false));
                continue;
            }
            foreach (var employee in personEmployees)
            {
                organizations.TryGetValue(employee.TenantId, out var organization);
                var employeeGuid = ParseGuid(employee.Id);
                var employeeProfiles = userProfiles.Where(u => u.UserId == employeeGuid).ToList();
                if (employeeProfiles.Count == 0)
                {
                    rows.Add(new SelectRow(NewSelectDto(person, employee, organization, null, null, null), organization != null));
                    continue;
                }
                foreach (var userProfile in employeeProfiles)
                {
                    profiles.TryGetValue(userProfile.ProfileId, out var profile);
                    var roleName = profile?.TypeId is { } typeId && roleNames.TryGetValue(typeId.ToString(), out var code) ? code : null;
                    rows.Add(new SelectRow(NewSelectDto(person, employee, organization, userProfile, profile, roleName), organization != null));
                }
            }
        }
        return rows;
    }

    private static UserProfileSelectLoginDto NewSelectDto(CmnPerson person, OrgEmployee? employee, TnTenant? organization,
        SecurityUserProfile? userProfile, SecurityProfile? profile, string? roleName) => new()
    {
        ProfileId = userProfile?.ProfileId ?? Guid.Empty,
        UserId = ParseGuid(employee?.Id) ?? Guid.Empty,
        UserCaption = employee?.Caption ?? "",
        ProfileCaption = profile?.Caption ?? "",
        RoleName = roleName ?? "",
        IsActive = profile?.IsActive ?? false,
        OrganizationId = ParseGuid(employee?.TenantId) ?? Guid.Empty,
        OrganizationCaption = organization?.Name ?? "",
        UserOuterId = person.UserId,
        Email = person.Email ?? ""
    };

    private async Task<List<UserProfileLoginDto>> GetUserProfileLoginDataAsync(string identityUserId)
    {
        var rows = await GetUserProfileSelectDataAsync(identityUserId);
        var persons = await _db.Persons.AsNoTracking().Where(p => p.UserId == identityUserId && p.RecordState == RecordStates.Active).ToListAsync();
        var employeeIds = rows.Where(r => r.UserId != Guid.Empty).Select(r => r.UserId.ToString()).Distinct().ToList();
        var employees = await _db.RunAsUserAsync(identityUserId, () => _db.Employees.IgnoreQueryFilters().AsNoTracking().IgnoreAutoIncludes().Where(e => employeeIds.Contains(e.Id)).ToDictionaryAsync(e => e.Id));
        var profileIds = rows.Where(r => r.ProfileId != Guid.Empty).Select(r => r.ProfileId).Distinct().ToList();
        var profiles = await _db.SecurityProfiles!.AsNoTracking().Where(p => profileIds.Contains(p.Id)).ToDictionaryAsync(p => p.Id);

        return rows.Where(r => r.UserId != Guid.Empty && r.ProfileId != Guid.Empty && profiles.ContainsKey(r.ProfileId))
            .Select(r =>
            {
                var employee = employees[r.UserId.ToString()];
                var person = persons.First(p => p.Id == employee.PersonId);
                var profile = profiles[r.ProfileId];
                return new UserProfileLoginDto
                {
                    ProfileId = r.ProfileId,
                    UserId = r.UserId,
                    PersonId = ParseGuid(person.Id) ?? Guid.Empty,
                    IsActive = profile.IsActive,
                    UserOuterId = person.UserId,
                    TypeId = profile.TypeId,
                    RoleName = "",
                    OrganizationId = ParseGuid(employee.TenantId)
                };
            }).ToList();
    }

    private static Guid? ParseGuid(string? value) => Guid.TryParse(value, out var g) ? g : null;
}
