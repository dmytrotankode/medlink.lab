using System.Globalization;
using MedLink.LIS.Core.Barcodes;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace MedLink.LIS.Api.Services;

public sealed class LabelPdfService
{
    static LabelPdfService()
    {
        QuestPDF.Settings.License = LicenseType.Community;
        QuestPDF.Settings.CheckIfAllTextGlyphsAreAvailable = false;
    }

    public static string NormalizeSize(string? size) => (size ?? "30x20").Trim().ToLowerInvariant() switch
    {
        "50x25" or "50*25" => "50x25",
        "a4" or "sheet" => "a4",
        _ => "30x20"
    };

    public byte[] GenerateLabelsPdf(IReadOnlyList<LabelDto> labels, string? size = "30x20")
    {
        var normSize = NormalizeSize(size);
        if (normSize == "a4")
        {
            return GenerateA4Sheet(labels);
        }

        var (widthMm, heightMm) = normSize == "50x25" ? (50f, 25f) : (30f, 20f);

        var doc = Document.Create(container =>
        {
            foreach (var label in labels)
            {
                container.Page(page =>
                {
                    page.Size(widthMm, heightMm, Unit.Millimetre);
                    page.Margin(1, Unit.Millimetre);
                    page.DefaultTextStyle(x => x.FontSize(normSize == "50x25" ? 7f : 5.5f).FontFamily("Lato"));

                    if (normSize == "50x25")
                        Compose50x25Label(page.Content(), label);
                    else
                        Compose30x20Label(page.Content(), label);
                });
            }
        });

        return doc.GeneratePdf();
    }

    private static void Compose30x20Label(IContainer c, LabelDto l)
    {
        c.Column(col =>
        {
            col.Item().Row(r =>
            {
                r.RelativeItem().Text(ShortenName(l.PatientName)).Bold().FontSize(6f);
                var dt = l.CollectedAt?.ToString("dd.MM.yy") ?? DateTime.Now.ToString("dd.MM.yy");
                r.AutoItem().Text(dt).FontSize(5f);
            });

            col.Item().Row(r =>
            {
                r.RelativeItem().Text(l.Tube).FontSize(5f);
                if (!string.IsNullOrEmpty(l.ReferralNumber))
                    r.AutoItem().Text($"Н:{l.ReferralNumber}").FontSize(5f);
                else if (!string.IsNullOrEmpty(l.OrderNumber))
                    r.AutoItem().Text($"№{l.OrderNumber}").FontSize(5f);
            });

            var svg = !string.IsNullOrEmpty(l.Svg) ? l.Svg : TubeBarcodeGenerator.RenderSvg(l.Barcode, l.Symbology, 28, 1, false);
            col.Item().Height(8, Unit.Millimetre).Svg(svg);

            col.Item().Row(r =>
            {
                r.RelativeItem().Text(l.Barcode).Bold().FontSize(6.5f);
                if (l.TestCodes.Count > 0)
                {
                    var codes = string.Join(",", l.TestCodes.Take(3));
                    r.AutoItem().Text(codes).FontSize(5f);
                }
            });
        });
    }

    private static void Compose50x25Label(IContainer c, LabelDto l)
    {
        c.Column(col =>
        {
            col.Item().Row(r =>
            {
                r.RelativeItem().Text(Truncate(l.PatientName, 26)).Bold().FontSize(7.5f);
                var dt = (l.CollectedAt ?? DateTime.Now).ToString("dd.MM.yy HH:mm");
                r.AutoItem().Text(dt).FontSize(6f);
            });

            col.Item().Row(r =>
            {
                var birth = l.PatientBirthDate.HasValue ? $"нар. {l.PatientBirthDate.Value:dd.MM.yyyy}" : "";
                var order = !string.IsNullOrEmpty(l.OrderNumber) ? $"№{l.OrderNumber}" : "";
                var refStr = !string.IsNullOrEmpty(l.ReferralNumber) ? $"Напр:{l.ReferralNumber}" : "";
                var meta = string.Join("  ", new[] { birth, order, refStr }.Where(s => !string.IsNullOrEmpty(s)));

                r.RelativeItem().Text(meta).FontSize(5.5f);
                r.AutoItem().Text(l.Tube).Bold().FontSize(6f);
            });

            var svg = !string.IsNullOrEmpty(l.Svg) ? l.Svg : TubeBarcodeGenerator.RenderSvg(l.Barcode, l.Symbology, 36, 1, false);
            col.Item().Height(11, Unit.Millimetre).Svg(svg);

            col.Item().Row(r =>
            {
                r.RelativeItem().Text(l.Barcode).Bold().FontSize(8f);
                if (l.TestCodes.Count > 0)
                {
                    var tests = string.Join(", ", l.TestCodes.Take(5));
                    r.AutoItem().Text(tests).FontSize(6f);
                }
            });
        });
    }

    private static byte[] GenerateA4Sheet(IReadOnlyList<LabelDto> labels)
    {
        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(8, Unit.Millimetre);
                page.DefaultTextStyle(x => x.FontSize(6.5f).FontFamily("Lato"));

                page.Content().Table(table =>
                {
                    table.ColumnsDefinition(cd =>
                    {
                        cd.RelativeColumn();
                        cd.RelativeColumn();
                        cd.RelativeColumn();
                    });

                    foreach (var label in labels)
                    {
                        table.Cell().Border(0.5f).BorderColor("#ccc").Padding(3).Element(c =>
                        {
                            Compose50x25Label(c, label);
                        });
                    }
                });
            });
        });

        return doc.GeneratePdf();
    }

    private static string Truncate(string s, int max) => string.IsNullOrEmpty(s) ? "" : (s.Length <= max ? s : s.Substring(0, max - 1) + "…");

    private static string ShortenName(string fullName)
    {
        if (string.IsNullOrWhiteSpace(fullName)) return "";
        var parts = fullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 1) return parts[0];
        if (parts.Length == 2) return $"{parts[0]} {parts[1][0]}.";
        return $"{parts[0]} {parts[1][0]}.{parts[2][0]}.";
    }
}

