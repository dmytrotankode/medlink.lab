using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Models;
using MedLink.LIS.Core.Common;

namespace MedLink.LIS.Api.Services;

public static class MedLinkPeople
{
    public static OrdPatient NewPatient(NewPatientRequest req, string tenantId)
    {
        var patient = new OrdPatient { TenantId = tenantId };
        Apply(patient, req, isNew: true);
        return patient;
    }

    public static void Apply(OrdPatient p, NewPatientRequest req, bool isNew)
    {
        if (isNew || !string.IsNullOrWhiteSpace(req.LastName)) p.LastName = req.LastName?.Trim();
        if (isNew || !string.IsNullOrWhiteSpace(req.FirstName)) p.Name = req.FirstName?.Trim();
        if (isNew || req.SecondName != null) p.MiddleName = string.IsNullOrWhiteSpace(req.SecondName) ? null : req.SecondName.Trim();
        if (isNew || req.BirthDate != null) p.Birthday = req.BirthDate;
        if (isNew || !string.IsNullOrWhiteSpace(req.Gender)) p.Sex = (req.Gender ?? "").Trim().ToUpperInvariant() switch { "M" => "male", "F" => "female", _ => "unknown" };
        if (isNew || req.Phone != null) p.Phone = req.Phone;
        if (isNew || req.Email != null) p.Email = req.Email;
        if (isNew || req.TaxId != null) p.Ipn = string.IsNullOrWhiteSpace(req.TaxId) ? null : req.TaxId.Trim();
        if (isNew || req.Address != null) p.Location = req.Address;

        p.Caption = CmnPerson.BuildCaption(p.LastName, p.Name, p.MiddleName);
        p.LastNameLatin = TransliterationKmu2010.ToLatin(p.LastName ?? "");
        p.FirstNameLatin = TransliterationKmu2010.ToLatin(p.Name ?? "");
    }

    public static PatientDto ToDto(OrdPatient p, DateTime? at = null) => new()
    {
        Id = p.Id, LastName = p.LastName ?? "", FirstName = p.Name ?? "", SecondName = p.MiddleName, FullName = p.Caption ?? "",
        LastNameLatin = p.LastNameLatin, FirstNameLatin = p.FirstNameLatin,
        BirthDate = p.Birthday, AgeYears = p.Birthday.HasValue ? Core.Clinical.AgeUnits.AgeYears(p.Birthday.Value, at ?? DateTime.UtcNow) : null,
        Gender = p.Gender, Phone = p.Phone, Email = p.Email, TaxId = p.Ipn, Address = p.Location
    };
}

/// <summary>Значення за замовчуванням для автономної ЛІС (один заклад). В evomis беруться з контексту користувача.</summary>
public static class MedLinkDefaults
{
    public const string ReferralCategoryLaboratoryCode = "laboratory_procedure";
    public const string GenericLabServiceCode = "LAB-GENERIC";
}
