// Нумератори та лічильники: номер замовлення {yyMM}-{000000}, лічильник штрихкодів lab_tube_barcode_ean8
using System.Globalization;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Core.Barcodes;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Services;

public interface INumeratorService
{
    Task<string> NextOrderNumberAsync(DateTime at, CancellationToken ct = default);
    Task<long> NextCounterAsync(string counterCode, CancellationToken ct = default);
    Task<string> NextTubeBarcodeAsync(CancellationToken ct = default);
    Task<string> NextManifestNumberAsync(DateTime at, CancellationToken ct = default);
    Task<string> NextBatchCodeAsync(DateTime at, CancellationToken ct = default);
    static string FormatMask(string mask, DateTime at, long value) => NumeratorService.ApplyMask(mask, at, value);
}

public sealed class NumeratorService : INumeratorService
{
    public const string OrderNumerator = "lab_order_number";
    public const string ManifestNumerator = "lab_manifest_number";
    public const string BatchNumerator = "lab_batch_code";
    public const string AllScope = "ALL";

    private readonly LisDbContext _db;
    public NumeratorService(LisDbContext db) => _db = db;

    public Task<string> NextOrderNumberAsync(DateTime at, CancellationToken ct = default) => NextFormattedAsync(OrderNumerator, "{yyMM}-{000000}", at, ct);
    public Task<string> NextManifestNumberAsync(DateTime at, CancellationToken ct = default) => NextFormattedAsync(ManifestNumerator, "MAN-{yyMMdd}-{0000}", at, ct);
    public Task<string> NextBatchCodeAsync(DateTime at, CancellationToken ct = default) => NextFormattedAsync(BatchNumerator, "WL-{yyMMdd}-{000}", at, ct);

    private async Task<string> NextFormattedAsync(string code, string defaultMask, DateTime at, CancellationToken ct)
    {
        var numerator = await _db.Numerators.AsNoTracking().FirstOrDefaultAsync(n => n.Code == code, ct);
        if (numerator == null)
        {
            numerator = new LabNumerator { Code = code, Name = code, Mask = defaultMask, ResetByPeriod = true };
            _db.Numerators.Add(numerator);
            await _db.SaveChangesAsync(ct);
            _db.Entry(numerator).State = EntityState.Detached;
        }
        var value = await NextSequenceAsync(_db, code, ScopeKey(numerator, at), ct);
        return ApplyMask(numerator.Mask, at, value);
    }

    public Task<long> NextCounterAsync(string counterCode, CancellationToken ct = default) => NextSequenceAsync(_db, counterCode, AllScope, ct);

    public static string ScopeKey(LabNumerator numerator, DateTime at) => numerator.ResetByPeriod ? PeriodKey(numerator.Mask, at) : AllScope;

    public static async Task<long> NextSequenceAsync(LisDbContext db, string key, string scopeKey, CancellationToken ct = default)
    {
        var tenantId = Guid.Parse(db.CurrentTenantId);
        var values = await db.Database.SqlQuery<long>($"INSERT INTO tn_sequence (tenant_id, key, scope_key, value) VALUES ({tenantId}, {key}, {scopeKey}, 1) ON CONFLICT (tenant_id, key, scope_key) DO UPDATE SET value = tn_sequence.value + 1 RETURNING value AS \"Value\"").ToListAsync(ct);
        return values.Single();
    }

    public static Task<long> CurrentSequenceAsync(LisDbContext db, string key, string scopeKey, CancellationToken ct = default) =>
        db.Sequences.AsNoTracking().Where(s => s.Key == key && s.ScopeKey == scopeKey).Select(s => s.Value).FirstOrDefaultAsync(ct);

    public async Task<string> NextTubeBarcodeAsync(CancellationToken ct = default)
    {
        var settings = await _db.LabSettingsAsync();
        var symbology = settings?.BarcodeSymbology;
        var prefix = settings?.BarcodePrefix;

        // Повтор на випадок колізії унікального індексу (напр. після відновлення БД)
        for (var attempt = 0; attempt < 5; attempt++)
        {
            var counter = await NextCounterAsync(TubeBarcodeGenerator.CounterCode, ct);
            var barcode = TubeBarcodeGenerator.GenerateFormatted(counter, symbology, prefix);
            bool taken;
            using (_db.Division.RunAs(null))
                taken = await _db.Samples.AsNoTracking().AnyAsync(s => s.Barcode == barcode, ct);
            if (!taken) return barcode;
        }
        throw new InvalidOperationException("Не вдалося згенерувати унікальний штрихкод пробірки");
    }

    /// <summary>Маска: {yyMM}, {yyMMdd}, {yyyy} → дата; {000000} → значення з доповненням нулями.</summary>
    public static string ApplyMask(string mask, DateTime at, long value)
    {
        var result = mask;
        result = System.Text.RegularExpressions.Regex.Replace(result, @"\{(y+M*d*)\}", m => at.ToString(m.Groups[1].Value, CultureInfo.InvariantCulture));
        result = System.Text.RegularExpressions.Regex.Replace(result, @"\{(0+)\}", m => value.ToString(new string('0', m.Groups[1].Value.Length), CultureInfo.InvariantCulture));
        return result;
    }

    private static string PeriodKey(string mask, DateTime at)
    {
        var m = System.Text.RegularExpressions.Regex.Match(mask, @"\{(y+M*d*)\}");
        return m.Success ? at.ToString(m.Groups[1].Value, CultureInfo.InvariantCulture) : "ALL";
    }
}
