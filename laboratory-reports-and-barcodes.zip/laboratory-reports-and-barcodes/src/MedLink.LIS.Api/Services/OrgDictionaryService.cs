// Довідники «Відділення» та «Співробітники» у структурі MedLink:
//  співробітник = [MedLink] org_employee + cmn_person + [ЛІС] lab_employee_settings (роль, посада, КЕП, активність).
// API віддає «плоский» вигляд (як у v4.0), щоб фронтенд не залежав від розкладки таблиць evomis.
using System.Text.Json;
using Core.Services;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Helpers;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using CoreRecordState = Core.Base.Data.RecordState;

namespace MedLink.LIS.Api.Services;

public sealed class DepartmentView
{
    public string Id { get; set; } = "";
    public string? Code { get; set; }
    public string? Name { get; set; }
    /// <summary>LABORATORY | COLLECTION_POINT | CLINICAL | BRANCH.</summary>
    public string LabKind { get; set; } = "CLINICAL";
    /// <summary>Тип підрозділу MedLink (cmn_enum_record DepartmentType).</summary>
    public string? DepartmentTypeId { get; set; }
    public string? DepartmentTypeName { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class EmployeeView
{
    public string Id { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? LastName { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? Position { get; set; }
    public string? PositionTypeId { get; set; }
    public string LabRole { get; set; } = LabRoles.Technician;
    public string? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? DigitalSignatureCertId { get; set; }
    public bool IsActive { get; set; } = true;
    public List<string> AllowedDepartmentIds { get; set; } = new();
}

public sealed class OrgDictionaryService
{
    public static readonly string[] LabKinds = DivisionTypes.All;
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };

    private readonly LisDbContext _db;
    private readonly IAuditService _audit;
    private readonly IUserInfoService _userService;
    private readonly IRolePolicy _policy;
    private readonly ICurrentEmployee _current;
    public OrgDictionaryService(LisDbContext db, IAuditService audit, IUserInfoService userService, IRolePolicy policy, ICurrentEmployee current)
    {
        _db = db; _audit = audit; _userService = userService; _policy = policy; _current = current;
    }

    public static string RankDeniedDetail(string? ownRole) =>
        $"Роль співробітника можна призначати лише нижчу за власну роль «{ownRole ?? "не визначено"}»; змінювати можна лише співробітників із нижчою роллю, крім власного запису";

    public string[] AssignableRoles() => _policy.Can(nameof(ApplicationOperations.EmployeeSave)) ? LabRoles.AssignableBy(ActorRole()) : Array.Empty<string>();

    private string? ActorRole()
    {
        var caption = _db.SecurityProfiles!.AsNoTracking().Where(p => p.Id == _current.ProfileId).Select(p => p.Caption).FirstOrDefault();
        return RightsSeedHelper.Security.ForCaption(caption)?.Code;
    }

    private async Task<string?> TargetRoleAsync(OrgEmployee e)
    {
        var roles = new List<string?>();
        if (Guid.TryParse(e.Id, out var userId))
        {
            var captions = RightsSeedHelper.Security.LabRoles.Select(r => r.Caption).ToList();
            var linked = await _db.UserProfiles!.AsNoTracking().Where(u => u.UserId == userId)
                .Join(_db.SecurityProfiles!.AsNoTracking().Where(p => captions.Contains(p.Caption)), u => u.ProfileId, p => p.Id, (u, p) => p.Caption).ToListAsync();
            roles.AddRange(linked.Select(c => RightsSeedHelper.Security.ForCaption(c)?.Code));
        }
        if (e.LabSettings != null) roles.Add(e.LabSettings.LabRole);
        return roles.OrderByDescending(LabRoles.Rank).FirstOrDefault();
    }

    /// <summary>Тип підрозділу MedLink за видом підрозділу ЛІС.</summary>
    public static string DepartmentTypeCodeFor(string labKind) => labKind switch
    {
        "LABORATORY" or "COLLECTION_POINT" => "02",
        "BRANCH" => "05",
        DivisionTypes.Clinical => "03",
        _ => throw new InvalidOperationException($"Вид підрозділу {labKind}: код DepartmentType не визначено")
    };

    /// <summary>Тип посади MedLink (OrgPositionType) за роллю ЛІС.</summary>
    public static string PositionTypeCodeFor(string labRole) => labRole switch
    {
        LabRoles.Doctor or LabRoles.Admin => "0002",
        LabRoles.Technician => "0003",
        LabRoles.Phlebotomist => "0005",
        LabRoles.Courier or LabRoles.Registrar or LabRoles.System => "0001",
        _ => throw new InvalidOperationException($"Роль {labRole}: код OrgPositionType не визначено")
    };

    // ------------------------------------------------------------------ departments
    public static DepartmentView ToView(TnDivision d) => new()
    {
        Id = d.Id, Code = d.Code, Name = d.Name, LabKind = d.Type, DepartmentTypeId = d.DepartmentTypeId,
        DepartmentTypeName = d.DepartmentType?.Caption, Address = d.Address, Phone = d.Phone, IsActive = d.IsActive
    };

    public async Task<List<DepartmentView>> DepartmentsAsync() =>
        (await _db.Divisions.AsNoTracking().Include(d => d.DepartmentType).Where(d => d.RecordState != RecordStates.Deleted).OrderBy(d => d.Name).ToListAsync()).Select(ToView).ToList();

    public async Task<DepartmentView?> DepartmentAsync(string id)
    {
        var d = await _db.Divisions.AsNoTracking().Include(x => x.DepartmentType).FirstOrDefaultAsync(x => (x.Id == id || x.Code == id) && x.RecordState != RecordStates.Deleted);
        return d == null ? null : ToView(d);
    }

    public async Task<DepartmentView> SaveDepartmentAsync(string? id, JsonElement body)
    {
        TnDivision d;
        if (id == null)
        {
            d = new TnDivision { TenantId = _db.CurrentTenantId };
            _db.Divisions.Add(d);
        }
        else
        {
            d = await _db.Divisions.FirstOrDefaultAsync(x => (x.Id == id || x.Code == id) && x.RecordState != RecordStates.Deleted) ?? throw NotFoundException.For("Відділення", id);
        }
        var before = ToView(d);
        var v = Merge(before, body);
        if (string.IsNullOrWhiteSpace(v.Name)) throw new ValidationException("Назва підрозділу обов'язкова");
        if (string.IsNullOrWhiteSpace(v.Code) || !System.Text.RegularExpressions.Regex.IsMatch(v.Code.Trim(), "^[A-Z0-9-]{2,10}$")) throw ValidationException.Field("code", "Код підрозділу обов'язковий: 2–10 символів A-Z, 0-9, -");
        // сумісність із v4.0: departmentType = LABORATORY|COLLECTION_POINT|…
        if (body.TryGetProperty("departmentType", out var dt) && dt.ValueKind == JsonValueKind.String && LabKinds.Contains(dt.GetString())) v.LabKind = dt.GetString()!;
        if (!LabKinds.Contains(v.LabKind)) throw ValidationException.Field("labKind", $"Вид підрозділу: {string.Join(", ", LabKinds)}");
        if (await _db.Divisions.AnyAsync(x => x.Code == v.Code.Trim() && x.Id != d.Id))
            throw new ConflictException($"Відділення з кодом {v.Code} вже існує");

        d.Name = v.Name!.Trim(); d.Code = v.Code.Trim(); d.Address = v.Address;
        d.DepartmentTypeId = string.IsNullOrWhiteSpace(v.DepartmentTypeId) || id == null ? await _db.EnumRecordIdAsync("DepartmentType", DepartmentTypeCodeFor(v.LabKind)) : v.DepartmentTypeId!;
        d.Type = v.LabKind; d.Phone = v.Phone; d.IsActive = v.IsActive;
        _audit.Log(id == null ? "CREATE" : "UPDATE", "tn_division", d.Id, id == null ? null : before, v);
        await _db.SaveChangesAsync();
        return (await DepartmentAsync(d.Id))!;
    }

    // ------------------------------------------------------------------ employees
    public static EmployeeView ToView(OrgEmployee e, List<string>? allowedDepartmentIds = null) => new()
    {
        Id = e.Id, FullName = e.Caption ?? "", LastName = e.Person?.LastName, FirstName = e.Person?.Name, MiddleName = e.Person?.MiddleName,
        Position = e.LabSettings?.PositionName ?? e.PositionType?.Caption, PositionTypeId = e.PositionTypeId,
        LabRole = e.LabSettings?.LabRole ?? LabRoles.Technician, DepartmentId = e.DepartmentId, DepartmentName = e.Department?.Name,
        Phone = e.Person?.Phone, Email = e.Person?.Email, DigitalSignatureCertId = e.LabSettings?.DigitalSignatureCertId, IsActive = e.LabSettings?.IsActive ?? true,
        AllowedDepartmentIds = allowedDepartmentIds ?? new()
    };

    private async Task<Dictionary<string, List<string>>> AllowedDepartmentsAsync(string? employeeId = null) =>
        (await _db.MembershipDivisions.AsNoTracking().Where(d => employeeId == null || d.MembershipId == employeeId).ToListAsync())
        .GroupBy(d => d.MembershipId).ToDictionary(g => g.Key, g => g.Select(d => d.DivisionId).OrderBy(id => id).ToList());

    private async Task SetAllowedDepartmentsAsync(OrgEmployee e, List<string> requested)
    {
        var ids = requested.Where(id => !string.IsNullOrWhiteSpace(id)).Distinct().ToList();
        var known = await _db.Divisions.CountAsync(d => ids.Contains(d.Id) && d.RecordState != RecordStates.Deleted);
        if (known != ids.Count) throw ValidationException.Field("allowedDepartmentIds", "Підрозділ не знайдено");
        if (_db.AllowedDepartmentIds != null && ids.Count == 0)
            throw ValidationException.Field("allowedDepartmentIds", "Співробітник з обмеженням за підрозділами може надати доступ лише до своїх підрозділів");
        var rows = await _db.MembershipDivisions.Where(d => d.MembershipId == e.Id).ToListAsync();
        foreach (var row in rows.Where(r => !ids.Contains(r.DivisionId) && (_db.AllowedDepartmentIds == null || _db.AllowedDepartmentIds.Contains(r.DivisionId))))
            _db.MembershipDivisions.Remove(row);
        foreach (var id in ids.Where(id => rows.All(r => r.DivisionId != id)))
            _db.MembershipDivisions.Add(new IdMembershipDivision { MembershipId = e.Id, DivisionId = id });
    }

    private IQueryable<OrgEmployee> EmployeesQuery() => _db.Employees.Include(e => e.Department).Include(e => e.PositionType).Where(e => e.RecordState != RecordStates.Deleted);

    public async Task<List<EmployeeView>> EmployeesAsync()
    {
        var allowed = await AllowedDepartmentsAsync();
        return (await EmployeesQuery().AsNoTracking().OrderBy(e => e.Caption).ToListAsync()).Select(e => ToView(e, allowed.GetValueOrDefault(e.Id))).ToList();
    }

    public async Task<EmployeeView?> EmployeeAsync(string id)
    {
        var e = await EmployeesQuery().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return e == null ? null : ToView(e, (await AllowedDepartmentsAsync(e.Id)).GetValueOrDefault(e.Id));
    }

    public async Task<EmployeeView> SaveEmployeeAsync(string? id, JsonElement body)
    {
        _policy.Require(nameof(ApplicationOperations.EmployeeSave));
        OrgEmployee e;
        string? targetRole = null;
        if (id == null)
        {
            var person = new CmnPerson();
            e = new OrgEmployee { Person = person, PersonId = person.Id, TenantId = _db.CurrentTenantId, WorkingStartDate = DateTime.UtcNow.Date, LabSettings = new LabEmployeeSettings() };
            e.LabSettings.EmployeeId = e.Id;
            _db.Employees.Add(e);
        }
        else
        {
            e = await EmployeesQuery().FirstOrDefaultAsync(x => x.Id == id) ?? throw NotFoundException.For("Співробітник", id);
            targetRole = await TargetRoleAsync(e);
            if (e.LabSettings == null) { e.LabSettings = new LabEmployeeSettings { EmployeeId = e.Id }; _db.EmployeeSettings.Add(e.LabSettings); }
        }
        var before = ToView(e, id == null ? null : (await AllowedDepartmentsAsync(e.Id)).GetValueOrDefault(e.Id));
        var v = Merge(before, body);
        if (body.TryGetProperty("positionName", out var pn) && pn.ValueKind == JsonValueKind.String) v.Position = pn.GetString(); // сумісність із v4.0
        if (string.IsNullOrWhiteSpace(v.FullName) && string.IsNullOrWhiteSpace(v.LastName)) throw new ValidationException("ПІБ співробітника обов'язкове");
        if (!LabRoles.All.Contains(v.LabRole)) throw ValidationException.Field("labRole", $"Роль має бути однією з: {string.Join(", ", LabRoles.All)}");
        var actorRole = ActorRole();
        if (actorRole != LabRoles.Admin && (actorRole == null || (id != null && (e.Id == _current.EmployeeId || !LabRoles.CanManage(actorRole, targetRole))) || !LabRoles.CanManage(actorRole, v.LabRole)))
            throw new OperationDeniedException(RankDeniedDetail(actorRole));
        if (v.DepartmentId != null && !await _db.Divisions.AnyAsync(d => d.Id == v.DepartmentId)) throw ValidationException.Field("departmentId", "Підрозділ не знайдено");

        // ПІБ: якщо змінено fullName — розкладаємо на прізвище/ім'я/по батькові
        if (body.TryGetProperty("fullName", out _) && !body.TryGetProperty("lastName", out _))
        {
            var parts = (v.FullName ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
            v.LastName = parts.ElementAtOrDefault(0); v.FirstName = parts.ElementAtOrDefault(1); v.MiddleName = parts.Length > 2 ? string.Join(" ", parts.Skip(2)) : null;
        }
        var p = e.Person!;
        p.LastName = v.LastName; p.Name = v.FirstName; p.MiddleName = v.MiddleName; p.Phone = v.Phone; p.Email = v.Email;
        p.Caption = CmnPerson.BuildCaption(p.LastName, p.Name, p.MiddleName);
        e.Caption = p.Caption; e.DepartmentId = v.DepartmentId;
        e.PositionTypeId = string.IsNullOrWhiteSpace(v.PositionTypeId) || id == null ? await _db.EnumRecordIdAsync("OrgPositionType", PositionTypeCodeFor(v.LabRole)) : v.PositionTypeId!;
        e.LabSettings!.LabRole = v.LabRole; e.LabSettings.PositionName = v.Position; e.LabSettings.DigitalSignatureCertId = v.DigitalSignatureCertId; e.LabSettings.IsActive = v.IsActive;
        if (id == null || body.TryGetProperty("allowedDepartmentIds", out _)) await SetAllowedDepartmentsAsync(e, v.AllowedDepartmentIds ?? new());
        var profileChanged = await RightsSeedHelper.SetLabSecurityProfileAsync(_db, e.Id, v.LabRole);
        var membershipRoleId = await MembershipRoleIdAsync(v.LabRole);
        if (id == null) e.Membership = new IdMembership { Id = e.Id, TenantId = e.TenantId, UserId = p.Id, RoleId = membershipRoleId, IsActive = true };
        else (await _db.Memberships.FirstOrDefaultAsync(m => m.Id == e.Id) ?? throw new InvalidOperationException($"Співробітник {e.Id}: членство не знайдено")).RoleId = membershipRoleId;
        _audit.Log(id == null ? "CREATE" : "UPDATE", "org_employee", e.Id, id == null ? null : before, v);
        await _db.SaveChangesAsync();
        if (profileChanged && !string.IsNullOrEmpty(p.UserId)) _userService.DeleteUserInfo(p.UserId);
        return (await EmployeeAsync(e.Id))!;
    }

    private async Task<string> MembershipRoleIdAsync(string labRole)
    {
        var caption = RightsSeedHelper.Security.ForRole(labRole)?.Caption ?? throw new InvalidOperationException($"Роль {labRole}: заголовок профілю не знайдено");
        var profileIds = await _db.SecurityProfiles!.AsNoTracking().Where(p => p.Caption == caption && p.RecordState == CoreRecordState.Active).Select(p => p.Id).ToListAsync();
        if (profileIds.Count != 1) throw new InvalidOperationException($"Роль {labRole}: профілів з назвою «{caption}» {profileIds.Count}, очікувався один");
        var roleIds = await _db.ProfileRoles!.AsNoTracking().Where(pr => pr.ProfileId == profileIds[0] && pr.RecordState == CoreRecordState.Active).Select(pr => pr.RoleId).ToListAsync();
        return roleIds.Count == 1 ? roleIds[0].ToString()
            : throw new InvalidOperationException($"Роль {labRole}: у профілі «{caption}» ролей {roleIds.Count}, очікувалась одна");
    }

    // ------------------------------------------------------------------ delete (деактивація при залежностях)
    public async Task<object> DeleteAsync(string name, string id)
    {
        if (name == "departments")
        {
            var d = await _db.Divisions.FirstOrDefaultAsync(x => (x.Id == id || x.Code == id) && x.RecordState != RecordStates.Deleted) ?? throw NotFoundException.For("Відділення", id);
            var deps = await _db.Employees.CountAsync(x => x.DepartmentId == d.Id) + await _db.Orders.CountAsync(o => o.DepartmentId == d.Id) + await _db.Analyzers.CountAsync(a => a.DepartmentId == d.Id)
                       + await _db.Sections.CountAsync(s => s.DepartmentId == d.Id);
            return await DeleteOrDeactivate("tn_division", d, d.Id, d, deps, s => s.IsActive = false);
        }
        var e = await _db.Employees.FirstOrDefaultAsync(x => x.Id == id && x.RecordState != RecordStates.Deleted) ?? throw NotFoundException.For("Співробітник", id);
        var edeps = await _db.Orders.CountAsync(o => o.DoctorId == e.Id || o.CreatedById == e.Id) + await _db.Results.CountAsync(r => r.VerifiedById == e.Id || r.EnteredById == e.Id);
        return await DeleteOrDeactivate("org_employee", e, e.Id, e.LabSettings, edeps, s => s.IsActive = false);
    }

    private async Task<object> DeleteOrDeactivate<TSettings>(string table, AuditableEntity entity, string entityId, TSettings? settings, int deps, Action<TSettings> deactivate) where TSettings : class
    {
        if (deps > 0)
        {
            if (settings != null) deactivate(settings);
            _audit.Log("SOFT_DELETE", table, entityId, null, new { isActive = false, dependencies = deps });
            await _db.SaveChangesAsync();
            return new { id = entityId, deleted = false, deactivated = true, dependencies = deps, message = $"Запис використовується ({deps}) — деактивовано (isActive=false)" };
        }
        // Як в evomis — м'яке видалення record_state = 4
        entity.RecordState = RecordStates.Deleted;
        if (settings != null) deactivate(settings);
        _audit.Log("DELETE", table, entityId, null, null);
        await _db.SaveChangesAsync();
        return new { id = entityId, deleted = true };
    }

    /// <summary>Накладає присутні в тілі запиту поля на поточний вигляд.</summary>
    private static T Merge<T>(T current, JsonElement body)
    {
        var node = System.Text.Json.Nodes.JsonNode.Parse(JsonSerializer.Serialize(current, Json))!.AsObject();
        foreach (var prop in body.EnumerateObject())
        {
            var key = node.Select(k => k.Key).FirstOrDefault(k => string.Equals(k, prop.Name, StringComparison.OrdinalIgnoreCase));
            if (key != null && !string.Equals(key, "id", StringComparison.OrdinalIgnoreCase)) node[key] = System.Text.Json.Nodes.JsonNode.Parse(prop.Value.GetRawText());
        }
        return JsonSerializer.Deserialize<T>(node.ToJsonString(), Json)!;
    }
}
