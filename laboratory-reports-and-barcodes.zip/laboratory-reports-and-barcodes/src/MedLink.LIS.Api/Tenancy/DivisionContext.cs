namespace MedLink.LIS.Api.Tenancy;

public interface IDivisionContext
{
    IReadOnlyCollection<string>? AllowedDepartmentIds { get; }
    void Resolve(IReadOnlyCollection<string>? departmentIds);
    IDisposable RunAs(IReadOnlyCollection<string>? departmentIds);
}

public sealed class DivisionContext : IDivisionContext
{
    private static readonly AsyncLocal<IReadOnlyCollection<string>?> Ambient = new();

    public IReadOnlyCollection<string>? AllowedDepartmentIds => Ambient.Value;

    public void Resolve(IReadOnlyCollection<string>? departmentIds) => Ambient.Value = departmentIds;

    public IDisposable RunAs(IReadOnlyCollection<string>? departmentIds)
    {
        var previous = Ambient.Value;
        Ambient.Value = departmentIds;
        return new Scope(previous);
    }

    private sealed class Scope(IReadOnlyCollection<string>? previous) : IDisposable
    {
        public void Dispose() => Ambient.Value = previous;
    }
}
