namespace MedLink.LIS.Api.Tenancy;

public interface ITenantContext
{
    string? TenantId { get; }
    void Resolve(string tenantId);
    IDisposable RunAs(string tenantId);
}

public sealed class TenantContext : ITenantContext
{
    private static readonly AsyncLocal<string?> Ambient = new();

    public string? TenantId => Ambient.Value;

    public void Resolve(string tenantId) => Ambient.Value = TenantIds.Require(tenantId);

    public IDisposable RunAs(string tenantId)
    {
        var previous = Ambient.Value;
        Ambient.Value = TenantIds.Require(tenantId);
        return new Scope(previous);
    }

    private sealed class Scope(string? previous) : IDisposable
    {
        public void Dispose() => Ambient.Value = previous;
    }
}

public static class TenantIds
{
    public static string Require(string? tenantId) =>
        Guid.TryParse(tenantId, out _) ? tenantId! : throw new TenantNotSetException();
}

public sealed class TenantNotSetException : InvalidOperationException
{
    public TenantNotSetException() : base("Організацію не визначено: доступ до даних організації без контексту організації заборонено") { }
}

public sealed class TenantMismatchException : InvalidOperationException
{
    public TenantMismatchException(string? table) : base($"Запис {table} належить іншій організації, ніж поточна") { }
}

public sealed class DepartmentNotAllowedException : InvalidOperationException
{
    public DepartmentNotAllowedException(string? departmentId) : base($"Підрозділ '{departmentId}' недоступний для поточного співробітника") { }
}
