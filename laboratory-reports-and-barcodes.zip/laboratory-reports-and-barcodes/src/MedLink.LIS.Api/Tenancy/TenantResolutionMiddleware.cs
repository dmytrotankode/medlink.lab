using Core.Services;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace MedLink.LIS.Api.Tenancy;

public sealed class TenantResolutionMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context, LisDbContext db, ITenantContext tenant, IDivisionContext division)
    {
        var ct = context.RequestAborted;
        var selected = await SelectedEmployeeAsync(context);
        if (selected == null)
        {
            await next(context);
            return;
        }

        var (identityUserId, employeeId) = selected.Value;
        var tenantId = await db.RunAsUserAsync(identityUserId, () => db.Employees.IgnoreQueryFilters().AsNoTracking()
            .Where(e => e.Id == employeeId)
            .Select(e => e.TenantId)
            .FirstOrDefaultAsync(ct), ct);
        if (tenantId == null)
        {
            await next(context);
            return;
        }

        tenant.Resolve(tenantId);
        await db.RunInTenantAsync(async () =>
        {
            var divisionIds = await db.MembershipDivisions.AsNoTracking()
                .Where(d => d.MembershipId == employeeId)
                .Select(d => d.DivisionId)
                .ToListAsync(ct);
            division.Resolve(divisionIds.Count > 0 ? divisionIds : null);
            await next(context);
        }, ct);
    }

    private static async Task<(string IdentityUserId, string EmployeeId)?> SelectedEmployeeAsync(HttpContext context)
    {
        if (context.User?.Identity?.IsAuthenticated != true || !context.Request.Path.StartsWithSegments("/api")) return null;
        var userInfo = await context.RequestServices.GetRequiredService<IUserInfoService>().GetCurrentUserInfoAsync();
        if (userInfo == null || string.IsNullOrEmpty(userInfo.Id) || userInfo.ProfileId == Guid.Empty || userInfo.UserId == Guid.Empty) return null;
        return (userInfo.Id, userInfo.UserId.ToString());
    }
}
