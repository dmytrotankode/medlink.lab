using System.Globalization;
using System.Text;

namespace MedLink.LIS.Core.Barcodes;

public static class Code39Svg
{
    private const string Alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%";

    private static readonly Dictionary<char, string> Patterns = new()
    {
        ['0'] = "000110100", ['1'] = "100100001", ['2'] = "001100001", ['3'] = "101100000",
        ['4'] = "000110001", ['5'] = "100110000", ['6'] = "001110000", ['7'] = "000100101",
        ['8'] = "100100100", ['9'] = "001100100", ['A'] = "100001001", ['B'] = "001001001",
        ['C'] = "101001000", ['D'] = "000011001", ['E'] = "100011000", ['F'] = "001011000",
        ['G'] = "000001101", ['H'] = "100001100", ['I'] = "001001100", ['J'] = "000011100",
        ['K'] = "100000011", ['L'] = "001000011", ['M'] = "101000010", ['N'] = "000010011",
        ['O'] = "100010010", ['P'] = "001010010", ['Q'] = "000000111", ['R'] = "100000110",
        ['S'] = "001000110", ['T'] = "000010110", ['U'] = "110000001", ['V'] = "011000001",
        ['W'] = "111000000", ['X'] = "010010001", ['Y'] = "110010000", ['Z'] = "011010000",
        ['-'] = "010000101", ['.'] = "110000100", [' '] = "011000100", ['$'] = "010101000",
        ['/'] = "010100010", ['+'] = "010001010", ['%'] = "000101010", ['*'] = "010010100"
    };

    public static char Checksum(string text)
    {
        if (string.IsNullOrEmpty(text))
            throw new ArgumentException("Порожній рядок", nameof(text));

        var sum = 0;
        foreach (var c in text.ToUpperInvariant())
        {
            var idx = Alphabet.IndexOf(c);
            if (idx < 0)
                throw new ArgumentException($"Символ '{c}' не підтримується Code39", nameof(text));
            sum += idx;
        }

        return Alphabet[sum % 43];
    }

    public static bool IsValid(string? text)
    {
        if (string.IsNullOrEmpty(text)) return false;
        var clean = text.Trim('*').ToUpperInvariant();
        if (clean.Length == 0) return false;
        return clean.All(c => Alphabet.Contains(c));
    }

    public static string Render(string text, int height = 60, int moduleWidth = 2, bool showText = true, bool includeChecksum = false)
    {
        if (string.IsNullOrEmpty(text))
            throw new ArgumentException("Порожній текст", nameof(text));

        var raw = text.Trim('*').ToUpperInvariant();
        if (includeChecksum)
            raw += Checksum(raw);

        var fullString = "*" + raw + "*";
        foreach (var c in fullString)
        {
            if (!Patterns.ContainsKey(c))
                throw new ArgumentException($"Символ '{c}' не підтримується Code39", nameof(text));
        }

        var wideRatio = 2;
        var charModuleCount = 6 * 1 + 3 * wideRatio + 1; // 6 narrow + 3 wide + 1 intercharacter gap
        var quiet = 10;
        var totalModules = quiet * 2 + (fullString.Length * charModuleCount) - 1;
        var width = totalModules * moduleWidth;
        var textHeight = showText ? 14 : 0;

        var sb = new StringBuilder();
        sb.Append(CultureInfo.InvariantCulture,
            $"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height + textHeight + 2}\" viewBox=\"0 0 {width} {height + textHeight + 2}\" shape-rendering=\"crispEdges\">");
        sb.Append(CultureInfo.InvariantCulture, $"<rect width=\"{width}\" height=\"{height + textHeight + 2}\" fill=\"#fff\"/>");

        var x = quiet * moduleWidth;
        for (var i = 0; i < fullString.Length; i++)
        {
            var pattern = Patterns[fullString[i]];
            for (var elem = 0; elem < 9; elem++)
            {
                var isBar = (elem % 2 == 0);
                var isWide = (pattern[elem] == '1');
                var w = (isWide ? wideRatio : 1) * moduleWidth;

                if (isBar)
                {
                    sb.Append(CultureInfo.InvariantCulture,
                        $"<rect x=\"{x}\" y=\"0\" width=\"{w}\" height=\"{height}\" fill=\"#000\"/>");
                }
                x += w;
            }

            if (i < fullString.Length - 1)
            {
                x += moduleWidth;
            }
        }

        if (showText)
        {
            var textY = height + 12;
            sb.Append(CultureInfo.InvariantCulture,
                $"<text x=\"{width / 2}\" y=\"{textY}\" text-anchor=\"middle\" font-family=\"monospace\" font-size=\"12\" fill=\"#000\">{fullString}</text>");
        }

        sb.Append("</svg>");
        return sb.ToString();
    }
}

