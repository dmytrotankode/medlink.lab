using System.Globalization;
using System.Text;

namespace MedLink.LIS.Core.Barcodes;

public static class Ean13Svg
{
    private static readonly string[] LPatterns =
    {
        "0001101", "0011001", "0010011", "0111101", "0100011",
        "0110001", "0101111", "0111011", "0110111", "0001011"
    };

    private static readonly string[] GPatterns =
    {
        "0100111", "0110011", "0011011", "0100001", "0011101",
        "0111001", "0000101", "0010001", "0001001", "0010111"
    };

    private static readonly string[] RPatterns =
    {
        "1110010", "1100110", "1101100", "1000010", "1011100",
        "1001110", "1010000", "1000100", "1001000", "1110100"
    };

    private static readonly string[] ParityPatterns =
    {
        "LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG",
        "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"
    };

    public static int CheckDigit(string first12Digits)
    {
        if (first12Digits == null || first12Digits.Length != 12 || !first12Digits.All(char.IsDigit))
            throw new ArgumentException("Очікується 12 цифр", nameof(first12Digits));

        var sum = 0;
        for (var i = 0; i < 12; i++)
        {
            var digit = first12Digits[i] - '0';
            sum += (i % 2 == 0) ? digit * 1 : digit * 3;
        }
        var rem = sum % 10;
        return rem == 0 ? 0 : 10 - rem;
    }

    public static bool IsValid(string? barcode)
    {
        if (string.IsNullOrEmpty(barcode) || barcode.Length != 13 || !barcode.All(char.IsDigit))
            return false;

        return CheckDigit(barcode.Substring(0, 12)) == (barcode[12] - '0');
    }

    public static string Complete(string first12Digits)
    {
        return first12Digits + CheckDigit(first12Digits).ToString(CultureInfo.InvariantCulture);
    }

    public static string Render(string barcode, int height = 60, int moduleWidth = 2, bool showText = true)
    {
        if (string.IsNullOrEmpty(barcode))
            throw new ArgumentException("Порожній штрихкод", nameof(barcode));

        var fullBarcode = barcode;
        if (fullBarcode.Length == 12 && fullBarcode.All(char.IsDigit))
            fullBarcode = Complete(fullBarcode);

        if (fullBarcode.Length != 13 || !fullBarcode.All(char.IsDigit))
            throw new ArgumentException("EAN-13 вимагає 12 або 13 цифр", nameof(barcode));

        var firstDigit = fullBarcode[0] - '0';
        var parity = ParityPatterns[firstDigit];

        var bits = new StringBuilder();
        bits.Append("101");

        for (var i = 1; i <= 6; i++)
        {
            var digit = fullBarcode[i] - '0';
            bits.Append(parity[i - 1] == 'L' ? LPatterns[digit] : GPatterns[digit]);
        }

        bits.Append("01010");

        for (var i = 7; i <= 12; i++)
        {
            var digit = fullBarcode[i] - '0';
            bits.Append(RPatterns[digit]);
        }

        bits.Append("101");

        var bitStr = bits.ToString();
        var quiet = 9;
        var totalModules = quiet * 2 + bitStr.Length;
        var width = totalModules * moduleWidth;
        var textHeight = showText ? 14 : 0;

        var sb = new StringBuilder();
        sb.Append(CultureInfo.InvariantCulture,
            $"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height + textHeight + 2}\" viewBox=\"0 0 {width} {height + textHeight + 2}\" shape-rendering=\"crispEdges\">");
        sb.Append(CultureInfo.InvariantCulture, $"<rect width=\"{width}\" height=\"{height + textHeight + 2}\" fill=\"#fff\"/>");

        var x = quiet * moduleWidth;
        for (var i = 0; i < bitStr.Length; i++)
        {
            if (bitStr[i] == '1')
            {
                var isGuard = (i < 3) || (i >= 45 && i < 50) || (i >= 92);
                var barHeight = isGuard && showText ? height + 5 : height;
                sb.Append(CultureInfo.InvariantCulture, $"<rect x=\"{x}\" y=\"0\" width=\"{moduleWidth}\" height=\"{barHeight}\" fill=\"#000\"/>");
            }
            x += moduleWidth;
        }

        if (showText)
        {
            var textY = height + 12;
            sb.Append(CultureInfo.InvariantCulture,
                $"<text x=\"{width / 2}\" y=\"{textY}\" text-anchor=\"middle\" font-family=\"monospace\" font-size=\"12\" fill=\"#000\">{fullBarcode}</text>");
        }

        sb.Append("</svg>");
        return sb.ToString();
    }
}

