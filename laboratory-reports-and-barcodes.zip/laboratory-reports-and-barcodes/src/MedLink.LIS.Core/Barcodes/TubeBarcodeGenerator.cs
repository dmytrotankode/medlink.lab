// =============================================================================
// MedLink LIS 4.0 — штрихкод пробірки: підтримка Code128 (10 цифр mod-10 дефолт),
// EAN-13, Code39 та збереження процедури Simplex EAN-8.
// =============================================================================
namespace MedLink.LIS.Core.Barcodes;

public static class TubeBarcodeGenerator
{
    public const string CounterCode = "lab_tube_barcode_ean8";
    public const string DefaultSymbology = "Code128";

    /// <summary>
    /// Алгоритм Simplex (EAN-8, 8 символів):
    /// 1) значення лічильника → останні 7 цифр із доповненням нулями + «0» (8 символів);
    /// 2) якщо перший символ «0» → замінюється на «1»;
    /// 3) контрольна цифра у стилі EAN-8: позиції 1..8, непарні ×3, парні ×1
    ///    (8-ма позиція — заглушка «0»), сума mod 10, доповнення до 10;
    /// 4) результат — перші 7 символів + контрольна цифра.
    /// </summary>
    public static string Generate(long counterValue)
    {
        if (counterValue < 0) throw new ArgumentOutOfRangeException(nameof(counterValue));
        var padded = ("00000000" + counterValue.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var seven = padded.Substring(padded.Length - 7, 7);
        var barcode = seven + "0";
        if (barcode[0] == '0') barcode = "1" + barcode.Substring(1, 7);
        var check = CheckDigit(barcode.Substring(0, 7));
        return barcode.Substring(0, 7) + check.ToString();
    }

    /// <summary>
    /// Числовий 10-значний штрихкод (Code128 дефолт):
    /// 9 цифр значення (перша не '0') + 10-а контрольна цифра (mod 10).
    /// </summary>
    public static string GenerateCode128(long counterValue)
    {
        if (counterValue < 0) throw new ArgumentOutOfRangeException(nameof(counterValue));
        var padded = ("0000000000" + counterValue.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var nine = padded.Substring(padded.Length - 9, 9);
        if (nine[0] == '0') nine = "1" + nine.Substring(1, 8);
        var check = CheckDigitMod10(nine);
        return nine + check.ToString(System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// EAN-13 (13 знаків): префікс 2 цифри (дефолт 20 для внутрішнього використання) + 10 цифр лічильника + контрольна.
    /// </summary>
    public static string GenerateEan13(long counterValue, string prefix = "20")
    {
        if (counterValue < 0) throw new ArgumentOutOfRangeException(nameof(counterValue));
        var pref = string.IsNullOrWhiteSpace(prefix) ? "20" : prefix.Trim();
        if (pref.Length > 2) pref = pref.Substring(0, 2);
        else if (pref.Length < 2) pref = pref.PadRight(2, '0');

        var padded = ("0000000000" + counterValue.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var ten = padded.Substring(padded.Length - 10, 10);
        var first12 = pref + ten;
        return Ean13Svg.Complete(first12);
    }

    /// <summary>
    /// Code39: буквено-числовий префікс (дефолт T) + 8 цифр лічильника.
    /// </summary>
    public static string GenerateCode39(long counterValue, string prefix = "T")
    {
        if (counterValue < 0) throw new ArgumentOutOfRangeException(nameof(counterValue));
        var pref = string.IsNullOrWhiteSpace(prefix) ? "T" : prefix.Trim().ToUpperInvariant();
        var padded = ("00000000" + counterValue.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var eight = padded.Substring(padded.Length - 8, 8);
        return pref + eight;
    }

    /// <summary>
    /// Генерація згідно з обраною символікою (Code128 / Ean13 / Code39 / Ean8).
    /// </summary>
    public static string GenerateFormatted(long counterValue, string? symbology, string? prefix = null)
    {
        var sym = (symbology ?? DefaultSymbology).Trim().ToUpperInvariant();
        return sym switch
        {
            "EAN13" or "EAN-13" => GenerateEan13(counterValue, prefix ?? "20"),
            "CODE39" => GenerateCode39(counterValue, prefix ?? "T"),
            "EAN8" or "EAN-8" => Generate(counterValue),
            _ => GenerateCode128(counterValue)
        };
    }

    /// <summary>Контрольна цифра mod-10 для 9 цифр.</summary>
    public static int CheckDigitMod10(string digits)
    {
        if (digits == null || digits.Length != 9 || !digits.All(char.IsDigit))
            throw new ArgumentException("Очікується 9 цифр", nameof(digits));

        var sum = 0;
        for (var i = 0; i < digits.Length; i++)
        {
            var digit = digits[i] - '0';
            sum += (i % 2 == 0) ? digit * 3 : digit * 1;
        }
        var rl1 = sum % 10;
        return rl1 != 0 ? 10 - rl1 : 0;
    }

    /// <summary>Контрольна цифра для перших 7 цифр (Simplex EAN-8).</summary>
    public static int CheckDigit(string firstSevenDigits)
    {
        if (firstSevenDigits == null || firstSevenDigits.Length != 7 || !firstSevenDigits.All(char.IsDigit))
            throw new ArgumentException("Очікується 7 цифр", nameof(firstSevenDigits));
        var body = firstSevenDigits + "0";
        var sum = 0;
        for (var i = 8; i > 0; i--)
        {
            var digit = body[i - 1] - '0';
            sum += (i % 2 == 0) ? digit * 1 : digit * 3;
        }
        var rl1 = sum % 10;
        return rl1 != 0 ? 10 - rl1 : 0;
    }

    /// <summary>Перевірка: 8-значний EAN-8, 10-значний Code128, 13-значний EAN-13 або Code39.</summary>
    public static bool IsValid(string? barcode)
    {
        if (string.IsNullOrEmpty(barcode)) return false;
        if (barcode.Length == 8 && barcode.All(char.IsDigit))
            return CheckDigit(barcode.Substring(0, 7)) == barcode[7] - '0';
        if (barcode.Length == 10 && barcode.All(char.IsDigit))
            return CheckDigitMod10(barcode.Substring(0, 9)) == barcode[9] - '0';
        if (barcode.Length == 13 && barcode.All(char.IsDigit))
            return Ean13Svg.IsValid(barcode);
        return Code39Svg.IsValid(barcode);
    }

    /// <summary>
    /// Рендеринг штрихкоду у SVG відповідно до символіки або автоматичного визначення.
    /// </summary>
    public static string RenderSvg(string barcode, string? symbology = null, int height = 60, int moduleWidth = 2, bool showText = true)
    {
        if (string.IsNullOrEmpty(barcode)) return "";

        var sym = symbology?.Trim().ToUpperInvariant();
        if (sym is "EAN13" or "EAN-13" || (sym == null && barcode.Length == 13 && barcode.All(char.IsDigit)))
            return Ean13Svg.Render(barcode, height, moduleWidth, showText);

        if (sym is "CODE39" || (sym == null && (barcode.StartsWith("*") || barcode.Any(char.IsLetter))))
            return Code39Svg.Render(barcode, height, moduleWidth, showText);

        return Code128Svg.Render(barcode, height, moduleWidth, showText);
    }
}
