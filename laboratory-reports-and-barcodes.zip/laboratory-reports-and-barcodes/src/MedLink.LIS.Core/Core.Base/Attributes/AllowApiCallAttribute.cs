﻿using System;

namespace Core.Base.Attributes;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, Inherited = true, AllowMultiple = false)]
public class AllowApiCallAttribute : Attribute
{
}

