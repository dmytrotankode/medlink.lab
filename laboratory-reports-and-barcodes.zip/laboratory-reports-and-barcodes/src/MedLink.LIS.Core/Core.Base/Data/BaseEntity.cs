﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Core.Base.Data
{
    public abstract class BaseEntity: CoreEntity, ICaption
    {
        public virtual string Caption { get; set; }
    }
}
