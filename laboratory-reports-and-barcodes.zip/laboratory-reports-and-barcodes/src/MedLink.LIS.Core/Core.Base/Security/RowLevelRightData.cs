﻿using System;
using System.Collections.Generic;
using System.Text;
using Core.Base.Data;

namespace Core.Security
{
    /// <summary>
    /// Class represents row level right data for property of a class
    /// For example, the data for OrganizationId of Employee class
    /// </summary>
    public class RowLevelRightData
    {
        /// <summary>
        /// Name of the field, that represents the entity, for example OrganizationId in Employee class
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Permission type for entity by field with name Name
        /// Entity name itself is not included to this class,
        /// because this class is used only in dictionaries or other structures that have EntityName field,
        /// that defines which entity should checked for access
        /// </summary>
        public RowLevelModelPermissionType PermissionType { get; set; }
        /// <summary>
        /// List of ids for type that Name property references to, for example list of OrganizationId
        /// </summary>
        public List<string> Entities { get; set; }

        public RowLevelRightData(string name, RowLevelModelPermissionType permissionType, List<string> entities)
        {
            Name = name;
            PermissionType = permissionType;
            Entities = entities;
        }
    }
}
