﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Security
{
    public class RowLevelRightRule
    {
        /// <summary>
        /// Entity name which records will be checked for access
        /// For example, if access to employees uses RLS for any column(s), then MainEntityName = Employee
        /// </summary>
        public string MainEntityName { get; set; }
        /// <summary>
        /// Access level for records of MainEntityName separated by EntityName
        /// </summary>
        public RowLevelModelPermissionType PermissionType { get; set; }
        /// <summary>
        /// Entity name that separates database records in class with name MainEntityName
        /// For example, if access to employees is based on theirs organization, then EntityName = Organization
        /// </summary>
        public string EntityName { get; set; }
        /// <summary>
        /// ids of entities that reference to table with name EntityName
        /// </summary>
        public List<string> Entities { get; set; }

        public RowLevelRightRule(): this("", RowLevelModelPermissionType.No, "", new List<string>())
        {
        }

        public RowLevelRightRule(string entityName, RowLevelModelPermissionType permissionType, string mainEntityName, List<string> entities)
        {
            EntityName = entityName;
            PermissionType = permissionType;
            MainEntityName = mainEntityName;
            Entities = entities;
        }
    }
}
