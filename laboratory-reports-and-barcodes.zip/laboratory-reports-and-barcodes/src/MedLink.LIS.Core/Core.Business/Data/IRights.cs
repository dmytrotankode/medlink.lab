﻿using Core.Security;

namespace Core.Data
{
    public interface IRights
    {
        UserApplicationRights Rights { get; set; }
    }
}
