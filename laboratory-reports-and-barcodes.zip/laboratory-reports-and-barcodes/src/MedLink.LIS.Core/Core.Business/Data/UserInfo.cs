﻿using System;
using System.Collections.Generic;
using Core.Base.Data;
using Core.Security;

namespace Core.Data
{
    public class UserInfo: BaseUserInfo, IRights
    {
        public override BaseUserCultureInfo CultureInfo { get; set; }
        public UserApplicationRights Rights { get; set; }

        public override void AssertCanReadTypeData(Type dataType)
        {
            //? ISSUE - when PatientEpisodeListDto Rights == null and throw NullReferenceException
            //TODO - debug chain and find caller
            Rights?.AssertCanReadTypeData(dataType);
        }

        public override void AssertRlsAllowsObject(object obj)
        {
            Rights.AssertRlsAllowsObject(obj);
        }

        public override void AssertCanWriteTypeData(Type dataType)
        {
            Rights.AssertCanWriteTypeData(dataType);
        }

        public override void AssertWriteRights(string entityName, string fieldName)
        {
            Rights.AssertWriteRights(entityName, fieldName);
        }

        public override void AssertCanExecuteOperation(string operationName)
        {
            Rights.AssertCanExecuteOperation(operationName);
        }

        public override AccessLevel GetFieldRight(string entityName, string fieldName)
        {
            return Rights == null ? AccessLevel.No : Rights.GetFieldRight(entityName, fieldName);
        }

        public override List<RowLevelRightData> GetTypeFieldsRlsRights(Type dataType)
        {
            return Rights == null ? new List<RowLevelRightData>(0) : Rights.GetTypeFieldsRlsRights(dataType);
        }

        public override bool RlsAllowsAccessToObject(object obj)
        {
            return Rights == null ? false : Rights.RlsAllowsAccessToObject(obj);
        }

        public override bool IsInGlobalAdminRole() => Id.Equals(GlobalAdminId);

        //public override bool RlsAllowsAccessToEntity(string entityName, string entityId)
        //{
        //    return Rights == null ? false : Rights.RlsAllowsAccessToEntity(entityName, entityId);
        //}

        //public override bool CanReadTypeData(Type dataType)
        //{
        //    return Rights == null ? false : Rights.CanReadTypeData(dataType);
        //}

        //public override EntityAccessLevel GetEntityAccessLevel(string entityName)
        //{
        //    return Rights == null ? EntityAccessLevel.No : Rights.GetEntityAccessLevel(entityName);
        //}
    }
}
