﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace Core.ThirdParty.Redis;

public class RedisDatabaseProvider: IRedisDatabaseProvider
{
    private ConnectionMultiplexer _connectionMultiplexer;
    private readonly IConfiguration _configuration;
    private readonly ILogger<RedisDatabaseProvider> _logger;

    public RedisDatabaseProvider(
        ILogger<RedisDatabaseProvider> logger, 
        IConfiguration configuration)
    {
        _configuration = configuration;
        _logger = logger;

        InitializeMultiplexer();
        InitializeDatabase();
        InitializeServer();
    }

    public IDatabase Database { get; private set; }
    public IServer Server { get; private set; }
    public ConnectionMultiplexer ConnectionMultiplexer => _connectionMultiplexer;

    private void InitializeServer()
    {
        var url = _configuration.GetValue("ConnectionStrings:Redis", "<url not specified>");
        Server = _connectionMultiplexer.GetServer(url);
    }

    private void InitializeDatabase()
    {
        Database = _connectionMultiplexer.GetDatabase();

        var minNumberOfThreads = _configuration.GetValue<int>("RedisConfiguration:MinNumberOfThreads");

        ThreadPool.GetMinThreads(out _, out var minIOC);
        ThreadPool.SetMinThreads(minNumberOfThreads, minIOC);
    }

    private void InitializeMultiplexer()
    {
        var url = _configuration.GetValue("ConnectionStrings:Redis", "<url not specified>");

        try
        {
            var redisOptions = ConfigurationOptions.Parse(url);
            redisOptions.SyncTimeout = _configuration.GetValue<int>("RedisConfiguration:ResponseTimeout");
            _connectionMultiplexer = ConnectionMultiplexer.Connect(redisOptions);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Unable to connect to Redis at address {0}", url);
            throw;
        }
    }
}
