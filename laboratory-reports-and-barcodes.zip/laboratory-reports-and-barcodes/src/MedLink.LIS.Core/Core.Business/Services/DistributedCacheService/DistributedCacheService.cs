﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Core.ThirdParty.Redis;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace Core.Services.DistributedCacheService
{
    public class DistributedCacheService: IDistributedCacheService
    {
        private readonly IRedisDatabaseProvider _sourceProvider;
        private readonly ILogger<DistributedCacheService> _logger;

        public DistributedCacheService(IRedisDatabaseProvider sourceProvider, ILogger<DistributedCacheService> logger)
        {
            _sourceProvider = sourceProvider;
            _logger = logger;
        }

        public IDatabase Source => _sourceProvider.Database;

        public T GetValue<T>(string key)
        {
            try
            {
                return Source.GetValueFromString<T>(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get value from cache for the key {0}", key);
                //ClearKey(key);
                throw;
            }
        }

        public IEnumerable<T> GetValuesByPrefix<T>(string prefix)
        {
            try
            {
                return Source.GetValuesByPrefix<T>(prefix);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get value from cache for the prefix {0}", prefix);
                //ClearKey(key);
                throw;
            }
        }

        public Dictionary<int, List<T>> GetValuesByPrefixDict<T>(string prefix)
        {
            try
            {
                return Source.GetValuesByPrefixDict<T>(prefix);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get value from cache for the prefix {0}", prefix);
                //ClearKey(key);
                throw;
            }
        }

        public void ClearByPrefix(string prefix)
        {

            try
            {
                Source.ClearByPrefix(prefix);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get value from cache for the prefix {0}", prefix);
                //ClearKey(key);
                throw;
            }
        }

        public async Task<T> GetValueAsync<T>(string key)
        {
            try
            {
                return await Source.GetValueFromStringAsync<T>(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get value from cache for the key {0}", key);
                //ClearKey(key);
                throw;
            }
        }

        public void SetValue(string key, object value, TimeSpan? expiry = null)
        {
            try
            {
                Source.SaveValueAsString(key, value, expiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get save value to cache for the key {0} and object {1}", key, value);
                throw;
            }
        }

        public async Task SetValueAsync(string key, object value, TimeSpan? expiry = null)
        {
            try
            {
                await Source.SaveValueAsStringAsync(key, value, expiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot get save value to cache for the key {0} and object {1}", key, value);
                throw;
            }
        }

        public async Task ClearByPattern(string keyPattern)
        {
            try
            {
                var keys = _sourceProvider.Server.KeysAsync(pattern: $"{keyPattern}*", pageSize: 5000);

                await foreach (var key in keys)
                {
                    await ClearKeyAsync(key);
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Cannot delete values from cache by key pattern \"{keyPattern}\"");
                throw;
            }
        }

        public bool ClearKey(string key)
        {
            try
            {
                return Source.KeyDelete(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot delete value from cache for the key {0}", key);
                throw;
            }
        }
        public Task<bool> ClearKeyAsync(string key)
        {
            try
            {
                return Source.KeyDeleteAsync(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Cannot delete value from cache for the key {0}", key);
                throw;
            }
        }

        public async Task Reset(bool allSources = false)
        {
            if (allSources)
            {
                await Source.ExecuteAsync("FLUSHALL");
            }
            else
            {
                await Source.ExecuteAsync("FLUSHDB");
            }
        }

        public async Task SetBytesAsync(string key, byte[] value, TimeSpan? expiry = null)
        {
            try
            {
                await Source.StringSetAsync(key, value, expiry);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to set binary value to Redis for key {Key}", key);
                throw;
            }
        }

        public async Task<byte[]?> GetBytesAsync(string key)
        {
            try
            {
                var value = await Source.StringGetAsync(key);
                return value.HasValue ? (byte[])value : null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get binary value from Redis for key {Key}", key);
                throw;
            }
        }
    }
}
