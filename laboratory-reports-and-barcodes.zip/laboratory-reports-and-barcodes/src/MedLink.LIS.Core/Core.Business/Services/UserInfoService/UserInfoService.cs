﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Core.Data;
using Core.Security;
using Core.Security.Models;
using Core.Services.DistributedCacheService;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace Core.Services
{
    public class UserInfoService: IUserInfoService
    {
        public BaseUserInfo SystemUser
        {
            get => _systemUser;
        }

        protected readonly IDistributedCacheService CacheService;
        protected readonly IHttpContextAccessor HttpContextAccessor;
        protected readonly ISecurityDbContext DbContext;
        protected readonly IConfiguration Configuration;
        protected readonly string CacheSuffix = "_userInfo";
        protected readonly string CacheRightsSuffix = "_userRights";
        private static readonly UserInfo _systemUser;
        private UserInfo UserInfo;

        static UserInfoService()
        {
            _systemUser = new UserInfo
            {
                Rights = new UserApplicationRights(true)
                {
                    EntityRights = new Dictionary<string, EntityRightData>(),
                    OperationRights = new Dictionary<string, AccessLevel>(),
                    RowLevelRights = new Dictionary<string, List<RowLevelRightRule>>()
                }
            };
        }

        public UserInfoService(ISecurityDbContext dbcontext, IDistributedCacheService cacheService, IHttpContextAccessor httpContextAccessor, IConfiguration confguration)
        {
            CacheService = cacheService;
            HttpContextAccessor = httpContextAccessor;
            DbContext = dbcontext;
            Configuration = confguration;
        }

        public BaseUserInfo GetUserInfo(string userId)
        {
            var userInfo = GetUserInfoInternal(userId);
            if (userInfo == null)
            {
                return new UserInfo();
            }

            return Clone(userInfo);
        }

        public virtual async Task<BaseUserInfo> GetUserInfoAsync(string userId)
        {
            var userInfo = await GetUserInfoInternalAsync(userId);
            if (userInfo == null)
            {
                return new UserInfo();
            }

            return Clone(userInfo);
        }

        public virtual BaseUserInfo GetCurrentUserInfo()
        {
            var (userId, loginData) = GetCurrentLoginData();
            if (string.IsNullOrEmpty(userId))
            {
                return new UserInfo();
            }

            var userInfo = GetUserInfoInternal(userId, true);
            if (string.IsNullOrEmpty(userInfo?.Id))
            {
                userInfo = new UserInfo
                {
                    Id = userId,
                    LoginData = loginData,
                    CultureInfo = new BaseUserCultureInfo()
                };

                SaveUserInfoToCache(userInfo);
                return userInfo;
            }

            return Clone(userInfo);
        }

        public virtual async Task<BaseUserInfo> GetCurrentUserInfoAsync()
        {
            var (userId, loginData) = GetCurrentLoginData();
            if (string.IsNullOrEmpty(userId))
            {
                return new UserInfo();
            }

            var userInfo = await GetUserInfoInternalAsync(userId, true);
            if (string.IsNullOrEmpty(userInfo?.Id))
            {
                userInfo = new UserInfo
                {
                    Id = userId,
                    LoginData = loginData,
                    CultureInfo = new BaseUserCultureInfo()
                };

                SaveUserInfoToCache(userInfo);
                return userInfo;
            }

            return Clone(userInfo);
        }

        public virtual bool UpdateUserInfo(string id, Guid personId, Guid userId, Guid profileId)
        {
            var userInfo = GetUserInfoInternal(id);
            userInfo.Rights = null;
            return UpdateUserInfo(userInfo, personId, userId, profileId, false);
        }

        public virtual bool UpdateCurrentUserInfo(Guid personId, Guid userId, Guid profileId)
        {
            var userInfo = GetCurrentUserInfo() as UserInfo;
            userInfo.Rights = null;
            return UpdateUserInfo(userInfo, personId, userId, profileId, true);
        }

        public virtual void DeleteCurrentUserInfo()
        {
            var (userId, _) = GetCurrentLoginData();
            DeleteUserInfo(userId);
            UserInfo = null;
        }

        public virtual void DeleteUserInfo(string userId)
        {
            if (!string.IsNullOrEmpty(userId))
            {
                var rightsCacheKey = userId + CacheRightsSuffix;
                CacheService.ClearKey(rightsCacheKey);

                var cacheKey = userId + CacheSuffix;
                CacheService.ClearKey(cacheKey);
            }
        }

        private bool UpdateUserInfo(UserInfo userInfo, Guid personId, Guid userId, Guid profileId, bool isCurrent)
        {
            if (userInfo?.Id == null)
            {
                return false;
            }

            if (userInfo.PersonId != personId || userInfo.UserId != userId || userInfo.ProfileId != profileId)
            {
                userInfo.PersonId = personId;
                userInfo.UserId = userId;
                userInfo.ProfileId = profileId;
                
                if (isCurrent)
                {
                    UserInfo.PersonId = personId;
                    UserInfo.UserId = userId;
                    UserInfo.ProfileId = profileId;
                    // we need update rights now so the current user could use it within current scope
                    UpdateUserRights(userInfo);
                    UserInfo.Rights = userInfo.Rights;
                }

                SaveUserInfoToCache(userInfo);
            }

            return true;
        }

        protected virtual UserInfo GetUserInfoInternal(string userId, bool isCurrentUser = false)
        {
            var userInfo = GetUserInfoFromCache(userId, isCurrentUser);

            if (UpdateUserRights(userInfo))
            {
                SaveUserInfoToCache(userInfo);
            }

            return userInfo;
        }

        protected virtual async Task<UserInfo> GetUserInfoInternalAsync(string userId, bool isCurrentUser = false)
        {
            var userInfo = GetUserInfoFromCache(userId, isCurrentUser);

            if (await UpdateUserRightsAsync(userInfo))
            {
                SaveUserInfoToCache(userInfo);
            }

            return userInfo;
        }

        protected virtual bool SaveUserInfoToCache(UserInfo userInfo)
        {
            if (string.IsNullOrEmpty(userInfo.Id))
            {
                return false;
            }

            var rightsCacheDuration = Configuration.GetValue<int?>("Caching:Rights");
            TimeSpan? expiry = null;
            if (rightsCacheDuration.HasValue)
            {
                expiry = TimeSpan.FromSeconds(rightsCacheDuration.Value);
            }

            var rightsCacheKey = userInfo.Id + CacheRightsSuffix;
            CacheService.SetValue(rightsCacheKey, userInfo.Rights, expiry);

            var userInfoCacheDuration = Configuration.GetValue<int?>("Caching:UserInfo");
            expiry = null;
            if (userInfoCacheDuration.HasValue)
            {
                expiry = TimeSpan.FromSeconds(userInfoCacheDuration.Value);
            }
            var cacheKey = userInfo.Id + CacheSuffix;
            // should save user without rights, because rights stored separately with own invalidation time
            var clone = Clone(userInfo);
            clone.Rights = null;
            CacheService.SetValue(cacheKey, clone, expiry);

            return true;
        }

        protected virtual (string userId, Dictionary<string, string> loginData) GetCurrentLoginData()
        {
            var httpContext = HttpContextAccessor?.HttpContext;
            var userLogin = httpContext?.User?.FindFirst("name")?.Value;
            var id = httpContext?.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            var loginData = new Dictionary<string, string>
            {
                ["UserLogin"] = userLogin
            };

            return (id, loginData);
        }

        protected virtual UserInfo GetUserInfoFromCache(string userId, bool isCurrentUser)
        {
            if (string.IsNullOrEmpty(userId))
            {
                return new UserInfo();
            }

            UserInfo userInfo = null;
            if (isCurrentUser)
            {
                userInfo = UserInfo;
            }

            if (userInfo == null)
            {
                userInfo = CacheService.GetValue<UserInfo>(userId + CacheSuffix);
                if (isCurrentUser)
                {
                    UserInfo = userInfo;
                }
            }

            if (userInfo == null)
            {
                return new UserInfo();
            }

            // rights are stored separately from user
            if (userInfo?.Rights == null)
            {
                userInfo.Rights = CacheService.GetValue<UserApplicationRights>(userId + CacheRightsSuffix);
            }

            return userInfo;
        }

        private bool UpdateUserRights(UserInfo userInfo)
        {
            if (userInfo == null || userInfo.Rights != null || userInfo.ProfileId == Guid.Empty)
            {
                return false;
            }

            userInfo.Rights = DbContext?.GetUserRights(userInfo.ProfileId, userInfo.UserId, userInfo.IsInGlobalAdminRole());

            return true;
        }

        private async Task<bool> UpdateUserRightsAsync(UserInfo userInfo)
        {
            if (userInfo == null || userInfo.Rights != null || userInfo.ProfileId == Guid.Empty)
            {
                return false;
            }

            userInfo.Rights = await DbContext?.GetUserRightsAsync(userInfo.ProfileId, userInfo.UserId, userInfo.IsInGlobalAdminRole());

            return true;
        }

        private UserInfo Clone(UserInfo userInfo)
        {
            var clone = new UserInfo
            {
                Id = userInfo.Id,
                LoginData = userInfo.LoginData,
                UserId = userInfo.UserId,
                PersonId = userInfo.PersonId,
                ProfileId = userInfo.ProfileId,
                CultureInfo = userInfo.CultureInfo,
                Rights = userInfo.Rights
            };

            return clone;
        }
    }
}
