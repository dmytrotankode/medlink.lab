﻿using Core.Base.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Runtime.CompilerServices;

namespace Core.Mvc.Helpers;

public static class ControllerHelper
{
    public static ProblemDetails CreateProblemDetails(Exception exception, ILogger logger, string logMessageTemplate, params string[] logArgs)
    {
        if (logger != null)
        {
            logger.LogError(new EventId(400), exception, logMessageTemplate, logArgs);
        }

        return CreateProblemDetails(exception);
    }

    public static ProblemDetails CreateProblemDetails(Exception exception, ILogger logger, string methodName)
    {
        if (logger != null)
        {
            logger.LogError(new EventId(400), exception, "Error occurred while trying execute method {MethodName}", methodName);
        }

        return CreateProblemDetails(exception);
    }

    public static ProblemDetails CreateProblemDetails(Exception exception, ILogger logger, [CallerMemberName] string methodName = default, [CallerLineNumber] int lineNumber = default)
    {
        logger?.LogError(new EventId(400), exception, $"Error occurred while trying execute method {methodName} in line [{lineNumber}]");
        return CreateProblemDetails(exception);
    }

    public static ProblemDetails CreateProblemDetails(int status, string title, string message, ILogger logger, string logMessageTemplate, params string[] logArgs)
    {
        if (logger != null)
        {
            logger.LogError(new EventId(status), logMessageTemplate, logArgs);
        }

        return CreateProblemDetails(status, title, message);
    }

    public static ProblemDetails CreateProblemDetails(Exception exception, int status, string title, string message, ILogger logger, string logMessageTemplate, params string[] logArgs)
    {
        if (logger != null)
        {
            logger.LogError(new EventId(status), exception, logMessageTemplate, logArgs);
        }

        return CreateProblemDetails(status, title, message);
    }

    public static ProblemDetails CreateProblemDetails(Exception exception)
    {
        return CreateProblemDetails(exception, 400);
    }

    public static ProblemDetails CreateProblemDetails(Exception exception, int status)
    {
        if (exception.Message.Contains("Access denied. Party is not verified"))
            return CreateProblemDetails(status, "Помилка", "Увага! Співробітника не верифіковано, можливість роботи в ЕСОЗ тимчасово обмежена.\n\nДля подальшого розблокування роботи в ЕСОЗ необхідно перевірити актуальність зазначених персональних даних та, за потреби, актуалізувати їх. Якщо дані вказані відповідно до актуальних документів - необхідно звернутись до ДПС або ДРАЦСГ (залежно від отриманого статусу верифікації) для уточнення даних про себе.\n\nДля перевірки зазначених персональних даних та більш детальною інформацією щодо статусу верифікації просимо Вас звернутися до працівника відділу кадрів, чи керівника Вашого медзакладу.");

        if (exception.Message.Contains("Illegal author position.."))
            return CreateProblemDetails(status, "Помилка", "Посада автора вказана некоректно");

        if (exception.Message.Contains("Person is not active"))
            return CreateProblemDetails(status, "Помилка", "Пацієнт не активний в системі");

        if (exception.Message.Contains("Attempted to perform an unauthorized operation."))
            return CreateProblemDetails(status, "Помилка", "Термін дії сесії у eHealth минув. Виконайте, будь ласка, вхід до електронної системи охорони здоров'я під своїм обліковим записом!");

        if (exception.Message.Contains("Start date must be in past"))
            return CreateProblemDetails(status, "Помилка", "Початкова дата візиту повинна бути в минулому");

        if (exception.Message.Contains("End date must be in past"))
            return CreateProblemDetails(status, "Помилка", "Кінцева дата візиту повинна бути зазначена");

        if (exception.Message.Contains("End date must be equal to or less than current date"))
            return CreateProblemDetails(status, "Помилка", "Кінцева дата візиту не повинна бути в майбутньому");

        if (exception.Message.Contains("Same end date for new and existing composition.."))
            return CreateProblemDetails(status, "Помилка", "Однакова кінцева дата для нового та існуючого медичного висновку");

        if (exception.Message.Contains("Existing composition has start date after suggested start date.."))
            return CreateProblemDetails(status, "Помилка", "Не дозволяється створення МВТН, оскільки існує інший висновок в зазначений період, але з датою початку пізніше, ніш запропонований в запиті");

        if (exception.Message.Contains("Can't cancel - this composition has incoming relationships.."))
            return CreateProblemDetails(status, "Помилка", "Не вдалося відмінити медвисновок, оскільки він не є останнім у ланцюгу");

        if (exception.Message.Contains("Authentication method doesn't belong to master person."))
            return CreateProblemDetails(status, "Помилка", "Метод автентифікації не належить даній особі");

        if (exception.Message.Contains("The number of available services according to the care plan activity has been exhausted."))
            return CreateProblemDetails(status, "Помилка", "Кількість доступних послуг в призначенні плану лікування вичерпана або менша за кількість, що виписується");

        if (exception.Message.Contains("Procedure cannot be registered in future"))
            return CreateProblemDetails(status, "Помилка", "Процедура не може бути зареєстрована в майбутньому");

        if (exception is AppException appex)
            return CreateProblemDetails(status, appex.Title, appex.Message);

        if (exception.Message.Contains("Object reference not set to an instance of an object."))
            return CreateProblemDetails(status, "Помилка", "У доступі відмовлено.");

        return CreateProblemDetails(status, "Bad request", "Error occurred (details hidden)");
    }

    public static ProblemDetails CreateProblemDetails(int status, string title, string message)
    {
        return new ProblemDetails { Status = status, Title = title, Detail = message };
    }

    /// <summary>
    /// Returns the action name for ASP.NET Core routing (the method name without the "Async" suffix).
    /// </summary>
    public static string GetActionName(string asyncMethodName)
    {
        const string asyncSuffix = "Async";

        if (!string.IsNullOrEmpty(asyncMethodName) && asyncMethodName.EndsWith(asyncSuffix, StringComparison.Ordinal))
        {
            return asyncMethodName.Substring(0, asyncMethodName.Length - asyncSuffix.Length);
        }

        return asyncMethodName;
    }
}
