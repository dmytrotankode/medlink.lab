﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Base.Data;
using Core.Security.Models;

namespace Core.Security
{
    // TODO: queries should be changed to using dto
    // maybe should wrap into service and interface and implement interface with another service, that used dto
    public static class SecurityExtensions
    {
        public static UserApplicationRights GetUserRights(
            this ISecurityDbContext context,
            Guid profileId,
            Guid? userId = null,
            bool hasFullRights = false)
        {
            if (profileId == Guid.Empty)
            {
                return new UserApplicationRights(hasFullRights);
            }

            var rights = new UserApplicationRights(hasFullRights)
            {
                EntityRights = GetEntityRightsModel(context, profileId),
                RowLevelRights = GetRowLevelRightsModel(context, profileId, userId),
                OperationRights = GetOperationRightsModel(context, profileId)
            };

            return rights;
        }

        public static async Task<UserApplicationRights> GetUserRightsAsync(
            this ISecurityDbContext context,
            Guid profileId,
            Guid? userId = null,
            bool hasFullRights = false)
        {
            if (profileId == Guid.Empty)
            {
                return new UserApplicationRights(hasFullRights);
            }

            var rights = new UserApplicationRights(hasFullRights)
            {
                EntityRights = await Task.Factory.StartNew(() => GetEntityRightsModel(context, profileId)),
                RowLevelRights = await Task.Factory.StartNew(() => GetRowLevelRightsModel(context, profileId, userId)),
                OperationRights = await Task.Factory.StartNew(() => GetOperationRightsModel(context, profileId))
            };

            return rights;
        }

        private static Dictionary<string, AccessLevel> GetOperationRightsModel(
            ISecurityDbContext context,
            Guid profileId)
        {
            var resultList = (from prole in context.ProfileRoles
                         .Where(pr => pr.ProfileId == profileId && pr.RecordState != RecordState.Deleted)
                              join role in context.Roles.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                              on prole.RoleId equals role.Id
                              join rright in context.RoleOperationRights.Where(rr => rr.RecordState != RecordState.Deleted)
                              on role.Id equals rright.RoleId
                              join right in context.OperationRights.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                              on rright.OperationRightId equals right.Id
                              select new
                              {
                                  OperationName = right == null ? "" : right.OperationName,
                                  AccessLevel = right == null ? 0 : right.AccessLevel
                              })
                         .Where(x => x.OperationName != "")
                         .ToList();

            var profileOperationRights = (from pright in context.ProfileOperationRights
                                .Where(pr => pr.ProfileId == profileId && pr.RecordState != RecordState.Deleted)
                          join right in context.OperationRights.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                          on pright.OperationRightId equals right.Id
                          select new
                          {
                              OperationName = right == null ? "" : right.OperationName,
                              AccessLevel = right == null ? 0 : right.AccessLevel
                          })
                         .Where(x => x.OperationName != "")
                         .ToList();

            resultList.AddRange(profileOperationRights);

            return resultList
                    .GroupBy(g => g.OperationName)
                    .ToDictionary(k => k.Key, v => v.Max(el => el.AccessLevel));
        }

        private static Dictionary<string, List<EntityRights>> GetEntityRights(
            ISecurityDbContext context,
            Guid profileId)
        {
            var resultList = (from prole in context.ProfileRoles
                              .Where(pr => pr.ProfileId == profileId && pr.RecordState != RecordState.Deleted)
                         join role in context.Roles.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                         on prole.RoleId equals role.Id
                         join rright in context.RoleRights.Where(rr => rr.RecordState != RecordState.Deleted)
                         on role.Id equals rright.RoleId
                         join right in context.Rights.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                         on rright.RightId equals right.Id
                         select new RoleRights(right.EntityName, right.EntityAccessLevel, role.Id, right.Id))
                         .ToList();

            var profileRigths = (from pright in context.ProfileRights
                                   .Where(pr => pr.ProfileId == profileId && pr.RecordState != RecordState.Deleted)
                           join right in context.Rights.Where(r => r.IsActive && r.RecordState != RecordState.Deleted)
                           on pright.RightId equals right.Id
                           select new RoleRights(right.EntityName, right.EntityAccessLevel, Guid.Empty, right.Id))
                         .ToList();

            resultList.AddRange(profileRigths);

            var result = resultList
                               .GroupJoin(context.FieldRights,
                                r => new { r.RightId, r.EntityAccessLevel },
                                fr => new { fr.RightId, EntityAccessLevel = EntityAccessLevel.Partial },
                                (r, fr) => new EntityRights(r.EntityName, r.EntityAccessLevel, fr.Select(f => new FieldRights (f.FieldName, f.AccessLevel)).ToList()))
                                //.Select(r => new { r.EntityName, r.EntityAccessLevel, r.FieldRights })
                                .GroupBy(g => g.EntityName)
                                //.ToList();
                                .ToDictionary(k => k.Key, v => v.ToList());

            return result;           
        }

        private static Dictionary<string, EntityRightData> GetEntityRightsModel(
            ISecurityDbContext context,
            Guid profileId)
        {
            var entityRights = GetEntityRights(context, profileId);
            var entityRightsModel = GetEntityRightsModelFromEntityRights(context, entityRights);
            return entityRightsModel;
        }

        private static Dictionary<string, EntityRightData> GetEntityRightsModelFromEntityRights(
            ISecurityDbContext context,
            Dictionary<string, List<EntityRights>> entityRights)
        {
            var entityRightsModel = new Dictionary<string, EntityRightData>();
            foreach (var groupedRights in entityRights)
            {
                var right = groupedRights.Value;
                var maxAccessLevel = right.Max(el => el.EntityAccessLevel);
                var entityRight = new EntityRightData
                {
                    EntityName = groupedRights.Key,
                    EntityAccessLevel = maxAccessLevel
                };
                entityRightsModel.Add(groupedRights.Key, entityRight);

                if (maxAccessLevel != EntityAccessLevel.Partial)
                {
                    continue;
                }

                // in case of partial access we need combining rights in a special way
                // if there is role with full entity read access, then we need reflection to get all the properties
                var fieldRights = new Dictionary<string, AccessLevel>();
                foreach (var fields in right)
                {
                    if (fields.EntityAccessLevel == EntityAccessLevel.Partial)
                    {
                        foreach (var field in fields.FieldRights)
                        {
                            fieldRights.Add(field.FieldName, field.AccessLevel);
                        }
                    }
                    else if (fields.EntityAccessLevel == EntityAccessLevel.Read)
                    {
                        var properties = context.GetApplicationModels(true)
                            .Where(model => model.Name == fields.EntityName)
                            .FirstOrDefault()
                            ?.GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                        if (properties != null)
                        {
                            foreach (var prop in properties)
                            {
                                fieldRights.Add(prop.Name, AccessLevel.Read);
                            }
                        }
                    }
                }

                var combinedFieldRights = fieldRights.GroupBy(kv => kv.Key)
                    .Select(g => new { FieldName = g.Key, AccessLevel = g.Max(el => el.Value) })
                    .Where(kv => kv.AccessLevel != AccessLevel.No)
                    .ToDictionary(g => g.FieldName, g => g.AccessLevel);

                if (combinedFieldRights.Count == 0)
                {
                    entityRight.EntityAccessLevel = EntityAccessLevel.No;
                }
                else
                {
                    entityRight.FieldRights = combinedFieldRights;
                }

            }

            return entityRightsModel;
        }

        private static IQueryable<RlsRights> GetRlsRightsQuery(
            ISecurityDbContext context,
            Guid profileId)
        {
            var rlsRights = (from usedrls in context.ApplicationRowLevelRights.Where(r => r.IsActive)

                                 join rls in context.RowLevelRights.Where(el => el.ProfileId == profileId)
                                 on usedrls.EntityName equals rls.EntityName into appRowLevelRights
                                 from apprls in appRowLevelRights.DefaultIfEmpty()

                                 join rlsobj in context.RowLevelSecurityObjects
                                 on apprls.Id equals rlsobj.RowLevelRightId into secObjects
                                 from securityObject in secObjects.DefaultIfEmpty()

                                 select new RlsRights
                                 (
                                     usedrls.EntityName,
                                     (securityObject.EntityId == null ? Guid.Empty : securityObject.EntityId),
                                     // because of left join AccessType actually CAN be null, so disable this warning
#pragma warning disable CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
                                     apprls.AccessType == null ? RowLevelAccessType.No : apprls.AccessType,
#pragma warning restore CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
                                     apprls.MainEntityName,
                                     usedrls.IsHierarchical ? usedrls.HierarchyFieldName : ""
                                 ));
                                 
            return rlsRights;
        }

        private static Dictionary<string, Guid> GetDefaultValues(
            ISecurityDbContext context,
            List<RlsRights> rlsRights,
            Guid? userId)
        {
            var defaultValues = new Dictionary<string, Guid>();
            if (userId == null)
            {
                return defaultValues;
            }

            var needDefaultValues = userId.HasValue
                   && rlsRights
                   .Any(x => x.AccessType == RowLevelAccessType.Default);

            if (needDefaultValues)
            {
                defaultValues = context.UserDefaultValues
                   .Where(el => el.UserId == userId.Value)
                   .ToList()
                   .GroupBy(el => el.EntityName)
                   .Select(g => new { EntityName = g.Key, ValueId = g.Select(el => el.ValueId).FirstOrDefault() })
                   .ToDictionary(k => k.EntityName, v => v.ValueId);
            }

            return defaultValues;
        }

        private static Dictionary<string, List<RowLevelRightRule>> GetRowLevelRightsModelFromRlsRights(
            ISecurityDbContext context,
            List<RlsRights> rlsRights,
            Dictionary<string, Guid> defaultValues)
        {
            var rules = new Dictionary<string, List<RowLevelRightRule>>();
            if (rlsRights.Count == 0)
            {
                return rules;
            }

            // first, group by entity name and main entity name, to get grouped data
            // also group by HierarchyFieldName - this field is common for all rls for one entity
            var groupedRlsList = rlsRights.GroupBy(el => new { el.EntityName, el.MainEntityName, el.HierarchyFieldName });

            var enumConverter = new EnumConverter();
            foreach (var rightPair in groupedRlsList.Where(x => !string.IsNullOrEmpty(x.Key.EntityName)))
            {
                var entityName = rightPair.Key.EntityName;
                if (!rules.TryGetValue(entityName, out var rule))
                {
                    rule = new List<RowLevelRightRule>();
                    rules.Add(entityName, rule);
                }
                
                // create new rule and add to the list
                var accessType = rightPair.Select(el => el.AccessType).First();
                var rlsRight = new RowLevelRightRule(rightPair.Key.EntityName,
                    enumConverter.ToRowLevelModelPermissionType(accessType),
                    rightPair.Key.MainEntityName,
                    new List<string>());

                rule.Add(rlsRight);

                // in case of specific access we need combining rights in a special way
                // if there is right "Except" we need create combined "Except" rule
                // otherwise it will be "Specified" rule
                if (accessType != RowLevelAccessType.No && accessType != RowLevelAccessType.All)
                {
                    var rlsExceptObjects = new List<string>();
                    var rlsIncludeObjects = new List<string>();
                    foreach (var rlsr in rightPair)
                    {
                        if (rlsr.AccessType == RowLevelAccessType.Default)
                        {
                            if (defaultValues.TryGetValue(rlsr.EntityName, out var defValue)
                                && defValue != Guid.Empty)
                            {
                                rlsIncludeObjects.Add(defValue.ToString());
                            }
                        }
                        else if (rlsr.AccessType == RowLevelAccessType.Specified && rlsr.EntityId != Guid.Empty)
                        {
                            rlsIncludeObjects.Add(rlsr.EntityId.ToString());
                        }
                        else if (rlsr.AccessType == RowLevelAccessType.Except && rlsr.EntityId != Guid.Empty)
                        {
                            rlsExceptObjects.Add(rlsr.EntityId.ToString());
                        }
                    }

                    rlsExceptObjects = rlsExceptObjects.Distinct().ToList();
                    rlsIncludeObjects = rlsIncludeObjects.Distinct().ToList();

                    if (rlsExceptObjects.Count > 0)
                    {
                        rlsRight.Entities.AddRange(rlsExceptObjects.Except(rlsIncludeObjects));
                    }
                    else
                    {
                        rlsRight.Entities.AddRange(rlsIncludeObjects);
                    }

                    // if entities list is empty after rules were merged, set permission type to All or No
                    if (rlsRight.Entities.Count == 0)
                    {
                        if (rlsRight.PermissionType == RowLevelModelPermissionType.Specified)
                        {
                            rlsRight.PermissionType = RowLevelModelPermissionType.No;
                        }
                        else if (rlsRight.PermissionType == RowLevelModelPermissionType.Except)
                        {
                            rlsRight.PermissionType = RowLevelModelPermissionType.All;
                        }
                    }
                    // otherwise fill list with children entities if needed
                    else if (rightPair.Key.HierarchyFieldName != string.Empty)
                    {
                        var childIds = context.GetIdentifiersRecursive(entityName, rightPair.Key.HierarchyFieldName, rlsRight.Entities);
                        rlsRight.Entities.AddRange(childIds.Except(rlsRight.Entities));
                    }
                }
            }

            return rules;
        }

        private static Dictionary<string, List<RowLevelRightRule>> GetRowLevelRightsModel(
            ISecurityDbContext context,
            Guid profileId,
            Guid? userId)
        {
            var rlsRights = GetRlsRightsQuery(context, profileId).ToList();
            var defaultValues = GetDefaultValues(context, rlsRights, userId);
            var rightsModel = GetRowLevelRightsModelFromRlsRights(context, rlsRights, defaultValues);

            return rightsModel;
        }

        private class FieldRights
        {
            public string FieldName { get; }
            public AccessLevel AccessLevel { get; }

            public FieldRights(string fieldName, AccessLevel accessLevel)
            {
                FieldName = fieldName;
                AccessLevel = accessLevel;
            }
        }

        private class EntityRights
        {
            public string EntityName { get; }
            public EntityAccessLevel EntityAccessLevel { get; }
            public List<FieldRights> FieldRights { get; }

            public EntityRights(string entityName, EntityAccessLevel accessLevel, List<FieldRights> fieldRights)
            {
                EntityName = entityName;
                EntityAccessLevel = accessLevel;
                FieldRights = fieldRights;
            }
        }

        /// <summary>
        /// Rerpesents flatten version of RowLevelRight record with joined RowLevelSecurityObjects
        /// </summary>
        private class RlsRights
        {
            /// <summary>
            /// RowLevelRight access type
            /// </summary>
            public RowLevelAccessType AccessType { get; set; }
            /// <summary>
            /// RowLevelRight MainEntityName
            /// </summary>
            public string MainEntityName { get; set; }
            /// <summary>
            /// RowLevelRight EntityName
            /// </summary>
            public string EntityName { get; set; }
            /// <summary>
            /// EntityId from RowLevelRight RowLevelSecurityObjects
            /// RlsRights class is flatten version of RowLevelRight with different EntityId, taken from RowLevelSecurityObjects
            /// </summary>
            public Guid EntityId { get; set; }
            /// <summary>
            /// If 
            /// </summary>
            public string HierarchyFieldName { get; set; }

            public RlsRights(string entityName, Guid entityId, RowLevelAccessType accessType, string mainEntityName, string hierarchyField)
            {
                EntityName = entityName;
                EntityId = entityId;
                AccessType = accessType;
                MainEntityName = mainEntityName;
                HierarchyFieldName = hierarchyField;
            }
        }

        private class RoleRights
        {
            public string EntityName { get; }
            public EntityAccessLevel EntityAccessLevel { get; }
            public Guid RoleId { get; }
            public Guid RightId { get; }

            public RoleRights(string entityName, EntityAccessLevel accessLevel, Guid roleId, Guid rightId)
            {
                EntityName = entityName;
                EntityAccessLevel = accessLevel;
                RoleId = roleId;
                RightId = rightId;
            }
        }
    }
}
