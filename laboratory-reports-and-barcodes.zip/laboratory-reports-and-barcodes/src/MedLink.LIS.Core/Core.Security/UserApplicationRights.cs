﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;

namespace Core.Security
{
    /// <summary>
    /// Represents all user's rights in an application during work
    /// </summary>
    public class UserApplicationRights: IUserApplicationRights
    {
        #region Fields

        /// <summary>
        /// Entity rights dictionary, where key - is the name of entity
        /// </summary>
        public Dictionary<string, EntityRightData> EntityRights { get; set; } = new Dictionary<string, EntityRightData>();
        /// <summary>
        /// Row level rights dictionary, where key - is the name of entity
        /// </summary>
        public Dictionary<string, List<RowLevelRightRule>> RowLevelRights { get; set; } = new Dictionary<string, List<RowLevelRightRule>>();
        /// <summary>
        /// Operation righs dictionary, where key - the operation name
        /// </summary>
        public Dictionary<string, AccessLevel> OperationRights { get; set; } = new Dictionary<string, AccessLevel>();
        /// <summary>
        /// Dictionary, containing rigths data for given type
        /// Key - entity type, for which rigths data belongs to
        /// </summary>
        private static readonly ConcurrentDictionary<Type, TypeRightsData> _typeRights = new ConcurrentDictionary<Type, TypeRightsData>();

        public bool HasFullRights { get; }

        #endregion Fields

        #region Constructors

        public UserApplicationRights(): this(false)    
        {
        }

        public UserApplicationRights(bool hasFullRights)
        {
            HasFullRights = hasFullRights;
        }

        #endregion Constructors

        #region Methods_Public

        public void AssertCanReadTypeData(Type dataType)
        {
            if (HasFullRights)
            {
                return;
            }

            if (dataType == null)
            {
                throw new ArgumentNullException("dataType argument cannot be null");
            }

            var entitiesToCheck = GetTypeRightsData(dataType).CheckedEntites;
            if (entitiesToCheck == null || entitiesToCheck.Count == 0)
            {
                return;
            }

            foreach (var entityName in entitiesToCheck)
            {
                if (!EntityRights.TryGetValue(entityName, out var right) || right.EntityAccessLevel == EntityAccessLevel.No)
                {
                    throw new NoRightsException($"Access to {dataType.Name} ({entityName}) is denied", "Access denied");
                }
            }
        }

        public void AssertCanWriteTypeData(Type dataType)
        {
            if (HasFullRights)
            {
                return;
            }

            if (dataType == null)
            {
                throw new ArgumentNullException("dataType argument cannot be null");
            }

            var checkedTypeData = GetTypeRightsData(dataType);
            var entitiesToCheck = checkedTypeData.CheckedEntites;
            if (entitiesToCheck == null || entitiesToCheck.Count == 0)
            {
                return;
            }

            // main entity is checked for write access, other entities for read access only
            foreach (var entityName in entitiesToCheck)
            {
                if (!EntityRights.TryGetValue(entityName, out var right))
                {
                    throw new NoRightsException($"Access to {dataType.Name} ({entityName}) is not set", "Access denied");
                }

                var isMainEntity = entityName == checkedTypeData.MainEntityName;
                // for main entity read is not enough
                if (right.EntityAccessLevel == EntityAccessLevel.No || (isMainEntity && right.EntityAccessLevel == EntityAccessLevel.Read))
                {
                    throw new NoRightsException($"Access to {dataType.Name} ({entityName}) is denied", "Access denied");
                }
            }
        }

        public void AssertRlsAllowsObject(object obj)
        {
            if (!RlsAllowsAccessToObject(obj))
            {
                throw new NoRightsException($"Row level access to {obj.GetType().Name} is denied", "Access to object denied");
            }
        }

        public void AssertWriteRights(string entityName, string fieldName)
        {
            var fieldRight = GetFieldRight(entityName, fieldName);
            if (fieldRight != AccessLevel.Write)
            {
                throw new NoRightsException($"There is no permission to perform this operation on field {entityName}.{fieldName}", "Write access denied");
            }
        }

        public void AssertCanExecuteOperation(string operationName)
        {
            if (!HasFullRights && !OperationRights.TryGetValue(operationName, out var _))
            {
                throw new NoRightsException($"There is no permission to perform the operation on {operationName}", "Operation denied");
            }
        }

        // TODO: think about further ways to optimize getting an object property value
        public bool RlsAllowsAccessToObject(object obj)
        {
            if (HasFullRights)
            {
                return true;
            }

            if (obj == null)
            {
                return false;
            }

            var type = obj.GetType();
            var typeRights = GetTypeRightsData(type);

            foreach (var propData in typeRights.RlsProperties)
            {
                if (propData?.PropertyInfo != null)
                {
                    var propValue = "";
                    if (propData.PropertyInfo.PropertyType == typeof(Guid))
                    {
                        var guid = (Guid)propData.PropertyInfo.GetValue(obj);
                        if (guid != Guid.Empty)
                        {
                            propValue = guid.ToString();
                        }
                    }
                    else
                    {
                        propValue = (propData.PropertyInfo.GetValue(obj) ?? "").ToString();
                    }

                    if (!RlsAllowsAccessToEntity(propData.EntityName, propValue, typeRights.MainEntityName))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Gets AccessLevel for entity field
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public AccessLevel GetFieldRight(string entityName, string fieldName)
        {
            if (HasFullRights)
            {
                return AccessLevel.Write;
            }

            if (!TryGetEntityRight(entityName, out var right))
            {
                return AccessLevel.No;
            }

            if (right.EntityAccessLevel == EntityAccessLevel.Partial && !string.IsNullOrEmpty(fieldName))
            {
                if (!right.FieldRights.TryGetValue(fieldName, out var fieldRight))
                {
                    return AccessLevel.No;
                }
                else
                {
                    return fieldRight;
                }
            }
            else
            {
                var enumConverter = new EnumConverter();
                return enumConverter.ToAccessLevel(right.EntityAccessLevel);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <exception cref="ArgumentNullException"></exception>
        /// <param name="type"></param>
        /// <returns></returns>
        public List<RowLevelRightData> GetTypeFieldsRlsRights(Type type)
        {
            var rlsList = new List<RowLevelRightData>();
            var typeRights = GetTypeRightsData(type);

            // iterating rls properties for givent type
            // rls properties defined by one or many RlsRight attributes
            foreach (var propRight in typeRights.RlsProperties)
            {
                // RowLevelRights contains all active rules
                // so if we do not found row level right, then rule does not exist or inactive and access is granted
                if (HasFullRights || !RowLevelRights.TryGetValue(propRight.EntityName, out var right))
                {
                    rlsList.Add(new RowLevelRightData(propRight.PropertyName, RowLevelModelPermissionType.All, new List<string>()));
                    continue;
                }

                var rlsRule = GetEntityRule(right, typeRights.MainEntityName);
                if (rlsRule == null)
                {
                    rlsList.Add(new RowLevelRightData(propRight.PropertyName, RowLevelModelPermissionType.No, new List<string>()));
                }
                else
                {
                    rlsList.Add(new RowLevelRightData(propRight.PropertyName, rlsRule.PermissionType, rlsRule.Entities));
                };
            }

            return rlsList;
        }

        #endregion Methods_Public

        #region Methods_Private

        private bool RlsAllowsAccessToEntity(string entityName, string entityId, string mainEntityName)
        {
            if (HasFullRights 
                || string.IsNullOrEmpty(entityName) 
                || string.IsNullOrEmpty(entityId) 
                || !RowLevelRights.TryGetValue(entityName, out var rlsRight))
            {
                return true;
            }

            var rlsRule = GetEntityRule(rlsRight, mainEntityName);
            if (rlsRule == null)
            {
                return false;
            }
            else if (rlsRule.PermissionType == RowLevelModelPermissionType.All)
            {
                return true;
            }
            else if (rlsRule.PermissionType == RowLevelModelPermissionType.Specified)
            {
                //return rlsRight.Entities.Exists(x => entityId.Contains(x));
                return rlsRule.Entities.Contains(entityId);
            }
            else if (rlsRule.PermissionType == RowLevelModelPermissionType.Except)
            {
                //return !rlsRight.Entities.Exists(x => entityId.Contains(x));
                return !rlsRule.Entities.Contains(entityId);
            }

            return false;
        }

        private bool TryGetEntityRight(string entityName, [NotNullWhen(true)] out EntityRightData? right)
        {
            right = null;
            if (EntityRights == null || string.IsNullOrEmpty(entityName))
            {
                return false;
            }

            return EntityRights.TryGetValue(entityName, out right);
        }

        /// <summary>
        /// Returns rights data that type contains
        /// </summary>
        /// <param name="type">type where rights data is</param>
        /// <returns>TypeRightsData object, that describes type rights</returns>
        private TypeRightsData GetTypeRightsData(Type type)
        {
            if (_typeRights.TryGetValue(type, out var rightsData))
            {
                return rightsData;
            }

            // checked entities
            var rightsCheckListAttribute = type.GetCustomAttribute<RightsCheckListAttribute>(true);
            rightsData = new TypeRightsData();
            if (rightsCheckListAttribute != null)
            {
                rightsData.CheckedEntites = rightsCheckListAttribute.CheckedEntities;
            }

            // add entity itself, if present in rights
            if (EntityRights.ContainsKey(type.Name) && !rightsData.CheckedEntites.Contains(type.Name))
            {
                rightsData.CheckedEntites.Add(type.Name);   
            }

            // if MainEntityAttribute is set
            var mainEntityAttr = type.GetCustomAttribute<MainEntityAttribute>(true);
            if (mainEntityAttr != null)
            {
                rightsData.MainEntityName = mainEntityAttr.EntityName;
                if (!rightsData.CheckedEntites.Contains(rightsData.MainEntityName))
                {
                    rightsData.CheckedEntites.Add(rightsData.MainEntityName);
                }
            }

            // adding informations aboout type rls
            foreach (RlsRightAttribute rightsAttr in type.GetCustomAttributes(typeof(RlsRightAttribute), true))
            {
                if (!string.IsNullOrEmpty(rightsAttr.TypeName) && !string.IsNullOrEmpty(rightsAttr.PropertyName))
                {
                    var propertyInfo = type.GetProperty(rightsAttr.PropertyName);
                    if (propertyInfo != null)
                    {
                        var propData = new RlsPropertyData(rightsAttr.TypeName, rightsAttr.PropertyName, propertyInfo);
                        rightsData.RlsProperties.Add(propData);
                    }
                }
            }

            // adding data to cache, if is not present yet
            _typeRights.TryAdd(type, rightsData);

            return rightsData;
        }

        private RowLevelRightRule? GetEntityRule(IEnumerable<RowLevelRightRule> rules, string mainEntityName)
        {
            // if type has MainEntity attribute then first we should search for
            // rls rules for concrete type and only then for common case if rule for concrete type is not found
            RowLevelRightRule? rlsRule = null;
            if (mainEntityName != string.Empty)
            {
                rlsRule = rules.FirstOrDefault(x => x.MainEntityName == mainEntityName);
            }

            // if rule for concrete entity not found, search for common case
            if (rlsRule == null)
            {
                rlsRule = rules.FirstOrDefault(x => x.MainEntityName == string.Empty);
            }

            return rlsRule;
        }

        #endregion Methods_Private

        /// <summary>
        /// Represents data of RlsRightAttribute
        /// </summary> 
        private class RlsPropertyData
        {
            /// <summary>
            /// EntityName - is  name of the class, that represents RLS entity
            /// For example, if Employee has attribute RlsRight(nameof(Organization), nameof(OrganizationId)),
            /// then EntityName = "Organization"
            /// </summary>
            public string EntityName { get; set; }
            /// <summary>
            /// PropertyName - is  property name that references to entity with name EntityName
            /// For example, if Employee has attribute RlsRight(nameof(Organization), nameof(OrganizationId)),
            /// then PropertyName = "OrganizationId"
            /// </summary>
            public string PropertyName { get; set; }
            /// <summary>
            /// PropertyInfo for property with name PropertyName
            /// </summary>
            public PropertyInfo PropertyInfo { get; set; }

            public RlsPropertyData(string entityName, string propertyName, PropertyInfo propertyInfo)
            {
                EntityName = entityName;
                PropertyName = propertyName;
                PropertyInfo = propertyInfo;
            }
        }

        private class TypeRightsData
        {
            /// <summary>
            /// MainEntityAttribute value for EntityType
            /// </summary>
            public string MainEntityName { get; set; } = string.Empty;
            /// <summary>
            /// These entities will be included into rights check for given EntityType (RightsCheckListAttribute values)
            /// </summary>
            public List<string> CheckedEntites { get; set; } = new List<string>();
            /// <summary>
            /// Represents model properties, that should be checked by rls system.
            /// These properties are described by RlsRightAttribute
            /// </summary>
            public List<RlsPropertyData> RlsProperties { get; set; } = new List<RlsPropertyData>();
        }
    }
}
