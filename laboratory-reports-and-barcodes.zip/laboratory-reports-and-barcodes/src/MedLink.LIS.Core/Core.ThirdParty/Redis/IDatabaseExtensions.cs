﻿using System;
using System.Threading.Tasks;
using StackExchange.Redis;
using System.Text.Json;
using System.Collections.Generic;
using System.Linq;

namespace Core.ThirdParty.Redis
{
    public static class IDatabaseExtensions
    {
        public static T GetValueFromString<T>(this IDatabase source, string key)
        {
            var stringValue = source.StringGet(key).ToString();
            if (string.IsNullOrEmpty(stringValue))
            {
                return default;
            }
            return JsonSerializer.Deserialize<T>(stringValue);
        }

        public static void SaveValueAsString(this IDatabase source, string key, object value, TimeSpan? expiry = null)
        {
            var stringValue = JsonSerializer.Serialize(value);
            source.StringSet(key, stringValue, expiry);
        }

        public static async Task<T> GetValueFromStringAsync<T>(this IDatabase source, string key)
        {
            var value = await source.StringGetAsync(key);
            var stringValue = value.ToString();
            if (string.IsNullOrEmpty(stringValue))
            {
                return default;
            }
            return JsonSerializer.Deserialize<T>(stringValue);
        }

        public static async Task SaveValueAsStringAsync(this IDatabase source, string key, object value, TimeSpan? expiry = null)
        {
            var stringValue = JsonSerializer.Serialize(value);
            await source.StringSetAsync(key, stringValue, expiry);
        }

        public static bool ClearKey(this IDatabase source, string key)
        {
            return source.KeyDelete(key);
        }

        public static IEnumerable<T> GetValuesByPrefix<T>(this IDatabase source, string prefix)
        {
            var server = source.Multiplexer.GetServer(source.Multiplexer.GetEndPoints().First());

            foreach (var key in server.Keys(pattern: prefix + "*"))
            {
                var stringValue = source.StringGet(key).ToString();

                if (!string.IsNullOrEmpty(stringValue))
                {
                    T deserializedValue = default;

                    try
                    {
                        deserializedValue = JsonSerializer.Deserialize<T>(stringValue);
                    }
                    catch
                    {
                        continue; 
                    }

                    if (deserializedValue != null)
                    {
                        yield return deserializedValue;
                    }
                }
            }
        }

        public static Dictionary<int, List<T>> GetValuesByPrefixDict<T>(this IDatabase source, string prefix)
        {
            var result = new Dictionary<int, List<T>>();
            var server = source.Multiplexer.GetServer(source.Multiplexer.GetEndPoints().First());

            foreach (var redisKey in server.Keys(pattern: prefix + "*"))
            {
                string key = redisKey.ToString();
                string[] parts = key.Split('_');
                string providerId = parts.Last();

                if (int.TryParse(providerId, out int providerIdInt))
                {
                    var stringValue = source.StringGet(redisKey).ToString();
                    if (!string.IsNullOrEmpty(stringValue))
                    {
                        var deserializedList = JsonSerializer.Deserialize<List<T>>(stringValue);
                        if (result.ContainsKey(providerIdInt))
                        {
                            result[providerIdInt].AddRange(deserializedList);
                        }
                        else
                        {
                            result[providerIdInt] = deserializedList;
                        }
                    }
                    else
                    {
                        result[providerIdInt] = new List<T>();
                    }
                }
            }

            return result;
        }

        public static void ClearByPrefix(this IDatabase source, string prefix)
        {
            var server = source.Multiplexer.GetServer(source.Multiplexer.GetEndPoints().First());
            var keys = server.Keys(pattern: prefix + "*").ToArray();

            if (keys.Any())
            {
                source.KeyDelete(keys);
            }
        }
    }
}
