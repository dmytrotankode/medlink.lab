﻿using StackExchange.Redis;

namespace Core.ThirdParty.Redis;

public interface IRedisDatabaseProvider
{
    ConnectionMultiplexer ConnectionMultiplexer { get; }
    IDatabase Database { get; }
    IServer Server { get; }
}
