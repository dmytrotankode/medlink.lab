﻿using System;
using System.Collections.Generic;
using Core.Security;

namespace Core.Data
{
    public abstract class BaseUserInfo: IUserApplicationRights
    {
        protected const string GlobalAdminId = "a6accf55-44db-4816-b0e7-53b6c2ab9d3b";

        public virtual string Id { get; set; }
        public virtual Dictionary<string, string> LoginData { get; set; }
        public virtual Guid ProfileId { get; set; }
        public virtual Guid UserId { get; set; }
        public virtual Guid PersonId { get; set; }
        public virtual BaseUserCultureInfo CultureInfo { get; set; }

        public abstract void AssertCanReadTypeData(Type dataType);
        public abstract void AssertCanWriteTypeData(Type dataType);
        public abstract void AssertRlsAllowsObject(object obj);   
        public abstract void AssertWriteRights(string entityName, string fieldName);
        public abstract void AssertCanExecuteOperation(string operationName);
        public abstract AccessLevel GetFieldRight(string entityName, string fieldName);
        public abstract List<RowLevelRightData> GetTypeFieldsRlsRights(Type dataType);
        public abstract bool RlsAllowsAccessToObject(object obj);
        public abstract bool IsInGlobalAdminRole();
    }
}
