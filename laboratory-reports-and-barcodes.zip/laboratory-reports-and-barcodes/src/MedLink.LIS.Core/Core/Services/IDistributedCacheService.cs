﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Services.DistributedCacheService
{
    public interface IDistributedCacheService
    {
        T GetValue<T>(string key);

        IEnumerable<T> GetValuesByPrefix<T>(string prefix);

        Dictionary<int, List<T>> GetValuesByPrefixDict<T>(string prefix);

        Task<T> GetValueAsync<T>(string key);

        void SetValue(string key, object value, TimeSpan? expiry = null);

        Task SetValueAsync(string key, object value, TimeSpan? expiry = null);

        bool ClearKey(string key);

        void ClearByPrefix(string prefix);

        Task<bool> ClearKeyAsync(string key);

        Task ClearByPattern(string keyPattern);

        Task Reset(bool allSources = false);

        Task<byte[]?> GetBytesAsync(string key);
        Task SetBytesAsync(string key, byte[] value, TimeSpan? expiry = null);
    }
}
