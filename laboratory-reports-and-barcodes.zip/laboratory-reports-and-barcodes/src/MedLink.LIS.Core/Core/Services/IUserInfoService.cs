﻿using System;
using System.Threading.Tasks;
using Core.Data;

namespace Core.Services
{
    public interface IUserInfoService
    {
        BaseUserInfo SystemUser { get; }
        BaseUserInfo GetUserInfo(string userId);
        Task<BaseUserInfo> GetUserInfoAsync(string userId);

        BaseUserInfo GetCurrentUserInfo();
        Task<BaseUserInfo> GetCurrentUserInfoAsync();

        bool UpdateUserInfo(string id, Guid personId, Guid userId, Guid profileId);
        bool UpdateCurrentUserInfo(Guid personId, Guid userId, Guid profileId);

        void DeleteCurrentUserInfo();

        void DeleteUserInfo(string userId);
    }
}
