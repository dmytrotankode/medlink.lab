module.exports = function (ctx) {
  const isDev = !!(ctx && ctx.dev);
  const devPort = Number(process.env.LAB_DEV_PORT) || 8085;
  const LAB_ORIGIN = (process.env.LAB_ORIGIN || (isDev ? `http://localhost:${devPort}` : 'http://localhost:5055')).replace(/\/$/, '');
  const BASE_ID_URI = (process.env.OIDC_AUTHORITY || 'https://localhost:5001').replace(/\/$/, '');

  const configuration = {
    API_BASE: '/api/v1/lab',
    ACCOUNT_API_BASE: '/api/account',
    OIDC_AUTHORITY: BASE_ID_URI,
    OIDC_CLIENTID: 'MisFront',
    OIDC_REDIRECT_URI: LAB_ORIGIN + '/callback',
    OIDC_POST_LOGOUT_REDIRECT_URI: LAB_ORIGIN + '/',
    OIDC_RESPONSE_TYPE: 'code',
    OIDC_SCOPE: 'MisFrontScope IdentityApiScope MisApiScope openid offline_access',
    OIDC_SILENT_REDIREC_URI: '/statics/silent-renew.html',
    REDIRECT_CALLBACK: '/',
    OIDC_ISSUER: BASE_ID_URI,
    OIDC_AUTH_ENDPOINT: BASE_ID_URI + '/connect/authorize',
    OIDC_TOKEN_ENDPOINT: BASE_ID_URI + '/connect/token',
    OIDC_USERINFO_ENDPOINT: BASE_ID_URI + '/connect/userinfo',
    OIDC_END_SESSION_ENDPOINT: BASE_ID_URI + '/connect/endsession',
    OIDC_JWKS_URI: BASE_ID_URI + '/.well-known/openid-configuration/jwks'
  };

  const finalConfig = {};
  Object.keys(configuration).forEach(key => {
    const value = process.env[key] || configuration[key];
    finalConfig[key] = JSON.stringify(value);
  });

  return finalConfig;
};
