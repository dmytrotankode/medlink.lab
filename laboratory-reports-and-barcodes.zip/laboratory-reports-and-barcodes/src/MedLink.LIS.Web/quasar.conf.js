/* eslint-env node */
/*
 * MedLink LIS 4.0 — конфігурація Quasar CLI v1 (webpack 4), як у evomis/src/App.View.
 * Node 22: NODE_OPTIONS=--openssl-legacy-provider задається у npm-скриптах (cross-env).
 */

const path = require('path');
const envparser = require('./config/envparser.js');

module.exports = function (ctx) {
  const envs = envparser(ctx);

  return {
    supportTS: false,

    boot: [
      'fonts',
      'axios',
      'oidc',
      'components'
    ],

    css: [
      'app.styl'
    ],

    // Шрифт Source Sans Pro підключається локально (boot/fonts.js, пакет @fontsource/source-sans-pro) — без CDN.
    extras: [
      'fontawesome-v5',
      'material-icons'
    ],

    framework: {
      iconSet: 'material-icons',
      lang: 'uk',
      all: 'auto',
      components: [],
      directives: [],
      plugins: [
        'Notify',
        'Dialog',
        'Loading',
        'LoadingBar'
      ],
      config: {
        notify: { position: 'top-right', timeout: 2500 },
        loadingBar: { color: 'accent', size: '3px' }
      }
    },

    build: {
      vueRouterMode: 'history',
      distDir: 'dist/spa',
      env: envs,
      extendWebpack (cfg) {
        cfg.resolve.alias = {
          ...cfg.resolve.alias,
          '@': path.resolve(__dirname, './src')
        };
        const CopyWebpackPlugin = require('copy-webpack-plugin');
        cfg.plugins.push(new CopyWebpackPlugin([
          {
            from: path.resolve(__dirname, 'node_modules/oidc-client/dist/oidc-client.min.js'),
            to: 'statics/oidc-client.min.js'
          }
        ]));
      }
    },

    devServer: {
      https: false,
      port: Number(process.env.LAB_DEV_PORT) || 8085,
      open: false,
      proxy: {
        '/api': {
          target: 'http://localhost:5055',
          changeOrigin: true
        },
        '/health': {
          target: 'http://localhost:5055',
          changeOrigin: true
        },
        '/verify': {
          target: 'http://localhost:5055',
          changeOrigin: true
        }
      }
    },

    animations: [],

    ssr: { pwa: false },
    pwa: {},
    cordova: {},
    capacitor: {},
    electron: {}
  };
};
