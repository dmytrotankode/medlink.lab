import { Notify } from 'quasar';
import { http, httpRoot, describeApiError, getAccessToken, openApiFile } from '../services/http';
import labApi from '../services/labApiService';
import Oidc from './security-oidc';
import { isIdentityServerResponse } from '../utils/identity-server-response';
import NotificationService from '../services/notificationService';

export default ({ store, Vue }) => {
  const onRequest = config => {
    const token = getAccessToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    if (!config.headers['Accept-Language']) {
      config.headers['Accept-Language'] = 'uk';
    }
    return config;
  };

  const onResponse = response => {
    if (store.state.laboratory.apiOffline) {
      store.commit('laboratory/SET_API_OFFLINE', false);
    }
    return response;
  };

  const notifyHttpError = error => {
    const response = error && error.response;
    const responseData = response && response.data;
    const dataStatus = responseData && responseData.status;
    const errorResponseStatus = dataStatus !== undefined && dataStatus !== null ? dataStatus : (response && response.status);
    const rateLimitResponseStatus = errorResponseStatus === 429;
    const isCustomError = errorResponseStatus === 409;

    if (/^[4-5]/.test(errorResponseStatus) && !isCustomError) {
      if (errorResponseStatus === 401 && isIdentityServerResponse(error)) {
        new Oidc().forceReauthenticate('identity_server_401');
      }

      let errorData = responseData !== undefined ? responseData : null;

      if (errorData instanceof ArrayBuffer) {
        const decodedErrorData = new TextDecoder('utf-8').decode(new Uint8Array(errorData));
        if (decodedErrorData) {
          errorData = JSON.parse(decodedErrorData);
        }
      }

      const message = [];
      let errorResponseTitle = '';
      let errorResponseStatusText = '';
      const field = name => (errorData && errorData[name]) || '';

      if (typeof errorData === 'string' && errorData.trim()) {
        message.push(errorData);
      } else {
        const errorResponseDetail = field('detail');
        const errorResponseMessage = field('message');
        const errorResponseErrors = (errorData && errorData.errors) || null;
        errorResponseTitle = field('title');
        errorResponseStatusText = field('statusText');

        if (errorResponseDetail) {
          message.push(errorResponseDetail);
        } else if (errorResponseMessage) {
          message.push(errorResponseMessage);
        } else if (errorResponseErrors) {
          message.push(JSON.stringify(errorResponseErrors));
        } else if (rateLimitResponseStatus) {
          const maxCalls = errorData.limit || 0;
          const durationInSeconds = errorData.windowSeconds || 0;

          const customMessage = `Ви досягли максимальну кількість запитів за ${durationInSeconds}s, максимально - ${maxCalls} (трохи зачекайте)`;
          message.push(customMessage);
        } else {
          message.push('Невідома помилка');
        }
      }

      const title = errorResponseTitle || errorResponseStatusText;
      if (errorResponseStatus === 403) {
        new NotificationService().notify('warningExclamation', message, errorResponseTitle);
      } else {
        new NotificationService().notify('warning', message, title);
      }
    }
  };

  const onError = error => {
    const info = describeApiError(error);
    error.userMessage = info.message;
    error.apiStatus = info.status;
    error.fieldErrors = info.fields;
    error.isOffline = info.offline;
    notifyHttpError(error);
    if (info.offline) {
      store.commit('laboratory/SET_API_OFFLINE', true);
    }
    store.commit('laboratory/SET_LAST_ERROR', { message: info.message, at: new Date().toISOString(), status: info.status });
    return Promise.reject(error);
  };

  [http, httpRoot].forEach(instance => {
    instance.interceptors.request.use(onRequest);
    instance.interceptors.response.use(onResponse, onError);
  });

  Vue.prototype.$http = http;
  Vue.prototype.$api = labApi;
  Vue.prototype.$apiError = describeApiError;
  Vue.prototype.$openApiFile = (url, options) => openApiFile(url, options).catch(e => {
    Notify.create({ type: 'negative', message: e.userMessage || 'Помилка завантаження файлу' });
  });
};

export { http };
