import Oidc from 'oidc-client';

export default ({ Vue }) => {
  const oidc = new Oidc.UserManager({
    userStore: new Oidc.WebStorageStateStore({ store: window.localStorage }),
    authority: process.env.OIDC_AUTHORITY,
    client_id: process.env.OIDC_CLIENTID
  });
  Vue.prototype.$oidc = oidc;
};
