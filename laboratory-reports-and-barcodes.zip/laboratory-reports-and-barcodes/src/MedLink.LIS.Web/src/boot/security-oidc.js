import Oidc from 'oidc-client';
import { Dialog } from 'quasar';

const env = process.env;

/** IdentityServer4 token URL; required when response_type is normalized to `code`. */
const resolveTokenEndpoint = () => {
  const explicit = (env.OIDC_TOKEN_ENDPOINT || '').trim();
  if (explicit) {
    return explicit;
  }
  const authority = (env.OIDC_AUTHORITY || '').trim().replace(/\/$/, '');
  return authority ? `${authority}/connect/token` : undefined;
};

const normalizeResponseType = (responseType) => {
  const raw = (responseType || '').trim();
  if (!raw) {
    return 'code';
  }

  const lower = raw.toLowerCase();
  // Current oidc-client rejects hybrid values ("code id_token", etc.); use code-only flow.
  if (lower.includes(' ')) {
    return 'code';
  }

  return lower;
};

const oidcSettings = {
  userStore: new Oidc.WebStorageStateStore({ store: window.localStorage }),
  monitorSession: false,
  authority: env.OIDC_AUTHORITY,
  client_id: env.OIDC_CLIENTID,
  redirect_uri: env.OIDC_REDIRECT_URI,
  post_logout_redirect_uri: env.OIDC_POST_LOGOUT_REDIRECT_URI,
  response_type: normalizeResponseType(env.OIDC_RESPONSE_TYPE || 'id_token token'),
  scope: env.OIDC_SCOPE,
  silent_redirect_uri: window.location.origin + env.OIDC_SILENT_REDIREC_URI,
  accessTokenExpiringNotificationTime: 2,
  automaticSilentRenew: true,
  filterProtocolClaims: true,
  loadUserInfo: true,
  clockSkew: 900,
  silentRequestTimeout: 2,
  metadata: {
    issuer: env.OIDC_ISSUER,
    authorization_endpoint: env.OIDC_AUTH_ENDPOINT,
    token_endpoint: resolveTokenEndpoint(),
    userinfo_endpoint: env.OIDC_USERINFO_ENDPOINT,
    end_session_endpoint: env.OIDC_END_SESSION_ENDPOINT,
    jwks_uri: env.OIDC_JWKS_URI
  },
  revokeAccessTokenOnSignout: true
};

const mgr = new Oidc.UserManager(oidcSettings);

Oidc.Log.logger = console;
Oidc.Log.level = Oidc.Log.WARN;

mgr.events.addAccessTokenExpired(function () {
  localStorage.setItem('marvel.authenticated', false);

  Dialog.create({
    title: 'Сеанс завершено',
    message: 'Перенаправлення для аутентифікації'
  })
    .onOk(() => {
      mgr.signoutRedirect().catch(() => {});
    })
    .onDismiss(() => {
      mgr.signoutRedirect();
    });
});

mgr.events.addSilentRenewError(function () {
  console.error('Silent Renew Error：', arguments);
});

mgr.events.addUserSignedOut(function () {
  mgr.removeUser().then(function () {
    mgr.clearStaleState().then(() => {
      mgr.signinRedirect();
    });
  });
});

export default class SecurityService {
  getUser () {
    const self = this;
    return new Promise((resolve, reject) => {
      mgr.getUser()
        .then(user => {
          if (!user) {
            self.signIn();
            return resolve(null);
          }
          return resolve(user);
        })
        .catch(err => {
          return reject(err);
        });
    });
  }

  getSignedIn () {
    return new Promise((resolve, reject) => {
      mgr.getUser()
        .then(user => resolve(!!user))
        .catch(err => reject(err));
    });
  }

  signIn () {
    mgr.signinRedirect().catch(function () {
      /* redirect may fail if popup blocked; avoid noisy logs */
    });
  }

  signOut () {
    const self = this;
    this.getSignedIn().then(isSignedIn => {
      if (isSignedIn) {
        self.clearOidcState();
        mgr.signoutRedirect();
      }
    });
  }

  getToken () {
    const self = this;
    return new Promise((resolve, reject) => {
      mgr.getUser()
        .then(user => {
          if (user == null) {
            self.signIn();
            return resolve(false);
          }
          return resolve(user);
        })
        .catch(err => {
          return reject(err);
        });
    });
  }

  getProfile () {
    return this.getToken().then(user => (user ? user.profile : false));
  }

  getIdToken () {
    return this.getToken().then(user => (user ? user.id_token : false));
  }

  getSessionState () {
    return this.getToken().then(user => (user ? user.session_state : false));
  }

  getAcessToken () {
    return this.getToken().then(user => (user ? user.access_token : false));
  }

  getScopes () {
    return this.getToken().then(user => (user ? user.scopes : false));
  }

  getRole () {
    return this.getToken().then(user => (user ? user.profile.role : false));
  }

  signinRedirectCallback () {
    return mgr.signinRedirectCallback();
  }

  clearOidcState () {
    const oidcKeyWord = 'oidc';
    Object.keys(window.localStorage).forEach(key => {
      if (key.includes(oidcKeyWord)) {
        localStorage.removeItem(key);
      }
    });
  }

  forceReauthenticate (reason = 'session_expired') {
    localStorage.setItem('marvel.authenticated', false);
    localStorage.setItem('LOG_OUT_CALLBACK', window.location.pathname + window.location.search);

    return mgr.removeUser()
      .catch(() => null)
      .then(() => mgr.clearStaleState().catch(() => null))
      .then(() => {
        this.clearOidcState();
        return mgr.signinRedirect({ state: { reason } });
      });
  }
}
