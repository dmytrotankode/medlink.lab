<template>
  <q-item data-testid="profilesMenu" clickable>
    <q-item-section v-if="isPageReady" side class="q-pl-sm">
      <q-icon name="fas fa-user-nurse" />
    </q-item-section>
    <q-item-section v-if="isPageReady">
      Змінити профіль
    </q-item-section>
    <q-item-section v-else class="items-center">
      <q-spinner color="primary" size="2em" :thickness="2" />
    </q-item-section>
    <q-menu
      v-if="isPageReady"
      v-model="showing"
      anchor="top left"
      self="top right"
    >
      <q-list style="min-width: 260px">
        <q-item
          v-for="(profile, index) in profiles"
          :key="index"
          active-class="bg-teal-1 text-grey-8"
          :clickable="!isActiveProfile(profile)"
          :active="isActiveProfile(profile)"
          @click="onProfileSelect(profile)"
        >
          <q-item-section avatar>
            <q-icon name="person" class="text-grey-8" />
          </q-item-section>
          <q-item-section>
            <q-item-label>{{ profile.profileCaption }}</q-item-label>
            <q-item-label caption v-if="profile.organizationCaption">{{ profile.organizationCaption }}</q-item-label>
          </q-item-section>
        </q-item>
        <q-item v-if="!profiles.length">
          <q-item-section class="text-grey">Відсутні значення</q-item-section>
        </q-item>
      </q-list>
    </q-menu>
  </q-item>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import { getUserProfiles } from '../../services/accountApiService';
import { authenticate } from '../../mixins/auth';

export default {
  name: 'ProfilesMenu',
  data () {
    return {
      profiles: [],
      showing: false,
      isPageReady: false
    };
  },

  computed: {
    ...mapState('context', ['user'])
  },

  methods: {
    ...mapActions('context', ['setAuthenticated', 'initUser', 'resetOrganizationData']),

    setUserProfiles (userProfiles) {
      this.profiles = userProfiles;
    },

    changePageReadyState () {
      this.isPageReady = !this.isPageReady;
    },

    isActiveProfile (profile) {
      const userProfileId = this.user ? this.user.profileId : null;
      const currentProfileId = profile ? profile.profileId : null;
      return userProfileId === currentProfileId;
    },

    onProfileSelect (selectedProfile) {
      this.showing = false;
      this.setUser(selectedProfile);
    },

    // authenticate selected user
    setUser (selectedProfile) {
      this.$q.loading.show();

      const hideLoadingWithTimeout = () => {
        setTimeout(() => { this.$q.loading.hide(); }, 2000);
      };

      authenticate(selectedProfile)
        .then(this.initCurrentUser)
        .catch(this.displayError)
        .finally(hideLoadingWithTimeout);
    },

    initCurrentUser () {
      this.resetOrganizationData()
        .then(() => this.initUser())
        .then(() => this.setAuthenticated(true))
        .then(this.goToMainPageRoute);
    },

    displayError () {
      setTimeout(() => {
        this.$router.push({ path: '/accessdenied' });
      }, 500);
    },

    goToMainPageRoute () {
      const mainPageRoute = '/laboratory/dashboard';
      if (this.$route.path !== mainPageRoute) {
        this.$router.push(mainPageRoute);
      }
      setTimeout(() => window.location.reload(), 500);
    }
  },

  created () {
    getUserProfiles()
      .then(this.setUserProfiles)
      .then(this.changePageReadyState);
  }
};
</script>
