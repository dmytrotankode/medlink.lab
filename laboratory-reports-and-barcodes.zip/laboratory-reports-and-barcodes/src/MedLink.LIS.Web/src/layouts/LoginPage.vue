<template>
  <q-layout data-testid="LoginPage" view="lHh Lpr lFf">
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
export default {
  name: 'LoginPage'
};
</script>
