import { ACCOUNT, postAuth, postAuthenticate } from '../services/accountApiService';

export const tryAuthenticate = () => {
  return postAuth(ACCOUNT.AUTH_TRY)
    .then(response => {
      const result = { authenticated: false };
      if (response.status === 200) {
        // single user
        result.authenticated = true;
        result.ehealthInfo = response.data.ehealthInfo;
        result.userProfileData = response.data.userProfileData;
      } else if (response.status === 300) {
        // multi user
        result.userData = response.data;
      }
      return result;
    });
};

export const authenticate = (profile) => {
  const { profileId, userId, ehealthEmployeeId, specialityEhealthId, email, legalEntityTypeCode } = profile;
  return postAuthenticate({ profileId, userId, ehealthEmployeeId, specialityEhealthId, email, legalEntityTypeCode })
    .then(response => response.data)
    .catch(error => error);
};
