import { mapActions, mapState } from 'vuex';
import Oidc from '../boot/security-oidc';
import { logout } from '../services/accountApiService';

const EMPTY_GUID = '00000000-0000-0000-0000-000000000000';

export default {
  data () {
    return {
      oidcManager: new Oidc(),
      authProcessIsOn: true
    };
  },

  computed: {
    ...mapState('context', ['user', 'authenticated', 'userName']),

    hasActiveUser () {
      return !!this.user;
    },

    showPageContent () {
      return this.hasActiveUser && this.authenticated && !this.authProcessIsOn;
    }
  },

  methods: {
    ...mapActions('context', ['fetchUserInfo', 'setUserInfo', 'setAuthenticated']),

    onAuthCreated () {
      this.authProcessIsOn = true;
      return this.fetchUserInfo()
        .then(this.initializeUser)
        .then(userInfo => {
          this.authProcessIsOn = false;
          return userInfo;
        })
        .catch(() => {
          this.authProcessIsOn = false;
          return null;
        });
    },

    onAuthMounted () {
      const logoutUrl = localStorage.getItem('LOG_OUT_CALLBACK');
      localStorage.setItem('REDIRECT_CALLBACK', logoutUrl || this.$route.fullPath);
      localStorage.removeItem('LOG_OUT_CALLBACK');
      // check user status
      this.oidcManager
        .getSignedIn()
        .then(this.signInIdentityUserIfNeeded);
    },

    initializeUser (response) {
      const userInfo = response && response.data ? response.data : null;
      const profileId = userInfo && userInfo.profileId;
      const userId = userInfo && userInfo.userId;
      const profileIsMissing = !profileId || profileId === EMPTY_GUID;
      const userIsMissing = !userId || userId === EMPTY_GUID;

      if (!userInfo || profileIsMissing || userIsMissing) {
        // Profile not selected: callback runs try-authenticate / profile selection.
        return Promise.resolve(this.setAuthenticated(false))
          .then(() => this.setUserInfo(null))
          .then(() => this.$router.replace({ name: 'callback' }))
          .then(() => null);
      }

      return Promise.resolve(this.setUserInfo(userInfo))
        .then(() => {
          this.setAuthenticated(true);
          return userInfo;
        });
    },

    signInIdentityUserIfNeeded (isIdentityAuthenticated) {
      const needSignIn = !isIdentityAuthenticated || !this.authenticated;
      if (needSignIn) {
        this.oidcManager.signIn();
      }
      return needSignIn;
    },

    // logout user
    logOut () {
      localStorage.setItem('LOG_OUT_CALLBACK', this.$route.fullPath);
      this.authProcessIsOn = true;
      Promise.resolve(this.setAuthenticated(false))
        .then(() => logout().catch(() => null))
        .then(() => this.oidcManager.signOut());
    }
  }
};
