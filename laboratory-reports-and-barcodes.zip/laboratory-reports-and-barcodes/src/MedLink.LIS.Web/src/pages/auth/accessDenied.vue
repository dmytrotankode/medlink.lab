<template>
  <q-page data-testid="accessDenied">
    <div class="fixed-center text-center">
      <q-icon name="lock" size="64px" color="grey-6" class="q-mb-md" />
      <p class="text-subtitle2 text-uppercase">У доступі відмовлено</p>
      <p class="text-subtitle2 text-uppercase">Зверніться до адміністратора</p>
      <q-btn @click="logout">
        <div>Назад</div>
      </q-btn>
    </div>
  </q-page>
</template>

<script>
import Oidc from '../../boot/security-oidc';

export default {
  name: 'AccessDenied',
  data () {
    return {
      oidcManager: new Oidc()
    };
  },
  methods: {
    logout () {
      this.oidcManager.signOut();
    }
  }
};
</script>
