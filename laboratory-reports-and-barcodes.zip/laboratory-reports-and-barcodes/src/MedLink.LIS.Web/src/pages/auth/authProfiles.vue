<template>
  <div data-testid="authProfiles" class="text-center q-mb-xl" style="width: 460px; max-width: 90vw">
    <div class="brand-logo-box q-mx-auto q-mb-sm" style="width: 48px; height: 48px">
      <q-icon name="fas fa-flask" size="24px" />
    </div>
    <div class="text-h6 q-mb-md">MedLink LIS</div>

    <q-select
      dense
      outlined
      v-model="selectedUser"
      :label="`Оберіть профіль для користувача ${profileUserCaption}`"
      :options="profiles"
      options-selected-class="text-primary"
      :rules="[val => !!val || 'Обов\'язкове поле']"
      class="q-mb-md text-left"
      data-testid="authProfileSelect"
    >
      <template v-slot:selected-item="scope">
        {{ scope.opt.profileCaption }}
        {{ scope.opt.organizationCaption ? `(${scope.opt.organizationCaption})` : '' }}
      </template>
      <template v-slot:option="scope">
        <q-item v-bind="scope.itemProps" v-on="scope.itemEvents">
          <q-item-section avatar>
            <q-icon name="person" class="text-grey-8" />
          </q-item-section>
          <q-item-section>
            <q-item-label>{{ scope.opt.profileCaption }}</q-item-label>
            <q-item-label caption v-if="scope.opt.userCaption">{{ scope.opt.userCaption }}</q-item-label>
            <q-item-label caption v-if="scope.opt.organizationCaption">{{ scope.opt.organizationCaption }}</q-item-label>
          </q-item-section>
        </q-item>
      </template>
      <template v-slot:no-option>
        <q-item>
          <q-item-section class="text-grey">Відсутні значення</q-item-section>
        </q-item>
      </template>
    </q-select>

    <q-btn
      :disable="!userIsSelected"
      unelevated
      color="primary"
      label="увійти в систему"
      data-testid="authProfileLogin"
      @click="setUser"
    />
  </div>
</template>

<script>
import authProfilesMixin from './mixins/authProfiles';

export default {
  name: 'AuthProfiles',
  mixins: [authProfilesMixin]
};
</script>
