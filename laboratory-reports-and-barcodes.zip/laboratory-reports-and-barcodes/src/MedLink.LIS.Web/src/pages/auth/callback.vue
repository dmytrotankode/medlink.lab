<template>
  <q-page data-testid="callback" class="window-height window-width column justify-center items-center bg-grey-2 q-pa-md">
    <div v-if="!hasMoreThanOneProfile" class="text-center">
      <div>
        <q-spinner-dots color="primary" size="3em" />
      </div>
      <p class="text-subtitle2 text-uppercase">Триває процес авторизації</p>
      <p class="text-subtitle2 text-uppercase">Зачекайте, будь ласка</p>
    </div>

    <auth-profiles
      v-if="hasMoreThanOneProfile"
      :profiles="users"
      @selected="routeToMainPage"
    />
  </q-page>
</template>

<script>
import AuthProfiles from './authProfiles.vue';
import Oidc from '../../boot/security-oidc';
import authProfilesMixin from './mixins/authProfiles';
import { tryAuthenticate } from '../../mixins/auth';

export default {
  name: 'AuthCallback',
  components: { AuthProfiles },
  mixins: [authProfilesMixin],
  data () {
    return {
      oidcClient: new Oidc(),
      users: []
    };
  },

  mounted () {
    this.oidcClient
      .signinRedirectCallback()
      .then(this.auth)
      .catch(this.handleSigninCallbackError);
  },

  methods: {
    handleSigninCallbackError () {
      this.auth();
    },

    auth () {
      tryAuthenticate()
        .then((data) => {
          return this.afterSuccesTryAuthenticate(data);
        })
        .catch(() => {
          this.routeToAccessDenied();
        });
    },

    afterSuccesTryAuthenticate (data) {
      // receive single user
      if (data.authenticated) {
        this.selectedUser = data.userProfileData;
        const setAuthenticated = () => this.setAuthenticated(true);

        this.initUser()
          .then(setAuthenticated)
          .then(this.routeToMainPage);
      } else {
        this.users = [...data.userData];
      }
    },

    routeToMainPage () {
      this.$router.push({ path: process.env.REDIRECT_CALLBACK });
    }
  },

  computed: {
    hasMoreThanOneProfile () {
      return !!this.users && this.users.length > 1;
    }
  }
};
</script>
