import { mapActions } from 'vuex';
import { authenticate } from '../../../mixins/auth';

export default {
  data () {
    return {
      selectedUser: null
    };
  },

  props: {
    profiles: {
      required: false,
      type: Array
    }
  },

  computed: {
    userIsSelected () {
      return !!this.selectedUser;
    },

    profileUserCaption () {
      return this.profiles && this.profiles.length ? this.profiles[0].userCaption : '';
    }
  },

  methods: {
    ...mapActions('context', ['setAuthenticated', 'initUser']),

    // authenticate selected user
    setUser () {
      const emitSelectClick = () => this.$emit('selected');
      authenticate(this.selectedUser)
        .then(this.initCurrentUser)
        .catch(this.routeToAccessDenied)
        .finally(emitSelectClick);
    },

    initCurrentUser () {
      return this.initUser()
        .then(() => this.setAuthenticated(true));
    },

    routeToAccessDenied () {
      this.$router.push({ path: '/accessdenied' });
    }
  }
};
