<template>
  <q-dialog :value="value" @input="$emit('input', $event)" persistent maximized-mobile>
    <q-card style="width: 980px; max-width: 98vw">
      <q-card-section class="row items-center bg-primary text-white q-py-sm">
        <q-icon name="post_add" class="q-mr-sm" />
        <div class="text-subtitle1 text-weight-bold">Нове направлення / замовлення</div>
        <q-space />
        <q-toggle v-model="form.isUrgentCito" color="deep-orange-5" keep-color label="CITO (терміново)" class="q-mr-md" />
        <q-btn flat round dense icon="close" v-close-popup />
      </q-card-section>

      <q-form @submit.prevent="submit">
        <q-card-section class="q-gutter-y-sm" style="max-height: 70vh; overflow: auto">
          <!-- Пацієнт -->
          <div class="section-title">1. Пацієнт</div>
          <div v-if="!newPatientMode" class="row q-col-gutter-sm items-start">
            <div class="col-12 col-md-8">
              <patient-select v-model="patient" :rules="[v => !!v || 'Оберіть пацієнта']" @create="startNewPatient" />
            </div>
            <div class="col-12 col-md-4">
              <q-btn outline color="primary" icon="person_add" label="Швидко створити пацієнта" class="full-width" @click="startNewPatient('')" />
            </div>
            <div v-if="patient" class="col-12">
              <q-banner dense class="bg-blue-1 text-grey-9" rounded>
                <b>{{ patientName }}</b> · {{ patient.birthDate | date }} ({{ patientAge }} р.) · {{ genderLabel(patient.gender) }}
                <span v-if="patient.phone"> · {{ patient.phone }}</span>
              </q-banner>
            </div>
          </div>
          <div v-else class="row q-col-gutter-sm">
            <div class="col-12 col-md-4"><q-input v-model="newPatient.lastName" outlined dense label="Прізвище *" :rules="[v => !!v || 'Обов’язково']" /></div>
            <div class="col-12 col-md-4"><q-input v-model="newPatient.firstName" outlined dense label="Ім’я *" :rules="[v => !!v || 'Обов’язково']" /></div>
            <div class="col-12 col-md-4"><q-input v-model="newPatient.middleName" outlined dense label="По батькові" /></div>
            <div class="col-6 col-md-3"><q-input v-model="newPatient.birthDate" outlined dense type="date" label="Дата народження *" stack-label :rules="[v => !!v || 'Обов’язково']" /></div>
            <div class="col-6 col-md-3">
              <q-select v-model="newPatient.gender" outlined dense label="Стать *" :options="[{ value: 'M', label: 'Чоловіча' }, { value: 'F', label: 'Жіноча' }]" emit-value map-options :rules="[v => !!v || 'Обов’язково']" />
            </div>
            <div class="col-6 col-md-3"><q-input v-model="newPatient.phone" outlined dense label="Телефон" mask="+38 (###) ###-##-##" unmasked-value fill-mask /></div>
            <div class="col-6 col-md-3"><q-input v-model="newPatient.taxId" outlined dense label="ІПН" mask="##########" /></div>
            <div class="col-12 col-md-8"><q-input v-model="newPatient.email" outlined dense label="E-mail (для сповіщень)" type="email" /></div>
            <div class="col-12 col-md-4 text-right">
              <q-btn flat color="grey-8" label="Назад до пошуку" icon="arrow_back" @click="newPatientMode = false" />
            </div>
          </div>

          <!-- Направлення -->
          <div class="section-title q-mt-md row items-center justify-between">
            <span>2. Направлення</span>
            <q-btn-toggle v-model="form.referralType" dense no-caps unelevated toggle-color="primary" color="white" text-color="grey-8" :options="referralTypeOptions" data-testid="referralType" />
          </div>
          <div class="row q-col-gutter-sm">
            <template v-if="form.referralType === 'EHEALTH'">
              <div class="col-12 col-md-4">
                <q-input v-model="ehealthNumber" outlined dense label="Номер е-направлення *" data-testid="ehealthNumber" @keyup.enter="lookupReferral">
                  <template v-slot:append><q-btn flat dense icon="search" :loading="referralLoading" @click="lookupReferral" /></template>
                </q-input>
              </div>
              <div class="col-12 col-md-8">
                <q-banner v-if="referralInfo" dense rounded :class="referralInfo.canUse ? 'bg-green-1' : 'bg-red-1'" data-testid="referralInfo">
                  <b>{{ referralInfo.serviceName }}</b> · {{ referralInfo.patientName }} · дійсне до {{ referralInfo.expirationDate | date }} · {{ referralInfo.statusName }}
                  <div v-for="(p, i) in referralInfo.problems" :key="i" class="text-negative text-caption">{{ p }}</div>
                </q-banner>
                <div v-else class="text-caption text-grey-7 q-pt-sm">Знайдіть направлення ЕСОЗ — пацієнт і послуга підставляться автоматично; при видачі результатів направлення буде погашено висновком.</div>
              </div>
            </template>
            <template v-if="form.referralType === 'PAPER'">
              <div class="col-6 col-md-3"><q-input v-model="paper.number" outlined dense label="№ паперового направлення *" /></div>
              <div class="col-6 col-md-3"><q-input v-model="paper.date" outlined dense type="date" stack-label label="Дата" /></div>
              <div class="col-12 col-md-4"><q-input v-model="paper.requesterLegalEntityName" outlined dense label="Заклад-направник *" /></div>
              <div class="col-6 col-md-2"><q-input v-model="paper.requesterLegalEntityEdrpou" outlined dense label="ЄДРПОУ" mask="########" /></div>
              <div class="col-6 col-md-4"><q-input v-model="paper.requesterEmployeeName" outlined dense label="Лікар-направник" /></div>
            </template>
            <template v-if="form.referralType === 'EXTERNAL_CLINIC'">
              <div class="col-12 col-md-4"><q-input v-model="form.referrerOrganizationName" outlined dense label="Клініка-партнер *" /></div>
              <div class="col-6 col-md-2"><q-input v-model="form.referrerOrganizationEdrpou" outlined dense label="ЄДРПОУ" mask="########" /></div>
              <div class="col-6 col-md-3"><q-input v-model="form.referrerDoctorName" outlined dense label="Лікар клініки" /></div>
              <div class="col-12 col-md-3"><q-input v-model="form.referrerNumber" outlined dense label="№ направлення клініки" /></div>
            </template>
            <div class="col-12 col-md-4">
              <q-select v-model="form.doctorId" outlined dense clearable :label="form.referralType === 'INTERNAL' ? 'Лікар закладу *' : 'Лікар-замовник'" :options="doctorOptions" emit-value map-options use-input input-debounce="0" @filter="filterDoctors" />
            </div>
            <div class="col-12 col-md-4">
              <q-select v-model="form.departmentId" outlined dense clearable label="Відділення" :options="departmentOptions" emit-value map-options />
            </div>
            <div class="col-12">
              <q-input v-model="form.clinicalNotes" outlined dense autogrow label="Клінічні дані / діагноз (МКХ-10), коментар" />
            </div>
          </div>

          <!-- Послуги -->
          <div class="section-title q-mt-md row items-center justify-between">
            <span>3. Послуги та показники</span>
            <q-btn-toggle v-model="pickMode" dense no-caps unelevated toggle-color="primary" color="white" text-color="grey-8" :options="[{ value: 'lists', label: 'Списки' }, { value: 'matrix', label: 'Матриця призначень' }]" data-testid="pickMode" />
          </div>
          <order-matrix v-if="pickMode === 'matrix'" :value="{ profileIds: form.profileIds, testIds: form.testIds }" height="34vh" @input="onMatrix" />
          <div v-show="pickMode === 'lists'" class="row q-col-gutter-sm">
            <div class="col-12 col-md-6">
              <q-select
                v-model="form.profileIds"
                outlined dense multiple use-chips use-input input-debounce="0"
                label="Профілі (послуги)"
                :options="profileOptionsFiltered"
                emit-value map-options
                @filter="filterProfiles"
              >
                <template v-slot:option="scope">
                  <q-item v-bind="scope.itemProps" v-on="scope.itemEvents">
                    <q-item-section>
                      <q-item-label>{{ scope.opt.label }}</q-item-label>
                      <q-item-label caption>{{ scope.opt.item.code }} · {{ scope.opt.item.category }} · {{ (scope.opt.item.items || []).length }} показн. · TAT {{ scope.opt.item.turnaroundHours }} год</q-item-label>
                    </q-item-section>
                    <q-item-section side><span class="text-weight-bold">{{ scope.opt.item.price | money }}</span></q-item-section>
                  </q-item>
                </template>
              </q-select>
            </div>
            <div class="col-12 col-md-6">
              <q-select
                v-model="form.testIds"
                outlined dense multiple use-chips use-input input-debounce="0"
                label="Окремі показники (тести)"
                :options="testOptionsFiltered"
                emit-value map-options
                @filter="filterTests"
              >
                <template v-slot:option="scope">
                  <q-item v-bind="scope.itemProps" v-on="scope.itemEvents">
                    <q-item-section>
                      <q-item-label>{{ scope.opt.label }}</q-item-label>
                      <q-item-label caption>{{ scope.opt.item.code }} · {{ scope.opt.item.unit }} · {{ biomaterialName(scope.opt.item.biomaterialTypeId) }}</q-item-label>
                    </q-item-section>
                  </q-item>
                </template>
              </q-select>
            </div>
          </div>

          <!-- План пробірок (сервер, FR-PRE-004) + ціна -->
          <div class="row q-col-gutter-md q-mt-xs">
            <div class="col-12 col-md-7">
              <div class="medlink-card" data-testid="tubePlanCard">
                <div class="medlink-card__title">
                  <span><q-icon name="science" class="q-mr-xs" />План пробірок у порядку забору</span>
                  <span class="text-grey-6 text-caption"><q-spinner v-if="planLoading" size="14px" class="q-mr-xs" />{{ planItems.length }} пробірк.</span>
                </div>
                <q-banner v-for="(w, i) in planWarnings" :key="i" dense class="bg-orange-1 text-deep-orange-9 q-ma-sm" rounded>
                  <template v-slot:avatar><q-icon name="warning" color="deep-orange" /></template>{{ w }}
                </q-banner>
                <tube-plan-list v-if="planItems.length" :items="planItems" />
                <div v-else-if="planError" class="q-pa-md text-negative text-caption">{{ planError }}</div>
                <div v-else class="q-pa-md text-grey-6 text-caption">Оберіть профілі або показники — сервер сформує план пробірок за правилами тари: окремі пробірки, об’єм, ліміт тестів, сумісність.</div>
              </div>
            </div>
            <div class="col-12 col-md-5">
              <div class="medlink-card q-pa-md">
                <div class="row items-center justify-between"><span class="text-grey-7">Показників усього</span><b>{{ allTestCodes.length }}</b></div>
                <div class="row items-center justify-between"><span class="text-grey-7">Профілів</span><b>{{ form.profileIds.length }}</b></div>
                <div class="row items-center justify-between"><span class="text-grey-7">Пробірок до забору</span><b>{{ planItems.length }}</b></div>
                <q-separator class="q-my-sm" />
                <q-select v-model="payerId" outlined dense emit-value map-options :options="payerOptions" label="Платник" data-testid="payerSelect" class="q-mb-xs" />
                <div v-if="selectedPayer && selectedPayer.requiresPolicy" class="q-mb-xs">
                  <q-select v-if="policies.length" v-model="policyId" outlined dense emit-value map-options :options="policyOptions" label="Поліс пацієнта" />
                  <div v-else class="row q-gutter-xs items-center">
                    <q-input v-model="newPolicy.number" outlined dense label="№ полісу *" class="col" />
                    <q-input v-model="newPolicy.validTo" outlined dense type="date" stack-label label="Дійсний до" class="col" />
                    <q-btn dense unelevated color="primary" icon="add" :disable="!newPolicy.number || !patient" @click="addPolicy"><q-tooltip>Додати поліс пацієнту</q-tooltip></q-btn>
                  </div>
                </div>
                <q-input v-if="selectedPayer && selectedPayer.requiresAuthorization" v-model="authorizationNumber" outlined dense label="№ гарантійного листа *" class="q-mb-xs" />
                <div v-if="payerId === 'AUTO' && quote" class="text-caption text-grey-7 q-mb-xs">Визначено: <b>{{ quote.payerName }}</b><span v-if="quote.policyNumber"> · поліс {{ quote.policyNumber }}</span></div>
                <q-banner v-if="quote && quote.warning" dense rounded class="bg-orange-1 text-deep-orange-9 q-mb-xs">{{ quote.warning }}</q-banner>
                <template v-if="quote">
                  <div v-for="l in quote.lines" :key="l.code" class="row justify-between text-caption">
                    <span>{{ l.code }}<span v-if="l.isPackage" class="text-primary"> (пакет)</span><span v-if="l.isNotCovered" class="text-deep-orange-8"> · не покривається</span></span>
                    <span>{{ l.amount | money }}</span>
                  </div>
                  <q-separator class="q-my-xs" />
                  <div class="row items-center justify-between"><span class="text-grey-7">Сплачує {{ quote.payerKind === 'PATIENT' ? 'пацієнт' : quote.payerName }}</span><b>{{ (quote.payerKind === 'PATIENT' ? quote.patientAmount : quote.payerAmount) | money }}</b></div>
                </template>
                <div class="row items-center justify-between text-h6" data-testid="patientToPay"><span>До сплати пацієнтом</span><span class="text-primary">{{ (quote ? quote.patientAmount : 0) | money }}</span></div>
                <div v-if="form.isUrgentCito" class="text-caption text-deep-orange-7 q-mt-xs"><q-icon name="bolt" /> CITO — пріоритетна черга та окрема позначка на етикетках</div>
              </div>
            </div>
          </div>
        </q-card-section>

        <q-card-actions align="right" class="bg-grey-1">
          <div v-if="submitError" class="text-negative text-caption q-mr-md ellipsis" style="max-width: 50%">{{ submitError }}</div>
          <q-btn flat label="Скасувати" v-close-popup />
          <q-btn type="submit" color="primary" icon="save" label="Створити замовлення" :loading="saving" :disable="!canSubmit" />
        </q-card-actions>
      </q-form>
    </q-card>
  </q-dialog>
</template>

<script>
import PatientSelect from '../../../components/common/PatientSelect.vue';
import OrderMatrix from '../../../components/orders/OrderMatrix.vue';
import TubePlanList from '../../../components/samples/TubePlanList.vue';
import { patientDisplay, genderLabel, ageFromBirthDate } from '../../../utils/format';

const emptyPaper = () => ({ number: '', date: '', requesterLegalEntityName: '', requesterLegalEntityEdrpou: '', requesterEmployeeName: '' });
const emptyForm = () => ({
  isUrgentCito: false,
  referralType: 'SELF',
  referrerOrganizationName: '',
  referrerOrganizationEdrpou: '',
  referrerDoctorName: '',
  referrerNumber: '',
  doctorId: null,
  departmentId: null,
  ehealthReferralId: '',
  clinicalNotes: '',
  profileIds: [],
  testIds: []
});

export default {
  name: 'CreateOrderDialog',
  components: { PatientSelect, OrderMatrix, TubePlanList },
  props: { value: Boolean },
  data () {
    return {
      pickMode: 'lists',
      patient: null,
      newPatientMode: false,
      newPatient: { lastName: '', firstName: '', middleName: '', birthDate: '', gender: null, phone: '', taxId: '', email: '' },
      form: emptyForm(),
      saving: false,
      submitError: '',
      profileFilter: '',
      testFilter: '',
      doctorFilter: '',
      ehealthNumber: '',
      referralInfo: null,
      referralLoading: false,
      paper: emptyPaper(),
      referralTypeOptions: [
        { value: 'SELF', label: 'Самозвернення' }, { value: 'INTERNAL', label: 'Внутрішнє' }, { value: 'EHEALTH', label: 'Е-направлення' },
        { value: 'PAPER', label: 'Паперове' }, { value: 'EXTERNAL_CLINIC', label: 'Клініка-партнер' }
      ],
      payers: [],
      payerId: 'AUTO',
      policies: [],
      policyId: null,
      newPolicy: { number: '', validTo: '' },
      authorizationNumber: '',
      quote: null,
      quoteTimer: null,
      plan: null,
      planLoading: false,
      planError: '',
      planTimer: null,
      planSeq: 0
    };
  },
  computed: {
    profiles () { return this.$store.getters['dictionaries/items']('profiles').filter(p => p.isActive !== false); },
    tests () { return this.$store.getters['dictionaries/items']('tests').filter(t => t.isActive !== false); },
    biomaterials () { return this.$store.getters['dictionaries/items']('biomaterials'); },
    tubeTypes () { return this.$store.getters['dictionaries/items']('tube-types'); },
    employees () { return this.$store.getters['dictionaries/items']('employees'); },
    departmentOptions () { return this.$store.getters['dictionaries/options']('departments'); },
    doctorOptions () {
      const f = this.doctorFilter.toLowerCase();
      return this.employees
        .map(e => ({ value: e.id, label: e.fullName || e.name, caption: e.position }))
        .filter(o => !f || (o.label || '').toLowerCase().includes(f));
    },
    profileOptionsFiltered () {
      const f = this.profileFilter.toLowerCase();
      return this.profiles.filter(p => !f || `${p.name} ${p.code}`.toLowerCase().includes(f)).map(p => ({ value: p.id, label: p.name, item: p }));
    },
    testOptionsFiltered () {
      const f = this.testFilter.toLowerCase();
      return this.tests.filter(t => !f || `${t.name} ${t.code}`.toLowerCase().includes(f)).map(t => ({ value: t.id, label: t.name, item: t }));
    },
    selectedProfiles () { return this.profiles.filter(p => this.form.profileIds.includes(p.id)); },
    selectedTests () {
      const ids = new Set(this.form.testIds);
      this.selectedProfiles.forEach(p => (p.items || []).forEach(i => ids.add(i.testId)));
      return this.tests.filter(t => ids.has(t.id));
    },
    allTestCodes () { return this.selectedTests.map(t => t.code); },
    totalPrice () {
      const profiles = this.selectedProfiles.reduce((s, p) => s + (Number(p.price) || 0), 0);
      const inProfiles = new Set();
      this.selectedProfiles.forEach(p => (p.items || []).forEach(i => inProfiles.add(i.testId)));
      const singles = this.tests.filter(t => this.form.testIds.includes(t.id) && !inProfiles.has(t.id)).reduce((s, t) => s + (Number(t.price) || 0), 0);
      return profiles + singles;
    },
    planItems () {
      return ((this.plan && this.plan.tubes) || []).map(t => ({
        key: String(t.index), index: t.index, color: t.colorCode, tubeName: t.tubeName, biomaterialName: t.biomaterialName,
        tests: t.tests, usedVolumeMl: t.usedVolumeMl, capacityMl: t.capacityMl, reasonTexts: t.reasonTexts,
        isSeparate: t.isSeparate, inversionsCount: t.inversionsCount, barcode: t.existingBarcode, existing: !!t.existingSampleId
      }));
    },
    planWarnings () { return (this.plan && this.plan.warnings) || []; },
    payerOptions () {
      return [{ value: 'AUTO', label: 'Автоматично (поліс / НСЗУ з е-направлення / каса)' }]
        .concat(this.payers.filter(p => p.isActive).map(p => ({ value: p.id, label: `${p.name} · ${p.kindName}` })));
    },
    selectedPayer () { return this.payers.find(p => p.id === this.payerId || p.code === this.payerId) || null; },
    policyOptions () { return this.policies.filter(p => !this.selectedPayer || p.payerId === this.selectedPayer.id).map(p => ({ value: p.id, label: `${p.policyNumber} · ${p.payerName}` })); },
    patientName () { return patientDisplay(this.patient); },
    patientAge () { return ageFromBirthDate(this.patient && this.patient.birthDate); },
    canSubmit () {
      const hasPatient = this.newPatientMode ? (this.newPatient.lastName && this.newPatient.firstName && this.newPatient.birthDate && this.newPatient.gender) : !!this.patient;
      return hasPatient && (this.form.profileIds.length || this.form.testIds.length) && !this.saving;
    }
  },
  watch: {
    'form.profileIds' () { this.schedulePlan(); },
    'form.testIds' () { this.schedulePlan(); },
    payerId () { this.scheduleQuote(); },
    patient (p) { this.loadPolicies(p); this.scheduleQuote(); },
    value: {
      // immediate: діалог може бути відкритий одразу при завантаженні сторінки (?create=1)
      immediate: true,
      handler (v) {
        if (v) {
          this.reset();
          this.$store.dispatch('dictionaries/loadMany', ['profiles', 'tests', 'biomaterials', 'tube-types', 'employees', 'departments']);
        }
      }
    }
  },
  methods: {
    genderLabel,
    schedulePlan () {
      clearTimeout(this.planTimer);
      this.planTimer = setTimeout(this.loadPlan, 300);
      this.scheduleQuote();
    },
    scheduleQuote () {
      clearTimeout(this.quoteTimer);
      this.quoteTimer = setTimeout(this.loadQuote, 350);
    },
    async loadQuote () {
      if (!this.form.profileIds.length && !this.form.testIds.length) { this.quote = null; return; }
      try {
        this.quote = await this.$api.billingQuote({
          profileIds: this.form.profileIds, testIds: this.form.testIds, payerId: this.payerId === 'AUTO' ? null : this.payerId,
          patientId: this.patient && this.patient.id, ehealthReferralNumber: this.form.referralType === 'EHEALTH' ? this.ehealthNumber : null
        });
      } catch (e) { this.quote = null; }
    },
    async loadPayers () { try { this.payers = await this.$api.payers(); } catch (e) { this.payers = []; } },
    async loadPolicies (p) {
      this.policies = []; this.policyId = null;
      if (!p || !p.id) return;
      try { this.policies = (await this.$api.patientInsurances(p.id)).filter(x => x.isValid); this.policyId = this.policies.length ? this.policies[0].id : null; } catch (e) { this.policies = []; }
    },
    async addPolicy () {
      try {
        await this.$api.addPatientInsurance(this.patient.id, { payerId: this.selectedPayer.id, policyNumber: this.newPolicy.number, validTo: this.newPolicy.validTo || null });
        this.newPolicy = { number: '', validTo: '' };
        await this.loadPolicies(this.patient);
        this.scheduleQuote();
      } catch (e) { this.$q.notify({ type: 'negative', message: e.userMessage || 'Не вдалося додати поліс' }); }
    },
    async loadPlan () {
      const body = { profileIds: this.form.profileIds, testIds: this.form.testIds };
      if (!body.profileIds.length && !body.testIds.length) { this.plan = null; this.planError = ''; return; }
      const seq = ++this.planSeq;
      this.planLoading = true;
      try {
        const plan = await this.$api.tubePlan(body);
        if (seq === this.planSeq) { this.plan = plan; this.planError = ''; }
      } catch (e) {
        if (seq === this.planSeq) { this.plan = null; this.planError = e.userMessage || 'Не вдалося побудувати план пробірок'; }
      } finally {
        if (seq === this.planSeq) this.planLoading = false;
      }
    },
    async lookupReferral () {
      if (!this.ehealthNumber) return;
      this.referralLoading = true;
      try {
        const info = await this.$api.lookupEhealthReferral(this.ehealthNumber.trim(), this.patient && this.patient.id);
        this.referralInfo = info;
        if (info.canUse && !this.patient && info.patientId) {
          try { const p = await this.$api.getPatient(info.patientId); this.patient = { ...p, display: p.fullName || [p.lastName, p.firstName, p.secondName].filter(Boolean).join(' ') }; } catch (e) { /* пацієнта оберуть вручну */ }
        }
        (info.matchingProfiles || []).forEach(p => { if (!this.form.profileIds.includes(p.id)) this.form.profileIds.push(p.id); });
      } catch (e) {
        this.referralInfo = { canUse: false, problems: [e.userMessage || 'Направлення не знайдено'] };
      } finally {
        this.referralLoading = false;
      }
    },
    reset () {
      this.payerId = 'AUTO';
      this.policies = []; this.policyId = null; this.authorizationNumber = ''; this.quote = null;
      this.loadPayers();
      this.ehealthNumber = '';
      this.referralInfo = null;
      this.paper = emptyPaper();
      this.plan = null;
      this.planError = '';
      this.patient = null;
      this.newPatientMode = false;
      this.form = emptyForm();
      this.submitError = '';
      this.newPatient = { lastName: '', firstName: '', middleName: '', birthDate: '', gender: null, phone: '', taxId: '', email: '' };
    },
    startNewPatient (query) {
      this.newPatientMode = true;
      const parts = (query || '').trim().split(/\s+/);
      if (parts[0]) this.newPatient.lastName = parts[0];
      if (parts[1]) this.newPatient.firstName = parts[1];
      if (parts[2]) this.newPatient.middleName = parts[2];
    },
    biomaterialName (id) {
      const b = this.biomaterials.find(x => x.id === id);
      return b ? b.name : '';
    },
    onMatrix (sel) { this.form.profileIds = sel.profileIds || []; this.form.testIds = sel.testIds || []; },
    filterProfiles (val, update) { update(() => { this.profileFilter = val || ''; }); },
    filterTests (val, update) { update(() => { this.testFilter = val || ''; }); },
    filterDoctors (val, update) { update(() => { this.doctorFilter = val || ''; }); },
    async submit () {
      this.saving = true;
      this.submitError = '';
      const body = {
        ...this.form,
        ehealthReferralId: null,
        ehealthReferralNumber: this.form.referralType === 'EHEALTH' ? (this.ehealthNumber || '').trim() : null,
        paperReferral: this.form.referralType === 'PAPER' ? { ...this.paper, date: this.paper.date || null } : null,
        clinicalNotes: this.form.clinicalNotes || null,
        payerId: this.payerId && this.payerId !== 'AUTO' ? this.payerId : null,
        patientInsuranceId: this.selectedPayer && this.selectedPayer.requiresPolicy ? this.policyId : null,
        authorizationNumber: this.authorizationNumber || null
      };
      ['referrerOrganizationName', 'referrerOrganizationEdrpou', 'referrerDoctorName', 'referrerNumber'].forEach(k => { if (this.form.referralType !== 'EXTERNAL_CLINIC' || !body[k]) body[k] = null; });
      if (this.newPatientMode) body.newPatient = { ...this.newPatient };
      else body.patientId = this.patient.id;
      try {
        const order = await this.$api.createOrder(body);
        this.$q.notify({ type: 'positive', message: `Замовлення ${order.orderNumber || ''} створено` });
        this.$emit('created', order);
        this.$emit('input', false);
      } catch (e) {
        this.submitError = e.userMessage || 'Не вдалося створити замовлення';
      } finally {
        this.saving = false;
      }
    }
  }
};
</script>
