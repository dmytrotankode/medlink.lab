import laboratoryRoutes from './laboratoryRoutes';
import portalRoutes from './portalRoutes';

const routes = [
  { path: '/', redirect: '/laboratory/dashboard' },
  ...laboratoryRoutes,
  ...portalRoutes,
  {
    path: '/login',
    name: 'login',
    component: () => import('layouts/LoginPage.vue'),
    children: [
      { path: '/callback', name: 'callback', meta: { title: 'Вхід' }, component: () => import('pages/auth/callback.vue') },
      { path: '/accessdenied', name: 'accessdenied', meta: { title: 'У доступі відмовлено' }, component: () => import('pages/auth/accessDenied.vue') }
    ]
  },
  {
    path: '/verify/:token',
    name: 'verify',
    meta: { title: 'Перевірка бланка' },
    component: () => import('pages/portal/VerifyReport.vue')
  },
  {
    path: '*',
    component: () => import('pages/Error404.vue')
  }
];

export default routes;
