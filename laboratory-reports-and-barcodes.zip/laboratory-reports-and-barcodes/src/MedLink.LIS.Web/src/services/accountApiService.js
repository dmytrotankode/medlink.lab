import { httpRoot, ACCOUNT_API_BASE } from './http';

export const ACCOUNT = {
  INFO: `${ACCOUNT_API_BASE}/info`,
  AUTH: `${ACCOUNT_API_BASE}/authenticate/`,
  AUTH_TRY: `${ACCOUNT_API_BASE}/try-authenticate/`,
  LOG_OUT: `${ACCOUNT_API_BASE}/logout/`,
  USER_PROFILES: `${ACCOUNT_API_BASE}/userProfiles`
};

export const postAuth = url => httpRoot({
  url,
  method: 'post',
  validateStatus (status) {
    return status >= 200 && status <= 300;
  }
});

export const getUserInfo = () => httpRoot.get(ACCOUNT.INFO);
export const logout = () => httpRoot.get(ACCOUNT.LOG_OUT);
export const getUserProfiles = () => httpRoot.get(ACCOUNT.USER_PROFILES).then(response => response.data);
export const postAuthenticate = body => httpRoot.post(ACCOUNT.AUTH, body);
