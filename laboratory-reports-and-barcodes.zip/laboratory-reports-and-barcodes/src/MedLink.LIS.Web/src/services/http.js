import axios from 'axios';

export const API_BASE = process.env.API_BASE || '/api/v1/lab';
export const ACCOUNT_API_BASE = process.env.ACCOUNT_API_BASE || '/api/account';

const jsonHeaders = {
  'Content-Type': 'application/json',
  Accept: 'application/json'
};

export const http = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
  headers: jsonHeaders
});

export const httpRoot = axios.create({
  baseURL: '',
  timeout: 30000,
  headers: jsonHeaders
});

export function getAccessToken () {
  try {
    const key = `oidc.user:${process.env.OIDC_ISSUER}:${process.env.OIDC_CLIENTID}`;
    const stored = window.localStorage.getItem(key);
    const parsed = stored ? JSON.parse(stored) : null;
    return (parsed && parsed.access_token) || null;
  } catch (e) {
    return null;
  }
}

/**
 * Перетворює помилку axios у зручний для UI вигляд (RFC 7807 ProblemDetails).
 */
export function describeApiError (error) {
  if (!error) return { message: 'Невідома помилка', offline: false, status: 0, fields: {} };
  if (error.response) {
    const data = error.response.data || {};
    const fields = data.errors || {};
    let message = data.detail || data.title || error.response.statusText || `HTTP ${error.response.status}`;
    const fieldMessages = Object.keys(fields).map(k => `${k}: ${[].concat(fields[k]).join(', ')}`);
    if (fieldMessages.length) message += ' — ' + fieldMessages.join('; ');
    return { message, offline: false, status: error.response.status, fields, raw: data };
  }
  if (error.request) {
    return {
      message: 'API лабораторії недоступне. Перевірте, що сервіс MedLink.LIS.Api запущено.',
      offline: true,
      status: 0,
      fields: {}
    };
  }
  return { message: error.message || 'Помилка запиту', offline: false, status: 0, fields: {} };
}

function fileNameFromDisposition (disposition) {
  if (!disposition) return null;
  const star = disposition.match(/filename\*=(?:UTF-8'')?([^;\n]+)/i);
  if (star && star[1]) {
    try { return decodeURIComponent(star[1].replace(/['"]/g, '')); } catch (e) { }
  }
  const plain = disposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/i);
  return plain && plain[1] ? plain[1].replace(/['"]/g, '') : null;
}

export function openApiFile (url, { download = false } = {}) {
  const win = download ? null : window.open('', '_blank');
  return httpRoot.get(url, { responseType: 'blob', headers: { Accept: '*/*' } })
    .then(response => {
      const blob = response.data;
      const type = (blob && blob.type) || 'application/octet-stream';
      const objectUrl = window.URL.createObjectURL(blob);
      const viewable = /^(application\/pdf|text\/html|text\/plain|image\/)/i.test(type);
      if (win && viewable) {
        win.location.href = objectUrl;
      } else {
        if (win) win.close();
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = objectUrl;
        a.download = fileNameFromDisposition(response.headers['content-disposition']) || `${Date.now()}`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => document.body.removeChild(a), 100);
      }
      setTimeout(() => window.URL.revokeObjectURL(objectUrl), 60000);
      return true;
    })
    .catch(error => {
      if (win) win.close();
      return Promise.reject(error);
    });
}

export default http;
