import { Notify } from 'quasar';

const DEFAULT_CONFIG = {
  position: 'bottom',
  timeout: 10000,
  html: true
};

const NOTIFICATION_TYPES = {
  info: {
    color: 'light-blue-5',
    textColor: 'dark',
    icon: 'info'
  },
  warning: {
    color: 'amber-3',
    textColor: 'grey-9',
    icon: 'warning'
  },
  negative: {
    color: 'red-5',
    textColor: 'white',
    icon: 'error'
  },
  positive: {
    color: 'green-6',
    textColor: 'white',
    icon: 'done'
  },
  default: {
    color: 'grey-9',
    textColor: 'white',
    icon: 'label'
  },
  warningExclamation: {
    color: 'amber-3',
    textColor: 'grey-9',
    icon: 'fas fa-exclamation'
  }
};

class NotificationService {
  notify (type, message, caption = '') {
    const title = caption ? `<div class="text-subtitle1">${caption}</div>` : '';
    const messageBody = `<div style="margin-left: 10px">${title}<div style="max-width: 600px">${message}</div></div>`;

    const notifyContext = {
      progress: DEFAULT_CONFIG.progress,
      position: DEFAULT_CONFIG.position,
      timeout: DEFAULT_CONFIG.timeout,
      html: true,
      message: messageBody,
      color: NOTIFICATION_TYPES[type].color,
      textColor: NOTIFICATION_TYPES[type].textColor,
      icon: NOTIFICATION_TYPES[type].icon
    };

    Notify.create(notifyContext);
  }
}

export default NotificationService;
