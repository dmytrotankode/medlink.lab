export const getOperationAccessLevel = (rights, operationName) => {
  if (rights) {
    if (rights.hasFullRights) {
      return 2;
    }

    if (rights.operationRights &&
      Object.prototype.hasOwnProperty.call(rights.operationRights, operationName)) {
      return rights.operationRights[operationName];
    }
  }
  return 0;
};
