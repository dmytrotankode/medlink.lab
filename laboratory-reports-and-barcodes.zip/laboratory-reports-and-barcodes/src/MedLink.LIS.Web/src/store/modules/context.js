import labApi from '../../services/labApiService';
import { getUserInfo } from '../../services/accountApiService';

const EMPTY_GUID = '00000000-0000-0000-0000-000000000000';

function readAuthenticated () {
  try {
    return JSON.parse(window.localStorage.getItem('marvel.authenticated')) === true;
  } catch (e) {
    return false;
  }
}

const state = {
  user: null,
  rights: null,
  authenticated: readAuthenticated(),
  userName: 'Не авторизовано',
  employeeId: null,
  employees: [],
  employee: null,
  assignableRoles: [],
  lab: null,
  organization: null,
  labSettings: null, // GET /settings/lab (принтер етикеток, бланки, retention)
  loaded: false,
  loading: false
};

const getters = {
  currentEmployee: s => s.employee || s.employees.find(e => e.id === s.employeeId) || null,
  currentRole: (s, g) => (g.currentEmployee && (g.currentEmployee.labRole || g.currentEmployee.role)) || null,
  labName: s => (s.lab && s.lab.name) || 'Клініко-діагностична лабораторія',
  organizationName: s => (s.user && s.user.organizationCaption) || (s.organization && s.organization.name) || '',
  hasProfile: s => !!(s.user && s.user.profileId && s.user.profileId !== EMPTY_GUID),
  employeeOptions: s => s.employees.map(e => ({
    value: e.id,
    label: e.fullName || e.name || e.id,
    caption: e.position || e.labRole || '',
    labRole: e.labRole
  }))
};

const mutations = {
  SET_USER_INFO (s, user) {
    s.user = user || null;
    s.employeeId = (user && user.employeeId && user.employeeId !== EMPTY_GUID) ? user.employeeId : null;
  },
  SET_RIGHTS (s, rights) { s.rights = rights || null; },
  SET_AUTHENTICATED (s, v) { s.authenticated = !!v; },
  SET_USER_NAME (s, name) { s.userName = name; },
  SET_EMPLOYEES (s, list) { s.employees = Array.isArray(list) ? list : (list && list.items) || []; },
  SET_ME (s, me) {
    s.employee = (me && me.employee) || null;
    s.assignableRoles = (me && me.assignableRoles) || [];
    s.lab = (me && me.lab) || null;
    s.organization = (me && me.organization) || null;
    s.loaded = true;
  },
  RESET_ORGANIZATION_DATA (s) {
    s.employees = [];
    s.employee = null;
    s.assignableRoles = [];
    s.lab = null;
    s.organization = null;
    s.labSettings = null;
    s.loaded = false;
  },
  SET_LAB_SETTINGS (s, v) { s.labSettings = v || null; },
  SET_LOADING (s, v) { s.loading = v; }
};

const actions = {
  fetchUserInfo () {
    return getUserInfo();
  },

  initUser ({ dispatch }) {
    return dispatch('fetchUserInfo').then(response => {
      const data = response && response.data;
      if (!data) return null;
      return dispatch('setUserInfo', data).then(() => data);
    });
  },

  setUserInfo ({ commit, dispatch }, user) {
    if (user) {
      commit('SET_RIGHTS', user.rights);
      const withoutRights = {};
      Object.keys(user).forEach(key => {
        if (key !== 'rights') withoutRights[key] = user[key];
      });
      commit('SET_USER_INFO', withoutRights);
    } else {
      commit('SET_RIGHTS', null);
      commit('SET_USER_INFO', null);
    }
    return dispatch('transformName', user);
  },

  setAuthenticated ({ commit }, authenticated) {
    try { window.localStorage.setItem('marvel.authenticated', authenticated); } catch (e) { }
    commit('SET_AUTHENTICATED', authenticated);
  },

  transformName ({ commit }, data) {
    if (data && data.personLastName) {
      const name = data.personLastName + ' ' +
        (data.personName ? data.personName.charAt(0) + '. ' : '') +
        (data.personMiddleName ? data.personMiddleName.charAt(0) + '.' : '');
      commit('SET_USER_NAME', name.trim());
    } else if (data && data.employeeCaption) {
      commit('SET_USER_NAME', data.employeeCaption);
    } else {
      commit('SET_USER_NAME', 'Не авторизовано');
    }
  },

  async loadEmployees ({ commit }) {
    const list = await labApi.getEmployees();
    commit('SET_EMPLOYEES', list);
    return Array.isArray(list) ? list : (list && list.items) || [];
  },

  async loadMe ({ commit }) {
    commit('SET_LOADING', true);
    try {
      const me = await labApi.getMe();
      commit('SET_ME', me);
      return me;
    } finally {
      commit('SET_LOADING', false);
    }
  },

  async loadLabSettings ({ commit }) {
    try {
      const s = await labApi.labSettings();
      commit('SET_LAB_SETTINGS', s);
      return s;
    } catch (e) {
      return null;
    }
  },

  resetOrganizationData ({ commit, dispatch }) {
    commit('RESET_ORGANIZATION_DATA');
    return Promise.all([dispatch('dictionaries/reset', null, { root: true }), dispatch('laboratory/reset', null, { root: true })]);
  },

  async init ({ dispatch }) {
    try {
      await dispatch('loadMe');
    } catch (e) { /* банер API покаже стан */ }
    dispatch('loadLabSettings');
  }
};

export default { namespaced: true, state, getters, mutations, actions };
