const identityChallengeHeader = 'x-auth-source';
const identityChallengeHeaderValue = 'identityserver';

const getHeader = (headers, name) => {
  if (!headers) {
    return '';
  }

  if (typeof headers.get === 'function') {
    return headers.get(name) || '';
  }

  return headers[name] || headers[name.toLowerCase()] || '';
};

export const isIdentityServerResponse = (error) => {
  const headers = error && error.response ? error.response.headers : null;
  const authSource = getHeader(headers, identityChallengeHeader);
  return String(authSource).toLowerCase() === identityChallengeHeaderValue;
};
