using System.Net;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Nodes;
using Core.Security;
using MedLink.LIS.Api.Controllers.adm;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Dto.Administration;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Tenancy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using SecurityFieldRight = Core.Security.Models.FieldRight;
using SecurityOperationRight = Core.Security.Models.OperationRight;
using SecurityProfile = Core.Security.Models.Profile;
using SecurityProfileOperationRight = Core.Security.Models.ProfileOperationRight;
using SecurityProfileRole = Core.Security.Models.ProfileRole;
using SecurityProfileRight = Core.Security.Models.ProfileRight;
using SecurityRight = Core.Security.Models.Right;
using SecurityUserProfile = Core.Security.Models.UserProfile;

namespace MedLink.LIS.Tests.Api;

[Collection("api")]
public class AuthApiTests
{
    private readonly LisApiFactory _f;
    public AuthApiTests(LisApiFactory f) => _f = f;

    private static async Task<JsonNode> Json(HttpResponseMessage r)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode} {r.RequestMessage?.Method} {r.RequestMessage?.RequestUri}: {text}");
        return JsonNode.Parse(text)!;
    }

    private static async Task<JsonNode> Problem(HttpResponseMessage r, HttpStatusCode status)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(status == r.StatusCode, $"Очікувано {(int)status}, отримано {(int)r.StatusCode}: {text}");
        var node = JsonNode.Parse(text)!;
        Assert.NotNull(node["title"]);
        return node;
    }

    private async Task Db(Func<LisDbContext, Task> f)
    {
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
        await f(db);
    }

    private async Task<(string identity, string employeeId, Guid[] profiles)> NewStaffAsync(int profileCount)
    {
        var identity = "test-user-" + Guid.NewGuid().ToString("N");
        var employeeId = Guid.NewGuid().ToString();
        var profiles = Enumerable.Range(0, profileCount).Select(_ => Guid.NewGuid()).ToArray();
        var adminRoleId = _f.RoleId(LabRoles.Admin);
        await Db(async db =>
        {
            var person = new CmnPerson { Id = Guid.NewGuid().ToString(), LastName = "Профільна", Name = "Олена", UserId = identity, Email = "olena@example.com" };
            person.Caption = CmnPerson.BuildCaption(person.LastName, person.Name, null);
            db.Persons.Add(person);
            db.Employees.Add(new OrgEmployee
            {
                Id = employeeId, PersonId = person.Id, Caption = person.Caption, TenantId = _f.TenantId, DepartmentId = _f.DivisionId(DemoDataSeeder.DeptCode),
                PositionTypeId = await db.EnumRecordIdAsync("OrgPositionType", "0002"), LabSettings = new LabEmployeeSettings { EmployeeId = employeeId, LabRole = "LAB_ADMIN" },
                Membership = new IdMembership { Id = employeeId, TenantId = _f.TenantId, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" }
            });
            for (var i = 0; i < profiles.Length; i++)
            {
                db.SecurityProfiles!.Add(new SecurityProfile { Id = profiles[i], Caption = $"Профіль {i + 1}", IsActive = true });
                db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(employeeId), ProfileId = profiles[i] });
                db.ProfileRoles!.Add(new SecurityProfileRole { Id = Guid.NewGuid(), ProfileId = profiles[i], RoleId = adminRoleId });
            }
            await db.SaveChangesAsync();
        });
        return (identity, employeeId, profiles);
    }

    [Fact]
    public async Task Unauthenticated_call_is_rejected()
    {
        var anon = _f.CreateClient();
        await Problem(await anon.GetAsync("/api/v1/lab/orders"), HttpStatusCode.Unauthorized);
        await Problem(await anon.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }), HttpStatusCode.Unauthorized);
        Assert.Equal(HttpStatusCode.Unauthorized, (await anon.GetAsync("/api/v1/lab/context/me")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await anon.GetAsync("/api/account/userProfiles")).StatusCode);
        var legacy = _f.CreateClient();
        legacy.DefaultRequestHeaders.Add("X-MedLink-Employee-Id", DemoDataSeeder.Admin);
        await Problem(await legacy.GetAsync("/api/v1/lab/orders"), HttpStatusCode.Unauthorized);
        Assert.Equal(HttpStatusCode.OK, (await anon.GetAsync("/health")).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, (await anon.GetAsync("/api/account/info")).StatusCode);
    }

    [Fact]
    public async Task Authenticated_without_selected_profile_is_rejected()
    {
        var (identity, _, _) = await NewStaffAsync(1);
        var c = _f.AsIdentity(identity);
        var p = await Problem(await c.GetAsync("/api/v1/lab/orders"), HttpStatusCode.Forbidden);
        Assert.Contains("профілю", p["detail"]!.GetValue<string>());
        await Problem(await c.GetAsync("/api/account/userProfiles"), HttpStatusCode.Forbidden);
        var info = await Json(await c.GetAsync("/api/account/info"));
        Assert.Equal(Guid.Empty.ToString(), info["profileId"]!.GetValue<string>());
    }

    [Fact]
    public async Task Profile_list_select_and_employee_resolved_from_profile()
    {
        var (identity, employeeId, profiles) = await NewStaffAsync(2);
        var c = _f.AsIdentity(identity);

        var tryResponse = await c.PostAsync("/api/account/try-authenticate/", null);
        Assert.Equal((HttpStatusCode)300, tryResponse.StatusCode);
        var list = JsonNode.Parse(await tryResponse.Content.ReadAsStringAsync())!.AsArray();
        Assert.Equal(2, list.Count);
        Assert.All(list, x =>
        {
            Assert.Equal(employeeId, x!["userId"]!.GetValue<string>());
            Assert.Equal(identity, x["userOuterId"]!.GetValue<string>());
            Assert.Equal(_f.TenantId, x["organizationId"]!.GetValue<string>());
            Assert.True(x["isActive"]!.GetValue<bool>());
        });
        Assert.Contains(list, x => x!["profileId"]!.GetValue<string>() == profiles[1].ToString() && x["profileCaption"]!.GetValue<string>() == "Профіль 2");

        var auth = await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = profiles[1], userId = employeeId }));
        Assert.Equal(employeeId, auth["userProfileData"]!["userId"]!.GetValue<string>());
        Assert.Equal(profiles[1].ToString(), auth["userProfileData"]!["profileId"]!.GetValue<string>());
        Assert.False(auth["isAuthInEhealth"]!.GetValue<bool>());
        Assert.NotNull(auth["ehealthInfo"]);

        var me = await Json(await c.GetAsync("/api/v1/lab/context/me"));
        Assert.True(me["isResolved"]!.GetValue<bool>());
        Assert.Equal(employeeId, me["employee"]!["id"]!.GetValue<string>());
        Assert.Equal("LAB_ADMIN", me["employee"]!["labRole"]!.GetValue<string>());

        var info = await Json(await c.GetAsync("/api/account/info"));
        Assert.Equal(employeeId, info["employeeId"]!.GetValue<string>());
        Assert.Equal(profiles[1].ToString(), info["profileId"]!.GetValue<string>());
        Assert.Equal(identity, info["userId"]!.GetValue<string>());
        Assert.Equal("Олена", info["personName"]!.GetValue<string>());
        Assert.NotNull(info["rights"]);

        var userProfiles = await Json(await c.GetAsync("/api/account/userProfiles"));
        Assert.Equal(2, userProfiles.AsArray().Count);

        var order = await Json(await c.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var orderId = order["id"]!.GetValue<string>();
        await Db(async db =>
        {
            var stored = await db.Orders.AsNoTracking().FirstAsync(o => o.Id == orderId);
            Assert.Equal(employeeId, stored.CreatedBy);
            Assert.Contains(await db.AuditLog.AsNoTracking().Where(a => a.EntityId == orderId).ToListAsync(), a => a.UserId == employeeId);
        });

        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/account/logout/")).StatusCode);
        await Problem(await c.GetAsync("/api/v1/lab/orders"), HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task Account_info_returns_access_levels_as_numbers()
    {
        var (identity, employeeId, profiles) = await NewStaffAsync(1);
        var profileId = profiles[0];
        await Db(async db =>
        {
            var write = new SecurityRight { Id = Guid.NewGuid(), Caption = "Тест: запис", EntityName = "LabOrderTest", EntityAccessLevel = EntityAccessLevel.Write, IsActive = true };
            var partial = new SecurityRight { Id = Guid.NewGuid(), Caption = "Тест: частково", EntityName = "LabSampleTest", EntityAccessLevel = EntityAccessLevel.Partial, IsActive = true };
            var operation = new SecurityOperationRight { Id = Guid.NewGuid(), Caption = "Тест: операція", OperationName = "LabVerifyTest", AccessLevel = AccessLevel.Read, IsActive = true };
            db.Rights!.AddRange(write, partial);
            db.FieldRights!.Add(new SecurityFieldRight { Id = Guid.NewGuid(), Caption = "Тест: поле", RightId = partial.Id, FieldName = "StatusCode", AccessLevel = AccessLevel.Write });
            db.OperationRights!.Add(operation);
            db.ProfileRights!.AddRange(
                new SecurityProfileRight { Id = Guid.NewGuid(), ProfileId = profileId, RightId = write.Id },
                new SecurityProfileRight { Id = Guid.NewGuid(), ProfileId = profileId, RightId = partial.Id });
            db.ProfileOperationRights!.Add(new SecurityProfileOperationRight { Id = Guid.NewGuid(), ProfileId = profileId, OperationRightId = operation.Id });
            await db.SaveChangesAsync();
        });
        var c = _f.AsIdentity(identity);
        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId, userId = employeeId }));

        var info = await Json(await c.GetAsync("/api/account/info"));
        var rights = info["rights"]!;
        Assert.False(rights["hasFullRights"]!.GetValue<bool>());
        var order = rights["entityRights"]!["LabOrderTest"]!;
        Assert.Equal("LabOrderTest", order["entityName"]!.GetValue<string>());
        Assert.Equal((int)EntityAccessLevel.Write, order["entityAccessLevel"]!.GetValue<int>());
        var sample = rights["entityRights"]!["LabSampleTest"]!;
        Assert.Equal((int)EntityAccessLevel.Partial, sample["entityAccessLevel"]!.GetValue<int>());
        Assert.Equal((int)AccessLevel.Write, sample["fieldRights"]!["StatusCode"]!.GetValue<int>());
        Assert.Equal((int)AccessLevel.Read, rights["operationRights"]!["LabVerifyTest"]!.GetValue<int>());
        Assert.NotNull(rights["rowLevelRights"]);

        var mvcJson = _f.Services.GetRequiredService<IOptions<JsonOptions>>().Value.JsonSerializerOptions;
        var probe = JsonNode.Parse(JsonSerializer.Serialize(new
        {
            level = AccessLevel.Write,
            profile = new UserFullProfileDto { Rights = new UserApplicationRights { OperationRights = { ["Op"] = AccessLevel.Write } } }
        }, mvcJson))!;
        Assert.Equal("Write", probe["level"]!.GetValue<string>());
        Assert.Equal(2, probe["profile"]!["rights"]!["operationRights"]!["Op"]!.GetValue<int>());
    }

    [Fact]
    public async Task Audit_author_is_profile_employee_even_when_employee_is_inactive()
    {
        var (identity, employeeId, profiles) = await NewStaffAsync(1);
        var c = _f.AsIdentity(identity);
        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = profiles[0], userId = employeeId }));
        await Db(async db =>
        {
            var employee = await db.Employees.FirstAsync(e => e.Id == employeeId);
            employee.RecordState = RecordStates.Deleted;
            await db.SaveChangesAsync();
        });

        var forbidden = await Problem(await c.PutAsJsonAsync("/api/v1/lab/dictionaries/order-matrix/favorites", new[] { new { name = "Набір", profileIds = Array.Empty<string>(), testIds = new[] { "GLU" } } }), HttpStatusCode.Forbidden);
        Assert.Contains(employeeId, forbidden["detail"]!.GetValue<string>());

        using var scope = _f.Services.CreateScope();
        var sp = scope.ServiceProvider;
        var http = new DefaultHttpContext { RequestServices = sp };
        http.Request.Path = "/api/v1/lab/orders";
        http.User = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim("sub", identity), new Claim(ClaimTypes.NameIdentifier, identity) }, TestAuthHandler.SchemeName));
        sp.GetRequiredService<IHttpContextAccessor>().HttpContext = http;
        var current = sp.GetRequiredService<ICurrentEmployee>();
        var db = sp.GetRequiredService<LisDbContext>();
        var person = new CmnPerson { LastName = "Аудит", Name = "Неактивний" };
        var profile = new SecurityProfile { Id = Guid.NewGuid(), Caption = "Аудит неактивного", IsActive = true };
        try
        {
            await new CurrentEmployeeMiddleware(async _ =>
            {
                db.Persons.Add(person);
                db.SecurityProfiles!.Add(profile);
                await db.SaveChangesAsync();
            }).InvokeAsync(http, current, db, sp.GetRequiredService<ITenantContext>());
        }
        finally
        {
            sp.GetRequiredService<IHttpContextAccessor>().HttpContext = null;
        }

        Assert.False(current.IsResolved);
        Assert.Equal(employeeId, current.EmployeeId);
        Assert.Equal(employeeId, db.CurrentUserId);
        await Db(async check =>
        {
            var storedPerson = await check.Persons.AsNoTracking().FirstAsync(p => p.Id == person.Id);
            Assert.Equal(employeeId, storedPerson.CreatedBy);
            Assert.Equal(employeeId, storedPerson.ModifiedBy);
            var storedProfile = await check.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Id == profile.Id);
            Assert.Equal(Guid.Parse(employeeId), storedProfile.CreatedBy);
            Assert.Equal(Guid.Parse(employeeId), storedProfile.ModifiedBy);
        });
    }

    [Fact]
    public async Task Seeded_local_admin_identity_has_single_profile_selected_by_try_authenticate()
    {
        var c = _f.AsIdentity(LisApiFactory.AdminIdentityUserId);
        var result = await Json(await c.PostAsync("/api/account/try-authenticate/", null));
        Assert.Equal(DemoDataSeeder.Admin, result["userProfileData"]!["userId"]!.GetValue<string>());
        Assert.Equal(_f.ProfileId(LabRoles.Admin).ToString(), result["userProfileData"]!["profileId"]!.GetValue<string>());
        var me = await Json(await c.GetAsync("/api/v1/lab/context/me"));
        Assert.Equal(DemoDataSeeder.Admin, me["employee"]!["id"]!.GetValue<string>());
    }

    [Fact]
    public async Task Identity_user_unknown_to_the_lab_cannot_select_profile()
    {
        var c = _f.AsIdentity("identity-user-without-person");
        var p = await Problem(await c.PostAsync("/api/account/try-authenticate/", null), HttpStatusCode.Unauthorized);
        Assert.Contains("Доступ для Вашої організації", p["detail"]!.GetValue<string>());
        var (_, employeeId, profiles) = await NewStaffAsync(1);
        await Problem(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = profiles[0], userId = employeeId }), HttpStatusCode.BadRequest);
        await Problem(await c.GetAsync("/api/v1/lab/orders"), HttpStatusCode.Forbidden);
    }

    private async Task<(string marker, string[] active, string deleted)> NewUsersForListAsync()
    {
        var marker = "Юзерлист" + Guid.NewGuid().ToString("N")[..8];
        var active = new[] { Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), Guid.NewGuid().ToString() };
        var deleted = Guid.NewGuid().ToString();
        await Db(async db =>
        {
            OrgEmployee Employee(string id, string suffix, string? departmentId, string positionTypeId, int recordState)
            {
                var person = new CmnPerson { Id = Guid.NewGuid().ToString(), LastName = marker, Name = suffix };
                person.Caption = CmnPerson.BuildCaption(person.LastName, person.Name, null);
                db.Persons.Add(person);
                return new OrgEmployee
                {
                    Id = id, PersonId = person.Id, Caption = person.Caption, TenantId = _f.TenantId,
                    DepartmentId = departmentId, PositionTypeId = positionTypeId, RecordState = recordState,
                    Membership = new IdMembership { Id = id, TenantId = _f.TenantId, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" }
                };
            }
            db.Employees.AddRange(
                Employee(active[0], "Альфа", _f.DivisionId(DemoDataSeeder.DeptCode), await db.EnumRecordIdAsync("OrgPositionType", "0002"), RecordStates.Active),
                Employee(active[1], "Бета", _f.DivisionId(DemoDataSeeder.DeptCode), await db.EnumRecordIdAsync("OrgPositionType", "0001"), RecordStates.Active),
                Employee(active[2], "Гамма", null, await db.EnumRecordIdAsync("OrgPositionType", "0002"), RecordStates.Active),
                Employee(deleted, "Видалений", _f.DivisionId(DemoDataSeeder.DeptCode), await db.EnumRecordIdAsync("OrgPositionType", "0002"), RecordStates.Deleted));
            await db.SaveChangesAsync();
        });
        return (marker, active, deleted);
    }

    private static string[] Ids(JsonNode list) => list.AsArray().Select(x => x!["id"]!.GetValue<string>()).ToArray();

    [Fact]
    public async Task Users_list_filters_pages_and_counts()
    {
        var (marker, active, deleted) = await NewUsersForListAsync();
        Assert.Equal(HttpStatusCode.Unauthorized, (await _f.CreateClient().GetAsync("/api/account/users")).StatusCode);
        var (identity, _, _) = await NewStaffAsync(1);
        await Problem(await _f.AsIdentity(identity).GetAsync("/api/account/users"), HttpStatusCode.Forbidden);

        var c = _f.As(DemoDataSeeder.Admin);
        var byCaption = $"/api/account/users?caption={Uri.EscapeDataString(marker.ToUpperInvariant())}";

        var all = await Json(await c.GetAsync(byCaption));
        Assert.Equal(active.OrderBy(x => x), Ids(all).OrderBy(x => x));
        Assert.DoesNotContain(deleted, Ids(all));

        string departmentCaption = "", organizationCaption = "", doctorsCaption = "", doctorsId = "";
        await Db(async db =>
        {
            departmentCaption = (await db.Divisions.AsNoTracking().FirstAsync(d => d.Id == _f.DivisionId(DemoDataSeeder.DeptCode))).Name;
            organizationCaption = (await db.Tenants.AsNoTracking().FirstAsync(o => o.Id == _f.TenantId)).Name;
            doctorsId = await db.EnumRecordIdAsync("OrgPositionType", "0002");
            doctorsCaption = (await db.EnumRecords.AsNoTracking().FirstAsync(r => r.Id == doctorsId)).Caption ?? "";
        });
        var alpha = all.AsArray().Single(x => x!["id"]!.GetValue<string>() == active[0])!;
        Assert.Equal(marker + " Альфа", alpha["caption"]!.GetValue<string>());
        Assert.Equal(_f.DivisionId(DemoDataSeeder.DeptCode), alpha["departmentId"]!.GetValue<string>());
        Assert.Equal(departmentCaption, alpha["departmentCaption"]!.GetValue<string>());
        Assert.Equal(_f.TenantId, alpha["organizationId"]!.GetValue<string>());
        Assert.Equal(organizationCaption, alpha["organizationCaption"]!.GetValue<string>());
        Assert.Equal(doctorsId, alpha["positionTypeId"]!.GetValue<string>());
        Assert.Equal(doctorsCaption, alpha["positionTypeCaption"]!.GetValue<string>());
        Assert.Equal(0, alpha["totalRecordCount"]!.GetValue<int>());
        var gamma = all.AsArray().Single(x => x!["id"]!.GetValue<string>() == active[2])!;
        Assert.Null(gamma["departmentId"]);
        Assert.Equal("", gamma["departmentCaption"]!.GetValue<string>());

        Assert.Equal(new[] { active[0], active[2] }.OrderBy(x => x),
            Ids(await Json(await c.GetAsync($"{byCaption}&positionTypeId={doctorsId}&unknownParam=1"))).OrderBy(x => x));
        Assert.Equal(new[] { active[0], active[1] }.OrderBy(x => x),
            Ids(await Json(await c.GetAsync($"{byCaption}&departmentId=[{_f.DivisionId(DemoDataSeeder.DeptCode)},{Guid.NewGuid()}]"))).OrderBy(x => x));
        Assert.Equal(new[] { active[1] }, Ids(await Json(await c.GetAsync($"{byCaption}&ID={active[1]}"))));

        Assert.Equal(new[] { active[2], active[1], active[0] }, Ids(await Json(await c.GetAsync($"{byCaption}&orderBy=-caption"))));
        Assert.Equal(new[] { active[1] }, Ids(await Json(await c.GetAsync($"{byCaption}&orderBy=caption&pageSize=1&pageNumber=2"))));

        var counted = (await Json(await c.GetAsync($"{byCaption}&calculateTotalRecords=true"))).AsArray();
        Assert.Single(counted);
        Assert.Equal(3, counted[0]!["totalRecordCount"]!.GetValue<int>());
        Assert.Empty((await Json(await c.GetAsync($"/api/account/users?caption={Guid.NewGuid():N}&calculateTotalRecords=true"))).AsArray());

        var badFilter = await Problem(await c.GetAsync("/api/account/users?organizationId=not-a-guid"), HttpStatusCode.BadRequest);
        Assert.Equal("Error occurred (details hidden)", badFilter["detail"]!.GetValue<string>());
        await Problem(await c.GetAsync("/api/account/users?orderBy=noSuchField"), HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task User_details_by_id()
    {
        var (marker, active, deleted) = await NewUsersForListAsync();
        Assert.Equal(HttpStatusCode.Unauthorized, (await _f.CreateClient().GetAsync($"/api/account/users/ext/{active[0]}")).StatusCode);
        var c = _f.As(DemoDataSeeder.Admin);

        var item = await Json(await c.GetAsync($"/api/account/users/ext/{active[1]}"));
        Assert.Equal(active[1], item["id"]!.GetValue<string>());
        Assert.Equal(marker + " Бета", item["caption"]!.GetValue<string>());
        string otherId = "";
        await Db(async db => otherId = await db.EnumRecordIdAsync("OrgPositionType", "0001"));
        Assert.Equal(otherId, item["positionTypeId"]!.GetValue<string>());

        foreach (var id in new[] { deleted, Guid.NewGuid().ToString(), Guid.Empty.ToString() })
        {
            var p = await Problem(await c.GetAsync($"/api/account/users/ext/{id}"), HttpStatusCode.BadRequest);
            Assert.Equal(404, p["status"]!.GetValue<int>());
            Assert.Equal(AccountController.NotFoundDetailsMessage, p["detail"]!.GetValue<string>());
        }
    }

    [Fact]
    public async Task Connector_calls_work_with_api_key_without_user_token()
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var created = await Json(await admin.PostAsJsonAsync("/api/v1/lab/connectors", new { name = "Тестовий коннектор (auth)", pollIntervalSec = 30, heartbeatIntervalSec = 30 }));
        var installKey = created["installKey"]!.GetValue<string>();

        var anon = _f.CreateClient();
        var reg = await Json(await anon.PostAsJsonAsync("/api/v1/lab/connector/register", new { installKey, hostName = "LAB-PC-AUTH", osDescription = "Windows 11", version = "4.0.0" }));
        var con = _f.CreateClient();
        con.DefaultRequestHeaders.Add("X-MedLink-ApiKey", reg["apiKey"]!.GetValue<string>());
        var config = await Json(await con.GetAsync("/api/v1/lab/connector/config"));
        Assert.Equal(reg["connectorId"]!.GetValue<string>(), config["connectorId"]!.GetValue<string>());
        await Json(await con.PostAsJsonAsync("/api/v1/lab/connector/heartbeat", new { version = "4.0.0", uptimeSec = 10, bufferedCount = 0, analyzers = Array.Empty<object>() }));
        Assert.Equal(HttpStatusCode.Accepted, (await con.PostAsJsonAsync("/api/v1/lab/connector/logs", new { entries = new[] { new { at = DateTime.UtcNow, level = "INFO", message = "auth test" } } })).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await con.GetAsync("/api/v1/lab/connector/orders/pending")).StatusCode);

        Assert.Equal(HttpStatusCode.Unauthorized, (await anon.GetAsync("/api/v1/lab/connector/config")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await admin.GetAsync("/api/v1/lab/connector/config")).StatusCode);
    }

    [Fact]
    public async Task Retention_cleanup_job_runs_without_user_context()
    {
        var job = _f.Services.GetRequiredService<RetentionCleanupService>();
        var (messages, logs) = await job.RunOnceAsync();
        Assert.True(messages >= 0 && logs >= 0);
    }
}
