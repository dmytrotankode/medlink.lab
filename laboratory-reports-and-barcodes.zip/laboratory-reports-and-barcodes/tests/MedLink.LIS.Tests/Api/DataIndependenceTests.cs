using System.Text.RegularExpressions;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Helpers;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Api.Models;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Tenancy;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

[Collection("api")]
public class DataIndependenceTests
{
    private string TenantA => _f.TenantId;
    private const string Migration0003 = "20261023153440_0003_tenancy_foundation";
    private const string Migration0004 = "20261025195202_0004_lab_data_independence";
    private readonly LisApiFactory _f;
    public DataIndependenceTests(LisApiFactory f) => _f = f;

    private static readonly string[] DocxCodes =
    {
        "orders.read", "orders.create", "orders.cancel", "orders.reopen", "labels.print", "documents.generate", "results.read", "results.enter",
        "results.verify", "results.correct", "results.reopen", "critical.acknowledge", "quarantine.resolve", "specimens.collect", "specimens.receive",
        "specimens.reject", "worklists.manage", "gateways.manage", "analyzers.manage", "catalog.manage", "catalog.import", "norms.manage",
        "patients.manage", "users.manage", "tenant.settings.manage"
    };

    private static async Task<List<string>> ReadStringsAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql, connection);
        await using var reader = await command.ExecuteReaderAsync();
        var values = new List<string>();
        while (await reader.ReadAsync()) values.Add(reader.GetValue(0).ToString()!);
        return values;
    }

    private static async Task ExecuteAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql, connection);
        await command.ExecuteNonQueryAsync();
    }

    private static async Task<List<string>> InTenantAsync(NpgsqlConnection connection, string tenantId, string sql)
    {
        await using var transaction = await connection.BeginTransactionAsync();
        await using (var set = new NpgsqlCommand("SELECT set_config('app.tenant_id', @tenant, true)", connection, transaction))
        {
            set.Parameters.AddWithValue("tenant", tenantId);
            await set.ExecuteNonQueryAsync();
        }
        var values = new List<string>();
        await using (var command = new NpgsqlCommand(sql, connection, transaction))
        await using (var reader = await command.ExecuteReaderAsync())
            while (await reader.ReadAsync()) values.Add(reader.GetValue(0).ToString()!);
        await transaction.CommitAsync();
        return values;
    }

    [Fact]
    public void Permission_catalog_maps_every_operation_to_130_docx_form_codes()
    {
        var operations = ApplicationOperations.GetDeclaredOperations().Select(o => o.OperationName).ToList();
        Assert.Equal(151, operations.Count);
        Assert.Equal(151, PermissionCatalog.CodeByOperation.Count);
        Assert.All(operations, o => Assert.True(PermissionCatalog.CodeByOperation.ContainsKey(o), o));
        var permissions = PermissionCatalog.Permissions().ToList();
        Assert.Equal(131, permissions.Count);
        Assert.Equal(131, permissions.Select(p => p.Code).Distinct().Count());
        Assert.All(permissions, p => Assert.Matches(new Regex("^[a-z_]+(\\.[a-z_]+)+$"), p.Code));
        Assert.All(permissions, p => Assert.InRange(p.Caption.Length, 1, 512));
        Assert.All(DocxCodes, c => Assert.Contains(c, permissions.Select(p => p.Code)));
    }

    [Fact]
    public void Lab_roles_keep_the_same_rights_under_the_permission_codes()
    {
        var security = RightsSeedHelper.Security;
        Assert.All(PermissionCatalog.CodeByOperation.GroupBy(kv => kv.Value), group =>
        {
            var roleSets = group.Select(kv => string.Join(",", security.OperationRoles[kv.Key].OrderBy(r => r))).Distinct().ToList();
            Assert.True(roleSets.Count == 1, $"{group.Key}: {string.Join(" / ", roleSets)}");
        });
        var rights = security.LabRoles.ToDictionary(r => r.Code, r => security.OperationsOf(r.Code).Select(o => PermissionCatalog.CodeByOperation[o]).ToHashSet());
        Assert.Equal(131, rights["LAB_ADMIN"].Count);
        Assert.Equal(94, rights["LAB_DOCTOR"].Count);
        Assert.Equal(67, rights["LAB_TECHNICIAN"].Count);
        Assert.Equal(26, rights["PHLEBOTOMIST"].Count);
        Assert.Equal(27, rights["REGISTRAR"].Count);
        Assert.Equal(15, rights["LOGISTICS_COURIER"].Count);
        Assert.Equal(360, rights.Values.Sum(r => r.Count));
        Assert.Equal(security.OperationRoles[nameof(ApplicationOperations.ResultsRead)].OrderBy(r => r), security.OperationRoles[nameof(ApplicationOperations.OrderPrintReport)].OrderBy(r => r));
    }

    [Fact]
    public async Task Seed_fills_the_permission_catalog_from_code()
    {
        _ = _f.Server;
        await using var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        var seeded = (await ReadStringsAsync(connection, "SELECT code FROM id_permission")).OrderBy(c => c, StringComparer.Ordinal).ToList();
        Assert.Equal(PermissionCatalog.Permissions().Select(p => p.Code).OrderBy(c => c, StringComparer.Ordinal), seeded);
    }

    [Fact]
    public async Task Role_links_reject_a_role_or_membership_of_another_tenant()
    {
        var tenantB = await _f.CreateTenantAsync();
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        var code = "TEST_" + Guid.NewGuid().ToString("N")[..8];
        var roleA = new IdRole { Code = code, Name = "Роль A" };
        var roleB = new IdRole { Code = code, Name = "Роль B" };
        var permission = PermissionCatalog.Permissions().First().Code;
        await db.RunAsTenantAsync(TenantA, async () => { db.LabRoles.Add(roleA); await db.SaveChangesAsync(); });
        await db.RunAsTenantAsync(tenantB.TenantId, async () => { db.LabRoles.Add(roleB); await db.SaveChangesAsync(); });
        db.ChangeTracker.Clear();

        await db.RunAsTenantAsync(tenantB.TenantId, async () =>
        {
            db.RolePermissions.Add(new IdRolePermission { RoleId = roleA.Id, PermissionCode = permission });
            await Assert.ThrowsAsync<TenantMismatchException>(() => db.SaveChangesAsync());
            db.ChangeTracker.Clear();
            db.MembershipRoles.Add(new IdMembershipRole { MembershipId = tenantB.EmployeeId, RoleId = roleA.Id });
            await Assert.ThrowsAsync<TenantMismatchException>(() => db.SaveChangesAsync());
            db.ChangeTracker.Clear();
            db.RolePermissions.Add(new IdRolePermission { RoleId = roleB.Id, PermissionCode = permission });
            db.MembershipRoles.Add(new IdMembershipRole { MembershipId = tenantB.EmployeeId, RoleId = roleB.Id });
            await db.SaveChangesAsync();
            db.ChangeTracker.Clear();
        });

        await db.RunAsTenantAsync(TenantA, async () =>
        {
            db.MembershipRoles.Add(new IdMembershipRole { MembershipId = tenantB.EmployeeId, RoleId = roleA.Id });
            await Assert.ThrowsAsync<TenantMismatchException>(() => db.SaveChangesAsync());
            db.ChangeTracker.Clear();
        });
    }

    [Fact]
    public async Task Patient_identifier_is_unique_in_a_tenant_free_across_tenants_and_hidden_outside_the_divisions()
    {
        var tenantB = await _f.CreateTenantAsync();
        var value = Guid.NewGuid().ToString("N");
        var request = new NewPatientRequest { LastName = "Ідентифікатор", FirstName = "Тест", Gender = "F", BirthDate = new DateTime(1990, 1, 1, 0, 0, 0, DateTimeKind.Utc) };
        var patientA = MedLinkPeople.NewPatient(request, TenantA);
        var patientB = MedLinkPeople.NewPatient(request, tenantB.TenantId);
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        await db.RunAsTenantAsync(TenantA, async () =>
        {
            db.Patients.Add(patientA);
            db.PatientIdentifiers.Add(new OrdPatientIdentifier { PatientId = patientA.Id, System = "test:patient", Value = value });
            db.Orders.Add(new LabOrder { OrderNumber = "ID-" + value[..10], PatientId = patientA.Id, DepartmentId = _f.DivisionId(DemoDataSeeder.DeptCode) });
            await db.SaveChangesAsync();
        });
        await db.RunAsTenantAsync(tenantB.TenantId, async () =>
        {
            db.Patients.Add(patientB);
            db.PatientIdentifiers.Add(new OrdPatientIdentifier { PatientId = patientB.Id, System = "test:patient", Value = value });
            await db.SaveChangesAsync();
        });
        db.ChangeTracker.Clear();

        await using var connection = new NpgsqlConnection(_f.AppConnectionString);
        await connection.OpenAsync();
        var duplicate = await Assert.ThrowsAsync<PostgresException>(() => InTenantAsync(connection, TenantA,
            $"INSERT INTO ord_patient_identifier (id, tenant_id, patient_id, system, value, created_on, created_by, modified_by, record_state) VALUES ('{Guid.NewGuid()}', '{TenantA}', '{patientA.Id}', 'test:patient', '{value}', now(), '{Guid.Empty}', '{Guid.Empty}', 2) RETURNING id"));
        Assert.Equal(PostgresErrorCodes.UniqueViolation, duplicate.SqlState);
        Assert.Equal(new[] { TenantA }, await InTenantAsync(connection, TenantA, $"SELECT tenant_id::text FROM ord_patient_identifier WHERE value = '{value}'"));
        Assert.Equal(new[] { tenantB.TenantId }, await InTenantAsync(connection, tenantB.TenantId, $"SELECT tenant_id::text FROM ord_patient_identifier WHERE value = '{value}'"));

        await db.RunAsTenantAsync(TenantA, async () =>
        {
            Assert.Equal(1, await db.PatientIdentifiers.AsNoTracking().CountAsync(i => i.Value == value));
            using (db.Division.RunAs(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) }))
                Assert.Equal(1, await db.PatientIdentifiers.AsNoTracking().CountAsync(i => i.Value == value));
            using (db.Division.RunAs(new[] { _f.DivisionId(DemoDataSeeder.CollectionPointCode) }))
                Assert.Equal(0, await db.PatientIdentifiers.AsNoTracking().CountAsync(i => i.Value == value));
        });
    }

    [Fact]
    public async Task Migration_0004_copies_sex_staff_attributes_and_insurance_keeps_force_and_reverts()
    {
        const string t = "0a200000-0000-4000-8000-000000000001", d1 = "0d200000-0000-4000-8000-000000000001",
            employee = "0e200000-0000-4000-8000-000000000001", person = "0f200000-0000-4000-8000-000000000001",
            female = "0b200000-0000-4000-8000-000000000001", male = "0b200000-0000-4000-8000-000000000002", other = "0b200000-0000-4000-8000-000000000003",
            payer = "0c200000-0000-4000-8000-000000000001", policy = "0c200000-0000-4000-8000-000000000002",
            e = MedLinkEnums.EmptyGuid;
        string dt = Guid.NewGuid().ToString(), pt = Guid.NewGuid().ToString(), gf = "01f0eff5-a698-4873-a45b-ad034a386d08", gm = "07b60329-7282-4262-9409-b24ea4440428";
        const string newTables = "'id_user', 'id_permission', 'id_role', 'id_role_permission', 'id_membership_role', 'ord_patient_identifier', 'ord_order_identifier', 'ord_requester', 'ord_patient_insurance'";
        const string forced = "'ord_patient', 'id_membership', 'org_employee', 'lab_employee_settings', 'mis_patient_insurance'";
        const string newTenantTables = "'id_role', 'id_role_permission', 'id_membership_role', 'ord_patient_identifier', 'ord_order_identifier', 'ord_requester', 'ord_patient_insurance'";
        var owner = TestDatabase.Create(Migration0003);
        try
        {
            await using var connection = new NpgsqlConnection(owner);
            await connection.OpenAsync();
            await ExecuteAsync(connection, $$"""
                INSERT INTO cmn_enum_record (id, caption, code, enum_type, parent_id, value_type, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{dt}}', 'Діагностичне', '02', 'DepartmentType', NULL, 0, now(), '{{e}}', NULL, '{{e}}', 2), ('{{pt}}', 'Лікарі', '0002', 'OrgPositionType', NULL, 0, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO tn_tenant (id, name, type, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{t}}', 'Лабораторія 0004', 'laboratory', now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO tn_division (id, tenant_id, code, name, type, address, phone, is_active, department_type_id, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{d1}}', '{{t}}', 'MAIN', 'Основна', 'laboratory', NULL, NULL, true, '{{dt}}', now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO cmn_person (id, last_name, name, middle_name, birthday, gender_id, ipn, no_ipn, phone, email, location, caption, description, subscribed_to_notifications, user_id, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{person}}', 'Співробітник', 'Нуль', NULL, NULL, NULL, NULL, true, NULL, NULL, NULL, 'Співробітник Нуль', NULL, false, NULL, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO id_membership (id, tenant_id, user_id, is_active, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{employee}}', '{{t}}', '{{person}}', true, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO org_employee (id, caption, person_id, tenant_id, department_id, department_section_id, position_type_id, working_start_date, has_schedule_with_partner, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{employee}}', 'Співробітник Нуль', '{{person}}', '{{t}}', '{{d1}}', NULL, '{{pt}}', NULL, false, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO lab_employee_settings (employee_id, tenant_id, lab_role, position_name, digital_signature_cert_id, is_active, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{employee}}', '{{t}}', 'LAB_DOCTOR', 'Завідувач', NULL, true, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO ord_patient (id, last_name, name, caption, gender_id, created_on, created_by, modified_on, modified_by, record_state, tenant_id) VALUES ('{{female}}', 'Ж', 'Ж', 'Ж Ж', '{{gf}}', now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}'), ('{{male}}', 'Ч', 'Ч', 'Ч Ч', '{{gm}}', now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}'), ('{{other}}', 'Н', 'Н', 'Н Н', NULL, now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                INSERT INTO lab_payer (id, code, name, kind, coverage_pct, franchise_amount, requires_policy, requires_authorization, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) VALUES ('{{payer}}', 'INS', 'Страхова', 'INSURANCE', 100, 0, true, false, true, now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                INSERT INTO mis_patient_insurance (id, patient_card_id, payer_id, policy_number, valid_from, valid_to, note, is_active, created_on, created_by, modified_on, modified_by, record_state, tenant_id) VALUES ('{{policy}}', '{{female}}', '{{payer}}', 'POL-1', NULL, NULL, NULL, true, now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                """);

            for (var round = 0; round < 2; round++)
            {
                await using (var db = TestDatabase.Context(owner)) await db.GetService<IMigrator>().MigrateAsync(Migration0004);
                Assert.Equal(new[] { $"{female}|female", $"{male}|male", $"{other}|unknown" }, await ReadStringsAsync(connection, "SELECT id || '|' || sex FROM ord_patient ORDER BY id"));
                Assert.Equal(new[] { $"{employee}|Завідувач|{d1}|True" }, await ReadStringsAsync(connection, "SELECT id || '|' || position_name || '|' || department_id || '|' || initcap(is_active::text) FROM id_membership"));
                Assert.Equal(new[] { $"{policy}|{female}|{payer}|POL-1|{t}" }, await ReadStringsAsync(connection, "SELECT id || '|' || patient_card_id || '|' || payer_id || '|' || policy_number || '|' || tenant_id FROM ord_patient_insurance"));
                Assert.Equal(new[] { "1" }, await ReadStringsAsync(connection, "SELECT count(*) FROM mis_patient_insurance"));
                Assert.Equal(new[] { "0|0" }, await ReadStringsAsync(connection, "SELECT (SELECT count(*) FROM id_user) || '|' || (SELECT count(*) FROM ord_requester)"));
                Assert.Equal(new[] { "gender_id" }, await ReadStringsAsync(connection, "SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'ord_patient' AND column_name = 'gender_id'"));
                Assert.Empty(await ReadStringsAsync(connection, $"SELECT relname FROM pg_class WHERE relkind = 'r' AND relname IN ({forced}, {newTenantTables}) AND NOT (relrowsecurity AND relforcerowsecurity)"));
                Assert.Empty(await ReadStringsAsync(connection, $"SELECT relname FROM pg_class WHERE relkind = 'r' AND relname IN ('id_user', 'id_permission') AND relrowsecurity"));

                await using (var db = TestDatabase.Context(owner)) await db.GetService<IMigrator>().MigrateAsync(Migration0003);
                Assert.Empty(await ReadStringsAsync(connection, $"SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ({newTables})"));
                Assert.Empty(await ReadStringsAsync(connection, "SELECT table_name || '.' || column_name FROM information_schema.columns WHERE table_schema = 'public' AND ((table_name = 'ord_patient' AND column_name = 'sex') OR (table_name = 'id_membership' AND column_name IN ('position_name', 'department_id')) OR (table_name = 'lab_order' AND column_name = 'requester_id'))"));
                Assert.Equal(new[] { $"{policy}|POL-1" }, await ReadStringsAsync(connection, "SELECT id || '|' || policy_number FROM mis_patient_insurance"));
                Assert.Empty(await ReadStringsAsync(connection, $"SELECT relname FROM pg_class WHERE relkind = 'r' AND relname IN ({forced}) AND NOT (relrowsecurity AND relforcerowsecurity)"));
            }
        }
        finally
        {
            TestDatabase.Drop(owner);
        }
    }
}
