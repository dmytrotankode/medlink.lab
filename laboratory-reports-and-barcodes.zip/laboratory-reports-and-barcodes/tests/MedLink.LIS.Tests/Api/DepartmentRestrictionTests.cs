using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

public class DepartmentRestrictionTests : IClassFixture<LisApiFactory>
{
    private string TenantA => _f.TenantId;
    private readonly LisApiFactory _f;
    public DepartmentRestrictionTests(LisApiFactory f) => _f = f;

    private static async Task<JsonNode> Json(HttpResponseMessage r)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode} {r.RequestMessage?.Method} {r.RequestMessage?.RequestUri}: {text}");
        return JsonNode.Parse(text)!;
    }

    private async Task<List<string>> OwnerColumnAsync(string sql)
    {
        await using var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand(sql, connection);
        await using var reader = await command.ExecuteReaderAsync();
        var values = new List<string>();
        while (await reader.ReadAsync()) values.Add(reader.GetValue(0).ToString()!);
        return values;
    }

    private async Task<(HttpClient Client, string EmployeeId)> RestrictedAsync(string[] departments, string? homeDepartment = DemoDataSeeder.DeptCode)
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var created = await Json(await admin.PostAsJsonAsync("/api/v1/lab/dictionaries/employees", new { fullName = "Обмежений Підрозділом " + Guid.NewGuid().ToString("N")[..6], labRole = LabRoles.Admin, departmentId = homeDepartment == null ? null : _f.DivisionId(homeDepartment), allowedDepartmentIds = departments }));
        var employeeId = created["id"]!.GetValue<string>();
        Assert.Equal(departments.OrderBy(d => d), created["allowedDepartmentIds"]!.AsArray().Select(d => d!.GetValue<string>()));
        var identity = "test-user-" + Guid.NewGuid().ToString("N");
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await db.RunAsTenantAsync(TenantA, async () =>
            {
                var employee = await db.Employees.FirstAsync(e => e.Id == employeeId);
                (await db.Persons.FirstAsync(p => p.Id == employee.PersonId)).UserId = identity;
                await db.SaveChangesAsync();
            });
        }
        var profileId = _f.ProfileId(LabRoles.Admin);
        return (await _f.AsAsync(new TestTenant(TenantA, _f.DivisionId(DemoDataSeeder.DeptCode), employeeId, identity, profileId)), employeeId);
    }

    private Task<List<string>> OrdersOfAsync(string department) => OwnerColumnAsync($"SELECT id FROM lab_order WHERE department_id = '{department}' ORDER BY id");

    [Fact]
    public async Task Employee_allowed_departments_are_administered_through_the_employees_api()
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var (_, employeeId) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });

        var both = await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{employeeId}", new { allowedDepartmentIds = new[] { _f.DivisionId(DemoDataSeeder.DeptCode), _f.DivisionId(DemoDataSeeder.CollectionPointCode) } }));
        Assert.Equal(new[] { _f.DivisionId(DemoDataSeeder.DeptCode), _f.DivisionId(DemoDataSeeder.CollectionPointCode) }.OrderBy(d => d), both["allowedDepartmentIds"]!.AsArray().Select(d => d!.GetValue<string>()));
        var cleared = await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{employeeId}", new { allowedDepartmentIds = Array.Empty<string>() }));
        Assert.Empty(cleared["allowedDepartmentIds"]!.AsArray());
        Assert.Empty((await Json(await admin.GetAsync($"/api/v1/lab/dictionaries/employees/{employeeId}")))["allowedDepartmentIds"]!.AsArray());

        var unknown = await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{employeeId}", new { allowedDepartmentIds = new[] { Guid.NewGuid().ToString() } });
        Assert.Equal(HttpStatusCode.BadRequest, unknown.StatusCode);
        Assert.Contains("allowedDepartmentIds", await unknown.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task Restricted_employee_cannot_grant_departments_beyond_its_own()
    {
        var (restricted, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var admin = _f.As(DemoDataSeeder.Admin);
        var (_, otherId) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });

        Assert.Equal(HttpStatusCode.BadRequest, (await restricted.PutAsJsonAsync($"/api/v1/lab/settings/users/{otherId}", new { allowedDepartmentIds = Array.Empty<string>() })).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, (await restricted.PutAsJsonAsync($"/api/v1/lab/settings/users/{otherId}", new { allowedDepartmentIds = new[] { _f.DivisionId(DemoDataSeeder.CollectionPointCode) } })).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, (await restricted.PostAsJsonAsync("/api/v1/lab/dictionaries/employees", new { fullName = "Без Обмеження", labRole = LabRoles.Technician })).StatusCode);
        Assert.Equal(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) }, (await Json(await admin.GetAsync($"/api/v1/lab/settings/users/{otherId}")))["allowedDepartmentIds"]!.AsArray().Select(d => d!.GetValue<string>()));
    }

    [Fact]
    public async Task Departments_list_shows_only_allowed_departments_and_others_return_404()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var departments = (await Json(await client.GetAsync("/api/v1/lab/dictionaries/departments")))["items"]!.AsArray().Select(d => d!["id"]!.GetValue<string>()).ToList();
        Assert.Equal(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) }, departments);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/dictionaries/departments/{_f.DivisionId(DemoDataSeeder.CollectionPointCode)}")).StatusCode);
    }

    [Fact]
    public async Task Orders_samples_and_results_of_other_departments_are_invisible_and_unchangeable()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var allowed = await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.DeptCode));
        var other = (await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.CollectionPointCode))).First();
        var otherBarcode = (await OwnerColumnAsync($"SELECT barcode FROM lab_order_sample WHERE order_id = '{other}'")).First();
        var otherTest = (await OwnerColumnAsync($"SELECT id FROM lab_order_test WHERE order_id = '{other}'")).First();

        var otherStatus = await OwnerColumnAsync($"SELECT status FROM lab_order WHERE id = '{other}'");
        var listed = (await Json(await client.GetAsync("/api/v1/lab/orders?pageSize=200")))["items"]!.AsArray().Select(o => o!["id"]!.GetValue<string>()).OrderBy(id => id).ToList();
        Assert.Equal(allowed, listed);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/orders/{other}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/samples/{otherBarcode}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/results/{otherTest}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await client.PostAsJsonAsync($"/api/v1/lab/orders/{other}/cancel", new { reason = "Чужий підрозділ" })).StatusCode);
        Assert.DoesNotContain((await Json(await client.GetAsync("/api/v1/lab/worklist?pageSize=500")))["items"]!.AsArray(), i => i!.ToJsonString().Contains(other));

        var foreignDepartment = await client.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000003", departmentId = _f.DivisionId(DemoDataSeeder.CollectionPointCode), testIds = new[] { "K" } });
        Assert.Equal(HttpStatusCode.BadRequest, foreignDepartment.StatusCode);
        Assert.Equal(otherStatus, await OwnerColumnAsync($"SELECT status FROM lab_order WHERE id = '{other}'"));
    }

    [Fact]
    public async Task Order_without_an_allowed_department_returns_404()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) }, homeDepartment: null);
        var before = await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.DeptCode));
        var response = await client.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "K" } });
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.Equal(before, await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.DeptCode)));
        var created = await Json(await client.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", departmentId = _f.DivisionId(DemoDataSeeder.DeptCode), testIds = new[] { "K" } }));
        Assert.Equal(_f.DivisionId(DemoDataSeeder.DeptCode), (await OwnerColumnAsync($"SELECT department_id FROM lab_order WHERE id = '{created["id"]!.GetValue<string>()}'")).Single());
    }

    [Fact]
    public async Task Patients_are_visible_only_through_orders_in_allowed_departments()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var visible = await OwnerColumnAsync($"SELECT DISTINCT patient_id FROM lab_order WHERE department_id = '{_f.DivisionId(DemoDataSeeder.DeptCode)}' ORDER BY 1");
        var hidden = (await OwnerColumnAsync($"SELECT patient_id FROM lab_order GROUP BY patient_id HAVING bool_and(department_id IS DISTINCT FROM '{_f.DivisionId(DemoDataSeeder.DeptCode)}') ORDER BY 1")).First();

        var listed = (await Json(await client.GetAsync("/api/v1/lab/patients?pageSize=200")))["items"]!.AsArray().Select(p => p!["id"]!.GetValue<string>()).OrderBy(id => id).ToList();
        Assert.Equal(visible, listed);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/patients/{hidden}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/patients/{hidden}/history")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync($"/api/v1/lab/portal/{hidden}/orders")).StatusCode);
    }

    [Fact]
    public async Task Statistics_count_only_allowed_departments()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var admin = _f.As(DemoDataSeeder.Admin);
        const string range = "from=2000-01-01&to=2100-01-01";

        var volume = await Json(await client.GetAsync($"/api/v1/lab/analytics/volume?groupBy=department&{range}"));
        Assert.Equal(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) }, volume["rows"]!.AsArray().Select(r => r!["key"]!.GetValue<string>()));
        var allowedOrders = (await OwnerColumnAsync($"SELECT id FROM lab_order WHERE department_id = '{_f.DivisionId(DemoDataSeeder.DeptCode)}' AND status <> 'CANCELLED'")).Count;
        Assert.Equal(allowedOrders, volume["totalOrders"]!.GetValue<int>());
        Assert.True((await Json(await admin.GetAsync($"/api/v1/lab/analytics/volume?groupBy=department&{range}")))["totalOrders"]!.GetValue<int>() > allowedOrders);
        Assert.Equal(allowedOrders, (await Json(await client.GetAsync($"/api/v1/lab/analytics/tat?{range}")))["orders"]!.GetValue<int>());
    }

    [Fact]
    public async Task Deletes_by_a_restricted_employee_never_cascade_into_data_of_other_departments()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var admin = _f.As(DemoDataSeeder.Admin);
        var other = (await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.CollectionPointCode))).First();
        var otherSample = (await OwnerColumnAsync($"SELECT id FROM lab_order_sample WHERE order_id = '{other}' ORDER BY id")).First();
        var code = "ZZ_DEP_" + Guid.NewGuid().ToString("N")[..6].ToUpperInvariant();
        var testId = (await Json(await admin.PostAsJsonAsync("/api/v1/lab/dictionaries/tests", new { code, name = "Тест іншого підрозділу", unit = "од", biomaterialTypeId = 4, tubeTypeId = 7, category = "BIOCHEM" })))["id"]!.GetValue<string>();
        var rackId = (await Json(await admin.PostAsJsonAsync("/api/v1/lab/biobank/racks", new { code = "R-" + code, name = "Штатив іншого підрозділу", temperatureCelsius = -20, rowsCount = 2, colsCount = 2, isActive = true })))["id"]!.GetValue<string>();
        var orderTestId = Guid.NewGuid().ToString();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await db.RunAsTenantAsync(TenantA, async () =>
            {
                var sample = await db.Samples.FirstAsync(s => s.Id == otherSample);
                db.OrderTests.Add(new LabOrderTest { Id = orderTestId, OrderId = other, TestId = testId, TestCode = code, TestName = "Тест іншого підрозділу" });
                db.Cells.Add(new LabArchiveCell { RackId = rackId, RowNum = 2, ColNum = 2, SampleId = sample.Id, Barcode = sample.Barcode, StoredAt = DateTime.UtcNow });
                await db.SaveChangesAsync();
            });
        }

        var deleted = await Json(await client.DeleteAsync($"/api/v1/lab/dictionaries/tests/{testId}"));
        Assert.False(deleted["deleted"]!.GetValue<bool>());
        Assert.Equal(new[] { orderTestId }, await OwnerColumnAsync($"SELECT id FROM lab_order_test WHERE test_id = '{testId}'"));
        Assert.Equal(HttpStatusCode.Conflict, (await client.PutAsJsonAsync($"/api/v1/lab/biobank/racks/{rackId}", new { code = "R-" + code, name = "Штатив", temperatureCelsius = -20, rowsCount = 1, colsCount = 1, isActive = true })).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, (await client.DeleteAsync($"/api/v1/lab/biobank/racks/{rackId}")).StatusCode);
        Assert.Equal(new[] { otherSample }, await OwnerColumnAsync($"SELECT sample_id FROM lab_archive_cell WHERE rack_id = '{rackId}'"));
    }

    [Fact]
    public async Task Tenant_wide_checks_of_a_restricted_employee_see_data_of_other_departments()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var other = (await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.CollectionPointCode))).First();
        var referral = (await OwnerColumnAsync("SELECT r.reg_number FROM ehe_incoming_medical_referral r WHERE NOT EXISTS (SELECT 1 FROM lab_order o WHERE o.ehealth_referral_id = r.id) AND r.expiration_date > now() ORDER BY r.id")).First();
        var code = "ZZ_DEP_" + Guid.NewGuid().ToString("N")[..6].ToUpperInvariant();
        var section = new LabSection { Code = code, Name = "Секція іншого підрозділу", DepartmentId = _f.DivisionId(DemoDataSeeder.CollectionPointCode) };
        var analyzer = new LabAnalyzer { Code = code, Name = "Аналізатор іншого підрозділу", DepartmentId = _f.DivisionId(DemoDataSeeder.CollectionPointCode) };
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await db.RunAsTenantAsync(TenantA, async () =>
            {
                analyzer.AnalyzerTypeId = await db.AnalyzerTypes.Select(t => t.Id).FirstAsync();
                var test = await db.Tests.FirstAsync();
                var orderTest = new LabOrderTest { OrderId = other, TestId = test.Id, TestCode = test.Code, TestName = test.Name };
                db.Sections.Add(section);
                db.Analyzers.Add(analyzer);
                db.OrderTests.Add(orderTest);
                db.Results.Add(new LabTestResult { OrderTestId = orderTest.Id, NumericValue = 1, AnalyzerId = analyzer.Id });
                db.JournalEntries.Add(new LabSectionJournalEntry { LabSectionId = section.Id, OrderId = other, JournalNumber = code, PeriodKey = "2026" });
                var order = await db.Orders.FirstAsync(o => o.Id == other);
                order.EhealthReferralId = (await db.Referrals.FirstAsync(r => r.RegNumber == referral)).Id;
                await db.SaveChangesAsync();
            });
        }

        var sectionDelete = await Json(await client.DeleteAsync($"/api/v1/lab/sections/{section.Id}"));
        Assert.False(sectionDelete["deleted"]!.GetValue<bool>());
        Assert.Single(await OwnerColumnAsync($"SELECT id FROM lab_section_journal_entry WHERE lab_section_id = '{section.Id}'"));
        Assert.Equal(HttpStatusCode.NoContent, (await client.DeleteAsync($"/api/v1/lab/analyzers/{analyzer.Id}")).StatusCode);
        Assert.Equal(new[] { "4" }, await OwnerColumnAsync($"SELECT record_state::text FROM lab_analyzer WHERE id = '{analyzer.Id}'"));
        var lookup = await Json(await client.GetAsync($"/api/v1/lab/referrals/ehealth/lookup?number={referral}"));
        Assert.False(lookup["canUse"]!.GetValue<bool>());
    }

    [Fact]
    public async Task Documents_and_prints_of_other_departments_return_404()
    {
        var (client, _) = await RestrictedAsync(new[] { _f.DivisionId(DemoDataSeeder.DeptCode) });
        var allowed = (await OwnerColumnAsync($"SELECT id FROM lab_order WHERE department_id = '{_f.DivisionId(DemoDataSeeder.DeptCode)}' AND status = 'RELEASED' ORDER BY id")).First();
        var other = (await OrdersOfAsync(_f.DivisionId(DemoDataSeeder.CollectionPointCode))).First();
        var otherBarcode = (await OwnerColumnAsync($"SELECT barcode FROM lab_order_sample WHERE order_id = '{other}'")).First();

        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync($"/api/v1/lab/orders/{allowed}/report")).StatusCode);
        foreach (var url in new[] { $"orders/{other}/report", $"orders/{other}/report.pdf", $"orders/{other}/labels", $"orders/{other}/receipt", $"samples/{otherBarcode}/label" })
            Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync("/api/v1/lab/" + url)).StatusCode);
        var attachments = await client.GetAsync($"/api/v1/lab/orders/{other}/attachments");
        Assert.True(attachments.StatusCode == HttpStatusCode.NotFound || (await attachments.Content.ReadAsStringAsync()) == "[]");
    }
}
