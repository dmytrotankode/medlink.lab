using System.Net;
using System.Net.Http.Headers;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using AspNet.Security.OAuth.Introspection;
using Core.Services.DistributedCacheService;
using Core.ThirdParty.Redis;
using MedLink.LIS.Api.Configuration;
using MedLink.LIS.Api.Data.Seed;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using StackExchange.Redis;

namespace MedLink.LIS.Tests.Api;

public class RealAuthLisApiFactory : WebApplicationFactory<Program>
{
    private readonly string _connectionString = TestDatabase.Create();
    public IDatabase RedisDb { get; }
    public FakeRedisDatabase Redis { get; }
    public FakeIdentityServerHandler IdentityServer { get; } = new();
    protected virtual bool UseRedis => true;
    protected virtual bool UseRefreshTokenFlow => true;

    public RealAuthLisApiFactory() => (RedisDb, Redis) = FakeRedisDatabase.Create();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("Identity:IntrospectionClientSecret", "test-only-secret");
        builder.UseSetting("Identity:UseRedisActiveTokenValidation", UseRedis ? "true" : "false");
        builder.UseSetting("Identity:UseRefreshTokenFlow", UseRefreshTokenFlow ? "true" : "false");
        builder.UseSetting("Identity:RedisActiveTokenFallbackToIntrospection", "false");
        builder.ConfigureAppConfiguration((_, cfg) => cfg.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["ConnectionStrings:DefaultConnection"] = TestDatabase.App(_connectionString) + ";Options=-c app.tenant_id=00000000-0000-4000-8000-00000000b001",
            ["Lab:SeedDemoData"] = "false",
            ["Logging:LogLevel:Default"] = "Warning"
        }));
        builder.ConfigureTestServices(services =>
        {
            services.AddSingleton<IRedisDatabaseProvider>(new FakeRedisDatabaseProvider(RedisDb));
            services.AddSingleton<InMemoryDistributedCacheService>();
            services.AddSingleton<IDistributedCacheService>(sp => sp.GetRequiredService<InMemoryDistributedCacheService>());
            services.Configure<OAuthIntrospectionOptions>(AuthenticationExtensions.IntrospectionScheme, o => o.HttpClient = new HttpClient(IdentityServer));
            services.Configure<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme, o => o.BackchannelHttpHandler = IdentityServer);
        });
    }

    public void IssueReferenceToken(string token, string sub, bool active = true)
    {
        var hash = ActiveTokenHashHelper.Compute(token)!;
        Redis.Values[SessionControlOptions.DefaultTokenByHashKeyPrefix + hash] = sub;
        Redis.Values[SessionControlOptions.DefaultActiveTokenKeyPrefix + sub] = active ? hash : "another-session-hash";
    }

    public HttpClient WithToken(string token)
    {
        var c = CreateClient();
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return c;
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        TestDatabase.Drop(_connectionString);
    }
}

public sealed class IntrospectionOnlyLisApiFactory : RealAuthLisApiFactory
{
    protected override bool UseRedis => false;
}

public sealed class JwtOnlyLisApiFactory : RealAuthLisApiFactory
{
    protected override bool UseRefreshTokenFlow => false;
}

public sealed class FakeIdentityServerHandler : HttpMessageHandler
{
    public const string Authority = "http://localhost:5001";
    public Dictionary<string, string> ActiveTokens { get; } = new();
    public int IntrospectionCalls { get; private set; }
    public string? LastAuthorization { get; private set; }
    public RSA SigningKey { get; } = RSA.Create(2048);

    public string IssueJwt(string sub, string audience = "MisApiScope")
    {
        var credentials = new SigningCredentials(new RsaSecurityKey(SigningKey) { KeyId = "test-key" }, SecurityAlgorithms.RsaSha256);
        var now = DateTime.UtcNow;
        return new JwtSecurityTokenHandler().CreateEncodedJwt(Authority, audience, new ClaimsIdentity(new[] { new Claim("sub", sub) }), now.AddMinutes(-1), now.AddHours(1), now.AddMinutes(-1), credentials);
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var path = request.RequestUri!.AbsolutePath;
        if (path.EndsWith("/.well-known/openid-configuration"))
            return JsonResponse($$"""{"issuer":"{{Authority}}","introspection_endpoint":"{{Authority}}/connect/introspect","jwks_uri":"{{Authority}}/.well-known/openid-configuration/jwks"}""");
        if (path.EndsWith("/.well-known/openid-configuration/jwks"))
        {
            var p = SigningKey.ExportParameters(false);
            return JsonResponse($$"""{"keys":[{"kty":"RSA","use":"sig","alg":"RS256","kid":"test-key","n":"{{Base64UrlEncoder.Encode(p.Modulus)}}","e":"{{Base64UrlEncoder.Encode(p.Exponent)}}"}]}""");
        }
        if (path.EndsWith("/connect/introspect"))
        {
            IntrospectionCalls++;
            LastAuthorization = request.Headers.Authorization?.ToString();
            var form = await request.Content!.ReadAsStringAsync(cancellationToken);
            var token = Uri.UnescapeDataString(form.Split('&').Select(p => p.Split('=')).First(p => p[0] == "token")[1]);
            return ActiveTokens.TryGetValue(token, out var sub)
                ? JsonResponse($$"""{"active":true,"sub":"{{sub}}","iss":"{{Authority}}","client_id":"MisFront","scope":"MisApiScope openid","current_session_id":"session-1","exp":{{DateTimeOffset.UtcNow.AddHours(1).ToUnixTimeSeconds()}}}""")
                : JsonResponse("""{"active":false}""");
        }
        return new HttpResponseMessage(HttpStatusCode.NotFound);
    }

    private static HttpResponseMessage JsonResponse(string json) => new(HttpStatusCode.OK) { Content = new StringContent(json, Encoding.UTF8, "application/json") };
}

public class RedisActiveTokenTests : IClassFixture<RealAuthLisApiFactory>
{
    private readonly RealAuthLisApiFactory _f;
    public RedisActiveTokenTests(RealAuthLisApiFactory f) => _f = f;

    [Fact]
    public async Task Active_reference_token_from_redis_authenticates_and_selects_profile()
    {
        _f.IssueReferenceToken("opaque-reference-token-1", LisApiFactory.AdminIdentityUserId);
        var c = _f.WithToken("opaque-reference-token-1");
        var r = await c.PostAsync("/api/account/try-authenticate/", null);
        Assert.True(r.IsSuccessStatusCode, await r.Content.ReadAsStringAsync());
        var me = JsonNode.Parse(await (await c.GetAsync("/api/v1/lab/context/me")).Content.ReadAsStringAsync())!;
        Assert.Equal(DemoDataSeeder.Admin, me["employee"]!["id"]!.GetValue<string>());
        Assert.Equal(0, _f.IdentityServer.IntrospectionCalls);
    }

    [Fact]
    public async Task Replaced_or_unknown_reference_token_is_rejected()
    {
        _f.IssueReferenceToken("opaque-old-session-token", "user-with-new-session", active: false);
        var inactive = _f.WithToken("opaque-old-session-token");
        Assert.Equal(HttpStatusCode.Unauthorized, (await inactive.GetAsync("/api/v1/lab/orders")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await inactive.GetAsync("/api/account/userProfiles")).StatusCode);

        var unknown = _f.WithToken("opaque-never-issued");
        Assert.Equal(HttpStatusCode.Unauthorized, (await unknown.GetAsync("/api/v1/lab/orders")).StatusCode);
    }
}

public class IntrospectionTests : IClassFixture<IntrospectionOnlyLisApiFactory>
{
    private readonly IntrospectionOnlyLisApiFactory _f;
    public IntrospectionTests(IntrospectionOnlyLisApiFactory f) => _f = f;

    [Fact]
    public async Task Reference_token_is_validated_by_identity_server_introspection()
    {
        _f.IdentityServer.ActiveTokens["introspected-token-1"] = LisApiFactory.AdminIdentityUserId;
        var c = _f.WithToken("introspected-token-1");
        Guid adminProfileId;
        using (var scope = _f.Services.CreateScope())
            adminProfileId = scope.ServiceProvider.GetRequiredService<MedLink.LIS.Api.Data.LisDbContext>().SecurityProfiles!.Single(p => p.Caption == RightsSeedHelper.Security.ForRole(MedLink.LIS.Api.Domain.LabRoles.Admin)!.Caption).Id;
        var r = await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = adminProfileId, userId = DemoDataSeeder.Admin });
        Assert.True(r.IsSuccessStatusCode, await r.Content.ReadAsStringAsync());
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/lab/orders")).StatusCode);
        Assert.True(_f.IdentityServer.IntrospectionCalls >= 2);
        Assert.StartsWith("Basic ", _f.IdentityServer.LastAuthorization);

        var rejected = _f.WithToken("introspected-unknown");
        var denied = await rejected.GetAsync("/api/account/userProfiles");
        Assert.Equal(HttpStatusCode.Unauthorized, denied.StatusCode);
        Assert.Equal("IdentityServer", denied.Headers.GetValues(AuthenticationExtensions.IdentityChallengeHeader).Single());
    }
}

public class JwtBearerTests : IClassFixture<JwtOnlyLisApiFactory>
{
    private readonly JwtOnlyLisApiFactory _f;
    public JwtBearerTests(JwtOnlyLisApiFactory f) => _f = f;

    [Fact]
    public async Task Signed_jwt_access_token_is_accepted_and_wrong_audience_is_rejected()
    {
        var c = _f.WithToken(_f.IdentityServer.IssueJwt(LisApiFactory.AdminIdentityUserId));
        var r = await c.PostAsync("/api/account/try-authenticate/", null);
        Assert.True(r.IsSuccessStatusCode, await r.Content.ReadAsStringAsync());
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/lab/orders")).StatusCode);

        var foreign = _f.WithToken(_f.IdentityServer.IssueJwt(LisApiFactory.AdminIdentityUserId, audience: "SomeOtherApi"));
        var denied = await foreign.GetAsync("/api/account/userProfiles");
        Assert.Equal(HttpStatusCode.Unauthorized, denied.StatusCode);
        Assert.Equal("IdentityServer", denied.Headers.GetValues(AuthenticationExtensions.IdentityChallengeHeader).Single());
    }
}
