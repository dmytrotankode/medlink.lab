using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using ClosedXML.Excel;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Helpers;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Filters;
using MedLink.LIS.Api.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SecurityProfile = Core.Security.Models.Profile;
using SecurityProfileRole = Core.Security.Models.ProfileRole;
using SecurityUserProfile = Core.Security.Models.UserProfile;

namespace MedLink.LIS.Tests.Api;

[Collection("api")]
public class OperationRightsTests
{
    private readonly LisApiFactory _f;
    public OperationRightsTests(LisApiFactory f) => _f = f;

    private static async Task<JsonNode> Json(HttpResponseMessage r)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode} {r.RequestMessage?.Method} {r.RequestMessage?.RequestUri}: {text}");
        return JsonNode.Parse(text)!;
    }

    private static async Task<JsonNode> Denied(HttpResponseMessage r, string profileCaption, string operationName)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.StatusCode == HttpStatusCode.Forbidden, $"Очікувано 403, отримано {(int)r.StatusCode}: {text}");
        var node = JsonNode.Parse(text)!;
        Assert.Equal(ApiAuthorizationFilter.OperationDeniedTitle, node["title"]!.GetValue<string>());
        Assert.Equal(403, node["status"]!.GetValue<int>());
        Assert.Equal(ApiAuthorizationFilter.OperationDeniedDetail(operationName, profileCaption), node["detail"]!.GetValue<string>());
        return node;
    }

    private async Task<(HttpClient client, string employeeId, string caption)> StaffWithRoleAsync(params string[] roles)
    {
        var identity = "test-user-" + Guid.NewGuid().ToString("N");
        var employeeId = Guid.NewGuid().ToString();
        var caption = "Права " + Guid.NewGuid().ToString("N")[..6];
        var profileId = Guid.NewGuid();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
            var template = await db.Employees.AsNoTracking().FirstAsync(e => e.Id == DemoDataSeeder.Registrar);
            var person = new MedLink.LIS.Api.Data.Entities.CmnPerson { Id = Guid.NewGuid().ToString(), LastName = "Права", Name = "Тест", UserId = identity };
            db.Persons.Add(person);
            db.Employees.Add(new MedLink.LIS.Api.Data.Entities.OrgEmployee
            {
                Id = employeeId, PersonId = person.Id, Caption = "Права Тест", TenantId = template.TenantId, DepartmentId = template.DepartmentId, PositionTypeId = template.PositionTypeId,
                Membership = new MedLink.LIS.Api.Data.Entities.IdMembership { Id = employeeId, TenantId = template.TenantId, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" }
            });
            db.SecurityProfiles!.Add(new SecurityProfile { Id = profileId, Caption = caption, IsActive = true });
            db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(employeeId), ProfileId = profileId });
            foreach (var role in roles)
                db.ProfileRoles!.Add(new SecurityProfileRole { Id = Guid.NewGuid(), ProfileId = profileId, RoleId = _f.RoleId(role) });
            await db.SaveChangesAsync();
        }
        var c = _f.AsIdentity(identity);
        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId, userId = employeeId }));
        return (c, employeeId, caption);
    }

    [Fact]
    public void Security_seed_covers_every_declared_operation_with_unique_captions()
    {
        var operations = ApplicationOperations.GetDeclaredOperations().ToList();
        var declared = operations.Select(o => o.OperationName).OrderBy(x => x).ToList();
        var seed = RightsSeedHelper.Security;
        Assert.Equal(operations.Count, operations.Select(o => o.OperationName).Distinct().Count());
        Assert.Equal(operations.Count, operations.Select(o => o.OperationCaption).Distinct().Count());
        Assert.Equal(declared, seed.OperationRoles.Keys.OrderBy(x => x));
        Assert.Equal(declared, seed.OperationsOf(LabRoles.Admin).OrderBy(x => x));
        Assert.All(seed.OperationRoles.Values, roles => Assert.Equal(roles.Length, roles.Distinct().Count()));
        Assert.All(seed.OperationRoles.Values.SelectMany(r => r), r => Assert.Contains(r, LabRoles.All));
        Assert.Equal(LabRoles.All, seed.LabRoles.Select(r => r.Code));
        var ruleOperations = new[] { LisEntities.Order, LisEntities.Sample, LisEntities.OrderTest, LisEntities.Manifest, LisEntities.Culture, LisEntities.Connector }
            .SelectMany(LisStateMachine.RulesFor).Select(r => r.Operation).ToList();
        Assert.Equal(ruleOperations.Count, ruleOperations.Distinct().Count());
        Assert.All(ruleOperations, op => Assert.Contains(operations, o => o.OperationName == op));
    }

    [Fact]
    public async Task Profile_without_operation_right_is_denied_by_filter_on_attributed_action()
    {
        var (none, _, caption) = await StaffWithRoleAsync();
        await Denied(await none.GetAsync("/api/v1/lab/orders"), caption, nameof(ApplicationOperations.OrdersRead));
        await Denied(await none.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }), caption, nameof(ApplicationOperations.OrderCreate));

        var (courier, _, courierCaption) = await StaffWithRoleAsync(LabRoles.Courier);
        await Json(await courier.GetAsync("/api/v1/lab/orders"));
        var orders = await Json(await _f.As(DemoDataSeeder.Admin).GetAsync("/api/v1/lab/orders?pageSize=1"));
        var orderId = orders["items"]![0]!["id"]!.GetValue<string>();
        await Json(await courier.GetAsync($"/api/v1/lab/orders/{orderId}"));
        await Denied(await courier.GetAsync($"/api/v1/lab/orders/{orderId}/report"), courierCaption, nameof(ApplicationOperations.ResultsRead));
        await Denied(await courier.GetAsync("/api/v1/lab/worklist?pageSize=1"), courierCaption, nameof(ApplicationOperations.ResultsRead));
    }

    [Fact]
    public async Task Profile_with_operation_right_passes_attributed_action()
    {
        var (registrar, _, _) = await StaffWithRoleAsync(LabRoles.Registrar);
        var order = await Json(await registrar.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var orderId = order["id"]!.GetValue<string>();
        await Json(await registrar.GetAsync($"/api/v1/lab/orders/{orderId}"));
        var worklist = await Json(await _f.As(DemoDataSeeder.Technician).GetAsync("/api/v1/lab/worklist?pageSize=1"));
        Assert.True(worklist["total"]!.GetValue<int>() > 0);
    }

    [Fact]
    public async Task In_service_check_denies_operation_with_same_problem_shape()
    {
        var (registrar, _, caption) = await StaffWithRoleAsync(LabRoles.Registrar);
        await Json(await registrar.PutAsJsonAsync("/api/v1/lab/dictionaries/order-matrix/favorites", new[] { new { name = "Свій набір", profileIds = Array.Empty<string>(), testIds = new[] { "GLU" } } }));
        await Denied(await registrar.PutAsJsonAsync($"/api/v1/lab/dictionaries/order-matrix/favorites?employeeId={DemoDataSeeder.Doctor}", new[] { new { name = "Чужий набір", profileIds = Array.Empty<string>(), testIds = new[] { "GLU" } } }),
            caption, nameof(ApplicationOperations.FavoritesEditOther));

        var order = await Json(await registrar.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var barcode = order["samples"]![0]!["barcode"]!.GetValue<string>();
        await Denied(await registrar.PostAsJsonAsync($"/api/v1/lab/samples/{barcode}/collect", new { }), caption, nameof(ApplicationOperations.SampleCollect));
        var conflict = await registrar.PostAsJsonAsync($"/api/v1/lab/samples/{barcode}/receive", new { });
        Assert.Equal(HttpStatusCode.Conflict, conflict.StatusCode);
    }

    [Fact]
    public async Task Allowed_actions_follow_profile_rights()
    {
        var (registrar, _, _) = await StaffWithRoleAsync(LabRoles.Registrar);
        var order = await Json(await registrar.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var orderId = order["id"]!.GetValue<string>();
        static List<string> Actions(JsonNode t) => t["allowedActions"]!.AsArray().Select(a => a!["action"]!.GetValue<string>()).OrderBy(x => x).ToList();

        var forRegistrar = Actions(await Json(await registrar.GetAsync($"/api/v1/lab/orders/{orderId}/transitions")));
        var expectedRegistrar = LisStateMachine.OrderRules.Where(r => r.FromStatuses.Contains("NEW") && RightsSeedHelper.Security.Allows(LabRoles.Registrar, r.Operation)).Select(r => r.Action).OrderBy(x => x).ToList();
        Assert.Equal(expectedRegistrar, forRegistrar);
        Assert.DoesNotContain(OrderActions.Collect, forRegistrar);

        var forNurse = Actions(await Json(await _f.As(DemoDataSeeder.Nurse).GetAsync($"/api/v1/lab/orders/{orderId}/transitions")));
        Assert.Contains(OrderActions.Collect, forNurse);
        Assert.DoesNotContain(OrderActions.Cancel, forNurse);

        var forAdmin = Actions(await Json(await _f.As(DemoDataSeeder.Admin).GetAsync($"/api/v1/lab/orders/{orderId}/transitions")));
        Assert.Equal(LisStateMachine.OrderRules.Where(r => r.FromStatuses.Contains("NEW")).Select(r => r.Action).OrderBy(x => x).ToList(), forAdmin);
    }

    [Fact]
    public async Task Lab_admin_rights_pass_attributed_and_in_service_checks()
    {
        var (admin, _, _) = await StaffWithRoleAsync(LabRoles.Admin);
        await Json(await admin.GetAsync("/api/v1/lab/orders"));
        var order = await Json(await admin.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var barcode = order["samples"]![0]!["barcode"]!.GetValue<string>();
        await Json(await admin.PostAsJsonAsync($"/api/v1/lab/samples/{barcode}/collect", new { }));
        await Json(await admin.PutAsJsonAsync($"/api/v1/lab/dictionaries/order-matrix/favorites?employeeId={DemoDataSeeder.Doctor}", new[] { new { name = "Набір лікаря", profileIds = Array.Empty<string>(), testIds = new[] { "GLU" } } }));
        await Json(await admin.GetAsync("/api/v1/lab/worklist?pageSize=1"));
    }

    [Fact]
    public async Task Phlebotomist_enters_results_like_technician()
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var nurse = _f.As(DemoDataSeeder.Nurse);
        var order = await Json(await nurse.PostAsJsonAsync("/api/v1/lab/orders", new { patientId = "0b000000-0000-0000-0000-000000000001", testIds = new[] { "GLU" } }));
        var barcode = order["samples"]![0]!["barcode"]!.GetValue<string>();
        await Json(await nurse.PostAsJsonAsync($"/api/v1/lab/samples/{barcode}/collect", new { }));
        await Json(await admin.PostAsJsonAsync($"/api/v1/lab/samples/{barcode}/receive", new { }));
        var detail = await Json(await nurse.GetAsync($"/api/v1/lab/orders/{order["id"]}"));
        var testId = detail["tests"]![0]!["id"]!.GetValue<string>();
        var row = await Json(await nurse.PutAsJsonAsync($"/api/v1/lab/results/{testId}", new { numericValue = 5.1 }));
        Assert.NotNull(row["status"]);
        await Json(await nurse.GetAsync($"/api/v1/lab/results/{testId}"));
    }

    private static string CaptionOf(string labRole) => RightsSeedHelper.Security.ForRole(labRole)!.Caption;

    private async Task<string> OrderWithResultsAsync()
    {
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
        return await db.OrderTests.AsNoTracking().Where(t => t.Result != null && t.Result.Flag != "NONE").Select(t => t.OrderId).FirstAsync();
    }

    private static List<JsonNode?> TestsOf(JsonNode order) => order["tests"]!.AsArray().ToList();

    [Fact]
    public async Task Courier_gets_the_order_card_without_result_values()
    {
        var orderId = await OrderWithResultsAsync();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
            var marked = await db.OrderTests.FirstAsync(t => t.OrderId == orderId);
            marked.RejectReason = "K 9.8 — неправдоподібно";
            marked.IsReflex = true;
            await db.SaveChangesAsync();
        }
        var courier = _f.As(DemoDataSeeder.Courier);
        var card = await Json(await courier.GetAsync($"/api/v1/lab/orders/{orderId}"));
        Assert.NotEmpty(TestsOf(card));
        Assert.All(TestsOf(card), t => Assert.Null(t!["result"]));
        Assert.All(TestsOf(card), t => Assert.Null(t!["rejectReason"]));
        Assert.All(TestsOf(card), t => Assert.False(t!["isReflex"]!.GetValue<bool>()));
        Assert.All(TestsOf(card), t => Assert.Null(t!["reflexFromTestId"]));
        var barcode = card["samples"]![0]!["barcode"]!.GetValue<string>();
        var byBarcode = await Json(await courier.GetAsync($"/api/v1/lab/orders/by-barcode/{barcode}"));
        Assert.All(TestsOf(byBarcode), t => Assert.Null(t!["result"]));
        var list = await Json(await courier.GetAsync("/api/v1/lab/orders?pageSize=200"));
        Assert.All(list["items"]!.AsArray(), o => Assert.False(o!["hasCritical"]!.GetValue<bool>()));
        var summary = await Json(await courier.GetAsync("/api/v1/lab/worklist/summary"));
        Assert.Null(summary["panic"]);

        var technician = _f.As(DemoDataSeeder.Technician);
        var full = await Json(await technician.GetAsync($"/api/v1/lab/orders/{orderId}"));
        Assert.Contains(TestsOf(full), t => t!["result"] != null && t["result"]!["displayValue"]!.GetValue<string>() != "");
        Assert.Contains(TestsOf(full), t => t!["rejectReason"]?.GetValue<string>() == "K 9.8 — неправдоподібно" && t["isReflex"]!.GetValue<bool>());
        var fullList = await Json(await technician.GetAsync("/api/v1/lab/orders?pageSize=200"));
        Assert.Contains(fullList["items"]!.AsArray(), o => o!["hasCritical"]!.GetValue<bool>());
        Assert.NotNull((await Json(await technician.GetAsync("/api/v1/lab/worklist/summary")))["panic"]);
    }

    [Fact]
    public async Task Courier_is_denied_result_reads_that_a_technician_passes()
    {
        var orderId = await OrderWithResultsAsync();
        var admin = _f.As(DemoDataSeeder.Admin);
        string attachmentId;
        using (var form = new MultipartFormDataContent { { new ByteArrayContent(Encoding.UTF8.GetBytes("%PDF-1.4 бланк")), "file", "external.pdf" } })
            attachmentId = (await Json(await admin.PostAsync($"/api/v1/lab/orders/{orderId}/attachments", form)))["id"]!.GetValue<string>();

        var courier = _f.As(DemoDataSeeder.Courier);
        var caption = CaptionOf(LabRoles.Courier);
        const string results = nameof(ApplicationOperations.ResultsRead);
        await Denied(await courier.GetAsync($"/api/v1/lab/orders/{orderId}/report"), caption, results);
        await Denied(await courier.GetAsync($"/api/v1/lab/orders/{orderId}/report.pdf"), caption, results);
        await Denied(await courier.GetAsync($"/api/v1/lab/attachments/{attachmentId}/content"), caption, results);
        await Denied(await courier.GetAsync($"/api/v1/lab/orders/{orderId}/attachments"), caption, results);
        await Denied(await courier.GetAsync("/api/v1/lab/panic-calls"), caption, results);
        await Denied(await courier.GetAsync("/api/v1/lab/panic/pending"), caption, results);
        await Denied(await courier.GetAsync("/api/v1/lab/results/unmatched"), caption, results);
        await Denied(await courier.GetAsync("/api/v1/lab/microbiology/cultures"), caption, results);

        var technician = _f.As(DemoDataSeeder.Technician);
        Assert.True((await technician.GetAsync($"/api/v1/lab/orders/{orderId}/report")).IsSuccessStatusCode);
        Assert.True((await technician.GetAsync($"/api/v1/lab/attachments/{attachmentId}/content")).IsSuccessStatusCode);
        Assert.Contains((await Json(await technician.GetAsync($"/api/v1/lab/orders/{orderId}/attachments"))).AsArray(), a => a!["id"]!.GetValue<string>() == attachmentId);
        Assert.NotEmpty((await Json(await technician.GetAsync("/api/v1/lab/panic-calls"))).AsArray());
        await Json(await technician.GetAsync("/api/v1/lab/panic/pending"));
    }

    [Fact]
    public async Task Doctor_saves_only_employees_of_lower_rank_than_his_own_role()
    {
        var doctor = _f.As(DemoDataSeeder.Doctor);
        var rankDenied = OrgDictionaryService.RankDeniedDetail(LabRoles.Doctor);
        async Task AssertRankDenied(HttpResponseMessage r)
        {
            var text = await r.Content.ReadAsStringAsync();
            Assert.True(r.StatusCode == HttpStatusCode.Forbidden, $"Очікувано 403, отримано {(int)r.StatusCode}: {text}");
            var node = JsonNode.Parse(text)!;
            Assert.Equal(ApiAuthorizationFilter.OperationDeniedTitle, node["title"]!.GetValue<string>());
            Assert.Equal(rankDenied, node["detail"]!.GetValue<string>());
        }

        var created = await Json(await doctor.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Нижчий Лаборант Тест", labRole = LabRoles.Technician, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        var technicianId = created["id"]!.GetValue<string>();
        await Json(await doctor.PutAsJsonAsync($"/api/v1/lab/dictionaries/employees/{technicianId}", new { labRole = LabRoles.Registrar }));

        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{DemoDataSeeder.Doctor}", new { labRole = LabRoles.Admin }));
        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{DemoDataSeeder.Doctor}", new { phone = "+380000000000" }));
        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{DemoDataSeeder.Admin}", new { labRole = LabRoles.Technician }));
        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/dictionaries/employees/{DemoDataSeeder.Admin}", new { phone = "+380000000000" }));
        await AssertRankDenied(await doctor.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Рівний Лікар Тест", labRole = LabRoles.Doctor, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        await AssertRankDenied(await doctor.PostAsJsonAsync("/api/v1/lab/dictionaries/employees", new { fullName = "Новий Адмін Тест", labRole = LabRoles.Admin, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{technicianId}", new { labRole = LabRoles.Doctor }));

        var admin = _f.As(DemoDataSeeder.Admin);
        var otherDoctor = await Json(await admin.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Інший Лікар Тест", labRole = LabRoles.Doctor, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        var otherDoctorId = otherDoctor["id"]!.GetValue<string>();
        await AssertRankDenied(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{otherDoctorId}", new { labRole = LabRoles.Technician }));

        foreach (var role in LabRoles.All)
            await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{otherDoctorId}", new { labRole = role }));
        await Json(await admin.PostAsJsonAsync("/api/v1/lab/dictionaries/employees", new { fullName = "Другий Адмін Тест", labRole = LabRoles.Admin, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));

        var me = await Json(await doctor.GetAsync("/api/v1/lab/context/me"));
        Assert.Equal(new[] { LabRoles.Technician, LabRoles.Phlebotomist, LabRoles.Courier, LabRoles.Registrar }, me["assignableRoles"]!.AsArray().Select(r => r!.GetValue<string>()));
        Assert.Equal(LabRoles.All, (await Json(await admin.GetAsync("/api/v1/lab/context/me")))["assignableRoles"]!.AsArray().Select(r => r!.GetValue<string>()));
        Assert.Empty((await Json(await _f.As(DemoDataSeeder.Technician).GetAsync("/api/v1/lab/context/me")))["assignableRoles"]!.AsArray());
    }

    [Fact]
    public async Task Employee_save_needs_its_own_operation_right()
    {
        var technician = _f.As(DemoDataSeeder.Technician);
        var caption = CaptionOf(LabRoles.Technician);
        await Denied(await technician.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Без Права Тест", labRole = LabRoles.Courier, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }), caption, nameof(ApplicationOperations.EmployeeSave));
        await Denied(await technician.PutAsJsonAsync($"/api/v1/lab/dictionaries/employees/{DemoDataSeeder.Courier}", new { phone = "+380000000000" }), caption, nameof(ApplicationOperations.EmployeeSave));
        Assert.Equal(new[] { LabRoles.Admin, LabRoles.Doctor }, RightsSeedHelper.Security.OperationRoles[nameof(ApplicationOperations.EmployeeSave)]);
    }

    [Fact]
    public async Task Courier_gets_audit_entries_without_result_derived_content()
    {
        var marker = "audit-" + Guid.NewGuid().ToString("N");
        const string value = "K = 6.8 > 5.5";
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
            db.AuditLog.AddRange(
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "REFLEX_CREATED", Entity = "lab_order_test", EntityId = "t1", AfterJson = $"{{\"id\":\"rule-1\",\"reason\":\"{value} (CRIT_HIGH)\",\"testCode\":\"K\"}}", Comment = $"Правило {value}" },
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "REJECT", Entity = "lab_order_test", EntityId = "t2", BeforeJson = "{\"status\":\"RESULTED\"}", AfterJson = $"{{\"status\":\"REJECTED\",\"reason\":\"{value}\"}}" },
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "REOPEN", Entity = "lab_order", EntityId = "o1", BeforeJson = "{\"status\":\"COMPLETED\"}", AfterJson = "{\"status\":\"IN_PROGRESS\"}", Comment = value },
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "RECEIVE", Entity = "lab_order_sample", EntityId = "s1", AfterJson = $"{{\"status\":\"RECEIVED\",\"req\":{{\"isHemolyzed\":true,\"notes\":\"{value}\"}}}}" },
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "ATTACH", Entity = "lab_order_attachment", EntityId = "a1", AfterJson = "{\"fileName\":\"external.pdf\"}" },
                new MedLink.LIS.Api.Data.Entities.LabAuditLog { UserId = marker, Action = "UPDATE", Entity = "lab_qc_result", EntityId = "q1", AfterJson = "{\"measuredValue\":5.1}", Comment = "Переоцінка правил" });
            await db.SaveChangesAsync();
        }
        async Task<Dictionary<string, JsonNode>> Audit(HttpClient c) =>
            (await Json(await c.GetAsync($"/api/v1/lab/audit?userId={marker}&pageSize=50")))["items"]!.AsArray().ToDictionary(a => a!["entityId"]!.GetValue<string>(), a => a!);
        static string? Field(JsonNode entry, string name) => entry[name]?.GetValue<string>();

        var courier = await Audit(_f.As(DemoDataSeeder.Courier));
        Assert.Equal(6, courier.Count);
        Assert.All(courier.Values, e => Assert.DoesNotContain("6.8", e.ToJsonString()));
        Assert.Null(Field(courier["t1"], "afterJson"));
        Assert.Null(Field(courier["t1"], "comment"));
        Assert.Equal("RESULTED", JsonNode.Parse(Field(courier["t2"], "beforeJson")!)!["status"]!.GetValue<string>());
        Assert.Equal("{\"status\":\"REJECTED\"}", Field(courier["t2"], "afterJson"));
        Assert.Null(Field(courier["o1"], "comment"));
        Assert.Equal("{\"status\":\"IN_PROGRESS\"}", Field(courier["o1"], "afterJson"));
        var sample = JsonNode.Parse(Field(courier["s1"], "afterJson")!)!;
        Assert.Equal("RECEIVED", sample["status"]!.GetValue<string>());
        Assert.True(sample["req"]!["isHemolyzed"]!.GetValue<bool>());
        Assert.Null(sample["req"]!["notes"]);
        Assert.Null(Field(courier["a1"], "afterJson"));
        Assert.Equal("Переоцінка правил", Field(courier["q1"], "comment"));
        Assert.NotNull(Field(courier["q1"], "afterJson"));

        var technician = await Audit(_f.As(DemoDataSeeder.Technician));
        Assert.Contains(value, Field(technician["t1"], "comment"));
        Assert.Contains(value, Field(technician["t2"], "afterJson"));
        Assert.Equal(value, Field(technician["o1"], "comment"));
        Assert.Contains(value, Field(technician["s1"], "afterJson"));
        Assert.NotNull(Field(technician["a1"], "afterJson"));
    }

    [Fact]
    public async Task Courier_gets_volume_analytics_without_result_flag_counts()
    {
        await OrderWithResultsAsync();
        var from = DateTime.UtcNow.AddYears(-5).ToString("O");
        var courierRows = (await Json(await _f.As(DemoDataSeeder.Courier).GetAsync($"/api/v1/lab/analytics/volume?from={Uri.EscapeDataString(from)}")))["rows"]!.AsArray();
        Assert.NotEmpty(courierRows);
        Assert.All(courierRows, r => { Assert.Null(r!["critical"]); Assert.Null(r["abnormal"]); Assert.NotNull(r["tests"]); Assert.NotNull(r["verified"]); });
        var technicianRows = (await Json(await _f.As(DemoDataSeeder.Technician).GetAsync($"/api/v1/lab/analytics/volume?from={Uri.EscapeDataString(from)}")))["rows"]!.AsArray();
        Assert.All(technicianRows, r => { Assert.NotNull(r!["critical"]); Assert.NotNull(r["abnormal"]); });
        Assert.Contains(technicianRows, r => r!["critical"]!.GetValue<int>() + r["abnormal"]!.GetValue<int>() > 0);

        async Task<List<string>> Headers(HttpClient c)
        {
            var r = await c.GetAsync($"/api/v1/lab/analytics/export.xlsx?report=volume&from={Uri.EscapeDataString(from)}");
            Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode}");
            using var wb = new XLWorkbook(await r.Content.ReadAsStreamAsync());
            return wb.Worksheet(1).Row(1).CellsUsed().Select(x => x.GetString()).ToList();
        }
        var courierHeaders = await Headers(_f.As(DemoDataSeeder.Courier));
        Assert.DoesNotContain("Критичних", courierHeaders);
        Assert.Equal("CITO", courierHeaders.Last());
        Assert.Contains("Критичних", await Headers(_f.As(DemoDataSeeder.Technician)));

        async Task<string> CsvHeader(HttpClient c)
        {
            var r = await c.GetAsync($"/api/v1/lab/analytics/export.csv?report=volume&from={Uri.EscapeDataString(from)}");
            Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode}");
            Assert.Equal("text/csv", r.Content.Headers.ContentType?.MediaType);
            var csv = Encoding.UTF8.GetString(await r.Content.ReadAsByteArrayAsync()).TrimStart('\uFEFF');
            return csv.Split("\r\n", StringSplitOptions.None)[0];
        }
        Assert.DoesNotContain("\"Критичних\"", await CsvHeader(_f.As(DemoDataSeeder.Courier)));
        Assert.Contains("\"Критичних\"", await CsvHeader(_f.As(DemoDataSeeder.Technician)));

        foreach (var report in new[] { "orders", "tat", "volume", "qc" })
        {
            var query = $"report={report}&from={Uri.EscapeDataString(from)}";
            var csv = await _f.As(DemoDataSeeder.Technician).GetAsync($"/api/v1/lab/analytics/export.csv?{query}");
            Assert.True(csv.IsSuccessStatusCode, $"{(int)csv.StatusCode}");
            Assert.Equal("text/csv", csv.Content.Headers.ContentType?.MediaType);
            Assert.NotEmpty(await csv.Content.ReadAsByteArrayAsync());

            var pdf = await _f.As(DemoDataSeeder.Technician).GetAsync($"/api/v1/lab/analytics/export.pdf?{query}");
            Assert.True(pdf.IsSuccessStatusCode, $"{(int)pdf.StatusCode}");
            Assert.Equal("application/pdf", pdf.Content.Headers.ContentType?.MediaType);
            Assert.StartsWith("%PDF-", Encoding.ASCII.GetString(await pdf.Content.ReadAsByteArrayAsync()));
        }
    }

    private async Task<HttpClient> LabStaffAsync(string? labRole, bool withLabSettings, string[] profileRoles, string selectedRole)
    {
        var identity = "test-user-" + Guid.NewGuid().ToString("N");
        var employeeId = Guid.NewGuid().ToString();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
            var template = await db.Employees.AsNoTracking().FirstAsync(e => e.Id == DemoDataSeeder.Registrar);
            var person = new MedLink.LIS.Api.Data.Entities.CmnPerson { Id = Guid.NewGuid().ToString(), LastName = "Ранг", Name = "Тест", UserId = identity };
            db.Persons.Add(person);
            db.Employees.Add(new MedLink.LIS.Api.Data.Entities.OrgEmployee
            {
                Id = employeeId, PersonId = person.Id, Caption = "Ранг Тест", TenantId = template.TenantId, DepartmentId = template.DepartmentId, PositionTypeId = template.PositionTypeId,
                LabSettings = withLabSettings ? new MedLink.LIS.Api.Data.Entities.LabEmployeeSettings { EmployeeId = employeeId, LabRole = labRole ?? "" } : null,
                Membership = new MedLink.LIS.Api.Data.Entities.IdMembership { Id = employeeId, TenantId = template.TenantId, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" }
            });
            foreach (var role in profileRoles)
                db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(employeeId), ProfileId = _f.ProfileId(role) });
            await db.SaveChangesAsync();
        }
        var c = _f.AsIdentity(identity);
        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = _f.ProfileId(selectedRole), userId = employeeId }));
        return c;
    }

    private async Task<string> EmployeeWithoutLabSettingsAsync(params string[] profileRoles)
    {
        var employeeId = Guid.NewGuid().ToString();
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
        var template = await db.Employees.AsNoTracking().FirstAsync(e => e.Id == DemoDataSeeder.Registrar);
        var person = new MedLink.LIS.Api.Data.Entities.CmnPerson { Id = Guid.NewGuid().ToString(), LastName = "Без", Name = "Налаштувань" };
        db.Persons.Add(person);
        db.Employees.Add(new MedLink.LIS.Api.Data.Entities.OrgEmployee { Id = employeeId, PersonId = person.Id, Caption = "Без Налаштувань", TenantId = template.TenantId, DepartmentId = template.DepartmentId, PositionTypeId = template.PositionTypeId, Membership = new MedLink.LIS.Api.Data.Entities.IdMembership { Id = employeeId, TenantId = template.TenantId, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" } });
        foreach (var role in profileRoles)
            db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(employeeId), ProfileId = _f.ProfileId(role) });
        await db.SaveChangesAsync();
        return employeeId;
    }

    private static async Task AssertRankDeniedFor(HttpResponseMessage r, string? ownRole)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.StatusCode == HttpStatusCode.Forbidden, $"Очікувано 403, отримано {(int)r.StatusCode}: {text}");
        Assert.Equal(OrgDictionaryService.RankDeniedDetail(ownRole), JsonNode.Parse(text)!["detail"]!.GetValue<string>());
    }

    private static async Task<List<string>> AssignableRoles(HttpClient c) =>
        (await Json(await c.GetAsync("/api/v1/lab/context/me")))["assignableRoles"]!.AsArray().Select(r => r!.GetValue<string>()).ToList();

    [Fact]
    public async Task Target_rank_counts_lab_profiles_of_an_employee_without_lab_settings()
    {
        var doctor = _f.As(DemoDataSeeder.Doctor);
        var misAdmin = await EmployeeWithoutLabSettingsAsync(LabRoles.Admin);
        await AssertRankDeniedFor(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{misAdmin}", new { phone = "+380000000001" }), LabRoles.Doctor);
        await AssertRankDeniedFor(await doctor.PutAsJsonAsync($"/api/v1/lab/dictionaries/employees/{misAdmin}", new { labRole = LabRoles.Courier }), LabRoles.Doctor);

        var misDoctor = await EmployeeWithoutLabSettingsAsync(LabRoles.Doctor);
        await AssertRankDeniedFor(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{misDoctor}", new { labRole = LabRoles.Technician }), LabRoles.Doctor);

        var plain = await EmployeeWithoutLabSettingsAsync();
        var saved = await Json(await doctor.PutAsJsonAsync($"/api/v1/lab/settings/users/{plain}", new { labRole = LabRoles.Courier }));
        Assert.Equal(LabRoles.Courier, saved["labRole"]!.GetValue<string>());

        await Json(await _f.As(DemoDataSeeder.Admin).PutAsJsonAsync($"/api/v1/lab/settings/users/{misAdmin}", new { phone = "+380000000001" }));
    }

    [Fact]
    public async Task Actor_rank_comes_from_the_selected_lab_profile()
    {
        foreach (var withSettings in new[] { false, true })
        {
            var admin = await LabStaffAsync(null, withSettings, new[] { LabRoles.Admin }, LabRoles.Admin);
            Assert.Equal(LabRoles.All, await AssignableRoles(admin));
            var created = await Json(await admin.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Адмін Без Ролі Тест", labRole = LabRoles.Admin, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
            await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{created["id"]}", new { labRole = LabRoles.Doctor }));
        }

        var doctorByProfile = await LabStaffAsync(LabRoles.Admin, true, new[] { LabRoles.Doctor }, LabRoles.Doctor);
        Assert.Equal(new[] { LabRoles.Technician, LabRoles.Phlebotomist, LabRoles.Courier, LabRoles.Registrar }, await AssignableRoles(doctorByProfile));
        await AssertRankDeniedFor(await doctorByProfile.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Рівний Лікар Тест", labRole = LabRoles.Doctor, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }), LabRoles.Doctor);
        await AssertRankDeniedFor(await doctorByProfile.PutAsJsonAsync($"/api/v1/lab/settings/users/{DemoDataSeeder.Doctor}", new { phone = "+380000000002" }), LabRoles.Doctor);
        await Json(await doctorByProfile.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Нижчий Кур'єр Тест", labRole = LabRoles.Courier, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
    }

    [Fact]
    public void System_policy_keeps_full_rights()
    {
        var system = new SystemRolePolicy();
        foreach (var op in ApplicationOperations.GetDeclaredOperations()) system.Require(op.OperationName);
        Assert.Equal(LisStateMachine.ConnectorRules.Count(r => r.FromStatuses.Contains(LisStateMachine.ConnectorPending)),
            system.AllowedActions(LisEntities.Connector, LisStateMachine.ConnectorPending).Count);
        Assert.Equal(LisStateMachine.ConnectorActive, system.Ensure(LisEntities.Connector, ConnectorActions.Register, LisStateMachine.ConnectorPending).ToStatus);
    }
}
