using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using Core.Security;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Tenancy;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Data.Helpers;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Domain;
using MedLink.LIS.Api.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityOperationRight = Core.Security.Models.OperationRight;
using SecurityProfile = Core.Security.Models.Profile;
using SecurityRole = Core.Security.Models.Role;
using SecurityRoleOperationRight = Core.Security.Models.RoleOperationRight;
using SecurityUserProfile = Core.Security.Models.UserProfile;

namespace MedLink.LIS.Tests.Api;

public sealed class SecuritySeedTests : IDisposable
{
    private readonly string _connectionString = TestDatabase.Create();

    private LisDbContext NewDb() => TestDatabase.Context(_connectionString);

    private static IDisposable AsDefaultTenant() => new TenantContext().RunAs(MedLink.LIS.Api.Data.Entities.UuidV7.New());

    private async Task SeedAsync()
    {
        await using var db = NewDb();
        await new SeedService(db, NullLogger<SeedService>.Instance).SeedAsync();
    }

    public void Dispose()
    {
        TestDatabase.Drop(_connectionString);
    }

    private static List<string> RoleOperations(LisDbContext db, Guid roleId) =>
        db.RoleOperationRights!.AsNoTracking().Where(r => r.RoleId == roleId).Include(r => r.OperationRight)
            .Select(r => r.OperationRight!).Where(r => r.AccessLevel == AccessLevel.Write && r.IsActive).Select(r => r.OperationName).ToList().OrderBy(x => x).ToList();

    private static async Task AssertSeededStateAsync(LisDbContext db)
    {
        var seed = RightsSeedHelper.Security;
        var declared = ApplicationOperations.GetDeclaredOperations().Select(o => o.OperationName).OrderBy(x => x).ToList();
        foreach (var level in new[] { AccessLevel.No, AccessLevel.Read, AccessLevel.Write })
            Assert.Equal(declared, (await db.OperationRights!.AsNoTracking().Where(r => r.AccessLevel == level).Select(r => r.OperationName).ToListAsync()).OrderBy(x => x));

        foreach (var labRole in seed.LabRoles)
        {
            var profile = await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Caption == labRole.Caption);
            Assert.Equal(labRole.Caption, profile.Caption);
            Assert.True(profile.IsActive);
            var role = await db.Roles!.AsNoTracking().FirstAsync(r => r.Caption == labRole.Caption);
            Assert.Equal(labRole.Caption, role.Caption);
            Assert.Equal(new[] { role.Id }, await db.ProfileRoles!.AsNoTracking().Where(p => p.ProfileId == profile.Id).Select(p => p.RoleId).ToListAsync());
            var expected = seed.OperationsOf(labRole.Code).OrderBy(x => x).ToList();
            Assert.Equal(expected, RoleOperations(db, role.Id));
            Assert.Equal(expected, db.GetUserRights(profile.Id).OperationRights.Keys.OrderBy(x => x));
        }
        Assert.Equal(declared, db.GetUserRights((await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Caption == seed.ForRole(LabRoles.Admin)!.Caption)).Id).OperationRights.Keys.OrderBy(x => x));

        var labCaptions = seed.LabRoles.Select(r => r.Caption).ToList();
        var labProfileIds = await db.SecurityProfiles!.AsNoTracking().Where(p => labCaptions.Contains(p.Caption)).Select(p => p.Id).ToListAsync();
        foreach (var userProfile in seed.UserProfiles)
        {
            var employee = await db.Employees.AsNoTracking().Include(e => e.LabSettings).FirstAsync(e => e.Id == userProfile.EmployeeId);
            var links = await db.UserProfiles!.AsNoTracking().Where(u => u.UserId == Guid.Parse(employee.Id) && labProfileIds.Contains(u.ProfileId)).ToListAsync();
            var link = Assert.Single(links);
            Assert.Equal(seed.ForRole(employee.LabSettings!.LabRole)!.Caption, (await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Id == link.ProfileId)).Caption);
        }
        var seededEmployees = seed.UserProfiles.Select(u => u.EmployeeId).ToList();
        Assert.Equal(LabRoles.All.OrderBy(x => x), (await db.Employees.AsNoTracking().Where(e => seededEmployees.Contains(e.Id)).Select(e => e.LabSettings!.LabRole).ToListAsync()).OrderBy(x => x));
    }

    private static async Task<int[]> CountsAsync(LisDbContext db) => new[]
    {
        await db.OperationRights!.CountAsync(), await db.SecurityProfiles!.CountAsync(), await db.Roles!.CountAsync(), await db.ProfileRoles!.CountAsync(),
        await db.RoleOperationRights!.CountAsync(), await db.UserProfiles!.CountAsync()
    };

    [Fact]
    public async Task Seed_creates_a_profile_with_operation_rights_for_every_lab_role()
    {
        using var tenantScope = AsDefaultTenant();
        await SeedAsync();
        await using var db = NewDb();
        await AssertSeededStateAsync(db);
        var admin = RightsSeedHelper.Security.ForRole(LabRoles.Admin)!;
        var adminProfileId = (await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Caption == admin.Caption)).Id;
        Assert.Equal("Адміністратор лабораторії", admin.Caption);
        Assert.Equal(adminProfileId, (await db.UserProfiles!.AsNoTracking().FirstAsync(u => u.UserId == Guid.Parse(DemoDataSeeder.Admin))).ProfileId);
    }

    [Fact]
    public async Task Seed_twice_changes_nothing()
    {
        using var tenantScope = AsDefaultTenant();
        await SeedAsync();
        int[] before;
        await using (var db = NewDb()) before = await CountsAsync(db);
        await SeedAsync();
        await using (var db = NewDb())
        {
            Assert.Equal(before, await CountsAsync(db));
            await AssertSeededStateAsync(db);
        }
    }

    [Fact]
    public async Task Existing_database_with_the_old_single_profile_gets_lab_rights_on_startup()
    {
        using var tenantScope = AsDefaultTenant();
        await SeedAsync();
        var seed = RightsSeedHelper.Security;
        var admin = seed.ForRole(LabRoles.Admin)!;
        var otherProfileId = Guid.NewGuid();
        var staleRightId = Guid.NewGuid();
        var staleRoleRightId = Guid.NewGuid();
        int employees;
        Guid adminProfileId, adminRoleId;
        await using (var db = NewDb())
        {
            employees = await db.Employees.CountAsync();
            adminProfileId = (await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Caption == admin.Caption)).Id;
            adminRoleId = (await db.Roles!.AsNoTracking().FirstAsync(r => r.Caption == admin.Caption)).Id;
            db.RoleOperationRights!.RemoveRange(db.RoleOperationRights!);
            db.ProfileRoles!.RemoveRange(db.ProfileRoles!);
            db.Roles!.RemoveRange(db.Roles!);
            db.OperationRights!.RemoveRange(db.OperationRights!);
            db.UserProfiles!.RemoveRange(db.UserProfiles!.Where(u => u.UserId != Guid.Parse(DemoDataSeeder.Admin)));
            db.SecurityProfiles!.RemoveRange(db.SecurityProfiles!.Where(p => p.Id != adminProfileId));
            await db.SaveChangesAsync();

            db.SecurityProfiles!.Add(new SecurityProfile { Id = otherProfileId, Caption = "Інший профіль", IsActive = true });
            db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(DemoDataSeeder.Doctor), ProfileId = otherProfileId });
            db.OperationRights!.Add(new SecurityOperationRight { Id = staleRightId, Caption = "Перегляд замовлень: Режим перегляду", OperationName = nameof(ApplicationOperations.OrdersRead), AccessLevel = AccessLevel.Read, IsActive = true });
            db.Roles!.Add(new SecurityRole { Id = adminRoleId, Caption = admin.Caption, IsActive = true });
            db.RoleOperationRights!.Add(new SecurityRoleOperationRight { Id = staleRoleRightId, RoleId = adminRoleId, OperationRightId = staleRightId });
            await db.SaveChangesAsync();

            Assert.Equal(new[] { adminProfileId, otherProfileId }.OrderBy(x => x), (await db.SecurityProfiles!.Select(p => p.Id).ToListAsync()).OrderBy(x => x));
            Assert.Empty(db.GetUserRights(adminProfileId).OperationRights.Where(o => o.Value == AccessLevel.Write));
        }

        await SeedAsync();

        await using (var db = NewDb())
        {
            await AssertSeededStateAsync(db);
            Assert.Equal(employees, await db.Employees.CountAsync());
            var updated = await db.RoleOperationRights!.AsNoTracking().Include(r => r.OperationRight).FirstAsync(r => r.Id == staleRoleRightId);
            Assert.Equal(AccessLevel.Write, updated.OperationRight!.AccessLevel);
            Assert.Equal(nameof(ApplicationOperations.OrdersRead), updated.OperationRight.OperationName);
            Assert.True(await db.UserProfiles!.AnyAsync(u => u.UserId == Guid.Parse(DemoDataSeeder.Doctor) && u.ProfileId == otherProfileId));
            Assert.Equal(admin.Caption, (await db.SecurityProfiles!.FirstAsync(p => p.Id == adminProfileId)).Caption);
        }
    }

    [Fact]
    public async Task Existing_database_loses_role_rights_the_seed_no_longer_lists()
    {
        using var tenantScope = AsDefaultTenant();
        await SeedAsync();
        var courier = RightsSeedHelper.Security.ForRole(LabRoles.Courier)!;
        var printReport = nameof(ApplicationOperations.OrderPrintReport);
        Assert.DoesNotContain(printReport, RightsSeedHelper.Security.OperationsOf(LabRoles.Courier));
        Guid courierRoleId, courierProfileId;
        await using (var db = NewDb())
        {
            courierRoleId = (await db.Roles!.AsNoTracking().FirstAsync(r => r.Caption == courier.Caption)).Id;
            courierProfileId = (await db.SecurityProfiles!.AsNoTracking().FirstAsync(p => p.Caption == courier.Caption)).Id;
            var right = await db.OperationRights!.FirstAsync(r => r.OperationName == printReport && r.AccessLevel == AccessLevel.Write);
            db.RoleOperationRights!.Add(new SecurityRoleOperationRight { Id = Guid.NewGuid(), RoleId = courierRoleId, OperationRightId = right.Id });
            await db.SaveChangesAsync();
            Assert.Contains(printReport, RoleOperations(db, courierRoleId));
            Assert.Contains(printReport, db.GetUserRights(courierProfileId).OperationRights.Keys);
        }

        await SeedAsync();

        await using (var db = NewDb())
        {
            Assert.DoesNotContain(printReport, RoleOperations(db, courierRoleId));
            Assert.DoesNotContain(printReport, db.GetUserRights(courierProfileId).OperationRights.Keys);
            await AssertSeededStateAsync(db);
        }
    }
}

[Collection("api")]
public class LabRoleProfileSyncTests
{
    private readonly LisApiFactory _f;
    public LabRoleProfileSyncTests(LisApiFactory f) => _f = f;

    private static async Task<JsonNode> Json(HttpResponseMessage r)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode} {r.RequestMessage?.Method} {r.RequestMessage?.RequestUri}: {text}");
        return JsonNode.Parse(text)!;
    }

    private async Task<List<SecurityUserProfile>> LinksAsync(string employeeId)
    {
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
        return await db.UserProfiles!.AsNoTracking().Where(u => u.UserId == Guid.Parse(employeeId)).ToListAsync();
    }

    private Guid ProfileOf(string labRole) => _f.ProfileId(labRole);

    private static async Task<JsonObject> OperationRightsAsync(HttpClient c) => (await Json(await c.GetAsync("/api/account/info")))["rights"]!["operationRights"]!.AsObject();

    [Fact]
    public async Task Employee_gets_the_lab_profile_of_lab_role_on_create()
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var created = await Json(await admin.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Нова Реєстраторка Тест", labRole = LabRoles.Registrar, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        var link = Assert.Single(await LinksAsync(created["id"]!.GetValue<string>()));
        Assert.Equal(ProfileOf(LabRoles.Registrar), link.ProfileId);
    }

    [Fact]
    public async Task Lab_role_change_replaces_the_lab_profile_and_clears_the_cached_user_info()
    {
        var admin = _f.As(DemoDataSeeder.Admin);
        var created = await Json(await admin.PostAsJsonAsync("/api/v1/lab/settings/users", new { fullName = "Синхронна Ольга Петрівна", labRole = LabRoles.Registrar, departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) }));
        var employeeId = created["id"]!.GetValue<string>();
        var identity = "test-user-" + Guid.NewGuid().ToString("N");
        var otherProfileId = Guid.NewGuid();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            using var tenantScope = TestTenantScope.Enter(db, _f.TenantId);
            var employee = await db.Employees.FirstAsync(e => e.Id == employeeId);
            (await db.Persons.FirstAsync(p => p.Id == employee.PersonId)).UserId = identity;
            db.SecurityProfiles!.Add(new SecurityProfile { Id = otherProfileId, Caption = "Профіль поза ЛІС", IsActive = true });
            db.UserProfiles!.Add(new SecurityUserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(employeeId), ProfileId = otherProfileId });
            await db.SaveChangesAsync();
        }
        var labLink = (await LinksAsync(employeeId)).Single(u => u.ProfileId == ProfileOf(LabRoles.Registrar));

        var c = _f.AsIdentity(identity);
        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = ProfileOf(LabRoles.Registrar), userId = employeeId }));
        var rights = await OperationRightsAsync(c);
        Assert.True(rights.ContainsKey(nameof(ApplicationOperations.PatientDelete)));
        Assert.False(rights.ContainsKey(nameof(ApplicationOperations.SampleCollect)));

        await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{employeeId}", new { labRole = LabRoles.Registrar }));
        await Json(await c.GetAsync("/api/v1/lab/orders?pageSize=1"));

        await Json(await admin.PutAsJsonAsync($"/api/v1/lab/settings/users/{employeeId}", new { labRole = LabRoles.Technician }));
        var links = await LinksAsync(employeeId);
        Assert.Equal(2, links.Count);
        Assert.Equal(ProfileOf(LabRoles.Technician), links.Single(u => u.Id == labLink.Id).ProfileId);
        Assert.Contains(links, u => u.ProfileId == otherProfileId);

        var denied = await c.GetAsync("/api/v1/lab/orders?pageSize=1");
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode);
        Assert.Equal(ApiAuthorizationFilter.NoProfileDetail, JsonNode.Parse(await denied.Content.ReadAsStringAsync())!["detail"]!.GetValue<string>());
        Assert.False((await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = ProfileOf(LabRoles.Registrar), userId = employeeId })).IsSuccessStatusCode);

        await Json(await c.PostAsJsonAsync("/api/account/authenticate/", new { profileId = ProfileOf(LabRoles.Technician), userId = employeeId }));
        rights = await OperationRightsAsync(c);
        Assert.True(rights.ContainsKey(nameof(ApplicationOperations.SampleCollect)));
        Assert.False(rights.ContainsKey(nameof(ApplicationOperations.PatientDelete)));
        await Json(await c.GetAsync("/api/v1/lab/orders?pageSize=1"));
    }
}
