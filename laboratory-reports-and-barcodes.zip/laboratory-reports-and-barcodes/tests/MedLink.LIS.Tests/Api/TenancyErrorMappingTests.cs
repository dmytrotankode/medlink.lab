using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Infrastructure;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Tenancy;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

public class TenancyErrorMappingTests : IClassFixture<LisApiFactory>
{
    private string TenantA => _f.TenantId;
    private readonly LisApiFactory _f;
    public TenancyErrorMappingTests(LisApiFactory f) => _f = f;

    private static async Task<(int Status, JsonNode Body)> MapAsync(Exception exception)
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        await new ProblemDetailsMiddleware(_ => throw exception, NullLogger<ProblemDetailsMiddleware>.Instance).InvokeAsync(context);
        context.Response.Body.Position = 0;
        return (context.Response.StatusCode, JsonNode.Parse(await new StreamReader(context.Response.Body).ReadToEndAsync())!);
    }

    public static TheoryData<string> NotFoundExceptions => new() { "mismatch", "department", "rls", "wrapped-mismatch" };

    private static Exception Create(string kind) => kind switch
    {
        "mismatch" => new TenantMismatchException("lab_order"),
        "department" => new DepartmentNotAllowedException("0d000000-0000-0000-0000-000000000002"),
        "rls" => new DbUpdateException("save", new PostgresException("new row violates row-level security policy for table \"lab_order\"", "ERROR", "ERROR", PostgresErrorCodes.InsufficientPrivilege)),
        _ => new InvalidOperationException("wrapped", new TenantMismatchException("lab_order"))
    };

    [Theory]
    [MemberData(nameof(NotFoundExceptions))]
    public async Task Foreign_organization_or_department_errors_map_to_404_without_details(string kind)
    {
        var (status, body) = await MapAsync(Create(kind));
        Assert.Equal(404, status);
        Assert.Equal(ProblemDetailsMiddleware.NotFoundTitle, body["title"]!.GetValue<string>());
        Assert.Equal(ProblemDetailsMiddleware.NotFoundDetail, body["detail"]!.GetValue<string>());
        Assert.DoesNotContain("lab_order", body.ToJsonString());
        Assert.DoesNotContain("0d000000", body.ToJsonString());
    }

    [Fact]
    public async Task Missing_organization_maps_to_400_tenant_required()
    {
        foreach (var exception in new Exception[] { new TenantNotSetException(), new InvalidOperationException("wrapped", new TenantNotSetException()), new PostgresException("unrecognized configuration parameter \"app.tenant_id\"", "ERROR", "ERROR", PostgresErrorCodes.UndefinedObject) })
        {
            var (status, body) = await MapAsync(exception);
            Assert.Equal(400, status);
            Assert.Equal(ProblemDetailsMiddleware.TenantRequiredCode, body["code"]!.GetValue<string>());
        }
    }

    [Fact]
    public async Task Request_whose_profile_resolves_no_organization_gets_400_tenant_required()
    {
        var tenant = await _f.CreateTenantAsync();
        var client = await _f.AsAsync(tenant);
        await using (var connection = new NpgsqlConnection(_f.OwnerConnectionString))
        {
            await connection.OpenAsync();
            await using var command = new NpgsqlCommand($"UPDATE cmn_person SET user_id = 'detached-{Guid.NewGuid():N}' WHERE id = (SELECT person_id FROM org_employee WHERE id = '{tenant.EmployeeId}')", connection);
            await command.ExecuteNonQueryAsync();
        }
        var response = await client.GetAsync("/api/v1/lab/orders");
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal(ProblemDetailsMiddleware.TenantRequiredCode, JsonNode.Parse(await response.Content.ReadAsStringAsync())!["code"]!.GetValue<string>());
    }

    [Fact]
    public async Task Reference_to_an_object_of_another_organization_returns_404_and_is_not_saved()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var code = "ISO" + Guid.NewGuid().ToString("N")[..5].ToUpperInvariant();

        var foreign = await adminB.PostAsJsonAsync("/api/v1/lab/sections", new { code, name = "Чужий підрозділ", sectionType = "OTHER", departmentId = _f.DivisionId(DemoDataSeeder.DeptCode) });
        Assert.Equal(HttpStatusCode.NotFound, foreign.StatusCode);
        var missing = await adminB.PostAsJsonAsync("/api/v1/lab/sections", new { code, name = "Неіснуючий підрозділ", sectionType = "OTHER", departmentId = Guid.NewGuid().ToString() });
        Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
        Assert.Equal(HttpStatusCode.Created, (await adminB.PostAsJsonAsync("/api/v1/lab/sections", new { code, name = "Власний підрозділ", sectionType = "OTHER", departmentId = tenantB.DepartmentId })).StatusCode);

        await using var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand($"SELECT count(*) FROM lab_section WHERE code = '{code}' AND department_id = '{_f.DivisionId(DemoDataSeeder.DeptCode)}'", connection);
        Assert.Equal(0L, await command.ExecuteScalarAsync());
    }

    [Fact]
    public async Task Manual_retention_run_cleans_only_the_current_organization()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        string logA;
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            logA = await db.RunAsTenantAsync(TenantA, async () =>
            {
                var connector = await db.Connectors.FirstOrDefaultAsync() ?? new LabConnectorInstallation { Name = "Ретеншн A", InstallKey = ConnectorService.NewInstallKey() };
                if (db.Entry(connector).State == EntityState.Detached) db.Connectors.Add(connector);
                var log = new LabConnectorLog { ConnectorId = connector.Id, At = DateTime.UtcNow.AddYears(-5), Message = "old A" };
                db.ConnectorLogs.Add(log);
                await db.SaveChangesAsync();
                return log.Id;
            });
        }

        var run = JsonNode.Parse(await (await adminB.PostAsync("/api/v1/lab/maintenance/retention/run", null)).Content.ReadAsStringAsync())!;
        Assert.Equal(0, run["deletedLogs"]!.GetValue<int>());
        await using var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        await using var command = new NpgsqlCommand($"SELECT count(*) FROM lab_connector_log WHERE id = '{logA}'", connection);
        Assert.Equal(1L, await command.ExecuteScalarAsync());
    }
}
