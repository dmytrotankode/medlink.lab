using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Services;
using MedLink.LIS.Api.Tenancy;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

[Collection("api")]
public class TenancyTests
{
    private string TenantA => _f.TenantId;
    private const string Migration0002 = "20261022223345_0002_tenancy";
    private readonly LisApiFactory _f;
    public TenancyTests(LisApiFactory f) => _f = f;

    private static async Task<JsonNode> Json(HttpResponseMessage r)
    {
        var text = await r.Content.ReadAsStringAsync();
        Assert.True(r.IsSuccessStatusCode, $"{(int)r.StatusCode} {r.RequestMessage?.Method} {r.RequestMessage?.RequestUri}: {text}");
        return JsonNode.Parse(text)!;
    }

    private string AppConnection(string applicationName, bool pooling = true, int maxPoolSize = 100) =>
        new NpgsqlConnectionStringBuilder(_f.AppConnectionString) { ApplicationName = applicationName, Pooling = pooling, MaxPoolSize = maxPoolSize }.ConnectionString;

    private static LisDbContext Context(string connectionString) => TestDatabase.Context(connectionString);

    private static async Task<List<string>> ReadStringsAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql, connection);
        await using var reader = await command.ExecuteReaderAsync();
        var values = new List<string>();
        while (await reader.ReadAsync()) values.Add(reader.GetValue(0).ToString()!);
        return values;
    }

    private static async Task ExecuteAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql, connection);
        await command.ExecuteNonQueryAsync();
    }

    private static async Task<List<string>> InTenantAsync(NpgsqlConnection connection, string tenantId, string sql)
    {
        await using var transaction = await connection.BeginTransactionAsync();
        await using (var set = new NpgsqlCommand("SELECT set_config('app.tenant_id', @tenant, true)", connection, transaction))
        {
            set.Parameters.AddWithValue("tenant", tenantId);
            await set.ExecuteNonQueryAsync();
        }
        var values = new List<string>();
        await using (var command = new NpgsqlCommand(sql, connection, transaction))
        await using (var reader = await command.ExecuteReaderAsync())
            while (await reader.ReadAsync()) values.Add(reader.GetValue(0).ToString()!);
        await transaction.CommitAsync();
        return values;
    }

    [Fact]
    public async Task Direct_SQL_under_the_app_role_with_tenant_A_set_locally_sees_only_tenant_A_rows()
    {
        var tenantB = await _f.CreateTenantAsync();
        await using var connection = new NpgsqlConnection(AppConnection("tenancy-rls"));
        await connection.OpenAsync();
        var divisionsA = await InTenantAsync(connection, TenantA, "SELECT tenant_id::text FROM tn_division");
        Assert.NotEmpty(divisionsA);
        Assert.All(divisionsA, t => Assert.Equal(TenantA, t));
        Assert.NotEmpty(await InTenantAsync(connection, TenantA, "SELECT id FROM lab_order"));
        Assert.Equal(new[] { tenantB.DepartmentId }, await InTenantAsync(connection, tenantB.TenantId, "SELECT id::text FROM tn_division"));
        Assert.Empty(await InTenantAsync(connection, tenantB.TenantId, "SELECT id FROM lab_order"));
    }

    [Fact]
    public async Task Tenant_table_is_isolated_by_row_level_security()
    {
        var tenantB = await _f.CreateTenantAsync();
        await using var connection = new NpgsqlConnection(AppConnection("tenancy-tenant-table"));
        await connection.OpenAsync();
        Assert.Equal(new[] { TenantA }, await InTenantAsync(connection, TenantA, "SELECT id::text FROM tn_tenant"));
        Assert.Equal(new[] { tenantB.TenantId }, await InTenantAsync(connection, tenantB.TenantId, "SELECT id::text FROM tn_tenant"));
        var insert = await Assert.ThrowsAsync<PostgresException>(() => InTenantAsync(connection, TenantA,
            $"INSERT INTO tn_tenant (id, name, type, created_on, created_by, modified_by, record_state) VALUES ('{Guid.NewGuid()}', 'Чужий', 'laboratory', now(), '{Guid.Empty}', '{Guid.Empty}', 2) RETURNING id"));
        Assert.Equal(PostgresErrorCodes.InsufficientPrivilege, insert.SqlState);
        var unset = await Assert.ThrowsAsync<PostgresException>(() => ReadStringsAsync(connection, "SELECT id::text FROM tn_tenant"));
        Assert.Equal(PostgresErrorCodes.UndefinedObject, unset.SqlState);
    }

    [Fact]
    public async Task App_role_has_no_bypassrls_and_every_tenant_table_forces_row_level_security_on_a_uuid_tenant_column()
    {
        await using var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        Assert.Equal(new[] { "False" }, await ReadStringsAsync(connection, "SELECT rolbypassrls FROM pg_roles WHERE rolname = 'lab_app'"));
        Assert.Empty(await ReadStringsAsync(connection, """
            SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relkind = 'r'
              AND (c.relname = 'tn_tenant' OR EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid = c.oid AND a.attname = 'tenant_id' AND NOT a.attisdropped))
              AND NOT (c.relrowsecurity AND c.relforcerowsecurity AND EXISTS (SELECT 1 FROM pg_policies p WHERE p.schemaname = n.nspname AND p.tablename = c.relname AND p.policyname = 'tenant_isolation'))
            """));
        Assert.Empty(await ReadStringsAsync(connection, "SELECT table_name FROM information_schema.columns WHERE table_schema = 'public' AND column_name = 'tenant_id' AND (data_type <> 'uuid' OR is_nullable <> 'NO')"));
        Assert.Empty(await ReadStringsAsync(connection, "SELECT table_name FROM information_schema.columns WHERE table_schema = 'public' AND column_name = 'organization_id'"));
        Assert.Empty(await ReadStringsAsync(connection, """
            SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relkind = 'r'
              AND EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid = c.oid AND a.attname = 'tenant_id' AND NOT a.attisdropped)
              AND NOT EXISTS (SELECT 1 FROM pg_index i JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = i.indkey[0] WHERE i.indrelid = c.oid AND a.attname = 'tenant_id')
            """));
    }

    [Fact]
    public void Every_tenant_scoped_entity_has_a_required_uuid_tenant_column_that_leads_an_index_and_a_query_filter()
    {
        using var db = Context(_f.AppConnectionString);
        var global = new HashSet<Type> { typeof(CmnEnumRecord), typeof(CmnPerson), typeof(EheServiceCatalogService), typeof(TnTenant), typeof(IdUser), typeof(IdPermission) };
        var failures = new List<string>();
        foreach (var entity in db.Model.GetEntityTypes().Where(e => e.ClrType.Namespace == typeof(TnTenant).Namespace && e.GetTableName() != null && !e.IsOwned()))
        {
            var table = entity.GetTableName()!;
            var scoped = typeof(ITenantScoped).IsAssignableFrom(entity.ClrType);
            if (global.Contains(entity.ClrType))
            {
                if (scoped) failures.Add($"{table}: global table must not be tenant-scoped");
                continue;
            }
            if (!scoped)
            {
                failures.Add($"{table}: not ITenantScoped");
                continue;
            }
            var tenant = entity.FindProperty(nameof(ITenantScoped.TenantId))!;
            if (tenant.GetColumnName(StoreObjectIdentifier.Table(table, null)) != "tenant_id") failures.Add($"{table}: tenant column is not tenant_id");
            if (tenant.GetColumnType() != "uuid") failures.Add($"{table}: tenant_id is not uuid");
            if (tenant.IsNullable) failures.Add($"{table}: tenant_id is nullable");
            if (entity.FindPrimaryKey()?.Properties[0] != tenant && !entity.GetIndexes().Any(i => i.Properties[0] == tenant)) failures.Add($"{table}: no index starts with tenant_id");
            if (entity.GetQueryFilter() == null) failures.Add($"{table}: no tenant query filter");
        }
        Assert.True(failures.Count == 0, string.Join("\n", failures));
    }

    private static async Task<string> OutcomeAsync(NpgsqlConnection connection, string sql)
    {
        try
        {
            var rows = (await ReadStringsAsync(connection, sql)).ToList();
            return $"{sql}: {rows.Count} rows [{string.Join(",", rows.Take(3))}]";
        }
        catch (PostgresException error)
        {
            return $"{sql}: {error.SqlState}";
        }
    }

    [Fact]
    public async Task Scoped_query_without_a_tenant_fails_on_a_fresh_connection_to_populated_tables_and_through_EF_on_empty_ones()
    {
        _ = _f.Server;
        await using (var connection = new NpgsqlConnection(AppConnection("tenancy-fail-closed-fresh", pooling: false)))
        {
            await connection.OpenAsync();
            var outcomes = new List<string>();
            foreach (var seqScan in new[] { "on", "off" })
            {
                await ReadStringsAsync(connection, $"SELECT set_config('enable_seqscan', '{seqScan}', false)");
                foreach (var sql in new[] { "SELECT id FROM lab_order", "SELECT count(*) FROM lab_order", "SELECT id::text FROM tn_division", "SELECT id::text FROM tn_tenant", "SELECT id FROM ord_patient" })
                    outcomes.Add($"enable_seqscan={seqScan} " + await OutcomeAsync(connection, sql));
            }
            Assert.True(outcomes.All(o => o.EndsWith(": " + PostgresErrorCodes.UndefinedObject)), string.Join("\n", outcomes));
        }

        var owner = TestDatabase.Create();
        try
        {
            await using (var ownerConnection = new NpgsqlConnection(owner))
            {
                await ownerConnection.OpenAsync();
                Assert.Equal(new[] { "0" }, await ReadStringsAsync(ownerConnection, "SELECT count(*) FROM lab_order"));
            }
            await using var db = Context(TestDatabase.App(owner));
            var orders = await Assert.ThrowsAnyAsync<InvalidOperationException>(() => db.Orders.AsNoTracking().CountAsync());
            Assert.IsType<TenantNotSetException>(orders is TenantNotSetException ? orders : orders.InnerException);
            var patients = await Assert.ThrowsAnyAsync<InvalidOperationException>(() => db.Patients.AsNoTracking().CountAsync());
            Assert.IsType<TenantNotSetException>(patients is TenantNotSetException ? patients : patients.InnerException);
            db.Racks.Add(new LabArchiveRack { Code = "RACK-NO-TENANT", Name = "Без тенанта" });
            var save = await Assert.ThrowsAnyAsync<InvalidOperationException>(() => db.SaveChangesAsync());
            Assert.IsType<TenantNotSetException>(save is TenantNotSetException ? save : save.InnerException);
        }
        finally
        {
            TestDatabase.Drop(owner);
        }
    }

    [Fact]
    public async Task Reused_pooled_connection_keeps_no_tenant_and_fails_instead_of_returning_rows()
    {
        _ = _f.Server;
        var connectionString = AppConnection("tenancy-pool", maxPoolSize: 1);
        int pidA;
        await using (var db = Context(connectionString))
        {
            pidA = await db.RunAsTenantAsync(TenantA, async () =>
            {
                Assert.True(await db.Orders.AsNoTracking().CountAsync() > 0);
                return await db.Database.SqlQueryRaw<int>("SELECT pg_backend_pid() AS \"Value\"").SingleAsync();
            });
        }

        await using (var connection = new NpgsqlConnection(connectionString))
        {
            await connection.OpenAsync();
            Assert.Equal(new[] { pidA.ToString() }, await ReadStringsAsync(connection, "SELECT pg_backend_pid()"));
            Assert.Equal(new[] { "" }, await ReadStringsAsync(connection, "SELECT coalesce(current_setting('app.tenant_id', true), '')"));
            var outcomes = new List<string>();
            foreach (var seqScan in new[] { "on", "off" })
            {
                await ReadStringsAsync(connection, $"SELECT set_config('enable_seqscan', '{seqScan}', false)");
                foreach (var sql in new[] { "SELECT id FROM lab_order", "SELECT count(*) FROM lab_order", "SELECT id::text FROM tn_division", "SELECT id::text FROM tn_tenant", "SELECT id FROM ord_patient" })
                    outcomes.Add($"enable_seqscan={seqScan} " + await OutcomeAsync(connection, sql));
            }
            Assert.True(outcomes.All(o => o.EndsWith(": " + PostgresErrorCodes.UndefinedObject)), string.Join("\n", outcomes));
        }

        await using (var db = Context(connectionString))
        {
            var efError = await Assert.ThrowsAnyAsync<InvalidOperationException>(() => db.Orders.AsNoTracking().CountAsync());
            Assert.IsType<TenantNotSetException>(efError is TenantNotSetException ? efError : efError.InnerException);
        }
    }

    [Fact]
    public async Task Patients_belong_to_their_tenant()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var patientB = (await Json(await adminB.PostAsJsonAsync("/api/v1/lab/patients", new { lastName = "Іншого", firstName = "Тенанта", birthDate = "1980-01-01", gender = "M" })))["id"]!.GetValue<string>();
        var listB = (await Json(await adminB.GetAsync("/api/v1/lab/patients?pageSize=200")))["items"]!.AsArray().Select(p => p!["id"]!.GetValue<string>()).ToList();
        Assert.Equal(new[] { patientB }, listB);
        Assert.Equal(HttpStatusCode.NotFound, (await _f.As(DemoDataSeeder.Admin).GetAsync($"/api/v1/lab/patients/{patientB}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await adminB.GetAsync("/api/v1/lab/patients/0b000000-0000-0000-0000-000000000001")).StatusCode);

        await using var connection = new NpgsqlConnection(AppConnection("tenancy-patients"));
        await connection.OpenAsync();
        Assert.Equal(new[] { patientB }, await InTenantAsync(connection, tenantB.TenantId, "SELECT id FROM ord_patient"));
        Assert.DoesNotContain(patientB, await InTenantAsync(connection, TenantA, "SELECT id FROM ord_patient"));

        await using var owner = new NpgsqlConnection(_f.OwnerConnectionString);
        await owner.OpenAsync();
        Assert.Equal(new[] { tenantB.TenantId }, await ReadStringsAsync(owner, $"SELECT tenant_id::text FROM ord_patient WHERE id = '{patientB}'"));
        Assert.Empty(await ReadStringsAsync(owner, "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'mis_patient_card'"));
    }

    [Fact]
    public async Task Migration_0003_moves_the_placeholder_rows_into_the_tenancy_tables_and_back()
    {
        const string t = "0a100000-0000-4000-8000-000000000001", d1 = "0d100000-0000-4000-8000-000000000001", d2 = "0d100000-0000-4000-8000-000000000002",
            employee = "0e100000-0000-4000-8000-000000000001", employeePerson = "0f100000-0000-4000-8000-000000000001", patientPerson = "0f100000-0000-4000-8000-000000000002",
            card = "0b100000-0000-4000-8000-000000000001", link = "0c100000-0000-4000-8000-000000000001", settings = "0c100000-0000-4000-8000-000000000002", role = "0c100000-0000-4000-8000-000000000003", profile = "0c100000-0000-4000-8000-000000000004", profileRole = "0c100000-0000-4000-8000-000000000005",
            e = MedLinkEnums.EmptyGuid;
        string dt = Guid.NewGuid().ToString(), pt = Guid.NewGuid().ToString();
        var owner = TestDatabase.Create(Migration0002);
        try
        {
            await using var connection = new NpgsqlConnection(owner);
            await connection.OpenAsync();
            await ExecuteAsync(connection, $$"""
                INSERT INTO cmn_enum_record (id, caption, code, enum_type, parent_id, value_type, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{dt}}', 'Діагностичне', '02', 'DepartmentType', NULL, 0, now(), '{{e}}', NULL, '{{e}}', 2), ('{{pt}}', 'Лікарі', '0002', 'OrgPositionType', NULL, 0, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO org_organization (id, caption, code, full_name, description, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{t}}', 'Лабораторія переносу', 'MOVE', 'ТОВ Перенос', NULL, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO org_department (id, caption, code, full_name, category, description, location, zip_code, department_type_id, organization_id, parent_id, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{d1}}', 'Основна лабораторія', 'MAIN', 'Основна лабораторія', NULL, NULL, 'Київ', NULL, '{{dt}}', '{{t}}', NULL, now(), '{{e}}', NULL, '{{e}}', 2), ('{{d2}}', 'Пункт забору', 'CP-01', 'Пункт забору', NULL, NULL, NULL, NULL, '{{dt}}', '{{t}}', NULL, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO lab_department_settings (department_id, lab_kind, phone, is_active, created_on, created_by, modified_on, modified_by, record_state, organization_id) VALUES ('{{d1}}', 'LABORATORY', '+380441', true, now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}'), ('{{d2}}', 'COLLECTION_POINT', NULL, false, now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                INSERT INTO cmn_person (id, last_name, name, middle_name, birthday, gender_id, ipn, no_ipn, phone, email, location, caption, description, subscribed_to_notifications, user_id, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{employeePerson}}', 'Співробітник', 'Перенос', NULL, NULL, NULL, NULL, true, NULL, NULL, NULL, 'Співробітник Перенос', NULL, false, 'move-user', now(), '{{e}}', NULL, '{{e}}', 2), ('{{patientPerson}}', 'Пацієнт', 'Перенос', 'Тестович', '1990-05-17', NULL, '3300112233', false, '+380501112233', 'p@example.com', 'Львів', 'Пацієнт Перенос Тестович', NULL, false, NULL, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO org_employee (id, caption, person_id, organization_id, department_id, department_section_id, position_type_id, working_start_date, has_schedule_with_partner, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{employee}}', 'Співробітник Перенос', '{{employeePerson}}', '{{t}}', '{{d1}}', NULL, '{{pt}}', NULL, false, now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO lab_employee_department (id, employee_id, department_id, created_on, created_by, modified_on, modified_by, record_state, organization_id) VALUES ('{{link}}', '{{employee}}', '{{d1}}', now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                INSERT INTO lab_employee_settings (employee_id, lab_role, position_name, digital_signature_cert_id, is_active, created_on, created_by, modified_on, modified_by, record_state, organization_id) VALUES ('{{employee}}', 'LAB_TECHNICIAN', 'Фельдшер-лаборант', 'CERT-MOVE-1', true, now(), '{{e}}', now(), '{{e}}', 2, '{{t}}');
                INSERT INTO sys_role (id, is_active, record_state, modified_by, modified_on, created_by, created_on, caption) VALUES ('{{role}}', true, 2, '{{e}}', now(), '{{e}}', now(), 'Фельдшер-лаборант');
                INSERT INTO sys_profile (id, is_active, type_id, record_state, modified_by, modified_on, created_by, created_on, caption) VALUES ('{{profile}}', true, 'LAB_ROLE', 2, '{{e}}', now(), '{{e}}', now(), 'Фельдшер-лаборант');
                INSERT INTO sys_profile_role (id, profile_id, role_id, record_state, modified_by, modified_on, created_by, created_on) VALUES ('{{profileRole}}', '{{profile}}', '{{role}}', 2, '{{e}}', now(), '{{e}}', now());
                INSERT INTO mis_patient_card (id, person_id, organization_id, reg_number, reg_date, caption, birthday, gender_id, document_type_id, patient_card_type_id, privacy_request_type_id, location, description, last_name_latin, first_name_latin, created_on, created_by, modified_on, modified_by, record_state) VALUES ('{{card}}', '{{patientPerson}}', '{{t}}', 'AMB-1', now(), 'Пацієнт Перенос Тестович', '1990-05-17', NULL, '{{e}}', '{{e}}', '{{e}}', NULL, NULL, 'Patsiient', 'Perenos', now(), '{{e}}', NULL, '{{e}}', 2);
                INSERT INTO lab_settings (id, name, edrpou, address, phone, email, license_number, logo_base64, director_name, working_hours, order_number_mask, barcode_prefix, report_footer, panic_phone, cold_chain_min_c, cold_chain_max_c, label_printer_host, label_printer_port, label_printer_name, report_templates_json, created_on, created_by, modified_on, modified_by, record_state, organization_id) VALUES ('{{settings}}', 'Лабораторія переносу', '12345678', 'Київ, вул. Тестова 1', '+380442', 'lab@example.com', 'LIC-1', NULL, 'Директор', NULL, '{yyMM}-{000000}', NULL, NULL, NULL, 2, 8, NULL, 9100, NULL, '{}', now(), '{{e}}', NULL, '{{e}}', 2, '{{t}}');
                INSERT INTO lab_numerator (code, name, mask, current_value, period_key, reset_by_period, modified_on, organization_id) VALUES ('lab_order_number', 'Номер', '{yyMM}-{000000}', 7, '2610', true, NULL, '{{t}}'), ('static', 'Без скидання', '{000}', 3, NULL, false, NULL, '{{t}}');
                INSERT INTO lab_counter (counter_code, counter_value, organization_id) VALUES ('lab_tube_barcode_ean8', 4800, '{{t}}');
                """);

            await using (var db = Context(owner)) await db.GetService<IMigrator>().MigrateAsync();

            Assert.Equal(new[] { $"{t}|Лабораторія переносу|laboratory" }, await ReadStringsAsync(connection, "SELECT id || '|' || name || '|' || type FROM tn_tenant"));
            Assert.Equal(new[] { $"CP-01|collection_point||false|{t}", $"MAIN|laboratory|+380441|true|{t}" }, await ReadStringsAsync(connection, "SELECT code || '|' || type || '|' || coalesce(phone, '') || '|' || is_active || '|' || tenant_id FROM tn_division ORDER BY code"));
            Assert.Equal(new[] { $"{employee}|{t}|{employeePerson}|true|{role}" }, await ReadStringsAsync(connection, "SELECT id || '|' || tenant_id || '|' || user_id || '|' || is_active || '|' || role_id FROM id_membership"));
            Assert.Equal(new[] { $"{employee}|{t}|{d1}" }, await ReadStringsAsync(connection, "SELECT membership_id || '|' || tenant_id || '|' || department_id FROM org_employee"));
            Assert.Equal(new[] { $"{employee}|{d1}|{t}" }, await ReadStringsAsync(connection, "SELECT membership_id || '|' || division_id || '|' || tenant_id FROM id_membership_division"));
            Assert.Equal(new[] { $"{card}|Пацієнт|Перенос|Тестович|3300112233|+380501112233|Львів|Patsiient|{t}" }, await ReadStringsAsync(connection, "SELECT id || '|' || last_name || '|' || name || '|' || middle_name || '|' || ipn || '|' || phone || '|' || location || '|' || last_name_latin || '|' || tenant_id FROM ord_patient"));
            Assert.Equal(new[] { employeePerson }, await ReadStringsAsync(connection, "SELECT id FROM cmn_person"));
            Assert.Equal(new[] { "Лабораторія переносу|12345678|Київ, вул. Тестова 1|LIC-1" }, await ReadStringsAsync(connection, "SELECT legal_name || '|' || edrpou || '|' || address || '|' || license_number FROM tn_requisites"));
            Assert.Equal(new[] { "Europe/Kyiv|uk" }, await ReadStringsAsync(connection, "SELECT time_zone || '|' || report_language FROM tn_settings"));
            Assert.Equal(new[] { "lab_order_number|2610|7", "lab_tube_barcode_ean8|ALL|4800", "static|ALL|3" }, await ReadStringsAsync(connection, "SELECT key || '|' || scope_key || '|' || value FROM tn_sequence ORDER BY key"));
            Assert.Empty(await ReadStringsAsync(connection, "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('org_organization', 'org_department', 'lab_department_settings', 'lab_employee_department', 'mis_patient_card', 'lab_counter')"));
            Assert.Empty(await ReadStringsAsync(connection, "SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'lab_settings' AND column_name IN ('name', 'edrpou', 'address')"));

            await using (var db = Context(owner)) await db.GetService<IMigrator>().MigrateAsync(Migration0002);

            Assert.Equal(new[] { $"{t}|Лабораторія переносу" }, await ReadStringsAsync(connection, "SELECT id || '|' || caption FROM org_organization"));
            Assert.Equal(new[] { $"{d2}|CP-01|Пункт забору|COLLECTION_POINT|false", $"{d1}|MAIN|Основна лабораторія|LABORATORY|true" }, await ReadStringsAsync(connection, "SELECT d.id || '|' || d.code || '|' || d.caption || '|' || s.lab_kind || '|' || s.is_active FROM org_department d JOIN lab_department_settings s ON s.department_id = d.id ORDER BY d.code"));
            Assert.Equal(new[] { $"{card}|Пацієнт|3300112233|{t}" }, await ReadStringsAsync(connection, "SELECT c.id || '|' || p.last_name || '|' || p.ipn || '|' || c.organization_id FROM mis_patient_card c JOIN cmn_person p ON p.id = c.person_id"));
            Assert.Equal(new[] { "2" }, await ReadStringsAsync(connection, "SELECT count(*) FROM cmn_person"));
            Assert.Equal(new[] { $"{employee}|{d1}" }, await ReadStringsAsync(connection, "SELECT employee_id || '|' || department_id FROM lab_employee_department"));
            Assert.Equal(new[] { "lab_order_number|7|2610", "static|3|-" }, await ReadStringsAsync(connection, "SELECT code || '|' || current_value || '|' || coalesce(period_key, '-') FROM lab_numerator ORDER BY code"));
            Assert.Equal(new[] { "lab_tube_barcode_ean8|4800" }, await ReadStringsAsync(connection, "SELECT counter_code || '|' || counter_value FROM lab_counter"));
            Assert.Equal(new[] { "Лабораторія переносу|12345678" }, await ReadStringsAsync(connection, "SELECT name || '|' || edrpou FROM lab_settings"));
            Assert.Equal(new[] { t }, await ReadStringsAsync(connection, "SELECT organization_id FROM org_employee"));
            Assert.Equal(new[] { "72" }, await ReadStringsAsync(connection, "SELECT count(*) FROM pg_policies WHERE schemaname = 'public' AND policyname = 'organization_isolation'"));
        }
        finally
        {
            TestDatabase.Drop(owner);
        }
    }

    [Fact]
    public async Task Background_job_without_RunAs_fails_and_with_RunAs_works_per_tenant()
    {
        var tenantB = await _f.CreateTenantAsync();
        var connectorIds = new Dictionary<string, string>();
        foreach (var tenantId in new[] { TenantA, tenantB.TenantId })
        {
            using var scope = _f.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await db.RunAsTenantAsync(tenantId, async () =>
            {
                var connector = new LabConnectorInstallation { Name = "Фонова задача", InstallKey = ConnectorService.NewInstallKey() };
                db.Connectors.Add(connector);
                db.ConnectorLogs.Add(new LabConnectorLog { ConnectorId = connector.Id, At = DateTime.UtcNow.AddYears(-5), Message = "old" });
                await db.SaveChangesAsync();
                connectorIds[tenantId] = connector.Id;
            });
        }

        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await Assert.ThrowsAnyAsync<InvalidOperationException>(() => db.ConnectorLogs.Where(l => l.At < DateTime.UtcNow.AddYears(-1)).ExecuteDeleteAsync());
        }

        await _f.Services.GetRequiredService<RetentionCleanupService>().RunOnceAsync();

        await using var owner = new NpgsqlConnection(_f.OwnerConnectionString);
        await owner.OpenAsync();
        foreach (var (tenantId, connectorId) in connectorIds)
        {
            Assert.Empty(await ReadStringsAsync(owner, $"SELECT id FROM lab_connector_log WHERE connector_id = '{connectorId}'"));
            Assert.Equal(new[] { tenantId }, await ReadStringsAsync(owner, $"SELECT tenant_id::text FROM lab_connector_installation WHERE id = '{connectorId}'"));
        }
    }

    [Fact]
    public async Task Connector_requests_run_in_the_tenant_of_their_installation()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var adminA = _f.As(DemoDataSeeder.Admin);

        var created = await Json(await adminB.PostAsJsonAsync("/api/v1/lab/connectors", new { name = "Коннектор організації B", pollIntervalSec = 30, heartbeatIntervalSec = 30 }));
        var connectorId = created["id"]!.GetValue<string>();
        var reg = await Json(await _f.CreateClient().PostAsJsonAsync("/api/v1/lab/connector/register", new { installKey = created["installKey"]!.GetValue<string>(), hostName = "LAB-B", osDescription = "Windows 11", version = "4.0.0" }));
        var connector = _f.CreateClient();
        connector.DefaultRequestHeaders.Add("X-MedLink-ApiKey", reg["apiKey"]!.GetValue<string>());
        Assert.Equal(connectorId, (await Json(await connector.GetAsync("/api/v1/lab/connector/config")))["connectorId"]!.GetValue<string>());
        Assert.Equal(HttpStatusCode.Accepted, (await connector.PostAsJsonAsync("/api/v1/lab/connector/logs", new { entries = new[] { new { at = DateTime.UtcNow, level = "INFO", message = "tenancy" } } })).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await connector.GetAsync("/api/v1/lab/connector/orders/by-barcode/" + await AnyBarcodeOfTenantAAsync())).StatusCode);

        await using var owner = new NpgsqlConnection(_f.OwnerConnectionString);
        await owner.OpenAsync();
        Assert.Equal(new[] { tenantB.TenantId }, await ReadStringsAsync(owner, $"SELECT tenant_id::text FROM lab_connector_installation WHERE id = '{connectorId}'"));
        var logTenants = await ReadStringsAsync(owner, $"SELECT tenant_id::text FROM lab_connector_log WHERE connector_id = '{connectorId}'");
        Assert.NotEmpty(logTenants);
        Assert.All(logTenants, t => Assert.Equal(tenantB.TenantId, t));

        var listA = (await Json(await adminA.GetAsync("/api/v1/lab/connectors"))).AsArray();
        Assert.DoesNotContain(listA, c => c!["id"]!.GetValue<string>() == connectorId);
        Assert.Equal(HttpStatusCode.NotFound, (await adminA.GetAsync($"/api/v1/lab/connectors/{connectorId}")).StatusCode);
    }

    private async Task<string> AnyBarcodeOfTenantAAsync()
    {
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        return await db.RunAsTenantAsync(TenantA, () => db.Samples.AsNoTracking().Select(s => s.Barcode).FirstAsync());
    }

    [Fact]
    public async Task Insert_carries_the_tenant_and_a_foreign_tenant_is_rejected()
    {
        var tenantB = await _f.CreateTenantAsync();
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            var stamped = new LabArchiveRack { Code = "RACK-B-" + Guid.NewGuid().ToString("N")[..6], Name = "Штатив B" };
            await db.RunAsTenantAsync(tenantB.TenantId, async () =>
            {
                db.Racks.Add(stamped);
                await db.SaveChangesAsync();
            });
            Assert.Equal(tenantB.TenantId, stamped.TenantId);

            await db.RunAsTenantAsync(tenantB.TenantId, async () =>
            {
                db.Racks.Add(new LabArchiveRack { Code = "RACK-X", Name = "Чужий", TenantId = TenantA });
                await Assert.ThrowsAsync<TenantMismatchException>(() => db.SaveChangesAsync());
                db.ChangeTracker.Clear();
            });
        }

        await using var connection = new NpgsqlConnection(AppConnection("tenancy-insert"));
        await connection.OpenAsync();
        var error = await Assert.ThrowsAsync<PostgresException>(() => InTenantAsync(connection, tenantB.TenantId, $"""
            INSERT INTO lab_archive_rack (id, code, name, temperature_celsius, rows_count, cols_count, is_active, created_on, created_by, modified_by, record_state, tenant_id)
            VALUES ('{Guid.NewGuid()}', 'RACK-SQL', 'SQL', -20, 1, 1, true, now(), '{Guid.Empty}', '{Guid.Empty}', 2, '{TenantA}') RETURNING id
            """));
        Assert.Equal(PostgresErrorCodes.InsufficientPrivilege, error.SqlState);
    }

    [Fact]
    public async Task Profile_of_another_tenant_sees_none_of_tenant_A_orders()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var adminA = _f.As(DemoDataSeeder.Admin);
        var ordersA = await Json(await adminA.GetAsync("/api/v1/lab/orders"));
        var orderA = ordersA["items"]![0]!["id"]!.GetValue<string>();

        Assert.Equal(0, (await Json(await adminB.GetAsync("/api/v1/lab/orders")))["total"]!.GetValue<int>());
        Assert.Equal(HttpStatusCode.NotFound, (await adminB.GetAsync($"/api/v1/lab/orders/{orderA}")).StatusCode);
        Assert.Equal(tenantB.TenantId, (await Json(await adminB.GetAsync("/api/account/info")))["organizationId"]!.GetValue<string>());
    }

    [Fact]
    public async Task Department_restriction_limits_orders_to_the_allowed_departments()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminA = _f.As(DemoDataSeeder.Admin);
        var all = (await Json(await adminA.GetAsync("/api/v1/lab/orders")))["total"]!.GetValue<int>();
        var inDept = (await Json(await adminA.GetAsync($"/api/v1/lab/orders?departmentId={_f.DivisionId(DemoDataSeeder.DeptCode)}")))["total"]!.GetValue<int>();
        Assert.True(inDept > 0 && inDept < all);

        var restricted = new TestTenant(TenantA, _f.DivisionId(DemoDataSeeder.DeptCode), UuidV7.New(), "test-user-" + Guid.NewGuid().ToString("N"), tenantB.ProfileId);
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
            await db.RunAsTenantAsync(TenantA, async () =>
            {
                var person = new CmnPerson { Id = Guid.NewGuid().ToString(), LastName = "Обмежена", Name = "Підрозділом", UserId = restricted.IdentityUserId };
                db.Persons.Add(person);
                db.Employees.Add(new OrgEmployee
                {
                    Id = restricted.EmployeeId, PersonId = person.Id, Caption = "Обмежена Підрозділом", DepartmentId = _f.DivisionId(DemoDataSeeder.DeptCode),
                    PositionTypeId = await db.EnumRecordIdAsync("OrgPositionType", "0002"), LabSettings = new LabEmployeeSettings { EmployeeId = restricted.EmployeeId, LabRole = "LAB_ADMIN" },
                    Membership = new IdMembership { Id = restricted.EmployeeId, TenantId = TenantA, UserId = person.Id, RoleId = "00000000-0000-4000-8000-00000000d001" }
                });
                db.MembershipDivisions.Add(new IdMembershipDivision { MembershipId = restricted.EmployeeId, DivisionId = _f.DivisionId(DemoDataSeeder.DeptCode) });
                db.UserProfiles!.Add(new global::Core.Security.Models.UserProfile { Id = Guid.NewGuid(), UserId = Guid.Parse(restricted.EmployeeId), ProfileId = restricted.ProfileId });
                await db.SaveChangesAsync();
            });
        }

        var client = await _f.AsAsync(restricted);
        Assert.Equal(inDept, (await Json(await client.GetAsync("/api/v1/lab/orders")))["total"]!.GetValue<int>());
        Assert.Equal(0, (await Json(await client.GetAsync($"/api/v1/lab/orders?departmentId={_f.DivisionId(DemoDataSeeder.CollectionPointCode)}")))["total"]!.GetValue<int>());
    }
}
