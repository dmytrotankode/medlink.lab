using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using MedLink.LIS.Api.Data;
using MedLink.LIS.Api.Data.Entities;
using MedLink.LIS.Api.Data.Seed;
using MedLink.LIS.Api.Services;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

public class TenantIsolationTests : IClassFixture<LisApiFactory>
{
    private string TenantA => _f.TenantId;
    private const string Lab = "api/v1/lab/";

    private static readonly string[] Endpoints =
    {
        "GET health", "GET verify/{token}",
        "GET api/Account/logout", "POST api/Account/try-authenticate", "POST api/Account/authenticate", "GET api/Account/info", "GET api/Account/users", "GET api/Account/users/ext/{id}", "GET api/Account/userProfiles",
        "GET api/v1/lab/worklist", "GET api/v1/lab/worklist/summary", "POST api/v1/lab/worklist/autoverify", "GET api/v1/lab/worklist/batches", "POST api/v1/lab/worklist/batches", "PUT api/v1/lab/worklist/batches/{id}", "DELETE api/v1/lab/worklist/batches/{id}", "GET api/v1/lab/worklist/batches/{id}/print",
        "PUT api/v1/lab/results/{orderTestId}", "GET api/v1/lab/results/{orderTestId}", "POST api/v1/lab/results/{orderTestId}/verify", "POST api/v1/lab/results/verify-batch", "POST api/v1/lab/results/{orderTestId}/reject", "POST api/v1/lab/results/{orderTestId}/rerun", "POST api/v1/lab/results/{orderTestId}/reopen", "DELETE api/v1/lab/results/{orderTestId}", "POST api/v1/lab/results/{orderTestId}/assign-analyzer", "POST api/v1/lab/results/{orderTestId}/transition", "GET api/v1/lab/results/{orderTestId}/history",
        "GET api/v1/lab/results/unmatched", "POST api/v1/lab/results/unmatched/{id}/link", "DELETE api/v1/lab/results/unmatched/{id}",
        "GET api/v1/lab/panic-calls", "POST api/v1/lab/panic-calls", "PUT api/v1/lab/panic-calls/{id}", "DELETE api/v1/lab/panic-calls/{id}", "GET api/v1/lab/panic/pending",
        "GET api/v1/lab/qc/materials", "GET api/v1/lab/qc/materials/{id}", "POST api/v1/lab/qc/materials", "PUT api/v1/lab/qc/materials/{id}", "DELETE api/v1/lab/qc/materials/{id}", "DELETE api/v1/lab/qc/materials/{id}/targets/{targetId}", "GET api/v1/lab/qc/levey-jennings",
        "GET api/v1/lab/qc/results", "POST api/v1/lab/qc/results", "PUT api/v1/lab/qc/results/{id}", "DELETE api/v1/lab/qc/results/{id}", "GET api/v1/lab/qc/lockouts", "POST api/v1/lab/qc/lockouts", "POST api/v1/lab/qc/lockouts/{id}/resolve", "DELETE api/v1/lab/qc/lockouts/{id}", "GET api/v1/lab/qc/report",
        "GET api/v1/lab/biobank/racks", "GET api/v1/lab/biobank/racks/{id}", "POST api/v1/lab/biobank/racks", "PUT api/v1/lab/biobank/racks/{id}", "DELETE api/v1/lab/biobank/racks/{id}", "GET api/v1/lab/biobank/racks/{id}/cells", "POST api/v1/lab/biobank/cells/place", "POST api/v1/lab/biobank/cells/{id}/remove", "PUT api/v1/lab/biobank/cells/{id}", "DELETE api/v1/lab/biobank/cells/{id}", "GET api/v1/lab/biobank/search", "GET api/v1/lab/biobank/expired",
        "GET api/v1/lab/reagents/lots", "GET api/v1/lab/reagents/lots/{id}", "POST api/v1/lab/reagents/lots", "PUT api/v1/lab/reagents/lots/{id}", "DELETE api/v1/lab/reagents/lots/{id}", "POST api/v1/lab/reagents/lots/{id}/consume", "GET api/v1/lab/reagents/alerts",
        "GET api/v1/lab/microbiology/cultures", "GET api/v1/lab/microbiology/cultures/{id}", "POST api/v1/lab/microbiology/cultures", "PUT api/v1/lab/microbiology/cultures/{id}", "DELETE api/v1/lab/microbiology/cultures/{id}", "POST api/v1/lab/microbiology/cultures/{id}/transition", "POST api/v1/lab/microbiology/cultures/{id}/isolates",
        "PUT api/v1/lab/microbiology/isolates/{id}", "DELETE api/v1/lab/microbiology/isolates/{id}", "POST api/v1/lab/microbiology/isolates/{id}/susceptibility", "DELETE api/v1/lab/microbiology/susceptibility/{id}", "GET api/v1/lab/microbiology/cultures/{id}/report",
        "GET api/v1/lab/analytics/tat", "GET api/v1/lab/analytics/volume", "GET api/v1/lab/analytics/export.xlsx", "GET api/v1/lab/analytics/export.csv", "GET api/v1/lab/analytics/export.pdf", "GET api/v1/lab/audit", "POST api/v1/lab/maintenance/retention/run",
        "GET api/v1/lab/settings/lab", "PUT api/v1/lab/settings/lab", "GET api/v1/lab/settings/users", "GET api/v1/lab/settings/users/{id}", "POST api/v1/lab/settings/users", "PUT api/v1/lab/settings/users/{id}", "DELETE api/v1/lab/settings/users/{id}", "GET api/v1/lab/settings/numerators", "PUT api/v1/lab/settings/numerators/{code}", "GET api/v1/lab/settings/counters",
        "GET api/v1/lab/portal/{patientId}/orders", "GET api/v1/lab/portal/{patientId}/orders/{id}", "GET api/v1/lab/portal/{patientId}/orders/{id}/report.pdf", "GET api/v1/lab/portal/{patientId}/trend/{testCode}", "GET api/v1/lab/portal/{patientId}/history", "GET api/v1/lab/portal/{patientId}/notifications",
        "POST api/v1/lab/import/results",
        "GET api/v1/lab/analyzers", "GET api/v1/lab/analyzers/{id}", "POST api/v1/lab/analyzers", "PUT api/v1/lab/analyzers/{id}", "DELETE api/v1/lab/analyzers/{id}", "GET api/v1/lab/analyzers/{id}/messages", "DELETE api/v1/lab/analyzers/{id}/messages/{messageId}", "POST api/v1/lab/analyzers/{id}/simulate", "GET api/v1/lab/analyzers/{id}/order-preview/{barcode}",
        "GET api/v1/lab/connectors", "GET api/v1/lab/connectors/{id}", "POST api/v1/lab/connectors", "PUT api/v1/lab/connectors/{id}", "DELETE api/v1/lab/connectors/{id}", "POST api/v1/lab/connectors/{id}/disable", "POST api/v1/lab/connectors/{id}/enable", "POST api/v1/lab/connectors/{id}/mark-offline", "POST api/v1/lab/connectors/{id}/rotate-key", "POST api/v1/lab/connectors/{id}/commands", "GET api/v1/lab/connectors/{id}/download", "GET api/v1/lab/connectors/{id}/logs",
        "POST api/v1/lab/connector/register", "GET api/v1/lab/connector/config", "POST api/v1/lab/connector/heartbeat", "GET api/v1/lab/connector/orders/by-barcode/{barcode}", "GET api/v1/lab/connector/orders/pending", "POST api/v1/lab/connector/results", "POST api/v1/lab/connector/messages", "POST api/v1/lab/connector/logs",
        "GET api/v1/lab/clients", "GET api/v1/lab/clients/{id}/orders", "POST api/v1/lab/clients/{id}/registry", "POST api/v1/lab/payers/{id}/invoices/period", "GET api/v1/lab/payers/{id}/invoices",
        "GET api/v1/lab/performers", "GET api/v1/lab/performers/{id}", "POST api/v1/lab/performers", "PUT api/v1/lab/performers/{id}", "DELETE api/v1/lab/performers/{id}", "PUT api/v1/lab/performers/{id}/tests", "PUT api/v1/lab/order-tests/{orderTestId}/performer",
        "GET api/v1/lab/send-out/queue", "GET api/v1/lab/send-out", "GET api/v1/lab/send-out/{id}", "POST api/v1/lab/send-out", "POST api/v1/lab/send-out/{id}/dispatch", "POST api/v1/lab/send-out/{id}/accept", "POST api/v1/lab/send-out/{id}/cancel", "POST api/v1/lab/send-out/items/{itemId}/result", "POST api/v1/lab/send-out/items/{itemId}/reject", "POST api/v1/lab/send-out/items/{itemId}/recall", "POST api/v1/lab/send-out/{id}/import",
        "GET api/v1/lab/orders/{orderId}/attachments", "POST api/v1/lab/orders/{orderId}/attachments", "GET api/v1/lab/attachments/{id}/content", "GET api/v1/lab/ehealth/exchange-log", "GET api/v1/lab/referrals/ehealth/lookup", "GET api/v1/lab/referrals/journal",
        "GET api/v1/lab/payers", "POST api/v1/lab/payers", "PUT api/v1/lab/payers/{id}", "GET api/v1/lab/price-lists", "POST api/v1/lab/price-lists", "PUT api/v1/lab/price-lists/{id}", "GET api/v1/lab/patients/{patientId}/insurances", "POST api/v1/lab/patients/{patientId}/insurances", "PUT api/v1/lab/patients/{patientId}/insurances/{id}", "POST api/v1/lab/billing/quote",
        "GET api/v1/lab/orders/{id}/billing", "PUT api/v1/lab/orders/{id}/payer", "PUT api/v1/lab/orders/{id}/charges/{chargeId}/patient-choice", "POST api/v1/lab/orders/{id}/payments", "POST api/v1/lab/orders/{id}/invoice", "GET api/v1/lab/orders/{id}/receipt", "POST api/v1/lab/invoices/{id}/cancel", "POST api/v1/lab/invoices/{id}/paid", "GET api/v1/lab/invoices/{id}/print",
        "GET api/v1/lab/context/me", "GET api/v1/lab/context/employees",
        "GET api/v1/lab/dictionaries", "GET api/v1/lab/dictionaries/order-matrix", "GET api/v1/lab/dictionaries/order-matrix/favorites", "PUT api/v1/lab/dictionaries/order-matrix/favorites", "DELETE api/v1/lab/dictionaries/order-matrix/favorites/{id}", "POST api/v1/lab/dictionaries/import", "GET api/v1/lab/dictionaries/tests/{code}/profiles",
        "GET api/v1/lab/dictionaries/{name}", "GET api/v1/lab/dictionaries/{name}/{id}", "POST api/v1/lab/dictionaries/{name}", "PUT api/v1/lab/dictionaries/{name}/{id}", "DELETE api/v1/lab/dictionaries/{name}/{id}",
        "GET api/v1/lab/norms/layers", "GET api/v1/lab/norms/combinations", "GET api/v1/lab/norms/combinations/{id}", "POST api/v1/lab/norms/combinations", "PUT api/v1/lab/norms/combinations/{id}", "DELETE api/v1/lab/norms/combinations/{id}", "POST api/v1/lab/norms/resolve-cascade", "GET api/v1/lab/norms/service-card/{profileId}",
        "GET api/v1/lab/patients", "GET api/v1/lab/patients/{id}", "POST api/v1/lab/patients", "PUT api/v1/lab/patients/{id}", "DELETE api/v1/lab/patients/{id}", "GET api/v1/lab/patients/{id}/history", "GET api/v1/lab/patients/{id}/trend/{testCode}",
        "GET api/v1/lab/orders", "GET api/v1/lab/orders/by-barcode/{barcode}", "GET api/v1/lab/orders/{id}", "GET api/v1/lab/orders/{id}/transitions", "POST api/v1/lab/orders/tube-plan", "POST api/v1/lab/orders", "POST api/v1/lab/orders/batch", "PUT api/v1/lab/orders/{id}", "DELETE api/v1/lab/orders/{id}",
        "POST api/v1/lab/orders/{id}/tests", "DELETE api/v1/lab/orders/{id}/tests/{orderTestId}", "POST api/v1/lab/orders/{id}/samples", "POST api/v1/lab/orders/{id}/cancel", "POST api/v1/lab/orders/{id}/reject", "POST api/v1/lab/orders/{id}/release", "POST api/v1/lab/orders/{id}/reopen",
        "GET api/v1/lab/orders/{id}/report", "GET api/v1/lab/orders/{id}/report.pdf", "GET api/v1/lab/orders/{id}/labels", "GET api/v1/lab/orders/{id}/journal-entries", "GET api/v1/lab/verify/{token}",
        "GET api/v1/lab/samples", "GET api/v1/lab/samples/{barcode}", "POST api/v1/lab/samples/{barcode}/collect", "POST api/v1/lab/samples/{barcode}/uncollect", "POST api/v1/lab/samples/{barcode}/receive", "POST api/v1/lab/samples/{barcode}/reject", "PUT api/v1/lab/samples/{barcode}", "POST api/v1/lab/samples/{barcode}/replace", "DELETE api/v1/lab/samples/{barcode}",
        "POST api/v1/lab/samples/{barcode}/transition", "GET api/v1/lab/samples/{barcode}/label", "POST api/v1/lab/samples/{barcode}/split", "GET api/v1/lab/samples/{barcode}/tree", "POST api/v1/lab/samples/{barcode}/stage", "GET api/v1/lab/samples/{barcode}/stages", "DELETE api/v1/lab/samples/stage-events/{eventId}",
        "GET api/v1/lab/workflow-templates", "PUT api/v1/lab/workflow-templates/{code}",
        "GET api/v1/lab/logistics/manifests", "GET api/v1/lab/logistics/manifests/{id}", "POST api/v1/lab/logistics/manifests", "PUT api/v1/lab/logistics/manifests/{id}", "DELETE api/v1/lab/logistics/manifests/{id}", "DELETE api/v1/lab/logistics/manifests/{id}/items/{itemId}", "POST api/v1/lab/logistics/manifests/{id}/dispatch", "POST api/v1/lab/logistics/manifests/{id}/receive", "POST api/v1/lab/logistics/manifests/{id}/reject",
        "GET api/v1/lab/sections", "GET api/v1/lab/sections/{id}", "POST api/v1/lab/sections", "PUT api/v1/lab/sections/{id}", "DELETE api/v1/lab/sections/{id}", "GET api/v1/lab/sections/{id}/journal", "POST api/v1/lab/sections/{id}/journal/renumber-preview", "PUT api/v1/lab/sections/journal-entries/{entryId}/status"
    };

    private static readonly HashSet<string> PublicTokenEndpoints = new() { "GET verify/{token}", "GET api/v1/lab/verify/{token}", "POST api/v1/lab/connector/register" };

    private static readonly Dictionary<string, string> ParameterSources = new()
    {
        ["verify/{token}"] = "SELECT verify_token FROM lab_order WHERE tenant_id = @a AND verify_token IS NOT NULL",
        ["ext/{id}"] = "SELECT id FROM org_employee WHERE tenant_id = @a",
        ["batches/{id}"] = "SELECT id FROM lab_worklist_batch WHERE tenant_id = @a",
        ["results/{orderTestId}"] = "SELECT order_test_id FROM lab_test_result WHERE tenant_id = @a",
        ["unmatched/{id}"] = "SELECT id FROM lab_unmatched_result WHERE tenant_id = @a",
        ["panic-calls/{id}"] = "SELECT id FROM lab_panic_call WHERE tenant_id = @a",
        ["materials/{id}"] = "SELECT qc_material_id FROM lab_qc_target WHERE tenant_id = @a",
        ["targets/{targetId}"] = "SELECT id FROM lab_qc_target WHERE tenant_id = @a",
        ["qc/results/{id}"] = "SELECT id FROM lab_qc_result WHERE tenant_id = @a",
        ["lockouts/{id}"] = "SELECT id FROM lab_analyzer_lockout WHERE tenant_id = @a",
        ["racks/{id}"] = "SELECT id FROM lab_archive_rack WHERE tenant_id = @a",
        ["cells/{id}"] = "SELECT id FROM lab_archive_cell WHERE tenant_id = @a",
        ["lots/{id}"] = "SELECT id FROM lab_reagent_lot WHERE tenant_id = @a",
        ["cultures/{id}"] = "SELECT id FROM lab_culture_order WHERE tenant_id = @a",
        ["isolates/{id}"] = "SELECT id FROM lab_isolate WHERE tenant_id = @a",
        ["susceptibility/{id}"] = "SELECT id FROM lab_susceptibility_result WHERE tenant_id = @a",
        ["users/{id}"] = "SELECT id FROM org_employee WHERE tenant_id = @a",
        ["numerators/{code}"] = "SELECT code FROM lab_numerator WHERE tenant_id = @a",
        ["portal/{patientId}"] = "SELECT patient_id FROM lab_order WHERE tenant_id = @a",
        ["patients/{patientId}"] = "SELECT patient_card_id FROM ord_patient_insurance WHERE tenant_id = @a",
        ["patients/{id}"] = "SELECT patient_id FROM lab_order WHERE tenant_id = @a",
        ["orders/{id}"] = "SELECT id FROM lab_order WHERE tenant_id = @a",
        ["orders/{orderId}"] = "SELECT order_id FROM lab_order_attachment WHERE tenant_id = @a",
        ["trend/{testCode}"] = "SELECT test_code FROM lab_order_test WHERE tenant_id = @a",
        ["analyzers/{id}"] = "SELECT analyzer_id FROM lab_analyzer_message WHERE tenant_id = @a",
        ["messages/{messageId}"] = "SELECT id FROM lab_analyzer_message WHERE tenant_id = @a",
        ["order-preview/{barcode}"] = "SELECT barcode FROM lab_order_sample WHERE tenant_id = @a",
        ["connectors/{id}"] = "SELECT id FROM lab_connector_installation WHERE tenant_id = @a",
        ["by-barcode/{barcode}"] = "SELECT barcode FROM lab_order_sample WHERE tenant_id = @a",
        ["clients/{id}"] = "SELECT id FROM lab_payer WHERE tenant_id = @a AND kind = 'CLINIC'",
        ["payers/{id}"] = "SELECT id FROM lab_payer WHERE tenant_id = @a",
        ["performers/{id}"] = "SELECT id FROM lab_performer WHERE tenant_id = @a",
        ["order-tests/{orderTestId}"] = "SELECT id FROM lab_order_test WHERE tenant_id = @a",
        ["send-out/{id}"] = "SELECT id FROM lab_send_out WHERE tenant_id = @a",
        ["items/{itemId}"] = "SELECT id FROM lab_send_out_item WHERE tenant_id = @a",
        ["attachments/{id}"] = "SELECT id FROM lab_order_attachment WHERE tenant_id = @a",
        ["price-lists/{id}"] = "SELECT id FROM lab_price_list WHERE tenant_id = @a",
        ["insurances/{id}"] = "SELECT id FROM ord_patient_insurance WHERE tenant_id = @a",
        ["charges/{chargeId}"] = "SELECT id FROM lab_order_charge WHERE tenant_id = @a",
        ["invoices/{id}"] = "SELECT id FROM lab_invoice WHERE tenant_id = @a",
        ["favorites/{id}"] = "SELECT id FROM lab_order_favorite WHERE tenant_id = @a",
        ["tests/{code}"] = "SELECT code FROM lab_test_definition WHERE tenant_id = @a",
        ["combinations/{id}"] = "SELECT id FROM lab_reference_layer WHERE tenant_id = @a",
        ["service-card/{profileId}"] = "SELECT id FROM lab_test_profile WHERE tenant_id = @a",
        ["tests/{orderTestId}"] = "SELECT id FROM lab_order_test WHERE tenant_id = @a",
        ["samples/{barcode}"] = "SELECT barcode FROM lab_order_sample WHERE tenant_id = @a",
        ["stage-events/{eventId}"] = "SELECT id FROM lab_sample_stage_event WHERE tenant_id = @a",
        ["workflow-templates/{code}"] = "SELECT code FROM lab_workflow_template WHERE tenant_id = @a",
        ["manifests/{id}"] = "SELECT logistics_id FROM lab_sample_logistics_item WHERE tenant_id = @a",
        ["manifests/{id}/items/{itemId}"] = "SELECT id FROM lab_sample_logistics_item WHERE tenant_id = @a",
        ["sections/{id}"] = "SELECT id FROM lab_section WHERE tenant_id = @a",
        ["journal-entries/{entryId}"] = "SELECT id FROM lab_section_journal_entry WHERE tenant_id = @a"
    };

    private static readonly Dictionary<string, string> DictionarySources = new()
    {
        ["biomaterials"] = "SELECT id::text FROM lab_biomaterial_type WHERE tenant_id = @a",
        ["tube-types"] = "SELECT id::text FROM lab_tube_type WHERE tenant_id = @a",
        ["method-types"] = "SELECT id::text FROM lab_method_type WHERE tenant_id = @a",
        ["analyzer-types"] = "SELECT id::text FROM lab_analyzer_type WHERE tenant_id = @a",
        ["tests"] = "SELECT id FROM lab_test_definition WHERE tenant_id = @a",
        ["profiles"] = "SELECT id FROM lab_test_profile WHERE tenant_id = @a",
        ["reflex-rules"] = "SELECT id FROM lab_reflex_rule WHERE tenant_id = @a",
        ["organisms"] = "SELECT id::text FROM lab_micro_organism WHERE tenant_id = @a",
        ["antibiotics"] = "SELECT id::text FROM lab_antibiotic WHERE tenant_id = @a",
        ["eucast-breakpoints"] = "SELECT id FROM lab_eucast_breakpoint WHERE tenant_id = @a",
        ["departments"] = "SELECT id FROM tn_division WHERE tenant_id = @a",
        ["employees"] = "SELECT id FROM org_employee WHERE tenant_id = @a"
    };

    private static readonly Regex Parameter = new(@"\{(?<name>[^}:]+)[^}]*\}", RegexOptions.Compiled);

    private readonly LisApiFactory _f;
    public TenantIsolationTests(LisApiFactory f) => _f = f;

    private static string Key(RouteEndpoint e, string method) => $"{method} {e.RoutePattern.RawText!.TrimStart('/')}";

    private List<string> ApiEndpoints() => _f.Services.GetRequiredService<EndpointDataSource>().Endpoints.OfType<RouteEndpoint>()
        .SelectMany(e => (e.Metadata.GetMetadata<HttpMethodMetadata>()?.HttpMethods ?? Array.Empty<string>()).Select(m => Key(e, m)))
        .Distinct().OrderBy(k => k).ToList();

    [Fact]
    public void Every_endpoint_has_an_isolation_case()
    {
        var actual = ApiEndpoints();
        var uncovered = actual.Except(Endpoints).ToList();
        var stale = Endpoints.Except(actual).ToList();
        Assert.True(uncovered.Count == 0, "Немає кейсу ізоляції: " + string.Join("; ", uncovered));
        Assert.True(stale.Count == 0, "Кейс без ендпоінта: " + string.Join("; ", stale));
        Assert.Equal(Endpoints.Length, Endpoints.Distinct().Count());
    }

    [Fact]
    public async Task Context_reports_the_active_organization_of_the_selected_profile()
    {
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var meB = JsonNode.Parse(await (await adminB.GetAsync("/api/v1/lab/context/me")).Content.ReadAsStringAsync())!;
        Assert.Equal(tenantB.TenantId, meB["organization"]!["id"]!.GetValue<string>());
        Assert.StartsWith("Тестова організація", meB["organization"]!["name"]!.GetValue<string>());
        var meA = JsonNode.Parse(await (await _f.As(DemoDataSeeder.Admin).GetAsync("/api/v1/lab/context/me")).Content.ReadAsStringAsync())!;
        Assert.Equal(TenantA, meA["organization"]!["id"]!.GetValue<string>());
    }

    private async Task<NpgsqlConnection> OwnerAsync()
    {
        var connection = new NpgsqlConnection(_f.OwnerConnectionString);
        await connection.OpenAsync();
        return connection;
    }

    private async Task<string?> ScalarAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql + " ORDER BY 1 LIMIT 1", connection);
        command.Parameters.AddWithValue("a", Guid.Parse(TenantA));
        return (await command.ExecuteScalarAsync())?.ToString();
    }

    private async Task<List<string>> ColumnAsync(NpgsqlConnection connection, string sql)
    {
        await using var command = new NpgsqlCommand(sql, connection);
        command.Parameters.AddWithValue("a", Guid.Parse(TenantA));
        await using var reader = await command.ExecuteReaderAsync();
        var values = new List<string>();
        while (await reader.ReadAsync()) if (!reader.IsDBNull(0)) values.Add(reader.GetValue(0).ToString()!);
        return values;
    }

    private async Task<List<string>> ScopedTablesAsync(NpgsqlConnection connection) => await ColumnAsync(connection, """
        SELECT c.table_name FROM information_schema.columns c JOIN information_schema.tables t ON t.table_schema = c.table_schema AND t.table_name = c.table_name
        WHERE c.table_schema = 'public' AND c.column_name = 'tenant_id' AND t.table_type = 'BASE TABLE' ORDER BY 1
        """);

    private async Task<Dictionary<string, string>> FingerprintAsync(NpgsqlConnection connection, List<string> tables)
    {
        var result = new Dictionary<string, string>();
        foreach (var table in tables)
            result[table] = (await ScalarAsync(connection, $"SELECT count(*)::text || ':' || coalesce(md5(string_agg(md5(t::text), '' ORDER BY md5(t::text))), '') FROM {table} t WHERE t.tenant_id = @a"))!;
        return result;
    }

    private async Task<HashSet<string>> MarkersAsync(NpgsqlConnection connection, List<string> tables)
    {
        var markers = new HashSet<string> { TenantA };
        foreach (var table in tables)
        {
            var key = (await ColumnAsync(connection, $"SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = '{table}' AND column_name IN ('id', 'department_id', 'employee_id') ORDER BY CASE column_name WHEN 'id' THEN 0 ELSE 1 END LIMIT 1")).FirstOrDefault();
            if (key == null) continue;
            markers.UnionWith((await ColumnAsync(connection, $"SELECT {key}::text FROM {table} WHERE tenant_id = @a")).Where(v => Guid.TryParse(v, out _)));
        }
        markers.UnionWith((await ColumnAsync(connection, "SELECT caption FROM ord_patient WHERE tenant_id = @a AND caption IS NOT NULL")).Where(c => c.Trim().Length > 5).Select(c => c.Trim()));
        return markers;
    }

    private sealed record Call(string Endpoint, string Method, string UrlA, string UrlRandom, bool HasObject, HashSet<string> Sent);

    private static string RandomFor(string value) => int.TryParse(value, out _) ? "987654" : Guid.TryParse(value, out _) ? Guid.NewGuid().ToString() : "ZZ" + Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();

    private async Task<List<Call>> CallsAsync(NpgsqlConnection connection, List<string> missing)
    {
        var calls = new List<Call>();
        foreach (var endpoint in Endpoints)
        {
            var method = endpoint[..endpoint.IndexOf(' ')];
            var template = endpoint[(endpoint.IndexOf(' ') + 1)..];
            IEnumerable<string?> names = template.Contains("{name}") ? DictionaryService.Names : new string?[] { null };
            foreach (var dictionary in names)
            {
                var urlA = template;
                var urlRandom = template;
                var sent = new HashSet<string>();
                var hasObject = false;
                foreach (Match m in Parameter.Matches(template))
                {
                    var name = m.Groups["name"].Value;
                    string? value;
                    var objectParameter = true;
                    if (name == "name") { value = dictionary; objectParameter = false; }
                    else if (dictionary != null && name == "id") value = await ScalarAsync(connection, DictionarySources[dictionary!]);
                    else
                    {
                        var before = template[..m.Index].TrimEnd('/').Split('/');
                        var candidates = new[] { string.Join('/', before.TakeLast(3)) + "/" + m.Value, string.Join('/', before.TakeLast(2)) + "/" + m.Value, before.Last() + "/" + m.Value };
                        var source = candidates.Select(c => template.Contains(c) && ParameterSources.TryGetValue(c, out var sql) ? sql : null).FirstOrDefault(s => s != null);
                        if (source == null) { missing.Add($"{endpoint}: no source for {m.Value}"); value = null; }
                        else value = await ScalarAsync(connection, source);
                    }
                    if (value == null) { missing.Add($"{endpoint}: tenant A has no row for {m.Value} {dictionary}"); continue; }
                    var random = objectParameter ? RandomFor(value) : value;
                    urlA = urlA.Replace(m.Value, Uri.EscapeDataString(value));
                    urlRandom = urlRandom.Replace(m.Value, Uri.EscapeDataString(random));
                    if (objectParameter) { hasObject = true; sent.Add(value); }
                }
                calls.Add(new Call(endpoint + (dictionary == null ? "" : $" [{dictionary}]"), method, "/" + urlA, "/" + urlRandom, hasObject, sent));
            }
        }
        return calls.OrderBy(c => c.Endpoint.StartsWith("GET api/Account/logout") ? 2 : c.Endpoint.Contains("api/Account/") ? 1 : 0).ToList();
    }

    private static async Task<(HttpStatusCode Status, string Body)> SendAsync(HttpClient client, string method, string url)
    {
        using var request = new HttpRequestMessage(new HttpMethod(method), url);
        if (method is "POST" or "PUT" or "PATCH") request.Content = new StringContent("{}", Encoding.UTF8, "application/json");
        using var response = await client.SendAsync(request);
        return (response.StatusCode, await response.Content.ReadAsStringAsync());
    }

    private static bool IsNotFoundOrEmpty(HttpStatusCode status, string body)
    {
        if (status == HttpStatusCode.NotFound) return true;
        var json = string.IsNullOrWhiteSpace(body) ? null : JsonNode.Parse(body);
        if (status == HttpStatusCode.BadRequest) return json?["status"]?.GetValue<int>() == 404;
        return status == HttpStatusCode.OK && (json is JsonArray { Count: 0 } || (json is JsonObject page && page["items"] is JsonArray { Count: 0 }));
    }

    private async Task<HttpClient> ConnectorOfAsync(HttpClient admin)
    {
        var created = JsonNode.Parse(await (await admin.PostAsJsonAsync("/api/v1/lab/connectors", new { name = "Коннектор ізоляції", pollIntervalSec = 30, heartbeatIntervalSec = 30 })).Content.ReadAsStringAsync())!;
        var registered = JsonNode.Parse(await (await _f.CreateClient().PostAsJsonAsync("/api/v1/lab/connector/register", new { installKey = created["installKey"]!.GetValue<string>(), hostName = "ISO-B", osDescription = "Windows 11", version = "4.0.0" })).Content.ReadAsStringAsync())!;
        var connector = _f.CreateClient();
        connector.DefaultRequestHeaders.Add("X-MedLink-ApiKey", registered["apiKey"]!.GetValue<string>());
        return connector;
    }

    private async Task EnsureTenantAObjectsAsync()
    {
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<LisDbContext>();
        await db.RunAsTenantAsync(TenantA, async () =>
        {
            var orderTest = await db.OrderTests.Include(t => t.Order).FirstAsync(t => t.SampleId != null);
            var analyzer = await db.Analyzers.FirstAsync();
            var performer = await db.Performers.FirstAsync();
            var payer = await db.Payers.FirstAsync();
            if (!await db.Batches.AnyAsync()) db.Batches.Add(new LabWorklistBatch { BatchCode = "WL-ISO-001", AnalyzerId = analyzer.Id, Items = new() { orderTest.Id } });
            if (!await db.UnmatchedResults.AnyAsync()) db.UnmatchedResults.Add(new LabUnmatchedResult { AnalyzerId = analyzer.Id, Barcode = "99999999", AnalyzerCode = "K", Value = "4.1", Reason = "Штрихкод не знайдено" });
            if (!await db.AnalyzerMessages.AnyAsync()) db.AnalyzerMessages.Add(new LabAnalyzerMessage { AnalyzerId = analyzer.Id, RawText = "H|\\^&", ParsedOk = true });
            if (!await db.SendOuts.AnyAsync())
            {
                var sendOut = new LabSendOut { Number = "SO-ISO-001", PerformerId = performer.Id };
                sendOut.Items.Add(new LabSendOutItem { SendOutId = sendOut.Id, OrderTestId = orderTest.Id, SampleId = orderTest.SampleId });
                db.SendOuts.Add(sendOut);
            }
            if (!await db.Attachments.AnyAsync()) db.Attachments.Add(new LabOrderAttachment { OrderId = orderTest.OrderId, FileName = "iso.pdf", Content = Encoding.ASCII.GetBytes("%PDF-1.4"), SizeBytes = 8, Sha256 = new string('0', 64) });
            if (!await db.Invoices.AnyAsync()) db.Invoices.Add(new LabInvoice { Number = "INV-ISO-001", PayerId = payer.Id, OrderId = orderTest.OrderId, Amount = 1 });
            if (!await db.OrderFavorites.AnyAsync()) db.OrderFavorites.Add(new LabOrderFavorite { EmployeeId = DemoDataSeeder.Admin, Name = "Ізоляція" });
            if (!await db.StageEvents.AnyAsync()) db.StageEvents.Add(new LabSampleStageEvent { SampleId = orderTest.SampleId!, StageCode = "CENTRIFUGE" });
            await db.SaveChangesAsync();
        });
    }

    [Fact]
    public async Task Tenant_B_gets_404_or_nothing_for_tenant_A_objects_on_every_endpoint_and_cannot_change_them()
    {
        await EnsureTenantAObjectsAsync();
        var tenantB = await _f.CreateTenantAsync();
        var adminB = await _f.AsAsync(tenantB);
        var connectorB = await ConnectorOfAsync(adminB);
        var anonymous = _f.CreateClient();

        await using var connection = await OwnerAsync();
        var tables = await ScopedTablesAsync(connection);
        var markers = await MarkersAsync(connection, tables);
        var missing = new List<string>();
        var calls = await CallsAsync(connection, missing);
        Assert.True(missing.Count == 0, string.Join("\n", missing));
        var before = await FingerprintAsync(connection, tables);

        var failures = new List<string>();
        foreach (var call in calls)
        {
            var template = call.Endpoint.Split(' ')[1];
            var client = PublicTokenEndpoints.Contains(call.Endpoint) ? anonymous : template.StartsWith(Lab + "connector/") ? connectorB : adminB;
            var a = await SendAsync(client, call.Method, call.UrlA);
            var leaked = markers.Where(m => !call.Sent.Contains(m) && a.Body.Contains(m, StringComparison.Ordinal)).Take(3).ToList();
            if (leaked.Count > 0) failures.Add($"{call.Endpoint}: response contains tenant A data ({string.Join(", ", leaked)})");
            if ((int)a.Status >= 500) failures.Add($"{call.Endpoint}: {(int)a.Status} {a.Body[..Math.Min(300, a.Body.Length)]}");
            if (!call.HasObject || PublicTokenEndpoints.Contains(call.Endpoint)) continue;
            var random = await SendAsync(client, call.Method, call.UrlRandom);
            if (a.Status != random.Status) failures.Add($"{call.Endpoint}: {(int)a.Status} for an tenant A object, {(int)random.Status} for a missing one");
            else if (call.Method == "GET" && !IsNotFoundOrEmpty(a.Status, a.Body)) failures.Add($"{call.Endpoint}: {(int)a.Status} instead of 404 or an empty list");
        }

        var after = await FingerprintAsync(connection, tables);
        failures.AddRange(tables.Where(t => before[t] != after[t]).Select(t => $"tenant A rows of {t} changed"));
        Assert.True(failures.Count == 0, string.Join("\n", failures));
    }
}
