using System.Collections.Concurrent;
using System.Reflection;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.Json;
using Core.Services.DistributedCacheService;
using Core.ThirdParty.Redis;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using StackExchange.Redis;

namespace MedLink.LIS.Tests.Api;

public sealed class TestAuthHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    public const string SchemeName = "Test";
    public const string Header = "X-Test-User";

    public TestAuthHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder) : base(options, logger, encoder) { }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var sub = Request.Headers[Header].FirstOrDefault();
        if (string.IsNullOrWhiteSpace(sub)) return Task.FromResult(AuthenticateResult.NoResult());
        var identity = new ClaimsIdentity(new[] { new Claim("sub", sub), new Claim(ClaimTypes.NameIdentifier, sub) }, SchemeName, ClaimTypes.NameIdentifier, null);
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(identity), SchemeName)));
    }

    protected override Task HandleChallengeAsync(AuthenticationProperties properties)
    {
        Response.StatusCode = StatusCodes.Status401Unauthorized;
        return Task.CompletedTask;
    }
}

public sealed class InMemoryDistributedCacheService : IDistributedCacheService
{
    private readonly ConcurrentDictionary<string, string> _values = new();

    public T GetValue<T>(string key) => _values.TryGetValue(key, out var s) && !string.IsNullOrEmpty(s) ? JsonSerializer.Deserialize<T>(s)! : default!;
    public IEnumerable<T> GetValuesByPrefix<T>(string prefix) => _values.Where(kv => kv.Key.StartsWith(prefix)).Select(kv => JsonSerializer.Deserialize<T>(kv.Value)!).ToList();
    public Dictionary<int, List<T>> GetValuesByPrefixDict<T>(string prefix) => throw new NotSupportedException();
    public Task<T> GetValueAsync<T>(string key) => Task.FromResult(GetValue<T>(key));
    public void SetValue(string key, object value, TimeSpan? expiry = null) => _values[key] = JsonSerializer.Serialize(value);
    public Task SetValueAsync(string key, object value, TimeSpan? expiry = null) { SetValue(key, value, expiry); return Task.CompletedTask; }
    public bool ClearKey(string key) => _values.TryRemove(key, out _);
    public void ClearByPrefix(string prefix) { foreach (var k in _values.Keys.Where(k => k.StartsWith(prefix)).ToList()) _values.TryRemove(k, out _); }
    public Task<bool> ClearKeyAsync(string key) => Task.FromResult(ClearKey(key));
    public Task ClearByPattern(string keyPattern) { ClearByPrefix(keyPattern); return Task.CompletedTask; }
    public Task Reset(bool allSources = false) { _values.Clear(); return Task.CompletedTask; }
    public Task<byte[]?> GetBytesAsync(string key) => throw new NotSupportedException();
    public Task SetBytesAsync(string key, byte[] value, TimeSpan? expiry = null) => throw new NotSupportedException();
    public bool Contains(string key) => _values.ContainsKey(key);
}

public class FakeRedisDatabase : DispatchProxy
{
    public ConcurrentDictionary<string, string> Values { get; private set; } = new();

    public static (IDatabase db, FakeRedisDatabase state) Create()
    {
        var db = DispatchProxy.Create<IDatabase, FakeRedisDatabase>();
        return (db, (FakeRedisDatabase)(object)db);
    }

    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args)
    {
        if (targetMethod?.Name == nameof(IDatabase.StringGetAsync) && args is { Length: > 0 } && args[0] is RedisKey key)
            return Task.FromResult(Values.TryGetValue(key.ToString(), out var v) ? (RedisValue)v : RedisValue.Null);
        throw new NotSupportedException(targetMethod?.Name);
    }
}

public sealed class FakeRedisDatabaseProvider : IRedisDatabaseProvider
{
    public FakeRedisDatabaseProvider(IDatabase db) => Database = db;
    public ConnectionMultiplexer ConnectionMultiplexer => throw new NotSupportedException();
    public IDatabase Database { get; }
    public IServer Server => throw new NotSupportedException();
}
