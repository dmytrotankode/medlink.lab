using MedLink.LIS.Api.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.Configuration;
using Npgsql;

namespace MedLink.LIS.Tests.Api;

internal static class TestDatabase
{
    private const string OwnerUsername = "postgres";
    private const string OwnerPassword = "postgres";
    private const string TestUserId = "00000000-0000-4000-8000-00000000c001";
    private const string TestColumnDefaults =
        "ALTER TABLE tn_tenant ALTER COLUMN created_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN modified_by SET DEFAULT '" + TestUserId + "';" +
        "ALTER TABLE tn_settings ALTER COLUMN created_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN modified_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN time_zone SET DEFAULT 'Europe/Kyiv', ALTER COLUMN report_language SET DEFAULT 'uk';" +
        "ALTER TABLE tn_requisites ALTER COLUMN created_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN modified_by SET DEFAULT '" + TestUserId + "';" +
        "ALTER TABLE id_membership ALTER COLUMN created_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN modified_by SET DEFAULT '" + TestUserId + "';" +
        "ALTER TABLE id_membership_division ALTER COLUMN created_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN modified_by SET DEFAULT '" + TestUserId + "', ALTER COLUMN id SET DEFAULT '00000000-0000-4000-8000-00000000e001';";

    private static readonly string AppConnectionString = new ConfigurationBuilder()
        .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.Tests.json"))
        .Build()
        .GetConnectionString("DefaultConnection")!;

    public static string Create(string? targetMigration = null)
    {
        var connectionString = new NpgsqlConnectionStringBuilder(AppConnectionString)
        {
            Database = $"medlink_lab_test_{Guid.NewGuid():N}",
            Username = OwnerUsername,
            Password = OwnerPassword
        }.ConnectionString;
        using var db = Context(connectionString);
        db.GetService<IMigrator>().Migrate(targetMigration);
        if (targetMigration == null)
            db.Database.ExecuteSqlRaw(TestColumnDefaults);
        return connectionString;
    }

    public static string App(string ownerConnectionString)
    {
        var app = new NpgsqlConnectionStringBuilder(AppConnectionString);
        return new NpgsqlConnectionStringBuilder(ownerConnectionString) { Username = app.Username, Password = app.Password }.ConnectionString;
    }

    public static string As(string ownerConnectionString, string username, string password) =>
        new NpgsqlConnectionStringBuilder(ownerConnectionString) { Username = username, Password = password }.ConnectionString;

    public static LisDbContext Context(string connectionString) =>
        new(new DbContextOptionsBuilder<LisDbContext>().UseNpgsql(connectionString).Options);

    public static void Drop(string connectionString)
    {
        var target = new NpgsqlConnectionStringBuilder(connectionString).Database;
        using var connection = new NpgsqlConnection(new NpgsqlConnectionStringBuilder(connectionString) { Database = "postgres", Pooling = false }.ConnectionString);
        connection.Open();
        using var command = new NpgsqlCommand($"DROP DATABASE IF EXISTS \"{target}\" WITH (FORCE)", connection);
        command.ExecuteNonQuery();
    }
}
