using MedLink.LIS.Api.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace MedLink.LIS.Tests.Api;

internal static class TestTenantScope
{
    public static IDisposable Enter(LisDbContext db, string tenantId)
    {
        var tenant = db.Tenant.RunAs(tenantId);
        return new Scope(tenant, db.Database.BeginTransaction());
    }

    private sealed class Scope(IDisposable tenant, IDbContextTransaction transaction) : IDisposable
    {
        public void Dispose()
        {
            transaction.Commit();
            transaction.Dispose();
            tenant.Dispose();
        }
    }
}
