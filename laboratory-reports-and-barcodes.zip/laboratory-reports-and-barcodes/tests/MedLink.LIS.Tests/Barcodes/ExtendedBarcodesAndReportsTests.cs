using MedLink.LIS.Api.Services;
using MedLink.LIS.Core.Barcodes;

namespace MedLink.LIS.Tests.Barcodes;

public sealed class ExtendedBarcodesAndReportsTests
{
    [Fact]
    public void Ean13_CheckDigit_CalculatesCorrectly()
    {
        // 4006381333931 (Stabilo Boss highlighter)
        var check = Ean13Svg.CheckDigit("400638133393");
        Assert.Equal(1, check);

        Assert.True(Ean13Svg.IsValid("4006381333931"));
        Assert.False(Ean13Svg.IsValid("4006381333932"));
        Assert.False(Ean13Svg.IsValid("12345"));
    }

    [Fact]
    public void Ean13_Render_ProducesSvg()
    {
        var svg = Ean13Svg.Render("4006381333931", 50, 2, true);
        Assert.StartsWith("<svg", svg);
        Assert.Contains("4006381333931", svg);
        Assert.EndsWith("</svg>", svg);
    }

    [Fact]
    public void Code39_ChecksumAndValidity_Works()
    {
        Assert.True(Code39Svg.IsValid("CODE39"));
        Assert.True(Code39Svg.IsValid("*TEST-123*"));
        Assert.False(Code39Svg.IsValid("INVALID_CHAR@"));

        var sum = Code39Svg.Checksum("CODE39");
        Assert.True(Code39Svg.IsValid(sum.ToString()));
    }

    [Fact]
    public void Code39_Render_ProducesSvg()
    {
        var svg = Code39Svg.Render("SAMPLE123", 40, 1, true);
        Assert.StartsWith("<svg", svg);
        Assert.Contains("SAMPLE123", svg);
        Assert.EndsWith("</svg>", svg);
    }

    [Fact]
    public void TubeBarcodeGenerator_Code128_10Digits_Mod10()
    {
        var barcode = TubeBarcodeGenerator.GenerateCode128(12345);
        Assert.Equal(10, barcode.Length);
        Assert.All(barcode, c => Assert.True(char.IsDigit(c)));
        Assert.True(TubeBarcodeGenerator.IsValid(barcode));

        var nine = barcode.Substring(0, 9);
        var expectedCheck = TubeBarcodeGenerator.CheckDigitMod10(nine);
        Assert.Equal(expectedCheck, barcode[9] - '0');
    }

    [Fact]
    public void TubeBarcodeGenerator_Ean13_And_Code39()
    {
        var ean13 = TubeBarcodeGenerator.GenerateEan13(555, "20");
        Assert.Equal(13, ean13.Length);
        Assert.True(TubeBarcodeGenerator.IsValid(ean13));

        var code39 = TubeBarcodeGenerator.GenerateCode39(777, "T");
        Assert.StartsWith("T", code39);
        Assert.True(TubeBarcodeGenerator.IsValid(code39));
    }

    [Fact]
    public void TubeBarcodeGenerator_SimplexEan8_Preserved()
    {
        var ean8 = TubeBarcodeGenerator.Generate(4800);
        Assert.Equal(8, ean8.Length);
        Assert.True(TubeBarcodeGenerator.IsValid(ean8));
    }

    [Fact]
    public void LabelPdfService_GeneratesValidPdf()
    {
        var svc = new LabelPdfService();
        var label = new LabelDto
        {
            Barcode = "1000012345",
            PatientName = "Шевченко Тарас Григорович",
            Tube = "Сироватка з активатором",
            OrderNumber = "2611-000100",
            ReferralNumber = "REF-9988",
            CollectedAt = DateTime.UtcNow,
            TestCodes = new() { "CBC", "ALT", "AST" }
        };

        var pdf30x20 = svc.GenerateLabelsPdf(new[] { label }, "30x20");
        Assert.NotNull(pdf30x20);
        Assert.True(pdf30x20.Length > 0);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(pdf30x20.Take(4).ToArray()));

        var pdf50x25 = svc.GenerateLabelsPdf(new[] { label }, "50x25");
        Assert.NotNull(pdf50x25);
        Assert.True(pdf50x25.Length > 0);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(pdf50x25.Take(4).ToArray()));

        var pdfA4 = svc.GenerateLabelsPdf(new[] { label }, "a4");
        Assert.NotNull(pdfA4);
        Assert.True(pdfA4.Length > 0);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(pdfA4.Take(4).ToArray()));
    }
}

